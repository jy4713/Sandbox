# Shared Admin policy source of truth

This directory contains Admin-managed policy/configuration sources that are shared by more than one runtime component or are baked into the DevContainer as managed settings.

- `admin-upstream-endpoints.json` - Admin-managed fixed upstream URLs for direct Claude, direct Gemini, Tavily API/MCP, and Snyk API/Code. Edit before building; the file is validated during the image build and baked read-only into the runtime.
- `ado-policy.json` - shared Azure DevOps credential-route configuration. It supplies only the fixed ADO host/loopback/upstream mappings used for PAT injection; it does not allowlist Git subcommands, CLI options, REST paths, or HTTP methods.
- `tavily-allowed-domains.json` - shared Tavily domain allowlist. Both local Tavily validation and broker enforcement consume the same baked copy.
- `claude-mcp.json` - Admin-managed Claude MCP configuration.
- `gemini-managed-settings.json` - Admin-managed Gemini settings/MCP configuration.
- `gemini-web-policy.toml` - Admin Gemini native-web/shell policy.
- `admin-settings.json` - Docker Desktop/Admin host-policy example.

Shared runtime files are installed under `/etc/ai-sandbox/policies/` as `root:root` mode `0444`. `admin-upstream-endpoints.json` is the single Admin source for the fixed provider destinations; changing a hostname that is not already covered by `squid/whitelist.txt` also requires an Admin Squid allowlist update and image rebuild. Tavily is the only application policy enforced there; the ADO file is credential-route metadata only.

Component-owned policy files remain with the component when they are not shared across runtime trust boundaries. In particular, Squid's destination ACL is intentionally kept at `squid/whitelist.txt`, next to `squid/squid.conf` and `squid/Dockerfile`. It is the single source of truth for Squid egress destinations and is copied to `/etc/squid/whitelist.txt` when the Squid image is built.

Do not create duplicate ADO/Tavily policy copies under `.devcontainer/`, and do not create a second Squid allowlist under `policies/`; package lint rejects those drift-prone layouts.
