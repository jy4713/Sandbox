# AI Secure Sandbox v1.16.48

## Scope

Minimal Snyk transport compatibility update on top of v1.16.47. No folder layout,
logging/export architecture, Git execution model, Tavily allow-domain policy, or
credential-broker error passthrough behavior was changed. The previously used
`eu-north-1` SSM/STS Squid service entries are restored without changing Squid's
default-deny policy structure.

## Changes

- Restores the project's previously used Squid AWS endpoints for `eu-north-1`: `ssm.eu-north-1.amazonaws.com` and `sts.eu-north-1.amazonaws.com`.
- Keeps the real Snyk CLI and Snyk MCP process in the DevContainer as `vscode`.
- Keeps caller Snyk argv unchanged.
- Preserves Snyk's native backend split by routing the general Snyk API through
  `/snyk` and Snyk Code `DEEPROXY_API_URL` traffic through `/snyk-code/`.
- Both routes retrieve the same `snyk-token` from SSM and inject it only in the
  credential broker. The real token is not placed in the DevContainer environment.
- Retains the v1.16.47 sanitized dependency-error passthrough logging.
- Preserves provider `Location` redirects (ADO credential-route redirects are still
  rewritten as required) and forwards `OPTIONS` so the broker does not introduce
  an unrelated application-command/method restriction.
- Regression tests assert native Snyk parameters/target URL are not changed and
  that the API/Code backend routes remain distinct.
- Claude/Gemini shell policy no longer blocks the normal wrapped `tvly` or
  `tavily-mcp` commands; only direct stashed-vendor-binary bypass remains denied
  so the Tavily domain allowlist cannot be bypassed.

## Native command contract

Claude, Gemini, ucode, Git, Snyk, Databricks and non-domain Tavily command argv
continue to be passed to their local vendor executables without Sandbox command
allowlists. Tavily allowed-domain enforcement remains the sole application-policy
exception. Local loopback base URLs remain an authentication transport mechanism:
they are required to keep real service credentials out of AI-visible process state.
