# AI Secure Sandbox v1.16.50 - Release Notes

## Summary

v1.16.50 corrects only the Snyk credential-transport implementation introduced in v1.16.48/v1.16.49. The v1.16.49 transparent TLS/custom-CA Snyk proxy is removed. The real Snyk CLI/MCP process stays in the DevContainer as `vscode`; the real token stays in SSM/Broker.

## Verified Snyk traffic split

The pinned Snyk CLI is `1.1306.2`, which depends on `github.com/snyk/code-client-go v1.27.0`. That Code client implements `SnykCodeApi()` by replacing `api` with `deeproxy` in its configured general API URL. Therefore the Sandbox uses:

- `SNYK_API=http://api.snyk.local:8771/snyk`
- `DEEPROXY_API_URL=http://deeproxy.snyk.local:8771/snyk`

The second value also supports Snyk components that consume `DEEPROXY_API_URL` explicitly. For CLI Code scanning, the local general hostname was deliberately chosen so the native `api` -> `deeproxy` transformation produces exactly the second local hostname.

## Broker behavior

- Host `api.snyk.local` + `/snyk/<original path>` -> `https://api.snyk.io/<original path>`
- Host `deeproxy.snyk.local` + `/snyk/<original path>` -> `https://deeproxy.snyk.io/<original path>`
- Original HTTP method, path, encoded query, and body are preserved.
- The broker does not classify `/filters`, `/bundle`, or any other Snyk product path.
- The broker strips caller authentication and injects `Authorization: token <SSM snyk-token>`.
- Any other Host using `/snyk` is rejected.

## Rolled back from v1.16.49

- Snyk port `8772` removed.
- Snyk TLS interception/MITM removed.
- Ephemeral Snyk CA and CA private key generation removed.
- `python3-cryptography` dependency added only for that proxy removed.
- No Snyk CA is installed or fetched by the DevContainer.

## Existing behavior retained

- v1.16.47 sanitized dependency/Broker error passthrough remains unchanged.
- Snyk uses a per-invocation writable ephemeral HOME/cache in the DevContainer.
- Broker has no workspace mount and does not execute Snyk or other applications.
- Claude/Gemini/ucode/Git/Databricks native command arguments remain unchanged.
- Tavily Admin allowed-domain enforcement remains unchanged.
- Squid default-deny and the existing `eu-north-1` SSM/STS entries are retained.


Snyk localhost credential routes explicitly set `SNYK_HTTP_PROTOCOL_UPGRADE=0`; Snyk otherwise upgrades an `http` `SNYK_API` to HTTPS, which is not appropriate for the loopback reverse-proxy hop.
