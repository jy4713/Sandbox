# AI Secure Sandbox v1.16.53 Release Notes

v1.16.53 is a targeted Snyk routing correction on top of v1.16.52. No other application flow or security boundary is intentionally changed.

## Fix

- Changed the local Snyk general API base from `http://api.snyk.local:8771/snyk` to `http://api.snyk.local:8771`.
- Changed the local Snyk Code base from `http://deeproxy.snyk.local:8771/snyk` to `http://deeproxy.snyk.local:8771`.
- Changed the broker Snyk route from path-prefix matching to strict local-hostname matching. Native `/rest`, `/v1`, `/filters`, `/bundle`, and future Snyk paths are now preserved unchanged.
- The broker continues to allow only `api.snyk.local` -> Admin `snyk_api` and `deeproxy.snyk.local` -> Admin `snyk_code`; arbitrary upstream selection remains impossible.
- The broker no longer forwards the local Snyk alias `Host` header upstream; the HTTP client generates the correct vendor Host from the fixed Admin target URL.
- Added regressions for the exact host-root `/rest/...` and `/filters` routes that previously returned broker `404 route not available`.

## Unchanged

- SSM Snyk token remains broker-only and is never exposed to the DevContainer process.
- Snyk CLI/MCP still execute locally against the Developer workspace.
- `api.snyk.local` and `deeproxy.snyk.local` remain loopback-only aliases through the provider relay.
- Admin upstream endpoints remain in `policies/admin-upstream-endpoints.json`.
- Squid remains default-deny.
- Claude, Gemini, Tavily, Databricks, ADO/Git, ucode, MCP, logging, TAR/ECR, and hardening flows are unchanged from v1.16.52.
