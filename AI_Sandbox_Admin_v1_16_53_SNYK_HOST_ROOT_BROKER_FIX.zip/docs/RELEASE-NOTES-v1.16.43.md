# AI Secure Sandbox v1.16.43 - Release Notes

## Summary

v1.16.43 keeps the v1.16.42 credential-only broker/local-execution boundary and removes policy-source drift between the DevContainer and credential broker.

## Changes

- Centralized all Admin-maintained policy/configuration source files under the top-level `policies/` directory.
- Added `policies/ado-policy.json` as the single Azure DevOps credential-use policy.
  - The DevContainer local ADO Git validator reads the shared policy for approved Git operations, repository host/path shape, loopback broker route and HTTPS rewrite origin.
  - The credential broker reads the same policy for ADO upstream routes, HTTP methods, path patterns and required query values before injecting `/sandbox/ado-pat`.
- Kept `policies/tavily-allowed-domains.json` as the single Tavily domain source and moved its runtime copy to `/etc/ai-sandbox/policies/tavily-allowed-domains.json`.
- Moved Claude MCP, Gemini managed settings and Gemini web policy sources from `.devcontainer/policies/` into the central `policies/` directory.
- Shared runtime security policies are baked as `root:root` mode `0444` under `/etc/ai-sandbox/policies/`.
- Removed the legacy `.devcontainer/policies/` source directory.
- Added lint/runtime checks that fail if ADO/Tavily shared policies are missing, writable, duplicated in the legacy location, or no longer consumed by both required enforcement layers.
- Added offline ADO regression coverage proving broker request authorization is policy-driven and the local Git policy reads the same policy source.

## Unchanged security boundary

- Git, Snyk, Tavily, Claude, Gemini, ucode, Databricks CLI and managed MCP processes execute in the DevContainer as `vscode` uid/gid 1000.
- The credential broker does not mount the workspace and does not execute application commands.
- Only the broker receives the host AWS profile and performs AWS SSM `GetParameter` calls.
- Raw service credentials are not exposed to the DevContainer/AI processes.

- Squid egress destinations are now Admin-managed from `policies/squid-egress-allowlist.txt`; the Squid image consumes that central source during build.
