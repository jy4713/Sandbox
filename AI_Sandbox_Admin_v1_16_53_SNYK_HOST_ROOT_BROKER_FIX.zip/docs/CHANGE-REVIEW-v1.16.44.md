# v1.16.44 Change Review - Restore Squid-Owned Whitelist

## Decision

Keep shared cross-component policy sources in `policies/`, but keep Squid's component-specific destination allowlist in the Squid component directory.

## Final source layout

```text
policies/
  ado-policy.json
  tavily-allowed-domains.json
  claude-mcp.json
  gemini-managed-settings.json
  gemini-web-policy.toml
  admin-settings.json

squid/
  Dockerfile
  squid.conf
  whitelist.txt
```

## Why

`ado-policy.json` and `tavily-allowed-domains.json` are intentionally shared because DevContainer-side validation and broker-side enforcement must use the same immutable policy. `squid/whitelist.txt` is not consumed by the DevContainer or credential broker; it is a Squid ACL input only. Keeping it in `squid/` makes the component boundary clear and avoids a second source of truth.

## Build flow

```text
squid/whitelist.txt
       |
       | docker build
       v
/etc/squid/whitelist.txt
       |
       v
squid.conf: acl whitelist dstdomain "/etc/squid/whitelist.txt"
```

## Regression protection

Package lint now requires `squid/whitelist.txt`, verifies the Squid Dockerfile copies it, and fails if `policies/squid-egress-allowlist.txt` is recreated. The Squid policy regression test reads `squid/whitelist.txt` directly.

## Unchanged security controls

- Credential broker remains credential-only and has no workspace mount.
- Git/Snyk/Claude/Gemini/ucode/Tavily/Databricks/MCP processes remain local to the DevContainer as `vscode`.
- ADO and Tavily continue to use shared Admin policies for local validation plus broker-side final enforcement.
- Squid remains default-deny and continues to enforce private-IP, direct-IP, DoH, and destination-port controls before the hostname allowlist.
