# Release Notes - v1.16.38

## Scope

v1.16.38 is a focused MCP consistency fix on top of v1.16.37. It preserves the
credential-isolated secret-broker, static/SAML host authentication, transparent
Git, UTF-8 host log export, separated content logs, Tavily policy, Snyk routing,
and Databricks provider routes.

## Fixed: Gemini could omit `databricks-sql`

v1.16.37 wrote Gemini MCP registrations into the persistent user
`~/.gemini/settings.json` during `postCreate`. If that Docker named volume came
from an older image, if `postCreate` was not re-run after an image refresh, or if
a different Gemini state home was selected, Gemini could keep an older MCP set
containing only Tavily/Snyk.

v1.16.38 adds a root-owned Gemini system settings file at:

```text
/etc/gemini-cli/settings.json
```

It contains the same three credential-free broker bridges as Claude:

```text
tavily         -> /usr/local/bin/tavily-mcp-ssm
snyk           -> /usr/local/bin/snyk-mcp-ssm
databricks-sql -> /usr/local/bin/databricks-sql-mcp-ssm
```

Gemini CLI 0.53.0 loads Linux system settings from this path and gives system
settings higher precedence than user/workspace server definitions. The file is
root-owned and read-only in the read-only container image. No PAT, API key, AWS
credential, or SSM value/reference is stored in it.

`configure-mcp` remains for compatibility with Gemini user tooling and
application-helper additions. It now validates the system policy and
self-heals the persistent user MCP copy before every public Gemini launch.
Older `mcp.allowed`/`mcp.excluded` lists are adjusted only for the three
Admin-managed names so they cannot accidentally hide a built-in bridge; all
unrelated entries are preserved.

## Fixed: `ucode gemini mcp list`

`ucode gemini mcp list` previously followed the normal Databricks model route,
which could add a model argument or require Databricks routing for a command
that is purely local CLI/MCP inspection.

v1.16.38 treats MCP/help/version operations after the `ucode claude|gemini`
prefix as local agent-control commands. They are executed by the corresponding
real agent without Databricks model injection:

```bash
claude mcp list
gemini mcp list
ucode claude mcp list
ucode gemini mcp list
```

Interactive sessions remain unchanged:

```bash
ucode claude   # Databricks AI Gateway Claude route
ucode gemini   # Databricks AI Gateway Gemini route
```

Inside either interactive agent, the normal `/mcp` UI sees the same managed MCP
set because Gemini's built-ins are now system-managed and Claude continues to
use its root-owned managed MCP configuration.

## Pinned Gemini update behavior

Gemini CLI remains pinned at the previously validated `0.53.0` baseline. The
root-owned Gemini system settings disable automatic package updates and update
notifications so a developer session cannot silently drift from the Admin-built
and scanned version. No vendor version was changed by this fix.

## Verification added

A new offline MCP mode-matrix regression verifies that Claude and Gemini contain
exactly the three built-in bridge names/commands, that Gemini self-healing is
wired into direct and ucode routes, and that `ucode ... mcp ...` is handled
before Databricks model validation. `verify-runtime` additionally verifies the
root-owned Gemini system settings and the user compatibility copy.

## Recommended smoke test

After rebuilding/reloading the v1.16.38 DevContainer image:

```bash
verify-runtime

claude mcp list
gemini mcp list
ucode claude mcp list
ucode gemini mcp list
```

All four paths should expose:

```text
tavily
snyk
databricks-sql
```

Then start the two Databricks-routed interactive sessions and use their MCP UI:

```bash
ucode claude
# /mcp

ucode gemini
# /mcp list
```

The Databricks SQL MCP may show a connection/authentication error if
`/sandbox/databricks-sql-mcp-token`, `DATABRICKS_HOST`, network allowlisting, or
the Databricks endpoint is not ready, but it must still be present as a
configured managed MCP server.
