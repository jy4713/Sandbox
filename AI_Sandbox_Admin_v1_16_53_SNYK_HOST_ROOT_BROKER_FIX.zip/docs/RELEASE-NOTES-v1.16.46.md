# AI Secure Sandbox v1.16.46 - Release Notes

## Summary

v1.16.46 is a narrow fix on top of v1.16.45 for CLI state paths under the read-only DevContainer root filesystem and for the Tavily native-command contract. It does not change the broker architecture, Squid layout, logging, deployment structure, or non-Tavily command routing.

## Changes

- Added a narrow persistent writable mount for Tavily's native `~/.tavily` state so `~/.tavily/config.json` can be created/read by `vscode`.
- Kept Tavily search/extract/crawl/map domain enforcement, and kept only the invocation shapes that cannot be domain-constrained (`research` and the no-command interactive REPL) denied for allowed-domain-policy reasons.
- Removed separate Tavily subcommand allowlisting: native non-domain commands such as `auth`, `login`, `logout`, help/version, and future non-domain vendor commands pass their argv through unchanged.
- Added a narrow persistent `~/.ucode` mount because ucode stores native state such as `state.json` and debug/backup metadata there; existing Claude/Gemini managed paths remain on their existing mounts.
- Redirected Databricks CLI config to `/home/vscode/.local/share/databricks/.databrickscfg`, using the already-existing writable `ai-local` volume rather than making the home directory broadly writable.
- Redirected managed `mcp-remote` runtime/auth state away from the read-only home root into the existing `/tmp` tmpfs via `MCP_REMOTE_CONFIG_DIR`.
- Added runtime and CI regressions for the writable paths and Tavily argv contract.

## Explicitly unchanged

- `secret-broker` remains credential-only and has no workspace mount.
- Git, Snyk, Claude, Gemini, ucode, Databricks CLI and MCP processes still execute locally in the DevContainer as `vscode`.
- `umask 0027` is unchanged.
- `squid/whitelist.txt`, logging scripts, Admin deployment flow, and package folder layout are unchanged.
- The DevContainer still has no AWS credential/profile mount.
