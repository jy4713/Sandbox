# AI Secure Sandbox v1.16.52 Release Notes

v1.16.52 is a maintenance/optimization release on top of v1.16.51. It keeps the runtime security model, credential broker routes, Snyk dual-endpoint behavior, MCP behavior, TAR/ECR workflows, logging model, and Developer command contracts unchanged.

## Changes

- Removed the standalone `scripts/ci/test-tavily-policy.py` test script after merging its local Tavily MCP policy-proxy regression coverage into `scripts/ci/test-broker-policies.py`. This removes a dead/uninvoked CI script without losing the assertions it contained.
- Kept the retired `run-with-ssm-secrets`, `secret-broker-client`, `git-askpass-ado`, and `ado-git` compatibility guards/aliases because they are intentional fail-closed compatibility controls, not unused runtime paths.
- Kept PowerShell and Bash pairs where they support Windows and Linux administration/developer workflows. TAR, ECR, hardening, SSM, logging, CIS, application-maintenance, and ADO helper scripts remain because they provide distinct supported functions.
- Improved hardened-base reuse resilience: if the disposable localhost scratch registry exists but Docker Desktop/ECI cannot restart it because of stale runtime metadata, the Admin build recreates only that container once and retains the registry data volume before continuing. The fail-closed provenance/config-ID checks remain unchanged.
- Aligned active package defaults to the project AWS region `eu-north-1`, matching the existing Squid SSM/STS service endpoints.

## Unchanged security boundaries

- The DevContainer still has no host AWS credential mount.
- The secret broker still owns the only SSM `GetParameter` subprocess path and cannot execute Developer/application commands.
- Claude, Gemini, Tavily, Snyk, Databricks, ADO/Git, ucode, and MCP execution/routing remain unchanged from v1.16.51.
- Admin provider upstreams remain in `policies/admin-upstream-endpoints.json`.
- Squid remains default-deny and requires approved destination coverage.
