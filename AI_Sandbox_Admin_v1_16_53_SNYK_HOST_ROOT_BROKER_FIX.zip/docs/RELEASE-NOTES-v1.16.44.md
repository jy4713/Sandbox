# AI Secure Sandbox v1.16.44 - Release Notes

## Summary

v1.16.44 corrects the Squid policy-source layout introduced in v1.16.43 without changing the credential-only broker or local-command execution model.

## Changes

- Restored `squid/whitelist.txt` as the authoritative Squid destination allowlist.
- `squid/Dockerfile` now copies `squid/whitelist.txt` directly to `/etc/squid/whitelist.txt`.
- Removed the duplicate/centralized `policies/squid-egress-allowlist.txt` source.
- Kept `policies/` for shared cross-component policies such as ADO and Tavily, plus managed Claude/Gemini policy/settings files.
- Updated Admin application helpers, Bash/PowerShell package lint, Squid policy tests, environment templates, and operational documentation to use `squid/whitelist.txt`.
- Added regression checks that fail if a second Squid allowlist is recreated under `policies/`.

## Security rationale

ADO and Tavily need a shared policy source because both DevContainer validation and broker-side final enforcement consume the same policy. Squid's destination ACL is consumed only by the Squid component, so keeping it next to `squid.conf` and `squid/Dockerfile` avoids unnecessary duplication and makes ownership explicit.

The v1.16.42/v1.16.43 security boundary remains unchanged: developer-facing commands run in the DevContainer as `vscode`; the broker has no workspace mount and only retrieves approved SSM secrets and injects them into authorized HTTP requests.
