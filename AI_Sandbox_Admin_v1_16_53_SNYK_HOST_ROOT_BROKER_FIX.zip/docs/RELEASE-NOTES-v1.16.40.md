# AI Secure Sandbox v1.16.40 Release Notes

## Scope

v1.16.40 is a Git compatibility/governance update on top of v1.16.39. It preserves the v1.16.39 native Claude/Gemini/ucode argument contract, managed MCP matrix, secret-broker/SSM boundary, protected logging, Tavily policy, Snyk integration, Databricks routes, and container hardening.

## Changed: native Git push semantics

The transparent `git` wrapper continues to route credentialed Azure DevOps operations through the secret broker so the ADO PAT never enters the AI DevContainer. The Sandbox no longer acts as a branch/history governance layer for standard Git pushes.

The following now use normal Git/Azure DevOps semantics through the broker:

- direct pushes to `main` or `master`
- `--force` / `-f`
- `--force-with-lease`
- `--force-if-includes`
- force refspecs such as `+source:destination`
- ref deletion (`--delete` or deletion refspecs)
- `--all`, `--mirror`, and `--prune`
- implicit `git push` from the current branch

Azure DevOps repository permissions and branch policies are the authoritative control for whether these operations are accepted remotely.

## Security boundary retained

This release does **not** relax credential isolation. PAT-backed ADO operations still reject:

- caller-controlled `-c` / `--config-env` Git configuration overrides
- `--upload-pack`, `--receive-pack`, custom exec paths, work-tree/git-dir/namespace overrides
- credential helper, URL rewrite, hooks/filter/custom transport settings in repository-local Git config
- `file://`, `ssh://`, `git://`, `ext::` and other non-approved transports
- repositories outside the Admin-approved Azure DevOps org/project/repository

The ADO PAT remains broker-only and is supplied to the pinned `/usr/bin/git` process through broker-side `GIT_ASKPASS`.

## Not changed

- `ado-pr-create` and `ado-trigger` remain available for backward compatibility but are not required for normal Git workflows.
- The separate Snyk whole-workspace discovery issue remains isolated from this Git change.
- MCP registration/ucode native CLI compatibility remains as implemented in v1.16.39.
