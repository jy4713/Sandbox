# Release Notes - v1.16.37

## Logging fixes

- Windows Docker log export now uses `System.Diagnostics.Process` and explicitly sets both stdout and stderr decoding to UTF-8 before PowerShell strings are created. This prevents mojibake such as `├ƒ`, `Γ`, or `┬º` caused by an inherited Windows code page.
- Host files continue to be written as UTF-8 without BOM. Existing already-corrupted files are not rewritten; new exported records use the corrected path.
- Content-bearing records are restored to a dedicated `devcontainer\content` directory, consistent with the earlier v1.16.16 operational layout.
- Content records are not duplicated into `devcontainer\all-*.log`, preserving separation for content-specific RBAC, retention and Sentinel collection.
- POC/Protected setup, TAR/ECR launchers, host-log verification and Linux exporter paths now create/validate the content subdirectory.

## Git and authentication

- Retains v1.16.36 transparent ordinary Git commands with broker-protected Azure DevOps PAT usage.
- Retains host static-key fallback and Azure/Entra SAML authentication modes.
