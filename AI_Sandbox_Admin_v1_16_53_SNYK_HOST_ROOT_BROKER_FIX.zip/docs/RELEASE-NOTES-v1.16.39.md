# AI Secure Sandbox v1.16.39 Release Notes

## Scope

v1.16.39 is a compatibility/hardening update on top of v1.16.38. It preserves the existing secret-broker/SSM boundary, transparent ADO Git, protected logging, Tavily policy, Snyk integration, Databricks routes, and container hardening.

## Fixed: native ucode agent argument contract

Upstream ucode passes arguments after the selected agent through to that agent. Earlier sandbox wrappers also injected a `--model` argument. That was not transparent for Gemini CLI because Gemini defines `--model` on its default chat command rather than on management subcommands such as `mcp list`. This could turn:

```text
ucode gemini mcp list
```

into a Gemini invocation containing an unsupported `--model` option and produce `Unknown argument: model`.

v1.16.39 no longer adds, removes, reorders, or rewrites Claude/Gemini CLI arguments. The Databricks-routed default model is supplied through the provider-supported environment defaults (`ANTHROPIC_MODEL` and `GEMINI_MODEL`) and the original argument vector is passed unchanged to the real agent CLI.

Expected syntax parity:

```text
claude <native args>        == ucode claude <native args>   (same Claude argument grammar)
gemini <native args>        == ucode gemini <native args>   (same Gemini argument grammar)
```

The ucode form still changes the provider route to the credential-isolated Databricks AI Gateway; it does not expose the Databricks PAT to the agent process.

## Fixed/retained: Gemini MCP matrix

Direct Gemini and ucode Gemini both synchronize the same Admin-managed MCP set before launch. The root-owned Gemini system settings and the persistent user compatibility settings contain the credential-free broker bridges:

- `tavily`
- `snyk`
- `databricks-sql`

`ucode gemini mcp list` and `ucode claude mcp list` are treated as local agent-management operations and do not require a model call. Direct and ucode Gemini both pin `/etc/gemini-cli/settings.json` as the system settings layer.

## Regression protection

CI/runtime checks now fail if the wrapper reintroduces `set -- --model`/`has_model_arg` argument mutation, or if either Databricks-routed agent stops using the documented environment default model while forwarding `$@` unchanged.

## Not changed in this release

The separate Snyk whole-workspace discovery issue remains isolated from this MCP/ucode compatibility change. Single-file Snyk Code scans and the SSM/broker credential path are unchanged.
