# Security Logging and Sentinel - v1.16.44

## Objective

The Windows 365 host must retain log files so the approved Windows monitoring agent can collect them for Microsoft Sentinel, while the Developer must not be able to manually modify, truncate, replace or delete those files from either Windows or the Linux containers.

v1.16.44 uses a two-stage logging boundary instead of allowing runtime containers to write directly into a Windows bind mount.

```text
DevContainer / Squid
        |
        | stdout/stderr only
        v
Docker local logging driver
        |
        | read by LOCALSYSTEM scheduled task
        v
C:\ProgramData\AI-Sandbox\Logs
        |
        +-- devcontainer\*.log
        +-- devcontainer\content\*.log
        `-- squid\*.log
        |
        +-- Windows Developer: read-only
        +-- LOCALSYSTEM: writer
        +-- Sentinel/AMA running as SYSTEM: read
        |
        `-- mounted back into containers as read-only
```

The Windows host log directory is therefore present for Sentinel collection, but it is not the write target of an untrusted container process.

## Interactive logging performance and serialization

The DevContainer still serializes managed records before writing them to PID1 stdout, but the serialization lock is **record-scoped**. A producer such as Gemini telemetry may keep `sandbox-log-emit` open for the duration of the AI session; it does not keep the lock for that duration. The emitter acquires the lock only immediately before one record is written and releases it immediately afterwards.

This prevents a long-lived telemetry producer from stalling Bash `PROMPT_COMMAND` logging and making unrelated commands such as `ls`, `pwd`, `cd`, or `rm` appear frozen. Interactive shell audit/security records have a 200 ms maximum serialization wait; required application audit keeps the one-second fail-closed window. Post-command interactive shell metadata is best-effort because the user command has already executed and blocking the next prompt would not undo that command.

The Bash audit logger also installs its prompt hook only once per shell. The guard is intentionally not exported, so child Bash processes still load their own audit functions through `BASH_ENV`. The normal prompt path uses Bash built-ins for history-number removal, command metadata, UTC timestamp generation and current-directory capture; it invokes only the shared `sandbox-log-emit` process for delivery. The emitter itself validates source labels with Bash regex and releases the per-record lock by closing its FD, avoiding a separate unlock process.

Shell-command attribution remains metadata-only. Generic commands and AI CLIs do not record arbitrary second arguments because those tokens may contain prompts, URLs, identifiers, or secrets. Only bounded command-group/subcommand tokens for `git`, `snyk`, `databricks`, and `tvly` are retained. Direct curl/wget handling records only the destination hostname in the separate `EGRESS_ATTEMPT` event.

## Runtime log sources

Runtime records first enter Docker-owned stdout/stderr streams:

- shell/security audit metadata -> `sandbox-log-emit` -> DevContainer PID1 stdout;
- application/MCP events for Anthropic, Gemini, Databricks, Tavily, Snyk, ADO, HiddenLayer, Git and MCP -> DevContainer PID1 stdout;
- Claude managed-hook metadata and approved content records -> DevContainer PID1 stdout;
- Gemini telemetry/content -> DevContainer PID1 stdout;
- Squid access records -> Squid stdout;
- Squid cache/runtime records -> Squid stderr.

Both containers use Docker's `local` logging driver with rotation. The Developer cannot edit a previously emitted record through the container filesystem because the original sink is a stream rather than a seekable file.

## Protected Windows file export

Run the following once from an elevated PowerShell 7.4+ session on each Windows 365 host:

```powershell
pwsh -NoProfile -File .\scripts\platform\03-setup-logging.ps1
```

The script creates:

```text
C:\ProgramData\AI-Sandbox\Logs\devcontainer
C:\ProgramData\AI-Sandbox\Logs\devcontainer\content
C:\ProgramData\AI-Sandbox\Logs\squid
C:\ProgramData\AI-Sandbox\Monitoring
```

and installs the scheduled task:

```text
AI-Sandbox-Protected-Log-Export
```

The task runs as `LOCALSYSTEM` and executes `scripts\monitoring\export-docker-logs-to-host.ps1` every minute by default.

The Windows exporter starts `docker.exe` through `System.Diagnostics.Process` with `StandardOutputEncoding` and `StandardErrorEncoding` explicitly set to UTF-8. This prevents the Windows console/native-command code page from corrupting Unicode characters before they are persisted. Host files are written as UTF-8 without BOM.

The protected log ACL is intentionally narrow:

| Principal | Normal rights on protected log tree |
|---|---|
| LOCALSYSTEM | Full control / writer |
| Local Administrators | Read and execute only through the normal ACL |
| Configured Developer/read principal | Read and execute only |
| DevContainer | Read-only bind mount |
| Squid container | Read-only bind mount |

The exporter fails closed if the protected host log directory owner changes away from `LOCALSYSTEM` or if a non-SYSTEM allow rule gains write/append/delete/ACL-change rights.

The default runtime configuration is:

```env
SANDBOX_LOG_MODE=auto
SANDBOX_LOG_ROOT=C:/ProgramData/AI-Sandbox/Logs
```

`auto` is resolved only after the launcher validates the trusted TAR/ECR manifest. `SandboxType=POC` resolves to `poc-local`; `SandboxType=Production` resolves to `protected`. A Production manifest rejects an explicit `poc-local` override so Developer-controlled `.env` cannot downgrade the logging boundary.

### Non-admin POC mode

For POC, no local Administrator is required. If the common template still contains the protected ProgramData path, the Windows launcher automatically resolves the POC path to `%USERPROFILE%\AI-Sandbox\Logs`. A custom writable path such as `C:/Temp/AI-Sandbox-Logs` may also be configured.

The TAR/ECR Windows launcher creates the root plus `devcontainer`, `devcontainer\content`, `squid`, and `.monitoring` subdirectories, validates one synchronous export, and starts a current-user background exporter every 30 seconds. No elevation, SYSTEM ACL, or SYSTEM scheduled task is required. The Linux containers still receive the log folders as read-only mounts, but the Windows user can modify/delete the POC host copies. Therefore POC-local files are functional evidence only and are not tamper-resistant Production audit evidence.

When Endpoint/Sandbox Admin provisioning becomes available, run `03-setup-logging.ps1` in Protected mode, use the protected ProgramData path, and set `SANDBOX_LOG_MODE=protected` (or leave it `auto` for a Production manifest). The writer then changes from the Developer session to LOCALSYSTEM while the container mounts remain read-only.

Recommended promotion sequence on the managed Windows 365 host:

```powershell
# Elevated PowerShell
pwsh -NoProfile -File .\scripts\platform\03-setup-logging.ps1 -Mode Protected
```

Then set `SANDBOX_LOG_ROOT=C:/ProgramData/AI-Sandbox/Logs`. Existing POC-local files should be treated as non-authoritative test evidence; archive them separately if required. Do not attempt to make a Developer-owned `%USERPROFILE%` folder the Production audit boundary merely by changing its child ACL, because the Developer controls the parent profile path.

TAR and ECR Compose definitions mount the two service folders back into the containers as `read_only: true`:

```text
C:\ProgramData\AI-Sandbox\Logs\devcontainer -> /var/log/sandbox  RO
C:\ProgramData\AI-Sandbox\Logs\squid        -> /var/log/squid    RO
```

These mounts are for inspection/compatibility only. Containers do not write their audit/access/content records through those mounts.

## Host file layout

The selected host exporter creates daily files such as:

```text
C:\ProgramData\AI-Sandbox\Logs\devcontainer\
  all-YYYY-MM-DD.log
  audit-YYYY-MM-DD.log
  security-YYYY-MM-DD.log
  application-YYYY-MM-DD.log
  claude-events-YYYY-MM-DD.log
  gemini-telemetry-YYYY-MM-DD.log
  verification-YYYY-MM-DD.log
  runtime-YYYY-MM-DD.log
  content\
    content-YYYY-MM-DD.log

C:\ProgramData\AI-Sandbox\Logs\squid\
  all-YYYY-MM-DD.log
  access-YYYY-MM-DD.log
  runtime-YYYY-MM-DD.log
```

`devcontainer\content\content-*.log` is populated only when content logging is explicitly approved and enabled. `SANDBOX_CONTENT_LOGGING=false` remains the default. Content-bearing records are intentionally **not duplicated into `devcontainer\all-*.log`**; this preserves a real separation boundary for content-specific RBAC, retention and Sentinel collection.

## Tamper-resistance matrix

| Record class | Linux Developer/constrained root | Normal Windows Developer | Local Windows Administrator |
|---|---|---|---|
| Audit/security/application files | Read-only mount; cannot modify/delete through the container | Read-only NTFS ACL | Can ultimately override endpoint ACL using administrator privileges |
| Claude/Gemini content files | Read-only mount | Read-only NTFS ACL | Can ultimately override endpoint ACL |
| Squid access/runtime files | Read-only mount | Read-only NTFS ACL | Can ultimately override endpoint ACL |
| Original Docker retained stream | No Docker socket inside DevContainer | Docker lifecycle permissions depend on host policy | Can manage Docker retention |

`read_only: true`, ECI, `cap_drop: ALL`, and `no-new-privileges` provide additional container-side defense in depth. Docker Desktop ECI also prevents a container from remounting an approved read-only bind mount as writable.

## Important administrator boundary

A local Windows Administrator cannot be made cryptographically or absolutely unable to delete endpoint-local evidence using NTFS ACLs alone. An Administrator can take ownership, reset ACLs, disable a task/agent, or otherwise alter the endpoint. Therefore:

- POC: keep Developers as standard Windows users; use the protected SYSTEM-owned log folder and the SYSTEM exporter.
- POST POC: centrally enforce Docker Desktop/ECI and endpoint settings so Developers cannot weaken the runtime configuration.
- Production authoritative evidence: forward the protected host files promptly to Log Analytics / Microsoft Sentinel.
- If policy requires that even endpoint/platform administrators cannot delete evidence, store the authoritative copy in immutable/WORM retention under a separately administered security control plane.

The local Windows files are a protected collection buffer and operational evidence copy. Sentinel/immutable central retention should be the authoritative record for administrator-resistant audit requirements.

## Docker lifecycle caveat

A Developer with unrestricted host Docker lifecycle access could attempt to stop/remove a container before the next exporter interval and suppress not-yet-exported local Docker records. The protected files already exported to Windows remain read-only to the normal Developer, but Production should also restrict Docker lifecycle/API operations or use an enterprise collector with sufficiently short forwarding latency.

## Sentinel collection

Configure the approved Windows collection method to read:

```text
C:\ProgramData\AI-Sandbox\Logs\devcontainer\*.log
C:\ProgramData\AI-Sandbox\Logs\devcontainer\content\*.log
C:\ProgramData\AI-Sandbox\Logs\squid\*.log
```

A collector running as LOCALSYSTEM can read the files without granting the Developer write access. If the client collector uses a different Windows service identity, grant only that dedicated identity read access (for example with `-ReadPrincipal`) and do not grant Developer write/modify/delete rights. Define the Windows file-collection DCR/custom-table mapping in the client monitoring platform. The package intentionally does not include a second direct Logs Ingestion API sender because that would duplicate the approved Windows protected-file -> AMA/Sentinel path and introduce an additional client-secret/endpoint configuration surface.

## Verification

After the protected host logging setup is installed and both containers are recreated, run from a normal Developer PowerShell session:

```powershell
pwsh -NoProfile -File .\scripts\monitoring\verify-host-log-export.ps1
```

The verification checks that:

- the current Windows user cannot create files in either protected host log folder;
- protected folders are SYSTEM-owned and no non-SYSTEM allow rule has write/modify/delete rights;
- the SYSTEM scheduled exporter is installed and can transfer a marker into the Windows file tree;
- audit/application/content metadata redaction behavior remains correct;
- `/var/log/sandbox` and `/var/log/squid` are non-writable inside the containers;
- those mount points are actually Docker read-only mounts;
- `/var/run/docker.sock` is absent from the DevContainer;
- both containers use Docker's `local` logging driver.

Useful manual checks:

```powershell
icacls C:\ProgramData\AI-Sandbox\Logs
Get-ScheduledTask -TaskName AI-Sandbox-Protected-Log-Export
Get-ChildItem C:\ProgramData\AI-Sandbox\Logs\devcontainer
Get-ChildItem C:\ProgramData\AI-Sandbox\Logs\squid
```

From the DevContainer:

```bash
touch /var/log/sandbox/developer-write-test
# Expected: Read-only file system or Permission denied
```

From Squid, the `/var/log/squid` bind mount is also read-only; Squid itself continues to log to stdout/stderr rather than to that path.

## Upgrade from v1.16.21/v1.16.22

Do not reuse the old Developer-writable `logs\devcontainer` or `logs\squid` bind mounts as log sinks. Archive any old evidence, run `03-setup-logging.ps1`, set `SANDBOX_LOG_ROOT`, and recreate the containers. The protected Windows paths are now written by LOCALSYSTEM and mounted into the containers read-only.
