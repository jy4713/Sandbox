# v1.16.42 Credential-Only Broker Change Review

## Security boundary after the change

```text
Windows host AWS profile (read-only mount)
                 |
                 v
        +-------------------+
        | credential broker |
        | - AWS SSM read    |
        | - fixed HTTP auth |
        | - no workspace    |
        | - no app child    |
        +---------+---------+
                  ^
                  | localhost relay / fixed routes
                  |
        +---------+-----------------------------------+
        | DevContainer: vscode uid/gid 1000           |
        |                                               |
        | Claude / Gemini / ucode agents               |
        | Git / ADO helpers                            |
        | Snyk CLI + MCP                               |
        | Tavily CLI + MCP                             |
        | Databricks CLI + SQL MCP                     |
        | workspace reads/writes                       |
        +-----------------------------------------------+
```

The broker is now a credential/network-authentication component, not a command-execution component. This is the package-wide invariant for existing and future integrations.

## Root-cause closure

The previous Git issue was caused by a workspace-writing process executing in a different container identity namespace. The old ADO path ran `/usr/bin/git` in `secret-broker`, and the secret runner set `umask 077`; the resulting directory could appear as `nobody:nogroup` and `0700` from the DevContainer. The same two-container workspace model made broker-side Snyk susceptible to source visibility differences.

v1.16.42 removes the workspace from `secret-broker` and moves Git, Snyk, Tavily, Databricks and MCP execution to the DevContainer. Direct Claude/Gemini and Databricks-routed ucode agents are explicitly verified as local as well.

## Reviewed command matrix

| Command family | Local real executable? | Broker executes vendor command? | Raw credential in DevContainer? |
|---|---:|---:|---:|
| `claude` | Yes | No | No |
| `gemini` | Yes | No | No |
| `ucode claude` | Yes, Claude | No | No |
| `ucode gemini` | Yes, Gemini | No | No |
| `git` / `ado-git` | Yes, `/usr/bin/git` | No | No |
| `snyk` / Snyk MCP | Yes | No | No |
| `tvly` / Tavily MCP | Yes | No | No |
| `databricks` / Databricks SQL MCP | Yes | No | No |
| `ado-pr-create` / `ado-trigger` | Yes | No | No |

## Key code controls

- `secret-broker-server.py`: only fixed HTTP routes plus one pinned AWS `ssm get-parameter` subprocess; no `Popen`, `os.exec`, command protocol, or workspace access.
- `tar/docker-compose.yml` and `ecr/docker-compose.yml`: workspace bind exists only on `devcontainer`; host `.aws` bind exists only on `secret-broker`.
- `sandbox-command-wrapper.sh`: local real executables, fixed `127.0.0.1:8771` credential route, inherited service/AWS secret variables stripped.
- `ado-git-policy.sh`: local Git; validated ADO HTTPS and localhost URL rewrite; no PAT/askpass.
- `snyk-mcp-ssm.sh`, `tavily-mcp-ssm.sh`, `databricks-sql-mcp-ssm.sh`: local MCP launchers with credential-free child configuration.
- `run-with-ssm-secrets.sh`, `secret-broker-client.py`, `git-askpass-ado.sh`: retired fail-closed guards, exit 126.
- `verify-runtime.sh`: runtime ownership, local process, MCP, SSM isolation and broker-boundary checks.
- `scripts/ci/lint-package.*` and regression tests: prevent reintroduction of broker-side application execution.

## Runtime acceptance checks after rebuild

Run inside the DevContainer:

```bash
whoami
id
umask
verify-runtime

git clone "https://dev.azure.com/ORG/PROJECT/_git/REPO"
stat -c '%U:%G %a %n' REPO
cd REPO
snyk code test

claude mcp list
gemini mcp list
ucode claude mcp list
ucode gemini mcp list
```

Expected Git owner is `vscode:vscode`; the exact directory mode follows `umask 027` and Git/filesystem behavior, but it must not be a foreign `nobody:nogroup` identity. Snyk should now inspect the same workspace namespace as the Developer/AI processes.
