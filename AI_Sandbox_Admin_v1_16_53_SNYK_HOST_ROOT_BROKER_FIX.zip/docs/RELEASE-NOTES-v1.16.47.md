# AI Secure Sandbox v1.16.47 - Release Notes

## Summary

v1.16.47 is a narrow broker error-observability update on top of v1.16.46. No folder layout, runtime architecture, Squid policy, command routing, MCP registration, logging/export design, or credential-isolation boundary is changed.

## Changes

- AWS SSM failures are no longer replaced by the generic `SSM credential retrieval failed; refresh the host AWS profile and restart the broker` message.
- The broker returns sanitized AWS CLI error detail to the caller with the source prefix `[broker:aws-ssm]`. This preserves useful diagnostics such as `ParameterNotFound`, `AccessDeniedException`, invalid/expired credential errors, and proxy connection errors.
- The same sanitized detail is written to the broker log as `dependency_error source=aws-ssm ...` metadata so Host/container logs can be correlated with the caller-visible failure.
- Non-HTTP upstream connection exceptions are returned as sanitized `[broker:upstream]` errors instead of the generic `upstream request failed` message.
- HTTP responses received from providers (for example Azure DevOps 401/403/404/5xx) keep their existing pass-through behavior.
- Added regression checks that useful proxy/AWS error detail is preserved while common credential forms are redacted.

## Security properties retained

- No PAT, API key, SecureString value, Authorization header, AWS secret key, or session token is intentionally logged or returned.
- Error text is sanitized and length-limited before logging/returning.
- The broker remains credential-only: its only subprocess is AWS CLI `ssm get-parameter`.
- The broker still has no workspace mount and does not execute Git, Snyk, Tavily, Databricks, Claude, Gemini, ucode, or MCP commands.
- Git and other native application errors are not reclassified by the broker when the broker is not involved.
- Tavily Admin allowed-domain enforcement is unchanged.
