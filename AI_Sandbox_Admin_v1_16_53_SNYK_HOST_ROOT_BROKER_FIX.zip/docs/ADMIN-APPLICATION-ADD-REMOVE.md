# AI Secure Sandbox v1.16.44 - Admin Application Add / Remove Runbook

## 1. Purpose

v1.16.44 preserves the v1.16.3 explicit runtime architecture but makes Admin application onboarding/removal less repetitive. It does **not** introduce a runtime application catalog and it does **not** install applications dynamically when a Developer starts the container.

The helper edits the same source files an Admin would edit manually in v1.16.44, and generated source is still visible for security review.

## 2. What v1.16.44 adds

```text
scripts/applications/
├── add-application.ps1
├── add-application.sh
├── remove-application.ps1
├── remove-application.sh
├── validate-application.ps1
├── validate-application.sh
├── application-helper.py
└── records/
```

On Windows, the PowerShell launchers require PowerShell 7.4+ (`pwsh`). The PowerShell and shell launchers call the same Admin-side Python 3 source editor so Windows/Linux output is consistent. Python is required only on the Admin source/build workstation for these helpers; it is not a new runtime dependency inside the Developer package.

If Python 3 is not approved/available on the Admin workstation, use the manual procedure in Section 22 of this runbook instead.

## 3. Security model remains unchanged

After Apply, the source still contains explicit code such as:

```text
Dockerfile install
    -> real/<command> stash
    -> local DevContainer wrapper/process as vscode
    -> fixed localhost credential route when a secret is required
    -> credential-only broker reads exact SSM parameter
    -> broker injects authentication into fixed upstream request
    -> Squid approved destination
```

The helper only reduces repetitive Admin editing.

## 4. Generated source markers

Every block generated for an application is marked:

```text
# BEGIN AI-SANDBOX APP acme-ai
...
# END AI-SANDBOX APP acme-ai
```

`remove-application` removes only blocks with that exact application marker. Existing v1.16.44 built-in application code is intentionally not converted into these markers.

The helper also creates:

```text
scripts/applications/records/<name>.json
```

This record is Admin source metadata for validation/removal. It is not copied into the DevContainer and is not read at runtime.

## 5. Supported install templates

| `InstallType` | Use | Required input |
|---|---|---|
| `npm` | Node CLI | package + exact version |
| `uv` | Python CLI | package + exact version |
| `apt` | package already available in configured apt repositories | package + exact apt version |
| `archive` | binary / ZIP / TAR.GZ download | HTTPS URL + SHA-256 + format; binary path for ZIP/TAR |
| `custom` | exceptional vendor install flow | locally reviewed Dockerfile snippet |

The helper deliberately does not provide a parameter for an arbitrary remote `curl | sh` installer.

For AWS CLI-like installation flows where a ZIP contains an installer program rather than only a binary, use a reviewed `custom` snippet or the v1.16.44 manual process.

## 6. Preview is mandatory operational practice

The helper defaults to preview. It modifies files only when `-Apply` / `--apply` is supplied.

Recommended sequence:

```text
Preview
  -> review planned files and parameters
Apply
  -> review git diff
Validate
  -> package lint
POC build/test
  -> Production release
```

## 7. Add a non-secret npm CLI - PowerShell

v1.16.44 intentionally **does not auto-generate a secret-backed runtime path**. A generic helper that accepts `SecretEnv`/`SsmParameter` would recreate the old design where a child process could receive a raw secret. Therefore `application-helper.py` fails closed if generic secret onboarding is requested.

For a non-secret CLI, preview first:

```powershell
.\scripts\applications\add-application.ps1 `
  -Name acme-tool `
  -Command acme `
  -InstallType npm `
  -Package '@acme/cli' `
  -Version '1.2.3' `
  -Egress '.acme.example' `
  -ConfigDir '.config/acme'
```

Apply only after review:

```powershell
.\scripts\applications\add-application.ps1 `
  -Name acme-tool `
  -Command acme `
  -InstallType npm `
  -Package '@acme/cli' `
  -Version '1.2.3' `
  -Egress '.acme.example' `
  -ConfigDir '.config/acme' `
  -Apply
```

## 8. Equivalent shell example

```bash
./scripts/applications/add-application.sh \
  --name acme-tool \
  --command acme \
  --install-type npm \
  --package '@acme/cli' \
  --version '1.2.3' \
  --egress '.acme.example' \
  --config-dir '.config/acme'
```

Add `--apply` after reviewing preview output.

## 9. Secret-backed applications require an explicit broker adapter

If the new application needs an API key, PAT, client secret, or other credential, do **not** use generic `--secret-env` onboarding. Follow the manual explicit procedure in Section 25 and implement a reviewed broker adapter.

Required pattern:

```text
AI DevContainer
  -> real application / MCP process runs locally as vscode
  -> credential-free fixed localhost HTTP route
  -> credential-only broker validates route/policy
  -> exact SSM parameter read
  -> broker injects authentication into fixed upstream API request
```

The broker must never return the secret value, execute the application, or provide a generic arbitrary command runner. Add method/path/tool validation and a fixed upstream destination before granting a route access to a secret.

## 10. uv/Python example

A non-secret Python CLI can still use the helper with an exact approved version:

```powershell
.\scripts\applications\add-application.ps1 `
  -Name pytool `
  -Command pytool `
  -InstallType uv `
  -Package 'pytool' `
  -Version '4.1.0' `
  -Egress '.pytool.example' `
  -Apply
```

## 11. Archive examples

For a direct binary, ZIP, or TAR.GZ, provide an approved HTTPS URL and SHA-256. Do not add secret options to the generic helper.

```powershell
.\scripts\applications\add-application.ps1 `
  -Name vendcli `
  -Command vendcli `
  -InstallType archive `
  -Url 'https://downloads.vendor.example/vendcli-2.0.0-linux-amd64' `
  -Sha256 '<APPROVED_64_HEX_SHA256>' `
  -ArchiveFormat binary `
  -Egress '.vendor.example' `
  -Apply
```

For ZIP/TAR.GZ, use a safe relative `BinaryPath` and review extraction paths.

## 12. apt example

Use `apt` only when the approved repository is already configured and an exact version is known. New repositories/signing keys require manual review.

## 13. custom install example

`custom` performs source insertion only. The Admin must review the local Dockerfile snippet for HTTPS, version pinning, signature/checksum validation, repository trust, installed paths and cleanup.

## 14. Add an MCP integration

A **credential-free** MCP server may be helper-generated. A secret-backed MCP server requires a manually reviewed credential-only HTTP adapter. The MCP process itself must still run in the DevContainer as `vscode`; registration must contain only the local launcher and non-secret configuration, never key/token environment variables.

Built-in v1.16.44 examples are Tavily, Snyk and Databricks SQL. Their local MCP processes use fixed localhost broker routes; SSM retrieval and real credential injection occur only inside the credential broker's outbound HTTP request.

## 15. Validate after Apply

PowerShell:

```powershell
.\scripts\applications\validate-application.ps1 -Name acme-tool -RunLint
```

Shell:

```bash
./scripts/applications/validate-application.sh --name acme-tool --run-lint
```

Always inspect the source diff in addition to helper validation.

## 16. Configure an SSM credential only after the broker adapter exists

For a secret-backed integration, add the SSM parameter name to both Admin setup scripts only after the reviewed broker operation and its pinned consumer have been implemented. The real value is entered only through the Admin SSM setup workflow. Never place the value in helper metadata, `.env`, Docker Compose, MCP configuration or the AI process environment.

## 17. POC acceptance after adding an app

1. Package lint passes.
2. Review source diff.
3. Build POC DevContainer/Squid images. For application-layer-only changes, v1.16.44 may use `build-sandbox.ps1 -SandboxType POC -ReuseHardenedBase`; the Admin entry point reuses the old hardened base only after validating the complete copied `.build.env`, the exact digest, and hardening labels, and automatically rebuilds the hardened base if any requirement fails.
4. Start the POC Sandbox.
5. Confirm `/usr/local/bin/<command>` resolves to the Admin wrapper.
6. Confirm `/usr/local/libexec/ai-sandbox/real/<command>` exists.
7. Confirm host AWS authentication uses either an Admin-approved static host profile for POC testing or Azure/Entra SAML through `aws-azure-login`; raw AWS keys in `.env` remain rejected.
8. Run local help/version without unnecessary secret fetch where supported.
9. Run one approved real operation.
10. Confirm the app emits its tagged metadata record to the Docker-owned DevContainer stream.
11. Confirm Squid access records appear in the Docker-owned Squid stream and destination behavior is correct.
12. If MCP enabled, test from both Claude and Gemini.
13. Verify MCP/application stream correlation by tag, timestamp and operation metadata.
14. Search `docker compose logs` for a dummy secret and a deliberately confidential test argument/query; neither should be present in metadata audit records.
15. Run image/CIS/security acceptance gates.

## 18. Production release

An app add/remove still requires a new DevContainer image. v1.16.44 does not make runtime installation dynamic.

For Production:

1. complete POC/security acceptance;
2. build the Production image;
3. publish immutable ECR digest;
4. if Squid changed, publish new Squid digest;
5. publish/update the approved-image manifest;
6. verify Developer `pull-and-start` resolves the newly approved image;
7. retain previous approved digest according to rollback policy.

## 19. Remove a helper-managed v1.16.44 app

### Preview removal

PowerShell:

```powershell
.\scripts\applications\remove-application.ps1 -Name acme-ai
```

Shell:

```bash
./scripts/applications/remove-application.sh --name acme-ai
```

The preview lists every source file that contains that application's generated marker.

Before Apply, determine whether any generated Squid domain or SSM parameter is shared with another workload.

### Apply removal

```powershell
.\scripts\applications\remove-application.ps1 -Name acme-ai -Apply
```

or:

```bash
./scripts/applications/remove-application.sh --name acme-ai --apply
```

The helper removes only exact `BEGIN/END AI-SANDBOX APP acme-ai` blocks, deletes the generated MCP launcher if one exists, and deletes the helper record.

## 20. What remove-application intentionally does not delete

The helper does **not**:

- call AWS SSM delete-parameter;
- revoke a vendor API key;
- delete a SaaS account;
- determine whether a Squid domain is shared outside helper-managed source;
- delete an old ECR image/digest;
- change the central approved manifest automatically.

Those actions have wider impact and require explicit Admin/change review.

Preferred credential-removal order:

```text
remove app from source/image
-> validate + POC
-> publish removal image
-> confirm old image retirement
-> revoke vendor credential
-> delete/disable SSM parameter
```

## 21. Removing built-in v1.16.44 applications

Claude, Gemini, Tavily, Snyk, Databricks, and any application integrated manually before v1.16.44 do not have helper records/markers.

Do not attempt to fabricate a record and run `remove-application` against them. Use:

```text
docs/ADMIN-APPLICATION-ADD-REMOVE.md
```

and reverse each explicit integration point manually.

## 22. Failure and rollback

If Apply produces an unexpected source change:

1. stop before image publication;
2. inspect `git diff`;
3. use `remove-application` for a correctly recorded helper-managed addition, or revert source control;
4. rerun package lint;
5. do not publish the image until the complete POC/security acceptance passes.

Production rollback is by approved immutable image digest/manifest, not only by source rollback.

## 23. Admin add checklist

- [ ] approval/change ticket exists
- [ ] preview reviewed
- [ ] install source is approved
- [ ] exact version is pinned
- [ ] direct download has approved SHA-256
- [ ] no unreviewed pipe-to-shell installer introduced
- [ ] only secret *names*, not secret values, supplied to helper
- [ ] generated Dockerfile block reviewed
- [ ] wrapper/SSM branch reviewed
- [ ] SSM setup names match
- [ ] audit metadata contains no content/secrets
- [ ] Squid domains are minimum required and non-overlapping
- [ ] MCP registration is secret-free
- [ ] validator passed
- [ ] package lint passed
- [ ] source diff reviewed
- [ ] POC functional test passed
- [ ] negative secret/query audit test passed
- [ ] CIS/security gates passed
- [ ] Production immutable digest/manifest updated

## 24. Admin removal checklist

- [ ] removal approved
- [ ] removal preview reviewed
- [ ] shared domains checked
- [ ] shared SSM parameters checked
- [ ] Apply removed only expected marker blocks
- [ ] validator/package lint passed after removal
- [ ] POC confirms command/MCP is absent
- [ ] Squid still works for remaining apps
- [ ] Production removal image/digest published
- [ ] old image retirement confirmed
- [ ] vendor credential revoked after retirement
- [ ] SSM parameter deleted/disabled after retirement
- [ ] documentation/change evidence updated

## 25. Manual explicit add procedure (built-in / exceptional applications)

Use this section when the application is a built-in integration, when Python helpers are unavailable, or when the install/authentication flow is too unusual for the helper templates. This preserves the explicit v1.16.3-style source model.

### 25.1 Collect approval inputs before editing

Record all of the following before changing source:

1. application name, business owner, change/security approval;
2. Developer-facing command(s);
3. official vendor installation method;
4. exact approved version (never `latest` or an open range);
5. for direct downloads, the exact HTTPS source URL and approved SHA-256;
6. runtime secret environment-variable names;
7. exact SSM parameter names under the approved Sandbox prefix;
8. required outbound FQDN/domain list;
9. MCP launch command/transport if applicable;
10. required narrow writable config/cache directories;
11. safe audit operation names and target identifiers;
12. rollback/removal dependencies, including shared domains and credentials.

### 25.2 Add build-time inputs

For version/source/hash values that must be controlled by Admin build configuration:

- add non-secret values to `.build.env.example`;
- add required-variable/format validation to `scripts/common/Load-BuildEnv.ps1` and `scripts/common/load-build-env.sh` when appropriate;
- propagate new Docker build arguments through both `scripts/tar/build-and-export.*` and `scripts/platform/02-setup-ecr.*`;
- declare/redeclare the matching `ARG` in the required Dockerfile stage(s).

Do **not** place runtime tokens/API keys/PATs in `.build.env`.

### 25.3 Install the application in `.devcontainer/Dockerfile`

Install during image build, not in `post-create.sh`. Preferred patterns are:

- npm: exact `package@version`;
- uv/Python: exact version or immutable Git commit;
- direct binary/archive: HTTPS source + SHA-256 validation before install;
- apt/deb: approved repository/package version according to supply-chain policy.

Avoid unverified remote `curl | sh`. If a vendor bootstrap installer is unavoidable, mirror/review/pin it according to the organisation's software supply-chain process.

### 25.4 Verify and stash the real executable

Before creating a public wrapper, verify that the expected executable exists and, where safe, that `--version`/`--help` works. Preserve the real vendor executable under:

```text
/usr/local/libexec/ai-sandbox/real/<command>
```

This prevents wrapper recursion and allows Admin-controlled public command paths.

### 25.5 Add only required writable directories

The runtime root filesystem is read-only. If the application needs local state, add only a narrowly scoped directory under `/home/vscode` and map/provision only that path. Do not make broad system locations writable as a workaround.

### 25.6 Add the public wrapper branch

Edit `.devcontainer/scripts/sandbox-command-wrapper.sh`.

- **all real application execution stays in the DevContainer as `vscode`**;
- local inspection operations such as `--version`/`--help` call the real binary locally when safe;
- a secret-backed operation points the local application at a fixed localhost broker URL and supplies only a non-secret placeholder if the vendor library requires one;
- never route the application executable itself through `secret-broker-client` or `run-with-ssm-secrets`; both legacy command interfaces are permanently fail closed;
- never log or copy raw `$@` into audit records.

### 25.7 Add the credential-only broker route and SSM mapping

For a secret-backed app, add a **fixed reviewed HTTP route** to `.devcontainer/scripts/secret-broker-server.py`. Do not add a child-process command operation. The route must:

1. use a fixed Admin-approved HTTPS upstream origin; never accept a caller-supplied destination;
2. validate path/method/tool policy as narrowly as practical before credential lookup;
3. call `get_parameter` only for the exact minimum SSM parameter names;
4. remove client-supplied authentication headers/query keys that could conflict with managed auth;
5. inject the real credential only into the broker's upstream request;
6. never return the secret, write it to workspace, export it into the local application process, or log it;
7. add an offline regression test proving the route cannot become an arbitrary credentialed proxy.

`run-with-ssm-secrets.sh`, `secret-broker-client.py`, and `git-askpass-ado.sh` are compatibility guards only and must remain fail closed (exit 126).

### 25.8 Add Admin SSM bootstrap

Update both:

```text
scripts/platform/01-setup-ssm.sh
scripts/platform/01-setup-ssm.ps1
```

Use `SecureString` for credentials. The SSM name must exactly match the credential-broker `get_parameter` name. Source files may contain parameter names but never real secret values.

### 25.9 Add application audit support

If the local wrapper emits `application-audit --app <app>`, add the app identifier to `.devcontainer/scripts/application-audit.sh`. Broker code must not launch application audit children; broker logging stays metadata-only and secret-free.

Audit only sanitized metadata. Do not log prompts, queries, request/response bodies, source code, findings, credentials, remote URLs containing credentials, or complete command arguments.

Expected runtime destination for a normal app is the Docker-owned DevContainer stdout stream. `application-audit` tags each structured record with the approved application name; no Developer-writable `<app>-events.log` file is created.

### 25.10 Add Squid egress only when required

Edit `squid/whitelist.txt` with the minimum approved destinations. Do not add both a parent suffix such as `.example.com` and a child/apex already covered by that suffix; package lint rejects overlaps.

Any Squid allowlist change requires a new Squid image/release as well as a DevContainer release when the application set changed.

### 25.11 Add MCP when applicable

For an MCP integration:

1. create `.devcontainer/scripts/<app>-mcp-ssm.sh`;
2. resolve the real binary under `/usr/local/libexec/ai-sandbox/real/`;
3. run that real MCP process locally in the DevContainer and record only MCP lifecycle metadata;
4. when authentication is needed, point the local MCP transport at a fixed localhost credential-broker HTTP route; never invoke `secret-broker-client` or `run-with-ssm-secrets`;
5. COPY/chmod the wrapper in the Dockerfile;
6. register it secret-free for Claude/Gemini in `configure-mcp.sh`;
7. never place API keys/tokens in MCP configuration or process environment;
8. extend runtime verification/lint to prove the MCP process is local and the broker route only injects authentication.

### 25.12 Extend runtime verification and package lint

At minimum verify:

- public command exists;
- public command resolves to the Admin wrapper when intended;
- real executable exists;
- runtime secret is absent from the parent environment;
- required writable path works;
- MCP wrapper/registration exists when applicable.

Add package-lint assertions for any new security invariant that must never silently regress.

### 25.13 Acceptance/release sequence

```text
source change
 -> Bash + PowerShell lint
 -> build the selected SandboxType
 -> distribute/start through the selected DeploymentType (TAR or ECR)
 -> host auth selector uses static [sandbox] key pair when present, otherwise Azure/Entra browser login through aws-azure-login
 -> local help/version test
 -> real approved operation
 -> application/MCP/Squid audit correlation
 -> dummy-secret/content non-leakage test
 -> CIS/image/security gates
 -> publish immutable TAR integrity evidence or ECR digests
 -> update release/approved-image evidence as applicable
```

An application addition always changes the DevContainer image. A Squid allowlist change also changes the Squid image.

## 26. Manual explicit removal procedure

Do not remove only the install line. First identify whether any other application shares the executable, package, SSM parameter, vendor credential, Squid domain, writable directory, MCP registration, or audit expectation.

Reverse every applicable integration point:

1. remove Dockerfile install code;
2. remove obsolete build `ARG` declarations/redeclarations;
3. remove unused `.build.env.example` values;
4. remove build-env required-variable/validation entries;
5. remove TAR/ECR build-argument propagation;
6. remove the `real/<command>` stash step;
7. remove the public symlink/wrapper branch;
8. remove the SSM profile allowlist/branch;
9. remove SSM bootstrap prompts from both SH and PS1;
10. remove application-audit allowlisting only if unused;
11. remove MCP wrapper/COPY/configuration when applicable;
12. remove application-only writable directories/mounts;
13. remove Squid domains only after checking they are not shared;
14. remove runtime verification/lint assertions that are no longer relevant;
15. update the current operational documentation and any external change/release evidence required by your governance process;
16. lint, rebuild and retest POC/Production.

Do **not** delete the SSM parameter or revoke the vendor credential first. Preferred order:

```text
remove app from new source/image
 -> lint + POC acceptance
 -> publish new approved image/digest
 -> verify old image/session retirement
 -> revoke vendor credential
 -> delete/disable SSM parameter
```

This keeps rollback controlled and prevents still-running approved old images from breaking unexpectedly.

## Content-logging integration rule

Do not add request/response bodies to `application-audit.sh` metadata records. If a future AI application requires approved content capture, emit a separately tagged `content` record to the Docker-owned stream, gated by `SANDBOX_CONTENT_LOGGING=true`. Keep the default disabled, document exact capture semantics, apply central SIEM RBAC/retention, and add a lint regression proving metadata remains content-free when the flag is disabled.


## v1.16.44 runtime compatibility update

- Snyk runs locally in the DevContainer and uses `/run/ai-sandbox-snyk`, a dedicated ephemeral `exec,nosuid,nodev` tmpfs, because the Snyk CLI downloads and executes a versioned native runtime from its cache. This also guarantees Snyk sees workspace files under the same `vscode` identity. `/tmp` and `/var/tmp` remain `noexec`.
- When `-ReuseHardenedBase`/`--reuse-hardened-base` is used, the build refreshes only the immutable `UCODE_GIT_REF` from Databricks ucode `main`; the hardened Ubuntu base is still reused.
- The pinned ucode source remains supply-chain tracked, but v1.16.44 does not use upstream PAT injection for `ucode claude/gemini`; the secure runtime wrapper keeps those agent processes local and routes only their HTTP authentication through the brokered Databricks AI Gateway path.
