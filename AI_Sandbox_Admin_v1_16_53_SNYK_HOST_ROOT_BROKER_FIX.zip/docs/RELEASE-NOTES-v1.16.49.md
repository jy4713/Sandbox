# AI Secure Sandbox v1.16.49 - Release Notes

## Summary

v1.16.49 is a narrow Snyk credential-transport correction on top of v1.16.48. It rolls back the v1.16.48 Snyk-specific API/Code URL override model and restores Snyk CLI native endpoint discovery while keeping the real Snyk process in the DevContainer. The v1.16.47 sanitized broker error passthrough is retained.

## Snyk transport correction

- The Sandbox no longer forces `SNYK_API` or `DEEPROXY_API_URL` to product-specific localhost routes.
- The local Snyk CLI and Snyk MCP process keep their native command arguments and native Snyk endpoint discovery.
- Only Snyk processes use a localhost HTTPS proxy on port `8772`.
- The proxy preserves the original Snyk destination hostname/path/query/body. For Snyk-owned hosts (`snyk.io` and `snykgov.io` subdomains), the broker replaces the non-secret placeholder authentication with the SSM-backed Snyk token and forwards the request to the original host through Squid.
- Non-Snyk HTTPS connections made by Snyk/dependency tooling are tunneled unchanged through Squid and receive no Snyk credential.
- The broker creates an ephemeral Snyk-proxy CA under broker `/run`; only the public CA certificate is provided to the Snyk process. The CA private key never enters the DevContainer and the CA is not installed into the system trust store.
- This avoids maintaining a growing list of Snyk internal API/backend URL variables while keeping the real Snyk token out of AI-visible process state.

## Existing behavior retained

- The real Snyk CLI/MCP process runs in the DevContainer as `vscode`, preserving workspace access and ownership semantics.
- The broker has no workspace mount and does not execute Snyk or other vendor applications.
- Broker subprocess use remains limited to AWS CLI SSM retrieval.
- v1.16.47 dependency-error passthrough/sanitization remains enabled.
- Tavily Admin allowed-domain enforcement is unchanged.
- Git, Claude, Gemini, ucode, Databricks, logging, deployment layout, and Squid default-deny policy are not structurally refactored by this change.
- Existing `eu-north-1` SSM/STS Squid entries remain in place.

## Regression coverage

- Snyk wrapper tests verify native CLI argv and caller-provided standard Snyk endpoint settings are not rewritten.
- An offline TLS proxy regression test verifies the original HTTPS host/path/body are preserved while only the Authorization credential is replaced.
- Broker tests verify Snyk-owned hostname scoping, ephemeral certificate generation, and absence of the v1.16.48 `/snyk` and `/snyk-code` reverse routes.
- Snyk MCP tests verify the real MCP process remains local and does not force `SNYK_API`/`DEEPROXY_API_URL`.
