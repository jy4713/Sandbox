# AI Secure Sandbox v1.16.42 Release Notes

## Summary

v1.16.42 changes the execution boundary from **broker-side application execution** to a **credential-only broker with local DevContainer execution**. The change addresses the cross-container ownership condition observed when Azure DevOps Git created a repository that appeared as `nobody:nogroup` and mode `0700` to the `vscode` DevContainer user, and the same class of cross-container readability problem that could affect Snyk whole-workspace scans.

The security objective is unchanged: raw AWS credentials, SSM SecureStrings, ADO PATs, provider API keys, Snyk tokens, Tavily keys, and Databricks PATs remain outside the AI/Developer process environment.

## New runtime invariant

Every real developer/vendor/MCP executable runs in the DevContainer as `vscode` uid/gid 1000:

| Interface | Real process location | Credential handling |
|---|---|---|
| Claude Code | DevContainer | broker injects Anthropic key into fixed upstream HTTP route |
| Gemini CLI | DevContainer | broker injects Gemini key into fixed upstream HTTP route |
| `ucode claude` | DevContainer, real Claude CLI | broker injects Databricks PAT into fixed AI Gateway route |
| `ucode gemini` | DevContainer, real Gemini CLI | broker injects Databricks PAT into fixed AI Gateway route |
| Git / ADO Git | DevContainer, `/usr/bin/git` | validated ADO HTTP transport is rewritten to localhost; broker injects ADO PAT upstream |
| Snyk CLI / MCP | DevContainer | broker injects Snyk token into fixed Snyk HTTP route |
| Tavily CLI / MCP | DevContainer | Admin domain policy is enforced locally and broker-side; broker injects Tavily key upstream |
| Databricks CLI / SQL MCP | DevContainer | broker injects only the appropriate Databricks token upstream |
| ADO PR/pipeline helpers | DevContainer | local `curl` uses fixed ADO credential route |

The `secret-broker` has **no workspace mount** and has no application command protocol. Its only subprocess use is the internal, pinned AWS CLI `ssm get-parameter` call needed to retrieve a reviewed SSM credential. It forwards only fixed Admin-defined upstream HTTP routes and injects authentication in broker memory.

## Git ownership fix

In v1.16.41, credentialed ADO Git commands were delegated to the sidecar broker. The broker also used a restrictive `umask 077`. With an isolated Docker Desktop/container user namespace, a repository created in the shared host workspace could therefore appear in the DevContainer as an unmapped `nobody:nogroup` owner with mode `0700`.

v1.16.42 removes broker-side Git execution. `/usr/bin/git` now always runs in the DevContainer. A root-owned local Git policy validates the ADO HTTPS target and uses an execution-time `url.<localhost>/insteadOf` rewrite so only HTTP authentication crosses the broker. Repository/source filesystem writes therefore originate from uid/gid 1000 and remain `vscode:vscode`.

The ADO PAT is never exposed through `GIT_ASKPASS`, an environment variable, a URL, a Git config file, or the workspace.

## Snyk whole-workspace fix

Snyk CLI and Snyk MCP no longer execute in the broker sidecar. They execute in the same DevContainer namespace as the workspace and can therefore read source files, AI-created files, virtual-environment metadata, and cache directories according to the normal `vscode` ownership/permission model.

Snyk uses a DevContainer-only executable tmpfs for its ephemeral home/cache state. The real Snyk token remains in the credential broker; the local Snyk process sees only a non-secret placeholder and a fixed localhost API base.

## AI-generated source ownership

Claude, Gemini, `ucode claude`, and `ucode gemini` all execute locally in the DevContainer. Files/directories created by those agent processes therefore use the same uid/gid 1000 identity as the Developer. The global non-login shell policy remains `umask 027`, so ordinary source creation is expected to be `vscode:vscode` with group-readable workspace permissions rather than a foreign sidecar identity.

## MCP behavior

The Admin-managed MCP set remains the same for all four supported agent entry points:

```text
tavily
snyk
databricks-sql
```

All three MCP launchers now start their real process in the DevContainer. Claude and Gemini configuration contains no service-secret environment blocks. `ucode claude mcp ...` and `ucode gemini mcp ...` remain local client-control operations and preserve the native underlying CLI command syntax.

## Retired command-broker compatibility paths

`run-with-ssm-secrets`, `secret-broker-client`, and `git-askpass-ado` remain installed only as fail-closed compatibility guards. Every invocation returns exit code `126`; they cannot fetch SSM values or start a Developer/vendor process.

Generic secret-backed application onboarding is also fail closed. A new secret-backed integration must keep its real process in the DevContainer and add a separately reviewed, fixed credential-injection HTTP adapter.

## Defense in depth retained

- host `.aws` is mounted read-only into `secret-broker` only;
- the DevContainer receives no AWS profile or AWS credential-provider environment;
- the broker has no workspace mount;
- DevContainer and broker keep `cap_drop: [ALL]`, `no-new-privileges`, and read-only root filesystems;
- Tavily allowed-domain policy remains Admin-owned and is now also enforced at the credential broker HTTP boundary;
- ADO PAT use at the broker is independently restricted to reviewed Git smart-HTTP, PR helper, pipeline helper, identity/profile routes;
- direct caller-injected AWS/service credential variables are removed from local application and MCP process environments;
- external egress remains governed by the Squid default-deny allowlist.

## Upgrade / migration

A new DevContainer image and recreated stack are required. An existing repository that was already created as `nobody:nogroup` is not automatically repaired by the code change. After starting v1.16.42, remove the unusable old checkout from the host/Admin side if necessary and clone it again with normal `git clone`; the new checkout should be `vscode:vscode`.

Run `verify-runtime` after recreation. It now includes an ownership smoke test that creates a local Git repository under `/home/vscode/workspace` and verifies uid/gid `1000:1000`.

## Verification performed for this package

The package was statically and offline-regression tested with:

- all Bash source syntax checks;
- all Python source AST/syntax checks;
- Tavily policy regression tests;
- Squid policy regression tests;
- credential-only broker regression tests;
- Claude/Gemini/ucode managed-MCP matrix tests;
- ADO Git policy regression tests;
- TAR/ECR Compose YAML parsing;
- package security/integration lint.

Live AWS SSM, Azure DevOps, Databricks, Anthropic, Gemini, Tavily and Snyk calls require the target customer credentials/network and therefore are runtime smoke tests after image rebuild, not offline package tests.
