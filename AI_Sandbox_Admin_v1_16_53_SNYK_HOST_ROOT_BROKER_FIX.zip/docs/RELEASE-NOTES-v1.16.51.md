# AI Secure Sandbox v1.16.51 - Release Notes

## Scope

v1.16.51 is a minimal maintainability change on top of v1.16.50. No existing command flow, credential isolation, MCP registration, Snyk dual-endpoint routing, logging, Databricks routing, or egress architecture is intentionally changed.

## Change

The fixed broker upstream URLs for the following services are moved from Python source literals into `policies/admin-upstream-endpoints.json`:

- Direct Claude (`anthropic`)
- Direct Gemini (`gemini`)
- Tavily REST (`tavily_api`)
- Tavily MCP (`tavily_mcp`)
- Snyk general API (`snyk_api`)
- Snyk Code / DeepProxy (`snyk_code`)

The file is copied into `/etc/ai-sandbox/policies/admin-upstream-endpoints.json`, owned by `root:root`, mode `0444`. The broker reads only the six known route identities; runtime callers cannot supply an arbitrary upstream.

## Validation

Each configured URL must use HTTPS/443 and may not contain userinfo, query, fragment, an IP-literal hostname, control characters, or path traversal. A vendor path is permitted for endpoint evolution. The Dockerfile executes `secret-broker-server --validate-config`, so malformed Admin configuration fails the image build.

If an Admin changes a hostname that is not already permitted by `squid/whitelist.txt`, the Squid allowlist must also be updated and the images rebuilt.

## Retained behavior

- Snyk CLI 1.1306.2 remains pinned.
- `api.snyk.local` and `deeproxy.snyk.local` remain the local dual-endpoint aliases.
- Snyk path/query/body/method preservation and SSM token injection are unchanged.
- `DATABRICKS_HOST` remains the environment-specific validated Databricks workspace setting.
- ucode Claude/Gemini continue through Databricks AI Gateway.
- Tavily allowed-domain enforcement remains unchanged.
- ADO policy, MCP policy, logging, and secret isolation are unchanged.
