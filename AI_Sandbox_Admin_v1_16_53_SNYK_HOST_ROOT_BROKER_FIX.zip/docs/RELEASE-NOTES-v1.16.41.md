# AI Secure Sandbox v1.16.41 Release Notes

## Summary

v1.16.41 simplifies Azure DevOps Git authorization while preserving the v1.16.40 credential boundary, transparent Git UX, native Claude/Gemini/ucode argument contract, managed MCP matrix, protected logging, Tavily policy, Snyk integration, Databricks routes, and container hardening.

## Azure DevOps changes

- `/sandbox/ado-pat` is now the only ADO SSM parameter required by the Sandbox.
- `/sandbox/ado-org`, `/sandbox/ado-project`, and `/sandbox/ado-repo` are no longer created, read, required, or compared by the Git broker.
- `.env`, TAR/ECR `.env.example`, and `.build.env` require no ADO organisation/project/repository metadata.
- PAT-backed Git is constrained to structurally valid HTTPS repository URLs on `dev.azure.com`; repository/project authorization is decided by the PAT and Azure DevOps permissions.
- Normal Git syntax remains unchanged, including direct `main`/`master` pushes, `--force`, `--force-with-lease`, delete, mirror, prune, and normal refspec semantics. Azure DevOps remains the authoritative branch/repository governance layer.
- Credential redirection and unsafe execution/configuration overrides remain blocked. The ADO PAT is still fetched only inside the trusted broker and supplied to pinned Git through `GIT_ASKPASS`.

## Optional ADO helpers

`ado-pr-create` and `ado-trigger` remain available for compatibility, but they no longer depend on SSM org/project/repository metadata. If used, target identifiers are supplied explicitly:

```bash
ado-pr-create --org ORG --project PROJECT --repo REPO \
  --title "..." --source feature/example

ado-trigger --org ORG --project PROJECT \
  --pipeline-id 42 --branch main
```

Only the PAT is broker-injected.

## Existing SSM metadata from older versions

Existing `/sandbox/ado-org`, `/sandbox/ado-project`, and `/sandbox/ado-repo` parameters are harmless but unused by v1.16.41. They are not deleted automatically. An Admin may remove them after confirming no older Sandbox version depends on them:

```powershell
aws --profile sandbox --region <region> ssm delete-parameters `
  --names "/sandbox/ado-org" "/sandbox/ado-project" "/sandbox/ado-repo"
```

## Compatibility

All v1.16.40 broker/SSM secret isolation and runtime hardening controls remain in place. This release does not change the separate Snyk whole-workspace scan issue currently under investigation.
