# v1.16.43 Change Review - Central Admin Policy Source

## Objective

Make Admin policy management deterministic: one source directory at build time and one immutable runtime policy location, while preserving the v1.16.42 credential-only broker/local-command execution model.

## Source layout

```text
policies/
  README.md
  ado-policy.json
  tavily-allowed-domains.json
  claude-mcp.json
  gemini-managed-settings.json
  gemini-web-policy.toml
  admin-settings.json
  squid-egress-allowlist.txt
```

There is no `.devcontainer/policies/` source directory in v1.16.43.

## Runtime enforcement

```text
Admin source
policies/ado-policy.json
       |
       | image build
       v
/etc/ai-sandbox/policies/ado-policy.json  (root:root 0444)
       |                              |
       |                              |
       v                              v
DevContainer local Git          Secret broker
first-line validation           authoritative PAT-use validation
       |                              |
       +---------- approved ----------+
                                      |
                                 inject ADO PAT
```

Tavily follows the same source-of-truth pattern with `tavily-allowed-domains.json`.

## ADO behavior preserved

The shared ADO policy currently permits the same operations as v1.16.42:

- Git smart HTTP for `clone`, `fetch`, `pull`, `push`, `ls-remote`, approved `remote`, `submodule` and remote `archive` paths.
- PR create/update routes used by the approved helper.
- Pipeline run create/read routes used by the approved helper.
- Identity lookup/current-profile routes required by the PR helper.

Generic ADO REST endpoints remain denied by the broker.

## Regression checks

- Broker remains command-execution-free; AWS SSM read is its only subprocess use.
- Broker has no workspace mount.
- Local Git still executes `/usr/bin/git` in the DevContainer.
- ADO local policy and broker both consume `ado-policy.json`.
- Tavily local and broker layers both consume `tavily-allowed-domains.json`.
- Claude/Gemini managed MCP definitions continue to expose Tavily, Snyk and Databricks SQL consistently.

- Squid egress destinations are now Admin-managed from `policies/squid-egress-allowlist.txt`; the Squid image consumes that central source during build.
