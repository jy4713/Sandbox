#!/usr/bin/env bash
# Azure DevOps credential-isolated usage/status helper - v1.16.44.
set -euo pipefail
mode="${1:-check}"
show_help(){ cat <<'HELP'
ADO authentication - v1.16.44 local-execution model

All Git/ADO helper commands execute in the devcontainer as vscode (uid 1000).
The credential broker only retrieves ADO_PAT from SSM and injects it into the
fixed upstream HTTP request. It never runs Git and never mounts the workspace.

Use normal commands:
  git clone https://dev.azure.com/ORG/PROJECT/_git/REPO
  git fetch --prune
  git pull
  git push -u origin feature/ai-123
  ado-pr-create --org ORG --project PROJECT --repo REPO --title "..." --source feature/ai-123
  ado-trigger --org ORG --project PROJECT --pipeline-id 42 --wait
HELP
}
show_check(){
  echo '=== ADO authentication status ==='
  echo '  PAT source       : AWS SSM, credential broker only'
  echo '  Git execution    : local /usr/bin/git as vscode'
  echo '  Workspace mount  : devcontainer only (not broker)'
  [[ -z "${ADO_PAT:-}" ]] && echo '  [OK]   ADO_PAT absent from AI environment' || echo '  [FAIL] ADO_PAT unexpectedly present'
  [[ ! -f "$HOME/.git-credentials" && ! -f "$HOME/.git-credentials-ado" ]] && echo '  [OK]   no Git credential files on disk' || echo '  [FAIL] stale Git credential file found'
  [[ "$(command -v git 2>/dev/null || true)" == /usr/local/bin/git ]] && echo '  [OK]   transparent local Git front-end installed' || echo '  [FAIL] Git front-end missing'
  curl --noproxy '*' -fsS --max-time 5 "${SANDBOX_PROVIDER_LOOPBACK_URL:-http://127.0.0.1:8771}/healthz" >/dev/null 2>&1 && echo '  [OK]   credential broker route reachable' || echo '  [FAIL] credential broker route unreachable'
}
case "$mode" in check) show_check ;; help|-h|--help) show_help ;; *) echo "ERROR: unknown mode '$mode'" >&2; exit 2 ;; esac
