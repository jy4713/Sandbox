#!/usr/bin/env bash
# =============================================================================
# PACKAGE MAINTENANCE NOTES
# Purpose: Bash workflow for creating Azure DevOps pull requests using approved authentication.
# Admin maintenance: Update only for ADO API/workflow changes; keep the PowerShell peer behaviorally equivalent.
# Safety rule: preserve secret-free images/configuration, immutable version or
# digest pinning where applicable, and update the paired Bash/PowerShell path.
# After any change, run scripts/ci/lint-package.* and the applicable build/QA.
# Full change procedure: docs/ADMIN-COMPLETE-GUIDE.md
# =============================================================================
# =============================================================================
# ado-pr-create — Create a Pull Request in Azure DevOps via REST API
#
# Optional convenience helper for creating an Azure DevOps PR. Git/branch
# governance itself is delegated to Azure DevOps permissions and policies.
#
# Usage:
#   ado-pr-create --org ORG --project PROJECT --repo REPO \
#     --title "feat: add X" --source feature/my-branch
#
# Options:
#   --title         PR title (required)
#   --source        Source branch (required; e.g. feature/ai-agent-change)
#   --target        Target branch (default: main)
#   --description   PR description
#   --reviewers     Comma-separated ADO user UPNs (e.g. user@org.com,user2@org.com)
#   --draft         Create as draft PR
#   --auto-complete Set auto-complete (merges when all checks pass)
#
# ADO PAT is broker-managed and never returned to the AI container. The helper itself runs locally and uses the fixed credential-proxy route. Target
# org/project/repo are explicit command arguments; they are not stored in SSM.
# =============================================================================
set -euo pipefail
umask 027

TITLE=""; SOURCE=""; TARGET="main"; DESCRIPTION=""; REVIEWERS=""; DRAFT=false; AUTO_COMPLETE=false
ORG=""; PROJECT=""; REPO=""
while [[ $# -gt 0 ]]; do
  case "$1" in
    --title) TITLE="$2"; shift 2 ;; --source) SOURCE="$2"; shift 2 ;; --target) TARGET="$2"; shift 2 ;;
    --description) DESCRIPTION="$2"; shift 2 ;; --reviewers) REVIEWERS="$2"; shift 2 ;;
    --draft) DRAFT=true; shift ;; --auto-complete) AUTO_COMPLETE=true; shift ;;
    --org) ORG="$2"; shift 2 ;; --project) PROJECT="$2"; shift 2 ;; --repo) REPO="$2"; shift 2 ;;
    *) echo "[ERROR] Unknown: $1"; exit 1 ;;
  esac
done
[[ -n "$TITLE" && -n "$SOURCE" && -n "$ORG" && -n "$PROJECT" && -n "$REPO" ]] || { echo '[ERROR] --title, --source, --org, --project and --repo are required'; exit 1; }
[[ "$SOURCE" != main && "$SOURCE" != master ]] || { echo '[ERROR] Cannot create PR from main/master as source branch.'; exit 1; }

# The helper runs locally. The broker route injects ADO_PAT into outbound HTTP;
# no PAT is present in this process, argv, environment, config, or output.
LOCAL="http://127.0.0.1:8771"
BASE="${LOCAL}/ado/dev/${ORG}/${PROJECT}/_apis"
VSSPS="${LOCAL}/ado/vssps/${ORG}/_apis"

REVIEWER_JSON="[]"
if [[ -n "$REVIEWERS" ]]; then
  REVIEWER_JSON="["; FIRST=true
  IFS=',' read -ra UPN_LIST <<< "$REVIEWERS"
  for upn in "${UPN_LIST[@]}"; do
    upn="$(echo "$upn" | xargs)"
    encoded_upn="$(python3 -c 'import sys,urllib.parse; print(urllib.parse.quote(sys.argv[1], safe=""))' "$upn")"
    DESC=$(curl --noproxy '*' -fsS "${VSSPS}/identities?searchFilter=MailAddress&filterValue=${encoded_upn}&api-version=7.1" | jq -r '.value[0].id // empty') || DESC=''
    if [[ -n "$DESC" ]]; then
      [[ "$FIRST" == false ]] && REVIEWER_JSON+=","; REVIEWER_JSON+="{\"id\":\"${DESC}\"}"; FIRST=false
    else
      echo "[WARN] Could not resolve reviewer: $upn"
    fi
  done
  REVIEWER_JSON+="]"
fi

BODY=$(jq -n --arg title "$TITLE" --arg description "$DESCRIPTION" --arg source "refs/heads/$SOURCE" --arg target "refs/heads/$TARGET" --argjson draft "$DRAFT" --argjson reviewers "$REVIEWER_JSON" '{title:$title,description:$description,sourceRefName:$source,targetRefName:$target,isDraft:$draft,reviewers:$reviewers}')
echo "[ado-pr-create] Creating PR: '$TITLE'"
echo "  ${SOURCE} -> ${TARGET}  (draft: $DRAFT)"
RESPONSE=$(curl --noproxy '*' -fsS -X POST "${BASE}/git/repositories/${REPO}/pullrequests?api-version=7.1" -H 'Content-Type: application/json' -d "$BODY") || { echo '[ERROR] PR creation request failed'; exit 1; }
PR_ID=$(jq -r '.pullRequestId // empty' <<<"$RESPONSE"); PR_URL=$(jq -r '._links.web.href // empty' <<<"$RESPONSE")
[[ -n "$PR_ID" ]] || { echo '[ERROR] PR creation failed:'; jq . <<<"$RESPONSE"; exit 1; }
printf '\n[OK] PR created:\n  PR ID: %s\n  URL:   %s\n' "$PR_ID" "$PR_URL"

if [[ "$AUTO_COMPLETE" == true ]]; then
  SELF_ID=$(curl --noproxy '*' -fsS "${VSSPS}/profile/profiles/me?api-version=7.1" | jq -r '.id')
  curl --noproxy '*' -fsS -X PATCH "${BASE}/git/repositories/${REPO}/pullrequests/${PR_ID}?api-version=7.1" \
    -H 'Content-Type: application/json' \
    -d "{\"autoCompleteSetBy\":{\"id\":\"${SELF_ID}\"},\"completionOptions\":{\"deleteSourceBranch\":true,\"mergeStrategy\":\"squash\"}}" >/dev/null
  echo '  Auto-complete: enabled (squash merge, delete source branch)'
fi
