#!/usr/bin/env bash
# =============================================================================
# PACKAGE MAINTENANCE NOTES
# Purpose: Bash workflow for triggering approved Azure DevOps pipeline operations.
# Admin maintenance: Update only for ADO API/workflow changes; keep the PowerShell peer behaviorally equivalent.
# Safety rule: preserve secret-free images/configuration, immutable version or
# digest pinning where applicable, and update the paired Bash/PowerShell path.
# After any change, run scripts/ci/lint-package.* and the applicable build/QA.
# Full change procedure: docs/ADMIN-COMPLETE-GUIDE.md
# =============================================================================
# =============================================================================
# ado-trigger — AI Sandbox ADO Pipeline Trigger Helper
#
# Triggers an Azure DevOps pipeline via REST API and optionally tails the run.
# Public/AI-side authentication is credential-free: the helper runs locally and sends only approved REST requests through the credential broker, which injects ADO_PAT upstream. Org/project are explicit CLI targets
# and are not stored in SSM.
#
# Usage:
#   ado-trigger --org ORG --project PROJECT --pipeline-id <id> [options]
#
# Options:
#   --pipeline-id  Pipeline definition ID (integer)
#   --branch       Source branch (default: main)
#   --params       JSON string of template parameters, e.g. '{"env":"staging"}'
#   --wait         Wait for the run to complete and exit with its status
#
# Example:
#   ado-trigger --pipeline-id 42 --branch feature/my-branch \
#     --params '{"deploy_env":"dev"}' --wait
#
# Internal broker note: only ADO_PAT is injected after argument validation.
# Org/project are caller-selected Azure DevOps targets and are not secrets.
# =============================================================================
set -euo pipefail
umask 027
ORG=""; PROJECT=""; PIPELINE_ID=""; BRANCH="main"; PARAMS="{}"; WAIT=false
while [[ $# -gt 0 ]]; do
  case "$1" in
    --org) ORG="$2"; shift 2 ;; --project) PROJECT="$2"; shift 2 ;; --pipeline-id) PIPELINE_ID="$2"; shift 2 ;;
    --branch) BRANCH="$2"; shift 2 ;; --params) PARAMS="$2"; shift 2 ;; --wait) WAIT=true; shift ;;
    -h|--help) sed -n '3,40p' "$0" | grep '^#' | sed 's/^# \?//'; exit 0 ;;
    *) echo "[ERROR] Unknown argument: $1"; exit 1 ;;
  esac
done
[[ -n "$ORG" && -n "$PROJECT" && -n "$PIPELINE_ID" ]] || { echo '[ERROR] --org, --project and --pipeline-id are required'; exit 1; }
[[ "$PIPELINE_ID" =~ ^[0-9]+$ ]] && (( PIPELINE_ID > 0 )) || { echo '[ERROR] --pipeline-id must be a positive integer'; exit 1; }
jq -e 'type == "object"' >/dev/null 2>&1 <<<"$PARAMS" || { echo '[ERROR] --params must be a valid JSON object'; exit 1; }
LOCAL="http://127.0.0.1:8771"
BASE_URL="${LOCAL}/ado/dev/${ORG}/${PROJECT}/_apis"; API_VERSION='api-version=7.1'
BODY=$(jq -n --argjson params "$PARAMS" --arg branch "refs/heads/$BRANCH" '{resources:{repositories:{self:{refName:$branch}}},templateParameters:$params}')
echo "[ado-trigger] Triggering pipeline ${PIPELINE_ID} on branch '${BRANCH}'..."
RESPONSE=$(curl --noproxy '*' -fsS -X POST "${BASE_URL}/pipelines/${PIPELINE_ID}/runs?${API_VERSION}" -H 'Content-Type: application/json' -d "$BODY") || { echo '[ERROR] Pipeline trigger request failed'; exit 1; }
RUN_ID=$(jq -r '.id // empty' <<<"$RESPONSE"); RUN_URL=$(jq -r '._links.web.href // empty' <<<"$RESPONSE"); STATE=$(jq -r '.state // empty' <<<"$RESPONSE")
[[ -n "$RUN_ID" ]] || { echo '[ERROR] Pipeline trigger failed:'; jq . <<<"$RESPONSE"; exit 1; }
printf '[ado-trigger] Run created:\n  Run ID: %s\n  State:  %s\n  URL:    %s\n' "$RUN_ID" "$STATE" "$RUN_URL"
if [[ "$WAIT" == true ]]; then
  POLL_INTERVAL=15; TIMEOUT=1800; ELAPSED=0
  while true; do
    sleep "$POLL_INTERVAL"; ELAPSED=$((ELAPSED+POLL_INTERVAL))
    STATUS=$(curl --noproxy '*' -fsS "${BASE_URL}/pipelines/${PIPELINE_ID}/runs/${RUN_ID}?${API_VERSION}") || { echo '[ERROR] Pipeline status request failed'; exit 1; }
    STATE=$(jq -r '.state' <<<"$STATUS"); RESULT=$(jq -r '.result // "unknown"' <<<"$STATUS")
    echo "  [${ELAPSED}s] state=${STATE} result=${RESULT}"
    if [[ "$STATE" == completed ]]; then echo "[ado-trigger] Run completed: $RESULT"; [[ "$RESULT" == succeeded ]] && exit 0 || exit 1; fi
    (( ELAPSED < TIMEOUT )) || { echo "[ERROR] Timeout after ${TIMEOUT}s"; exit 1; }
  done
fi
