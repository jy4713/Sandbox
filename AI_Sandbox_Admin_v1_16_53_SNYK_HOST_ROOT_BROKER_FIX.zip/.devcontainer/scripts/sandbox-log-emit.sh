#!/usr/bin/env bash
# =============================================================================
# PACKAGE MAINTENANCE NOTES
# Purpose: Append structured records to the container's PID1 stdout. Docker owns
#          the retained log stream; the DevContainer receives no writable
#          audit/access/content log filesystem mount.
# Security: /proc/1/fd/1 is a stream, not a seekable log file, so prior records
#           cannot be edited or truncated through the container filesystem.
# Performance: Serialization is acquired and released for EACH record. Never
#              hold the flock while waiting for a long-lived input stream (for
#              example Gemini telemetry), because that would stall interactive
#              shell audit records until the producer exits. Interactive shell
#              metadata has a shorter bounded wait than required application
#              audit, and source validation uses Bash built-ins only.
# Usage:   printf '%s\n' '<record>' | sandbox-log-emit <stream> [source]
# =============================================================================
set -euo pipefail
set +x
umask 077

stream="${1:-}"
source_name="${2:-sandbox}"
target="/proc/1/fd/1"
lock_timeout="1"

case "$stream" in
  audit|security|application|claude-events|content|gemini-telemetry|verification) ;;
  *) echo "ERROR: unsupported sandbox log stream: $stream" >&2; exit 2 ;;
esac

# Stream is already allowlisted above. Source identifiers are metadata labels,
# not arbitrary payloads: reject malformed values instead of spawning external sanitizers on
# every interactive command.
if [[ ! "$source_name" =~ ^[A-Za-z0-9._:-]{1,64}$ ]]; then
  echo "ERROR: invalid sandbox log source identifier" >&2
  exit 2
fi

# Post-command shell audit is explicitly best-effort so it must never make a
# normal prompt wait for the full required-audit window. Application audit keeps
# the one-second fail-closed delivery window in application-audit.sh.
if [[ "$source_name" == "shell" && ( "$stream" == "audit" || "$stream" == "security" ) ]]; then
  lock_timeout="0.2"
fi

while IFS= read -r line || [[ -n "$line" ]]; do
  # Open the existing /tmp directory inode only as an advisory lock anchor.
  # Reopen it for each record; closing FD 9 releases the lock without spawning a
  # second `flock -u` process. Long-lived producers therefore hold no lock while
  # waiting for their next input record.
  exec 9</tmp
  if ! flock -w "$lock_timeout" -x 9; then
    exec 9>&-
    echo "ERROR: sandbox log serialization timeout for stream: $stream" >&2
    exit 75
  fi
  if ! printf 'AI_SANDBOX_LOG|%s|%s|%s\n' "$stream" "$source_name" "$line" >> "$target"; then
    exec 9>&-
    echo "ERROR: sandbox log sink write failed for stream: $stream" >&2
    exit 74
  fi
  # flock(2) is associated with the inherited open file description. Closing the
  # shell's FD releases the record lock when the flock helper has exited.
  exec 9>&-
done
