#!/usr/bin/env python3
"""Admin Tavily CLI policy wrapper.

This is defense in depth for the public `tvly` command. Claude/Gemini web search
is expected to use Tavily MCP, whose stdio proxy is the hard MCP enforcement
point. This wrapper applies the same allowlist if a Developer invokes `tvly`.
No query, URL content, results, or credentials are logged.
"""
from __future__ import annotations

import json
import os
import re
import sys
from pathlib import Path
from urllib.parse import urlparse

POLICY = Path('/etc/ai-sandbox/policies/tavily-allowed-domains.json')
DOMAIN_TOKEN_RE = re.compile(r"(?i)(?<![@a-z0-9_.-])(?:https?://)?(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}(?::\d+)?(?:/[^\s\"'<>]*)?")


def fail(msg: str, code: int = 2) -> None:
    print(f'ERROR: {msg}', file=sys.stderr)
    raise SystemExit(code)


def load_allowed() -> tuple[str, ...]:
    try:
        raw = json.loads(POLICY.read_text(encoding='utf-8'))['allowed_domains']
    except Exception as exc:
        fail(f'cannot load Admin Tavily policy: {exc}', 1)
    if not isinstance(raw, list) or not raw:
        fail('Admin Tavily policy has no allowed domains', 1)
    out = []
    for v in raw:
        if not isinstance(v, str):
            fail('Admin Tavily policy contains an invalid domain', 1)
        d = v.strip().lower().rstrip('.')
        if not re.fullmatch(r'[a-z0-9.-]+', d) or '..' in d:
            fail('Admin Tavily policy contains an invalid domain', 1)
        out.append(d)
    return tuple(dict.fromkeys(out))


ALLOWED = load_allowed()


def host(value: str) -> str:
    v = value.strip().lower()
    if v.startswith('*.'):
        v = v[2:]
    if '://' in v:
        return (urlparse(v).hostname or '').lower().rstrip('.')
    return v.split('/', 1)[0].split(':', 1)[0].rstrip('.')


def allowed_host(h: str) -> bool:
    return bool(h) and any(h == a or h.endswith('.' + a) for a in ALLOWED)


def explicit_domains(text: str) -> list[str]:
    out = []
    for m in DOMAIN_TOKEN_RE.finditer(text):
        h = host(m.group(0))
        if h:
            out.append(h)
    return list(dict.fromkeys(out))


def require_https_url(v: str) -> str:
    p = urlparse(v)
    h = (p.hostname or '').lower().rstrip('.')
    if p.scheme != 'https' or not allowed_host(h):
        fail('Tavily URL is outside the Admin allowlist')
    return h


def normalize_search(args: list[str]) -> list[str]:
    # args starts with `search`. Explicit hostnames in the search request are
    # policy input too: an unapproved hostname must be denied rather than being
    # silently rewritten to some other allowed source.
    result = list(args)
    query_text = args[1] if len(args) > 1 and not args[1].startswith('-') else ''
    query_domains = explicit_domains(query_text)
    blocked = [d for d in query_domains if not allowed_host(d)]
    if blocked:
        fail('Tavily search explicitly requests a domain outside the Admin allowlist')
    found = False
    i = 1
    while i < len(result):
        a = result[i]
        if a == '--include-domains':
            if i + 1 >= len(result):
                fail('--include-domains requires a value')
            domains = [x.strip() for x in result[i + 1].split(',') if x.strip()]
            if not domains or any(not allowed_host(host(d)) for d in domains):
                fail('Tavily include-domains contains a domain outside the Admin allowlist')
            result[i + 1] = ','.join(dict.fromkeys(host(d) for d in domains))
            found = True
            i += 2
            continue
        if a.startswith('--include-domains='):
            domains = [x.strip() for x in a.split('=', 1)[1].split(',') if x.strip()]
            if not domains or any(not allowed_host(host(d)) for d in domains):
                fail('Tavily include-domains contains a domain outside the Admin allowlist')
            result[i] = '--include-domains=' + ','.join(dict.fromkeys(host(d) for d in domains))
            found = True
        i += 1
    if not found:
        result.extend(['--include-domains', ','.join(query_domains or ALLOWED)])
    return result


def normalize_extract(args: list[str]) -> list[str]:
    # Official syntax places one or more URLs immediately after `extract`.
    urls = []
    for a in args[1:]:
        if a.startswith('-'):
            break
        urls.append(a)
    if not urls:
        fail('Tavily extract requires an approved HTTPS URL')
    for u in urls:
        require_https_url(u)
    return args


def remove_option(args: list[str], name: str, takes_value: bool) -> list[str]:
    out = []
    i = 0
    while i < len(args):
        a = args[i]
        if a == name:
            i += 2 if takes_value and i + 1 < len(args) else 1
            continue
        if takes_value and a.startswith(name + '='):
            i += 1
            continue
        out.append(a)
        i += 1
    return out


def normalize_crawl_map(args: list[str]) -> list[str]:
    if len(args) < 2:
        fail(f'Tavily {args[0]} requires an approved HTTPS root URL')
    h = require_https_url(args[1])
    out = list(args)
    out = remove_option(out, '--allow-external', False)
    out = remove_option(out, '--no-external', False)
    out = remove_option(out, '--select-domains', True)
    # Force same-host traversal only.
    out.extend(['--no-external', '--select-domains', '^' + re.escape(h) + '$'])
    return out


def main() -> int:
    if len(sys.argv) < 2:
        fail('usage: tavily-cli-policy.py <real-tvly> [command] [args...]')
    real = sys.argv[1]
    args = sys.argv[2:]
    if not args:
        # Interactive REPL cannot be pre-constrained to the Admin domain allowlist,
        # so this is the one native invocation shape intentionally denied by the
        # Tavily allow-domain policy. All non-content/admin commands otherwise
        # pass through unchanged.
        fail('Tavily interactive mode is disabled because Admin allowed domains cannot be enforced in the REPL')
    cmd = args[0]
    if cmd == 'search':
        args = normalize_search(args)
    elif cmd == 'extract':
        args = normalize_extract(args)
    elif cmd in {'crawl', 'map'}:
        args = normalize_crawl_map(args)
    elif cmd == 'research':
        # Tavily CLI 0.1.6 exposes no domain filter for research. Letting this
        # start would bypass the only intended application policy in the
        # Sandbox, so research remains denied specifically for domain-policy
        # reasons. This is not a generic command allowlist.
        fail('Tavily research is disabled because it cannot be constrained to the Admin domain allowlist')
    else:
        # Preserve the vendor CLI contract for auth/login/logout/status and any
        # other native non-domain command. The wrapper does not maintain a
        # separate Tavily subcommand allowlist.
        pass
    os.execvpe(real, [real, *args], os.environ.copy())
    return 127


if __name__ == '__main__':
    raise SystemExit(main())
