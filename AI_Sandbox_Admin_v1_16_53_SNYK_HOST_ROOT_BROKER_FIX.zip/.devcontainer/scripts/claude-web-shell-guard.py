#!/usr/bin/env python3
"""Claude PreToolUse guard preventing direct web/Tavily policy bypass via Bash."""
import json
import re
import sys


def deny(reason: str) -> None:
    print(json.dumps({'hookSpecificOutput': {
        'hookEventName': 'PreToolUse',
        'permissionDecision': 'deny',
        'permissionDecisionReason': reason,
    }}))
    raise SystemExit(0)


data = json.load(sys.stdin)
if data.get('tool_name') != 'Bash':
    print('{}')
    raise SystemExit(0)
command = str((data.get('tool_input') or {}).get('command', ''))
# Wrapped `tvly` and `tavily-mcp` commands are allowed: they execute the native
# vendor process locally and enforce the Admin domain allowlist. Block only
# explicit bypass paths that invoke the stashed vendor binary directly.
patterns = [
    r'/usr/local/libexec/ai-sandbox/real/(?:tvly|tavily-mcp)(?:\s|$)',
    r'(?:/usr/local/bin/)?secret-broker-client\s+--tool\s+tavily-cli(?:\s|$)',
]
if any(re.search(p, command) for p in patterns):
    deny('Admin Tavily domain policy: direct vendor-binary bypass is disabled. Use the normal wrapped tvly/Tavily MCP command.')
print('{}')
