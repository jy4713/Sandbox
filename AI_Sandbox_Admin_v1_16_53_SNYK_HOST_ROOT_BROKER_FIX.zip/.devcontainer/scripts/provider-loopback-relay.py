#!/usr/bin/env python3
"""Credential-free localhost TCP relay to the trusted provider broker.

Gemini CLI permits plain HTTP custom base URLs only for loopback hosts. This
relay exposes 127.0.0.1 only and forwards opaque bytes to secret-broker:8770.
It never parses, logs, or stores prompts, responses, headers, or credentials.
"""
from __future__ import annotations
import os
import selectors
import socket
import socketserver

LISTEN_HOST = "127.0.0.1"
LISTEN_PORT = int(os.environ.get("SANDBOX_PROVIDER_LOOPBACK_PORT", "8771"))
UPSTREAM_HOST = os.environ.get("SANDBOX_SECRET_BROKER_HOST", "secret-broker")
UPSTREAM_PORT = int(os.environ.get("SANDBOX_SECRET_BROKER_HTTP_PORT", "8770"))


def relay(a: socket.socket, b: socket.socket) -> None:
    sel = selectors.DefaultSelector()
    sel.register(a, selectors.EVENT_READ, b)
    sel.register(b, selectors.EVENT_READ, a)
    try:
        while True:
            events = sel.select(timeout=60)
            if not events:
                continue
            for key, _ in events:
                src: socket.socket = key.fileobj
                dst: socket.socket = key.data
                try:
                    data = src.recv(65536)
                except OSError:
                    return
                if not data:
                    try: dst.shutdown(socket.SHUT_WR)
                    except OSError: pass
                    return
                try:
                    dst.sendall(data)
                except OSError:
                    return
    finally:
        sel.close()


class Handler(socketserver.BaseRequestHandler):
    def handle(self) -> None:
        try:
            upstream = socket.create_connection((UPSTREAM_HOST, UPSTREAM_PORT), timeout=10)
        except OSError:
            return
        with upstream:
            relay(self.request, upstream)


class Server(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True


if __name__ == "__main__":
    if os.environ.get("AI_SANDBOX_ROLE") != "client":
        raise SystemExit("provider loopback relay is client-only")
    with Server((LISTEN_HOST, LISTEN_PORT), Handler) as server:
        server.serve_forever(poll_interval=0.5)
