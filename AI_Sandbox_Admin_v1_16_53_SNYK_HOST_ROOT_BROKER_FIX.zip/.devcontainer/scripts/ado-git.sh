#!/usr/bin/env bash
# Compatibility alias: execute the same local ADO Git policy as transparent git.
set -euo pipefail
exec /usr/local/libexec/ai-sandbox/ado-git-policy /usr/bin/git "$@"
