#!/usr/bin/env bash
# Retired compatibility guard - AI Secure Sandbox v1.16.53.
# ADO_PAT is never exposed to Git or to the devcontainer. Local Git is rewritten
# to the loopback ADO route and the credential broker injects HTTP Basic auth.
set -euo pipefail
set +x
echo 'ERROR: git-askpass-ado is retired; ADO authentication is injected by the credential-only HTTP broker.' >&2
exit 126
