#!/usr/bin/env bash
# Local Snyk MCP launcher. The Snyk process and filesystem access stay in the
# DevContainer. General API and Code API traffic use the same validated local
# aliases as the CLI; the real SNYK_TOKEN remains in the credential broker.
set -euo pipefail
set +x
umask 027
. /usr/local/libexec/ai-sandbox/mcp-wrapper-preamble
readonly REAL_SNYK="/usr/local/libexec/ai-sandbox/real/snyk"
readonly ROOT="/run/ai-sandbox-snyk"
readonly SNYK_API_BASE="http://api.snyk.local:8771"
readonly SNYK_CODE_BASE="http://deeproxy.snyk.local:8771"
[[ -x "$REAL_SNYK" && -d "$ROOT" && -w "$ROOT" ]] || { echo 'ERROR: Snyk local runtime unavailable' >&2; exit 1; }
h="$(mktemp -d "$ROOT/mcp-home.XXXXXX")"; trap 'rm -rf "$h"' EXIT; chmod 0700 "$h"; mkdir -p "$h/.cache" "$h/.config"
if [[ -d /opt/snyk-cache ]]; then cp -a /opt/snyk-cache "$h/.cache/snyk" 2>/dev/null || true; chmod -R u+rwX "$h/.cache/snyk" 2>/dev/null || true; fi
snyk_no_proxy="api.snyk.local,deeproxy.snyk.local${NO_PROXY:+,$NO_PROXY}"
start_ms="$(date +%s%3N)"; application-audit --app mcp --event server_start --operation snyk --target snyk --status started --transport stdio || true
set +e
if (( $# == 0 )); then
  env HOME="$h" XDG_CACHE_HOME="$h/.cache" XDG_CONFIG_HOME="$h/.config" \
    SNYK_TOKEN=ai-sandbox-broker-placeholder \
    SNYK_API="$SNYK_API_BASE" DEEPROXY_API_URL="$SNYK_CODE_BASE" \
    SNYK_HTTP_PROTOCOL_UPGRADE=0 \
    NO_PROXY="$snyk_no_proxy" no_proxy="$snyk_no_proxy" \
    SNYK_DISABLE_ANALYTICS=1 \
    "$REAL_SNYK" mcp -t stdio
else
  env HOME="$h" XDG_CACHE_HOME="$h/.cache" XDG_CONFIG_HOME="$h/.config" \
    SNYK_TOKEN=ai-sandbox-broker-placeholder \
    SNYK_API="$SNYK_API_BASE" DEEPROXY_API_URL="$SNYK_CODE_BASE" \
    SNYK_HTTP_PROTOCOL_UPGRADE=0 \
    NO_PROXY="$snyk_no_proxy" no_proxy="$snyk_no_proxy" \
    SNYK_DISABLE_ANALYTICS=1 \
    "$REAL_SNYK" mcp "$@"
fi
ec=$?
set -e
end_ms="$(date +%s%3N)"; status=success; (( ec == 0 )) || status=failure
application-audit --app mcp --event server_end --operation snyk --target snyk --status "$status" --exit-code "$ec" --duration-ms "$((end_ms-start_ms))" --transport stdio || true
exit "$ec"
