#!/usr/bin/env bash
# Local Databricks SQL MCP bridge. mcp-remote runs in the devcontainer and the
# broker injects the SSM-backed PAT when forwarding to the fixed SQL MCP URL.
set -euo pipefail
set +x
umask 027
. /usr/local/libexec/ai-sandbox/mcp-wrapper-preamble
readonly REAL_MCP_REMOTE="/usr/local/libexec/ai-sandbox/real/mcp-remote"
readonly URL="http://127.0.0.1:8771/databricks/sql-mcp"
[[ -x "$REAL_MCP_REMOTE" ]] || { echo 'ERROR: real mcp-remote executable is missing' >&2; exit 1; }
start_ms="$(date +%s%3N)"; application-audit --app mcp --event server_start --operation databricks-sql --target databricks-sql --status started --transport stdio || true
set +e
"$REAL_MCP_REMOTE" "$URL" --silent --enable-proxy --transport http-only "$@"
ec=$?
set -e
end_ms="$(date +%s%3N)"; status=success; (( ec == 0 )) || status=failure
application-audit --app mcp --event server_end --operation databricks-sql --target databricks-sql --status "$status" --exit-code "$ec" --duration-ms "$((end_ms-start_ms))" --transport stdio || true
exit "$ec"
