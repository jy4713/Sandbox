#!/usr/bin/env bash
# Local Tavily MCP launcher. Policy + MCP relay run in the devcontainer; the
# credential broker only adds the SSM-backed key to the upstream HTTP request.
set -euo pipefail
set +x
umask 027
. /usr/local/libexec/ai-sandbox/mcp-wrapper-preamble
readonly REAL_MCP_REMOTE="/usr/local/libexec/ai-sandbox/real/mcp-remote"
readonly POLICY_PROXY="/usr/local/libexec/ai-sandbox/tavily-policy-proxy.py"
readonly URL="http://127.0.0.1:8771/tavily-mcp"
[[ -x "$REAL_MCP_REMOTE" && -x "$POLICY_PROXY" ]] || { echo 'ERROR: Tavily MCP runtime component missing' >&2; exit 1; }
start_ms="$(date +%s%3N)"; application-audit --app mcp --event server_start --operation tavily --target tavily --status started --transport stdio || true
set +e
"$POLICY_PROXY" "$REAL_MCP_REMOTE" "$URL" --silent --enable-proxy --transport http-only "$@"
ec=$?
set -e
end_ms="$(date +%s%3N)"; status=success; (( ec == 0 )) || status=failure
application-audit --app mcp --event server_end --operation tavily --target tavily --status "$status" --exit-code "$ec" --duration-ms "$((end_ms-start_ms))" --transport stdio || true
exit "$ec"
