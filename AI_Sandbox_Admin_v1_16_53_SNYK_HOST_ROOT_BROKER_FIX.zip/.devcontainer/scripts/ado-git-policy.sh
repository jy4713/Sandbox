#!/usr/bin/env bash
# Azure DevOps credential-route adapter executed locally in the DevContainer.
#
# Native Git argv is preserved. This script only adds the Admin-managed URL
# rewrite needed to send dev.azure.com HTTPS authentication through the local
# credential broker. The real /usr/bin/git process remains uid/gid 1000 and the
# ADO PAT never enters the Git process.
set -euo pipefail
set +x

readonly REAL_GIT="/usr/bin/git"
readonly ADO_POLICY_FILE="/etc/ai-sandbox/policies/ado-policy.json"
[[ "${1:-}" == "$REAL_GIT" ]] || { echo 'ERROR: ADO Git adapter requires the pinned git executable' >&2; exit 2; }
shift

command -v jq >/dev/null 2>&1 || exec "$REAL_GIT" "$@"
[[ -r "$ADO_POLICY_FILE" ]] || exec "$REAL_GIT" "$@"

ADO_REPOSITORY_HOST="$(jq -er '.git.repository_host | ascii_downcase' "$ADO_POLICY_FILE")" || exec "$REAL_GIT" "$@"
LOCAL_ADO_BASE="$(jq -er '.git.broker_base' "$ADO_POLICY_FILE")" || exec "$REAL_GIT" "$@"
ADO_REWRITE_ORIGIN="$(jq -er '.git.rewrite_origin' "$ADO_POLICY_FILE")" || exec "$REAL_GIT" "$@"
readonly ADO_REPOSITORY_HOST LOCAL_ADO_BASE ADO_REWRITE_ORIGIN

[[ "$ADO_REPOSITORY_HOST" =~ ^[a-z0-9.-]+$ && "$ADO_REPOSITORY_HOST" != *..* ]] || { echo 'ERROR: invalid Admin ADO repository host policy' >&2; exit 2; }
[[ "$ADO_REWRITE_ORIGIN" == "https://${ADO_REPOSITORY_HOST}/" ]] || { echo 'ERROR: ADO rewrite origin and repository host policy are inconsistent' >&2; exit 2; }
[[ "$LOCAL_ADO_BASE" == http://127.0.0.1:8771/ado/*/ ]] || { echo 'ERROR: ADO broker route must remain on the fixed loopback broker' >&2; exit 2; }
ADO_BROKER_PREFIX="/${LOCAL_ADO_BASE#http://127.0.0.1:8771/}"
ADO_BROKER_PREFIX="/${ADO_BROKER_PREFIX#/}"; ADO_BROKER_PREFIX="${ADO_BROKER_PREFIX%/}"
readonly ADO_BROKER_PREFIX
jq -e --arg prefix "$ADO_BROKER_PREFIX" --arg origin "https://${ADO_REPOSITORY_HOST}" \
  '.broker_routes | any(.prefix == $prefix and .upstream_origin == $origin and .credential_parameter == "ado-pat" and .auth_kind == "ado")' \
  "$ADO_POLICY_FILE" >/dev/null || { echo 'ERROR: ADO Git and broker route policy are inconsistent' >&2; exit 2; }

# Preserve native Git behaviour. The only injected Git configuration is the URL
# rewrite required for brokered ADO authentication. No subcommand, option,
# refspec, hook, transport or repository-local configuration is rejected here.
rewrite_args=(-c "url.${LOCAL_ADO_BASE}.insteadOf=${ADO_REWRITE_ORIGIN}")

collect_user_prefix() {
  local u="${1:-}" authority userinfo host
  # Also inspect the value portion of native -c key=https://user@dev.azure.com/...
  [[ "$u" == *=https://* ]] && u="${u#*=}"
  [[ "$u" == https://* ]] || return 0
  authority="${u#https://}"; authority="${authority%%/*}"
  [[ "$authority" == *@* ]] || return 0
  userinfo="${authority%@*}"; host="${authority##*@}"
  [[ "${host,,}" == "$ADO_REPOSITORY_HOST" ]] || return 0
  [[ -n "$userinfo" && "$userinfo" != *:* ]] || return 0
  rewrite_args+=(-c "url.${LOCAL_ADO_BASE}.insteadOf=https://${userinfo}@${ADO_REPOSITORY_HOST}/")
}

for a in "$@"; do collect_user_prefix "$a"; done

# Read configured remotes only to add the username-form rewrite when required.
# This does not authorize or reject any Git operation.
workdir="$(pwd -P)"
args=("$@")
i=0
while (( i < ${#args[@]} )); do
  case "${args[$i]}" in
    -C)
      if (( i + 1 < ${#args[@]} )); then
        p="${args[$((i+1))]}"; [[ "$p" == /* ]] || p="$workdir/$p"
        if next="$(cd "$p" 2>/dev/null && pwd -P)"; then workdir="$next"; fi
        i=$((i+2)); continue
      fi
      ;;
    -C?*)
      p="${args[$i]#-C}"; [[ "$p" == /* ]] || p="$workdir/$p"
      if next="$(cd "$p" 2>/dev/null && pwd -P)"; then workdir="$next"; fi
      ;;
  esac
  i=$((i+1))
done

while IFS= read -r r; do
  while IFS= read -r u; do collect_user_prefix "$u"; done < <("$REAL_GIT" -C "$workdir" remote get-url --all "$r" 2>/dev/null || true)
  while IFS= read -r u; do collect_user_prefix "$u"; done < <("$REAL_GIT" -C "$workdir" remote get-url --push --all "$r" 2>/dev/null || true)
done < <("$REAL_GIT" -C "$workdir" remote 2>/dev/null || true)

export NO_PROXY="localhost,127.0.0.1${NO_PROXY:+,$NO_PROXY}"
export no_proxy="$NO_PROXY"
exec "$REAL_GIT" "${rewrite_args[@]}" "$@"
