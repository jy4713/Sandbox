#!/usr/bin/env bash
# =============================================================================
# PACKAGE MAINTENANCE NOTES
# Purpose: Write redacted structured application/integration audit events to the
#          Docker-owned append-only container log stream.
# Admin maintenance: Add a new application name to the allowlist only after its
#                    event fields have been reviewed for secret/content safety.
# Safety rule: Never pass tokens, prompts, response bodies, tool payloads,
#              source-code contents, URLs containing credentials, or raw command
#              arguments to this logger.
# =============================================================================
set -euo pipefail
set +x

DEVELOPER_ID_VALUE="${DEVELOPER_ID:-unknown}"
SANDBOX_ENV_VALUE="${SANDBOX_ENV:-unknown}"
AUDIT_REQUIRED="${SANDBOX_AUDIT_REQUIRED:-true}"

usage() {
  cat >&2 <<'USAGE'
Usage:
  application-audit --app <name> --event <event> [options]

Options:
  --operation <safe-operation-name>
  --target <safe-service/model/provider-name>
  --status <started|success|failure|denied|info>
  --exit-code <integer>
  --duration-ms <integer>
  --transport <safe-transport-name>

Allowed applications:
  anthropic, gemini, databricks, tavily, snyk, ado, hiddenlayer, mcp, git

This command accepts metadata only. Never pass secrets, prompts, responses,
search queries, source code, tool input/output, or complete command arguments.
USAGE
  exit 2
}

app="" event="" operation="" target="" status="info" exit_code="" duration_ms="" transport=""
while [[ $# -gt 0 ]]; do
  case "$1" in
    --app) app="${2:-}"; shift 2 ;;
    --event) event="${2:-}"; shift 2 ;;
    --operation) operation="${2:-}"; shift 2 ;;
    --target) target="${2:-}"; shift 2 ;;
    --status) status="${2:-}"; shift 2 ;;
    --exit-code) exit_code="${2:-}"; shift 2 ;;
    --duration-ms) duration_ms="${2:-}"; shift 2 ;;
    --transport) transport="${2:-}"; shift 2 ;;
    -h|--help) usage ;;
    *) echo "ERROR: unknown application-audit option: $1" >&2; usage ;;
  esac
done

[[ -n "$app" && -n "$event" ]] || usage
case "$app" in
  anthropic|gemini|databricks|tavily|snyk|ado|hiddenlayer|mcp|git) ;;
  *) echo "ERROR: unsupported audit application: $app" >&2; exit 2 ;;
esac

# Permit only short identifier-like metadata. This deliberately prevents callers
# from accidentally sending prompts, search queries, arbitrary command lines, or
# other free-form content into the SIEM audit stream.
safe_value() {
  local value="${1:-}" max="${2:-96}"
  [[ -z "$value" ]] && { printf ''; return 0; }
  # Managed callers use identifier-like values only. If a caller supplies
  # whitespace or free-form punctuation, replace the field instead of trying to
  # clean it, because cleaning could preserve sensitive prompt/query text.
  if [[ "$value" =~ [[:space:]] || ! "$value" =~ ^[A-Za-z0-9._:@/+\=-]+$ ]]; then
    printf 'redacted'
    return 0
  fi
  printf '%s' "${value:0:max}"
}

event="$(safe_value "$event" 64)"
operation="$(safe_value "$operation" 64)"
target="$(safe_value "$target" 128)"
status="$(safe_value "$status" 24)"
transport="$(safe_value "$transport" 32)"
[[ "$exit_code" =~ ^-?[0-9]+$ ]] || exit_code=""
[[ "$duration_ms" =~ ^[0-9]+$ ]] || duration_ms=""

record="$(jq -cn \
  --arg ts "$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
  --arg app "$app" \
  --arg event "$event" \
  --arg developer_id "$DEVELOPER_ID_VALUE" \
  --arg sandbox_env "$SANDBOX_ENV_VALUE" \
  --arg operation "$operation" \
  --arg target "$target" \
  --arg status "$status" \
  --arg exit_code "$exit_code" \
  --arg duration_ms "$duration_ms" \
  --arg transport "$transport" \
  --arg host "$(hostname)" \
  --arg pid "$$" '
  {
    ts:$ts,
    source:"ai-sandbox-application-audit",
    app:$app,
    event:$event,
    developer_id:$developer_id,
    sandbox_env:$sandbox_env,
    operation:$operation,
    target:$target,
    status:$status,
    exit_code:(if $exit_code=="" then null else ($exit_code|tonumber) end),
    duration_ms:(if $duration_ms=="" then null else ($duration_ms|tonumber) end),
    transport:$transport,
    host:$host,
    audit_writer_pid:($pid|tonumber)
  }
  | with_entries(select(.value != null and .value != ""))
')"

if ! printf '%s\n' "$record" | /usr/local/bin/sandbox-log-emit application "$app" 2>/dev/null; then
  if [[ "$AUDIT_REQUIRED" == "true" ]]; then
    echo "ERROR: unable to write required application audit stream for: $app" >&2
    exit 1
  fi
fi
