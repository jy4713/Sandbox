#!/usr/bin/env bash
# Transparent Git front-end for the AI DevContainer.
#
# Native Git argv is preserved. If the invocation explicitly references Azure
# DevOps, or runs inside a repository with an Azure DevOps remote, the same
# local /usr/bin/git process receives only an Admin URL rewrite to the localhost
# credential route. The PAT remains broker-only and Git is never command-gated.
set -euo pipefail
set +x

readonly REAL_GIT="/usr/bin/git"
readonly ADO_POLICY="/usr/local/libexec/ai-sandbox/ado-git-policy"
readonly ADO_POLICY_FILE="/etc/ai-sandbox/policies/ado-policy.json"

if [[ "${AI_SANDBOX_ROLE:-client}" != "client" ]]; then exec "$REAL_GIT" "$@"; fi
command -v jq >/dev/null 2>&1 || exec "$REAL_GIT" "$@"
[[ -r "$ADO_POLICY_FILE" ]] || exec "$REAL_GIT" "$@"
ADO_REPOSITORY_HOST="$(jq -er '.git.repository_host | ascii_downcase' "$ADO_POLICY_FILE" 2>/dev/null)" || exec "$REAL_GIT" "$@"
readonly ADO_REPOSITORY_HOST

(( $# > 0 )) || exec "$REAL_GIT"
original=("$@")

looks_like_ado_url() {
  local value="${1:-}" authority host
  # Native -c key=https://... forms are still ordinary Git argv; inspect only
  # the value to decide whether brokered ADO authentication may be needed.
  [[ "$value" == *=https://* ]] && value="${value#*=}"
  [[ "${value,,}" == https://* ]] || return 1
  authority="${value#*://}"; authority="${authority%%/*}"
  [[ -n "$authority" ]] || return 1
  host="${authority##*@}"
  [[ "${host,,}" == "$ADO_REPOSITORY_HOST" ]]
}

# Resolve -C only for routing inspection. The original -C argument remains in
# argv and is executed natively by /usr/bin/git.
workdir="$(pwd -P)"
i=0
while (( i < ${#original[@]} )); do
  case "${original[$i]}" in
    -C)
      if (( i + 1 < ${#original[@]} )); then
        p="${original[$((i+1))]}"; [[ "$p" == /* ]] || p="$workdir/$p"
        if next="$(cd "$p" 2>/dev/null && pwd -P)"; then workdir="$next"; fi
        i=$((i+2)); continue
      fi
      ;;
    -C?*)
      p="${original[$i]#-C}"; [[ "$p" == /* ]] || p="$workdir/$p"
      if next="$(cd "$p" 2>/dev/null && pwd -P)"; then workdir="$next"; fi
      ;;
  esac
  i=$((i+1))
done

needs_credential_route=false
for a in "${original[@]}"; do
  if looks_like_ado_url "$a"; then needs_credential_route=true; break; fi
done

# For any native Git command executed in an existing ADO repository, make the
# credential route available without trying to parse or allowlist subcommands.
if [[ "$needs_credential_route" == false ]]; then
  while IFS= read -r r; do
    while IFS= read -r u; do
      if looks_like_ado_url "$u"; then needs_credential_route=true; break 2; fi
    done < <("$REAL_GIT" -C "$workdir" remote get-url --all "$r" 2>/dev/null || true)
    while IFS= read -r u; do
      if looks_like_ado_url "$u"; then needs_credential_route=true; break 2; fi
    done < <("$REAL_GIT" -C "$workdir" remote get-url --push --all "$r" 2>/dev/null || true)
  done < <("$REAL_GIT" -C "$workdir" remote 2>/dev/null || true)
fi

[[ "$needs_credential_route" == true ]] || exec "$REAL_GIT" "${original[@]}"
exec "$ADO_POLICY" "$REAL_GIT" "${original[@]}"
