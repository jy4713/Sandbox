"""Runtime-only Tavily SDK patch for the credential broker loopback route.

Loaded via PYTHONPATH only by the Admin tvly wrapper. It keeps the official CLI
process in the devcontainer while forcing the SDK to the fixed local broker
endpoint. The value supplied as TAVILY_API_KEY is a non-secret placeholder; the
broker replaces its Authorization header with the SSM-backed key.
"""
from __future__ import annotations
import os

BROKER_BASE = "http://127.0.0.1:8771/tavily-api"
try:
    import tavily  # type: ignore
except Exception:
    tavily = None


def _patch(cls):
    if cls is None or getattr(cls, "__ai_sandbox_patched__", False):
        return
    original = cls.__init__
    def wrapped(self, *args, **kwargs):
        kwargs["api_base_url"] = BROKER_BASE
        if not kwargs.get("api_key"):
            kwargs["api_key"] = "ai-sandbox-broker-placeholder"
        return original(self, *args, **kwargs)
    cls.__init__ = wrapped
    cls.__ai_sandbox_patched__ = True

if tavily is not None:
    _patch(getattr(tavily, "TavilyClient", None))
    _patch(getattr(tavily, "AsyncTavilyClient", None))
