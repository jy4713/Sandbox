#!/usr/bin/env bash
# Initialize the credential-isolated AI client container.
set -uo pipefail
umask 027

echo '=============================================='
echo '  AI Secure Sandbox v1.16.53 - Container Init'
echo '=============================================='

# Ensure narrow writable vendor state exists even when persistent named volumes
# were created by an earlier Sandbox image. No credential is created here.
databricks_cfg_dir="${DATABRICKS_CONFIG_FILE:-$HOME/.local/share/databricks/.databrickscfg}"
databricks_cfg_dir="${databricks_cfg_dir%/*}"
if ! mkdir -p "$HOME/.tavily" "$HOME/.ucode" "$databricks_cfg_dir"; then
  echo 'ERROR: could not initialize writable Tavily/ucode/Databricks CLI state directories' >&2
  exit 1
fi
chmod 0750 "$HOME/.tavily" "$HOME/.ucode" "$databricks_cfg_dir" 2>/dev/null || true

git config --global safe.directory /home/vscode/workspace 2>/dev/null && echo '[1/4] Git safe.directory set' || echo '[1/4] WARN: could not set git safe.directory'

echo; echo '[2/4] Configuring credential-free MCP definitions'
if configure-mcp; then
  echo '  [OK] Tavily/Snyk/Databricks SQL MCP use local devcontainer processes with credential-only HTTP broker routes.'
else
  echo '  [FAIL] MCP configuration failed'
fi

echo; echo '[3/4] Credential-broker boundary check'
if env | grep -Eq '^AWS_(ACCESS_KEY_ID|SECRET_ACCESS_KEY|SESSION_TOKEN|SECURITY_TOKEN)='; then
  echo '  [FAIL] AWS credential environment variable is present in the AI container.'
  broker_status=FAILED
elif [[ -e /home/vscode/.aws/credentials || -e /home/vscode/.aws/sso/cache ]]; then
  echo '  [FAIL] AWS credential/cache material is present in the AI container.'
  broker_status=FAILED
elif curl --noproxy '*' -fsS --max-time 5 http://127.0.0.1:8771/healthz >/dev/null 2>&1; then
  echo '  [OK] AI container has no AWS credential material; credential-only broker is reachable through localhost.'
  broker_status=PASSED
else
  echo '  [FAIL] credential broker localhost health endpoint is not reachable.'
  broker_status=FAILED
fi

echo; echo '[4/4] Runtime security verification'
if verify-runtime; then verify_status=PASSED; else verify_status=FAILED; fi

echo
echo "Broker boundary: $broker_status"
echo "Runtime verification: $verify_status"
echo 'Developer workflow:'
echo '  1. On the WINDOWS HOST, the launcher creates/refreshes the temporary AWS profile.'
echo '  2. Only the credential-broker sidecar receives the host .aws directory read-only.'
echo '  3. Git, Claude, Gemini, ucode, Snyk, Tavily, Databricks CLI and all MCP processes'
echo '     execute inside the DevContainer as vscode (uid/gid 1000).'
echo '  4. Those local processes receive only fixed localhost endpoints and non-secret placeholders.'
echo '     The broker retrieves approved SSM values and injects authentication only while forwarding'
echo '     approved HTTP requests. It cannot execute developer commands and has no workspace mount.'

[[ "$verify_status" == FAILED || "$broker_status" == FAILED ]] && exit 1
