#!/usr/bin/env bash
set -euo pipefail
LOG_ROOT="${SANDBOX_LOG_ROOT:-/var/log/ai-sandbox-host}"
STATE_ROOT="${SANDBOX_MONITORING_STATE_ROOT:-/var/lib/ai-sandbox-monitoring}"
[[ "$(id -u)" == 0 ]] || { echo 'ERROR: run as root to protect host log ACLs.' >&2; exit 1; }
install -d -o root -g root -m 0755 "$LOG_ROOT" "$LOG_ROOT/devcontainer" "$LOG_ROOT/devcontainer/content" "$LOG_ROOT/squid"
install -d -o root -g root -m 0700 "$STATE_ROOT"
find "$LOG_ROOT" -type d -exec chmod 0755 {} +
find "$LOG_ROOT" -type f -exec chmod 0444 {} +
echo "[OK] Protected host log root: $LOG_ROOT"
echo "[OK] Monitoring state root: $STATE_ROOT"
echo 'Install scripts/monitoring/export-docker-logs-to-host.sh as a root-owned cron/systemd job.'
echo '[WARN] A host root administrator can still alter local evidence; use remote immutable retention.'
