#!/usr/bin/env bash
# =============================================================================
# PACKAGE MAINTENANCE NOTES
# Purpose:
#   Developer ECR launcher. Fetches the centrally approved manifest from
#   AWS SSM, validates the two approved ECR image references, pulls exact
#   DevContainer + Squid digests, creates local runtime aliases, and starts
#   Docker Compose.
#
# Logging:
#   Uses manifest-driven auto logging: POC can use a current-user host log root;
#   Production requires the Admin-protected root. Runtime mounts stay read-only.
# =============================================================================
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
ENV_FILE="$ROOT/.env"
COMPOSE="$ROOT/docker-compose.yml"

if [[ ! -f "$ENV_FILE" ]]; then
  cp "$ROOT/.env.example" "$ENV_FILE"
  echo "Created $ENV_FILE. Configure runtime values and rerun. AWS authentication is host-only: AUTO uses an existing static host profile first, otherwise Azure/Entra SAML browser login." >&2
  exit 2
fi

get_env() {
  sed -n "s/^$1=//p" "$ENV_FILE" | tail -n 1 | tr -d '\r'
}

configured_value() {
  local v="${1:-}"
  [[ -n "$v" && "$v" != *'<'* && "$v" != *'>'* && "$v" != *REPLACE_* && "$v" != yourname ]]
}

PROFILE="$(get_env SANDBOX_AWS_PROFILE)"; PROFILE="${PROFILE:-sandbox}"
REGION="$(get_env AWS_REGION)"; REGION="${REGION:-eu-north-1}"

set_env_value() {
  local key="$1" value="$2" tmp
  tmp="$(mktemp)"
  awk -v key="$key" -v value="$value" '
    BEGIN { found=0 }
    $0 ~ ("^" key "=") { print key "=" value; found=1; next }
    { print }
    END { if (!found) print key "=" value }
  ' "$ENV_FILE" > "$tmp"
  mv "$tmp" "$ENV_FILE"
}

assert_protected_log_root() {
  local log_root="$1" dev_dir content_dir squid_dir probe
  dev_dir="$log_root/devcontainer"
  content_dir="$log_root/devcontainer/content"
  squid_dir="$log_root/squid"
  for d in "$dev_dir" "$content_dir" "$squid_dir"; do
    [[ -d "$d" ]] || {
      echo "ERROR: protected host log directory is missing: $d" >&2
      exit 1
    }
    probe="$d/.developer-write-probe-$$-$RANDOM"
    if ( umask 077; : > "$probe" ) 2>/dev/null; then
      rm -f "$probe" || true
      echo "ERROR: current host user can write to protected log directory: $d" >&2
      exit 1
    fi
  done
}

initialize_host_log_root() {
  local sandbox_type="$1" requested mode log_root persist_root=0
  requested="$(get_env SANDBOX_LOG_MODE)"; requested="${requested:-auto}"; requested="${requested,,}"
  case "$requested" in auto|protected|poc-local) ;; *) echo "ERROR: SANDBOX_LOG_MODE must be auto, protected, or poc-local" >&2; exit 1 ;; esac
  if [[ "$sandbox_type" == production && "$requested" == poc-local ]]; then
    echo 'ERROR: Production manifests require protected host logging; SANDBOX_LOG_MODE=poc-local is not permitted.' >&2
    exit 1
  fi
  if [[ "$requested" == auto ]]; then
    [[ "$sandbox_type" == poc ]] && mode=poc-local || mode=protected
  else
    mode="$requested"
  fi
  log_root="$(get_env SANDBOX_LOG_ROOT)"
  if [[ "$mode" == poc-local ]]; then
    if ! configured_value "$log_root" || [[ "${log_root//\\//}" == C:/ProgramData/AI-Sandbox/Logs ]]; then
      log_root="$HOME/AI-Sandbox/Logs"
      persist_root=1
    fi
    mkdir -p "$log_root/devcontainer/content" "$log_root/squid" "$log_root/.monitoring"
    echo "WARN: POC LOCAL LOG MODE: host copies are writable by the current user: $log_root" >&2
  else
    configured_value "$log_root" || { echo 'ERROR: SANDBOX_LOG_ROOT is missing. Ask the Sandbox Admin to provision protected logging.' >&2; exit 1; }
    assert_protected_log_root "$log_root"
  fi
  export SANDBOX_LOG_ROOT="$log_root"
  if [[ "$persist_root" == 1 ]]; then
    set_env_value SANDBOX_LOG_ROOT "$log_root"
    echo "[OK] Persisted POC host log root in .env for future Compose recreation: $log_root"
  fi
  RESOLVED_LOG_MODE="$mode"
}

start_poc_local_exporter() {
  local log_root="$1" exporter state_file pid_file old_pid
  exporter="$ROOT/scripts/monitoring/export-docker-logs-to-host.sh"
  state_file="$log_root/.monitoring/host-log-export-state.json"
  pid_file="$log_root/.monitoring/poc-log-exporter.pid"
  AI_SANDBOX_ALLOW_NON_ROOT_LOG_EXPORT=true SANDBOX_LOG_ROOT="$log_root" SANDBOX_MONITORING_STATE_FILE="$state_file" "$exporter"
  if [[ -s "$pid_file" ]]; then
    old_pid="$(cat "$pid_file" 2>/dev/null || true)"
    if [[ "$old_pid" =~ ^[0-9]+$ ]] && kill -0 "$old_pid" 2>/dev/null; then
      echo "[OK] POC local log exporter is already running (PID $old_pid)."
      return
    fi
  fi
  (
    while true; do
      AI_SANDBOX_ALLOW_NON_ROOT_LOG_EXPORT=true SANDBOX_LOG_ROOT="$log_root" SANDBOX_MONITORING_STATE_FILE="$state_file" "$exporter" || true
      sleep 30
    done
  ) >>"$log_root/.monitoring/poc-log-exporter.out.log" 2>>"$log_root/.monitoring/poc-log-exporter.err.log" &
  echo $! > "$pid_file"
  echo "[OK] POC local log exporter started in background (PID $!, every 30 seconds)."
}

PREFIX="$(get_env SSM_PREFIX)"; PREFIX="${PREFIX:-/sandbox}"
REGISTRY="$(get_env ECR_REGISTRY)"
DEVELOPER_ID="$(get_env DEVELOPER_ID)"
MANIFEST_PARAMETER="$(get_env APPROVED_IMAGES_SSM_PARAMETER)"
MANIFEST_PARAMETER="${MANIFEST_PARAMETER:-${PREFIX%/}/runtime/approved-images-json}"

[[ -n "$REGISTRY" && -n "$DEVELOPER_ID" && "$DEVELOPER_ID" != yourname ]] || {
  echo 'ERROR: configure ECR_REGISTRY and DEVELOPER_ID in .env' >&2
  exit 1
}
REGISTRY="${REGISTRY%/}"

# Runtime records are Docker-owned stdout/stderr first, then a privileged host exporter writes protected host files. Containers mount those files read-only.

clear_aws_credential_provider_environment() {
  unset AWS_ACCESS_KEY_ID AWS_SECRET_ACCESS_KEY AWS_SESSION_TOKEN AWS_SECURITY_TOKEN
  unset AWS_PROFILE AWS_DEFAULT_PROFILE AWS_CONFIG_FILE AWS_SHARED_CREDENTIALS_FILE
  unset AWS_CONTAINER_CREDENTIALS_RELATIVE_URI AWS_CONTAINER_CREDENTIALS_FULL_URI
  unset AWS_CONTAINER_AUTHORIZATION_TOKEN AWS_CONTAINER_AUTHORIZATION_TOKEN_FILE
  unset AWS_WEB_IDENTITY_TOKEN_FILE AWS_ROLE_ARN AWS_ROLE_SESSION_NAME AWS_CREDENTIAL_EXPIRATION
}

initialize_broker_aws_directory() {
  local aws_dir="$HOME/.aws"
  mkdir -p "$aws_dir"; chmod 700 "$aws_dir" 2>/dev/null || true
  SANDBOX_HOST_AWS_DIR="$aws_dir"
  export SANDBOX_HOST_AWS_DIR
  set_env_value SANDBOX_HOST_AWS_DIR "$SANDBOX_HOST_AWS_DIR"
}

has_static_aws_profile() {
  local credentials="$HOME/.aws/credentials" target="$PROFILE"
  [[ -f "$credentials" ]] || return 1
  awk -v target="$target" '
    BEGIN { in_target=0; access=0; secret=0; token=0 }
    /^[[:space:]]*\[[^]]+\][[:space:]]*$/ {
      name=$0; sub(/^[[:space:]]*\[/,"",name); sub(/\][[:space:]]*$/,"",name)
      in_target=(name==target); next
    }
    in_target && /^[[:space:]]*aws_access_key_id[[:space:]]*=[[:space:]]*[^[:space:]]+/ { access=1; next }
    in_target && /^[[:space:]]*aws_secret_access_key[[:space:]]*=[[:space:]]*[^[:space:]]+/ { secret=1; next }
    in_target && /^[[:space:]]*aws_session_token[[:space:]]*=[[:space:]]*[^[:space:]]+/ { token=1; next }
    END { exit !(access && secret && !token) }
  ' "$credentials"
}

initialize_aws_azure_saml_profile() {
  local key value duration remember aws_dir config section tmp out
  for key in AZURE_TENANT_ID AZURE_APP_ID_URI AZURE_DEFAULT_USERNAME AZURE_DEFAULT_ROLE_ARN AZURE_DEFAULT_DURATION_HOURS AZURE_DEFAULT_REMEMBER_ME; do
    value="$(get_env "$key")"
    configured_value "$value" || { echo "ERROR: $key is missing or still a placeholder in .env" >&2; exit 1; }
  done

  [[ "$(get_env AZURE_DEFAULT_ROLE_ARN)" =~ ^arn:[a-z0-9-]+:iam::[0-9]{12}:role/.+ ]] || {
    echo 'ERROR: AZURE_DEFAULT_ROLE_ARN must be a complete AWS IAM role ARN.' >&2; exit 1;
  }
  duration="$(get_env AZURE_DEFAULT_DURATION_HOURS)"
  [[ "$duration" =~ ^[0-9]+$ ]] && (( duration >= 1 && duration <= 12 )) || {
    echo 'ERROR: AZURE_DEFAULT_DURATION_HOURS must be an integer from 1 to 12.' >&2; exit 1;
  }
  remember="$(get_env AZURE_DEFAULT_REMEMBER_ME)"; remember="${remember,,}"
  [[ "$remember" == true || "$remember" == false ]] || {
    echo 'ERROR: AZURE_DEFAULT_REMEMBER_ME must be true or false.' >&2; exit 1;
  }
  command -v aws-azure-login >/dev/null 2>&1 || {
    echo 'ERROR: aws-azure-login is not installed on the host. Install the Admin-approved aws-azure-login package and rerun.' >&2
    exit 1
  }

  aws_dir="$HOME/.aws"
  config="$aws_dir/config"
  mkdir -p "$aws_dir"; chmod 700 "$aws_dir" 2>/dev/null || true
  touch "$config"; chmod 600 "$config" 2>/dev/null || true
  section="profile $PROFILE"; [[ "$PROFILE" == default ]] && section=default
  tmp="$(mktemp)"; out="$(mktemp)"
  awk -v target="$section" '
    /^\[[^]]+\][[:space:]]*$/ {
      name=$0; sub(/^\[/,"",name); sub(/\][[:space:]]*$/,"",name)
      skip=(name==target)
      if (!skip) print
      next
    }
    !skip { print }
  ' "$config" > "$tmp"
  awk 'BEGIN{n=0} {a[++n]=$0} END{while(n>0 && a[n] ~ /^[[:space:]]*$/) n--; for(i=1;i<=n;i++) print a[i]}' "$tmp" > "$out"
  if [[ -s "$out" ]]; then printf '\n' >> "$out"; fi
  cat >> "$out" <<CFG
[$section]
azure_tenant_id=$(get_env AZURE_TENANT_ID)
azure_app_id_uri=$(get_env AZURE_APP_ID_URI)
azure_default_username=$(get_env AZURE_DEFAULT_USERNAME)
azure_default_role_arn=$(get_env AZURE_DEFAULT_ROLE_ARN)
azure_default_duration_hours=$duration
azure_default_remember_me=$remember
region=$REGION
output=json
CFG
  mv "$out" "$config"; rm -f "$tmp"; chmod 600 "$config" 2>/dev/null || true
}

invoke_aws_azure_browser_login() {
  echo "Opening Azure/Entra browser login for AWS profile '$PROFILE'..." >&2
  if ! aws-azure-login --profile "$PROFILE" --mode gui; then
    echo 'WARN: GUI login failed once; retrying with GPU acceleration disabled.' >&2
    aws-azure-login --profile "$PROFILE" --mode gui --disable-gpu || {
      echo 'ERROR: aws-azure-login browser authentication failed.' >&2; exit 1;
    }
  fi
}

initialize_aws_authentication() {
  local key value requested has_static=0
  command -v aws >/dev/null 2>&1 || { echo 'ERROR: AWS CLI is not installed on the host.' >&2; exit 1; }

  for key in AWS_ACCESS_KEY_ID AWS_SECRET_ACCESS_KEY AWS_SESSION_TOKEN; do
    value="$(get_env "$key")"
    if configured_value "$value"; then
      echo "ERROR: do not store $key in .env. Put the key pair in the host profile with: aws configure --profile $PROFILE" >&2
      exit 1
    fi
  done
  for key in AWS_SSO_SESSION AWS_SSO_START_URL AWS_SSO_REGION AWS_SSO_ACCOUNT_ID AWS_SSO_ROLE_NAME; do
    value="$(get_env "$key")"
    if configured_value "$value"; then
      echo "ERROR: native IAM Identity Center setting '$key' is not supported. Use host static profile credentials or Azure/Entra SAML." >&2
      exit 1
    fi
  done

  requested="$(get_env AWS_AUTH_MODE)"; requested="${requested:-auto}"; requested="${requested,,}"
  case "$requested" in auto|static|saml) ;; *) echo 'ERROR: AWS_AUTH_MODE must be auto, static, or saml.' >&2; exit 1 ;; esac

  clear_aws_credential_provider_environment
  initialize_broker_aws_directory
  has_static_aws_profile && has_static=1 || true

  if [[ "$requested" == static && "$has_static" != 1 ]]; then
    echo "ERROR: AWS_AUTH_MODE=static requires aws_access_key_id and aws_secret_access_key in host profile '$PROFILE'. Run: aws configure --profile $PROFILE" >&2
    exit 1
  fi

  if [[ "$requested" == static || ( "$requested" == auto && "$has_static" == 1 ) ]]; then
    AWS_AUTH_MODE_RESOLVED=static
    echo "[OK] AWS authentication: host static key profile '$PROFILE' (browser login skipped)."
    echo "Host AWS directory is mounted read-only into secret-broker only: $SANDBOX_HOST_AWS_DIR"
    return
  fi

  initialize_aws_azure_saml_profile
  invoke_aws_azure_browser_login
  AWS_AUTH_MODE_RESOLVED=saml
  echo "[OK] Azure/Entra browser authentication completed for host profile '$PROFILE'."
  echo "Host AWS directory is mounted read-only into secret-broker only: $SANDBOX_HOST_AWS_DIR"
}


aws_cli() { aws --profile "$PROFILE" "$@"; }

initialize_aws_authentication

get_ssm() {
  local name="$1" value rc
  set +e
  value="$(aws_cli ssm get-parameter \
    --name "$name" \
    --region "$REGION" \
    --query Parameter.Value \
    --output text 2>&1)"
  rc=$?
  set -e
  if (( rc != 0 )); then
    printf '%s\n' "$value" >&2
    if [[ "${AWS_AUTH_MODE_RESOLVED:-}" == static ]]; then
      echo "ERROR: cannot read required SSM parameter: $name with host static profile '$PROFILE'. Check the key pair and ssm:GetParameter permission." >&2
    else
      echo "ERROR: cannot read required SSM parameter: $name. Re-run: aws-azure-login --profile $PROFILE --mode gui" >&2
    fi
    return "$rc"
  fi
  printf '%s' "$value"
}

MANIFEST_JSON="$(get_ssm "$MANIFEST_PARAMETER")"
EXPECTED_HASH="$(get_ssm "$MANIFEST_PARAMETER-sha256" | tr '[:upper:]' '[:lower:]')"
ACTUAL_HASH="$(printf '%s' "$MANIFEST_JSON" | sha256sum | awk '{print $1}')"
[[ "$EXPECTED_HASH" == "$ACTUAL_HASH" ]] || {
  echo 'ERROR: approved manifest SHA-256 validation failed' >&2
  exit 1
}

# Parse and validate the exact registry/repository/digest shape before any pull.
# Capture the parser result before eval so a Python validation failure cannot be
# hidden by `eval "$(...)"` returning success for an empty substitution.
if ! MANIFEST_ASSIGNMENTS="$(MANIFEST_JSON="$MANIFEST_JSON" REGISTRY="$REGISTRY" python3 - <<'PY2'
import json, os, re, shlex
manifest = json.loads(os.environ['MANIFEST_JSON'])
registry = os.environ['REGISTRY'].rstrip('/')
if manifest.get('registry') != registry:
    raise SystemExit('ERROR: approved manifest registry mismatch')

def approved(key, repository):
    value = manifest['images'][key]['full']
    pattern = '^' + re.escape(registry) + '/ai-sandbox/' + re.escape(repository) + r'@sha256:[0-9a-f]{64}$'
    if not re.match(pattern, value):
        raise SystemExit('ERROR: invalid approved ' + repository + ' image')
    return value

print('DEV=' + shlex.quote(approved('devcontainer', 'devcontainer')))
print('SQUID=' + shlex.quote(approved('squid', 'squid')))
stype=str(manifest.get('sandboxType','')).lower()
if stype not in ('poc','production'):
    raise SystemExit('ERROR: approved manifest sandboxType must be poc or production')
if str(manifest.get('deploymentType','')).lower() != 'ecr':
    raise SystemExit('ERROR: approved manifest deploymentType must be ecr')
print('SANDBOX_ENV=' + shlex.quote(stype))
print('RELEASE=' + shlex.quote(str(manifest.get('releaseTag', 'unknown'))))
PY2
)"; then
  echo 'ERROR: approved ECR manifest parsing/validation failed' >&2
  exit 1
fi
eval "$MANIFEST_ASSIGNMENTS"
unset MANIFEST_ASSIGNMENTS

initialize_host_log_root "$SANDBOX_ENV"
echo "Approved release: $RELEASE"
aws_cli ecr get-login-password --region "$REGION" \
  | docker login --username AWS --password-stdin "$REGISTRY" >/dev/null

docker pull "$DEV" >/dev/null
docker tag "$DEV" sandbox/approved-devcontainer:current

docker pull "$SQUID" >/dev/null
docker tag "$SQUID" sandbox/approved-squid:current

docker compose --env-file "$ENV_FILE" -f "$COMPOSE" config >/dev/null
docker compose --env-file "$ENV_FILE" -f "$COMPOSE" up -d --force-recreate

echo "[OK] Approved $SANDBOX_ENV ECR sandbox started."
if [[ "$RESOLVED_LOG_MODE" == poc-local ]]; then
  start_poc_local_exporter "$SANDBOX_LOG_ROOT"
  echo "WARN: POC host log copies are mutable by the current host user." >&2
else
  echo "[OK] Runtime logs: Docker streams exported to protected host root $SANDBOX_LOG_ROOT"
fi
