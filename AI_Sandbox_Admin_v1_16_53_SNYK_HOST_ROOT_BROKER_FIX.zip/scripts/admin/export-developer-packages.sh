#!/usr/bin/env bash
# =============================================================================
# ADMIN ONLY - Export minimal TAR and ECR Developer runtime packages.
# Documentation is optional and is not required by this export workflow.
# =============================================================================
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
OUT="${1:-$ROOT/developer-packages}"
INCLUDE="${2:-}"
TAR="$OUT/AI_Sandbox_Developer_TAR"
ECR="$OUT/AI_Sandbox_Developer_ECR"
rm -rf "$TAR" "$ECR"
mkdir -p "$TAR" "$ECR"

copy(){ mkdir -p "$(dirname "$2")"; cp -a "$1" "$2"; }

# Stamp optional Admin-approved NON-SECRET Azure/Entra -> AWS SAML defaults from
# .build.env into the Developer .env.example. Authentication itself always
# happens on the Developer host with aws-azure-login GUI browser/MFA.
stamp_azure_saml_defaults(){
  local target="$1" build="$ROOT/.build.env" key src value tmp
  [[ -f "$target" && -f "$build" ]] || return 0
  while IFS='|' read -r key src; do
    value="$(awk -F= -v k="$src" '$1==k {sub(/^[^=]*=/,""); print; exit}' "$build")"
    [[ -n "$value" ]] || continue
    tmp="${target}.tmp.$$"
    awk -v k="$key" -v v="$value" 'index($0,k"=")==1 {$0=k"="v} {print}' "$target" > "$tmp"
    mv "$tmp" "$target"
  done <<'MAP'
SANDBOX_AWS_PROFILE|DEVELOPER_AWS_PROFILE
AWS_REGION|DEVELOPER_AWS_REGION
AZURE_TENANT_ID|DEVELOPER_AZURE_TENANT_ID
AZURE_APP_ID_URI|DEVELOPER_AZURE_APP_ID_URI
AZURE_DEFAULT_USERNAME|DEVELOPER_AZURE_DEFAULT_USERNAME
AZURE_DEFAULT_ROLE_ARN|DEVELOPER_AZURE_DEFAULT_ROLE_ARN
AZURE_DEFAULT_DURATION_HOURS|DEVELOPER_AZURE_DEFAULT_DURATION_HOURS
AZURE_DEFAULT_REMEMBER_ME|DEVELOPER_AZURE_DEFAULT_REMEMBER_ME
MAP
}

# TAR deployment package (POC or Production hardening)
copy "$ROOT/.devcontainer/devcontainer.json" "$TAR/.devcontainer/devcontainer.json"
copy "$ROOT/tar/docker-compose.yml" "$TAR/tar/docker-compose.yml"
for f in load-and-start.ps1 load-and-start.sh verify-sandbox.ps1 verify-sandbox.sh; do
  copy "$ROOT/scripts/tar/$f" "$TAR/scripts/tar/$f"
done
for f in export-docker-logs-to-host.ps1 export-docker-logs-to-host.sh verify-host-log-export.ps1 verify-host-log-export.sh; do
  copy "$ROOT/scripts/monitoring/$f" "$TAR/scripts/monitoring/$f"
done
copy "$ROOT/.env.example" "$TAR/tar/.env.example"
stamp_azure_saml_defaults "$TAR/tar/.env.example"
copy "$ROOT/workspace/README.md" "$TAR/workspace/README.md"
copy "$ROOT/templates/developer/DEVELOPER-GUIDE-TAR.md" "$TAR/DEVELOPER-GUIDE.md"
mkdir -p "$TAR/tar/images"
printf '%s\n' 'Admin supplies the complete generated tar/images bundle here. Do not modify bundle files.' > "$TAR/tar/images/README.txt"
if [[ "$INCLUDE" == '--include-tar-images' ]]; then
  [[ -f "$ROOT/tar/images/SHA256SUMS" ]] || { echo 'ERROR: TAR image bundle has not been built yet.' >&2; exit 1; }
  cp -a "$ROOT/tar/images/." "$TAR/tar/images/"
fi

# ECR package
copy "$ROOT/ecr/docker-compose.yml" "$ECR/docker-compose.yml"
copy "$ROOT/templates/developer/devcontainer-ecr.json" "$ECR/.devcontainer/devcontainer.json"
for f in pull-and-start.ps1 pull-and-start.sh; do
  copy "$ROOT/scripts/ecr/$f" "$ECR/scripts/ecr/$f"
done
for f in export-docker-logs-to-host.ps1 export-docker-logs-to-host.sh verify-host-log-export.ps1 verify-host-log-export.sh; do
  copy "$ROOT/scripts/monitoring/$f" "$ECR/scripts/monitoring/$f"
done
copy "$ROOT/.env.example" "$ECR/.env.example"
stamp_azure_saml_defaults "$ECR/.env.example"
copy "$ROOT/workspace/README.md" "$ECR/workspace/README.md"
copy "$ROOT/templates/developer/DEVELOPER-GUIDE-ECR.md" "$ECR/DEVELOPER-GUIDE.md"

echo "[OK] $TAR"
echo "[OK] $ECR"
