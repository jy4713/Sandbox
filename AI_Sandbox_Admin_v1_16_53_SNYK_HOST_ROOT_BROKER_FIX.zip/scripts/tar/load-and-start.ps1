#Requires -Version 7.4
# =============================================================================
# PACKAGE MAINTENANCE NOTES
# Purpose:
#   Developer TAR launcher for an Admin-approved POC or Production hardened bundle.
#
# Maintenance boundary:
#   Keep the required bundle files, runtime-policy validation, image ID checks,
#   and the paired Bash launcher synchronized with scripts/tar/build-and-export.*.
#
# Logging:
#   This launcher creates host-visible DevContainer and Squid log directories.
#   It does not start or authenticate a monitoring/forwarding container.
# =============================================================================
[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
$Images = Join-Path $Root 'tar\images'
$EnvFile = Join-Path $Root 'tar\.env'
$EnvTemplate = Join-Path $Root 'tar\.env.example'
$LegacyEnvFile = Join-Path $Root '.env'
$Compose = Join-Path $Root 'tar\docker-compose.yml'

if (-not (Test-Path $EnvTemplate)) {
    # Admin source packages keep one canonical master template at the package root.
    $EnvTemplate = Join-Path $Root '.env.example'
}

$Required = @(
    'sandbox-devcontainer.tar',
    'sandbox-squid.tar',
    'image-manifest.json',
    'image-manifest.env',
    'runtime-policy.sha256',
    'SHA256SUMS'
)

foreach ($FileName in $Required) {
    $Path = Join-Path $Images $FileName
    if (-not (Test-Path $Path) -or (Get-Item $Path).Length -eq 0) {
        throw "Missing or empty TAR bundle file: $Path"
    }
}

if (-not (Test-Path $EnvFile)) {
    if (Test-Path $LegacyEnvFile) {
        Copy-Item $LegacyEnvFile $EnvFile
        Write-Host "[MIGRATION] Copied legacy root .env to canonical TAR runtime file: $EnvFile" -ForegroundColor Yellow
    }
    else {
        if (-not (Test-Path $EnvTemplate)) { throw "Missing runtime template: $EnvTemplate" }
        Copy-Item $EnvTemplate $EnvFile
        Write-Host "Created $EnvFile from .env.example. Site-specific values are blank by default; configure the required values and rerun. AWS authentication is host-only: an existing static host profile is used first in AUTO mode, otherwise Azure/Entra SAML browser login is used." -ForegroundColor Yellow
        exit 2
    }
}

function Read-KeyValueFile {
    param([Parameter(Mandatory = $true)][string]$Path)
    $Map = @{}
    Get-Content $Path | ForEach-Object {
        $Line = $_.TrimEnd("`r")
        if ($Line -and -not $Line.TrimStart().StartsWith('#')) {
            $Index = $Line.IndexOf('=')
            if ($Index -gt 0) {
                $Map[$Line.Substring(0, $Index).Trim()] = $Line.Substring($Index + 1)
            }
        }
    }
    return $Map
}

function Test-ConfiguredValue {
    param([string]$Value)
    return (
        -not [string]::IsNullOrWhiteSpace($Value) -and
        $Value -notmatch '[<>]' -and
        $Value -notlike '*REPLACE_*' -and
        $Value -ne 'yourname'
    )
}

function Set-RuntimeEnvValue {
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][string]$Key,
        [Parameter(Mandatory = $true)][string]$Value
    )
    $Lines = [System.Collections.Generic.List[string]]::new()
    $Found = $false
    foreach ($Line in (Get-Content -LiteralPath $Path -Encoding UTF8)) {
        if ($Line -match ('^' + [regex]::Escape($Key) + '=')) {
            $Lines.Add("$Key=$Value")
            $Found = $true
        }
        else { $Lines.Add($Line) }
    }
    if (-not $Found) { $Lines.Add("$Key=$Value") }
    $Temp = "$Path.tmp.$([guid]::NewGuid().ToString('N'))"
    try {
        [IO.File]::WriteAllLines($Temp, $Lines, [Text.UTF8Encoding]::new($false))
        Move-Item -LiteralPath $Temp -Destination $Path -Force
    }
    finally {
        if (Test-Path -LiteralPath $Temp) { Remove-Item -LiteralPath $Temp -Force -ErrorAction SilentlyContinue }
    }
}


$ProtectedLogSystemSid = 'S-1-5-18'
$ProtectedLogWriteMask = [Security.AccessControl.FileSystemRights]::WriteData `
    -bor [Security.AccessControl.FileSystemRights]::AppendData `
    -bor [Security.AccessControl.FileSystemRights]::CreateDirectories `
    -bor [Security.AccessControl.FileSystemRights]::WriteAttributes `
    -bor [Security.AccessControl.FileSystemRights]::WriteExtendedAttributes `
    -bor [Security.AccessControl.FileSystemRights]::Delete `
    -bor [Security.AccessControl.FileSystemRights]::DeleteSubdirectoriesAndFiles `
    -bor [Security.AccessControl.FileSystemRights]::ChangePermissions `
    -bor [Security.AccessControl.FileSystemRights]::TakeOwnership

function Get-ProtectedLogRuleSid([Security.Principal.IdentityReference]$IdentityReference) {
    try { return $IdentityReference.Translate([Security.Principal.SecurityIdentifier]).Value }
    catch { return $IdentityReference.Value }
}

function Assert-ProtectedLogAcl([string]$Path) {
    $Acl = Get-Acl -LiteralPath $Path
    try { $OwnerSid = ([Security.Principal.NTAccount]::new($Acl.Owner)).Translate([Security.Principal.SecurityIdentifier]).Value }
    catch { $OwnerSid = $Acl.Owner }
    if ($OwnerSid -ne $ProtectedLogSystemSid -and $Acl.Owner -notmatch 'SYSTEM') {
        throw "Security check failed: protected log path '$Path' is not owned by LOCALSYSTEM."
    }
    foreach ($Rule in $Acl.Access) {
        if ($Rule.AccessControlType -ne [Security.AccessControl.AccessControlType]::Allow) { continue }
        $RuleSid = Get-ProtectedLogRuleSid -IdentityReference $Rule.IdentityReference
        if ((([int64]$Rule.FileSystemRights -band [int64]$ProtectedLogWriteMask) -ne 0) -and $RuleSid -ne $ProtectedLogSystemSid) {
            throw "Security check failed: non-SYSTEM principal '$($Rule.IdentityReference)' has write/modify/delete rights on protected log path '$Path'."
        }
    }
}

function Initialize-HostLogRoot {
    param(
        [hashtable]$Runtime,
        [Parameter(Mandatory = $true)][ValidateSet('poc','production')][string]$SandboxType
    )
    $PersistRoot = $false
    $RequestedMode = if (Test-ConfiguredValue $Runtime['SANDBOX_LOG_MODE']) { $Runtime['SANDBOX_LOG_MODE'].Trim().ToLowerInvariant() } else { 'auto' }
    if ($RequestedMode -notin @('auto','protected','poc-local')) {
        throw "SANDBOX_LOG_MODE must be 'auto', 'protected', or 'poc-local'. Current value: $RequestedMode"
    }
    if ($SandboxType -eq 'production' -and $RequestedMode -eq 'poc-local') {
        throw 'Production manifests require protected host logging; SANDBOX_LOG_MODE=poc-local is not permitted.'
    }
    $Mode = if ($RequestedMode -eq 'auto') {
        if ($SandboxType -eq 'poc') { 'poc-local' } else { 'protected' }
    }
    else { $RequestedMode }

    if (-not (Test-ConfiguredValue $Runtime['SANDBOX_LOG_ROOT'])) {
        if ($Mode -eq 'poc-local') {
            $Runtime['SANDBOX_LOG_ROOT'] = (Join-Path $env:USERPROFILE 'AI-Sandbox\Logs') -replace '\\','/'
            $PersistRoot = $true
        }
        else {
            throw 'SANDBOX_LOG_ROOT is missing or still a placeholder in .env. Ask the Sandbox Admin to run scripts\platform\03-setup-logging.ps1 first.'
        }
    }
    $LogRoot = [IO.Path]::GetFullPath($Runtime['SANDBOX_LOG_ROOT'].Replace('/', '\'))

    # The common template intentionally carries the Production protected path.
    # For a POC that resolves to poc-local, automatically move to a user-owned
    # path so an Administrator is not required merely to run the functional POC.
    if ($Mode -eq 'poc-local' -and $LogRoot.TrimEnd('\') -ieq 'C:\ProgramData\AI-Sandbox\Logs') {
        $LogRoot = Join-Path $env:USERPROFILE 'AI-Sandbox\Logs'
        $Runtime['SANDBOX_LOG_ROOT'] = $LogRoot -replace '\\','/'
        $PersistRoot = $true
        Write-Warning "POC local mode replaced the protected default log path with user-writable path: $LogRoot"
    }

    if ($Mode -eq 'poc-local') {
        foreach ($Path in @($LogRoot, (Join-Path $LogRoot 'devcontainer'), (Join-Path $LogRoot 'devcontainer\content'), (Join-Path $LogRoot 'squid'), (Join-Path $LogRoot '.monitoring'))) {
            New-Item -ItemType Directory -Force -Path $Path | Out-Null
        }
        Write-Warning 'POC LOCAL LOG MODE: Windows host log files are writable by the current user. This mode is for non-admin POC testing only.'
        return @{ Mode = $Mode; RequestedMode = $RequestedMode; Root = $LogRoot; ComposeRoot = ($LogRoot -replace '\\','/'); PersistRoot = $PersistRoot }
    }

    if (-not (Test-Path -LiteralPath $LogRoot -PathType Container)) {
        throw "Protected host log root is missing: $LogRoot. Ask the Sandbox Admin to run scripts\platform\03-setup-logging.ps1."
    }
    Assert-ProtectedLogAcl -Path $LogRoot
    foreach ($Subdir in @('devcontainer','devcontainer\content','squid')) {
        $Path = Join-Path $LogRoot $Subdir
        if (-not (Test-Path -LiteralPath $Path -PathType Container)) {
            throw "Protected host log directory is missing: $Path. Ask the Sandbox Admin to run scripts\platform\03-setup-logging.ps1."
        }
        Assert-ProtectedLogAcl -Path $Path
        $Probe = Join-Path $Path ('.developer-write-probe-' + [guid]::NewGuid().ToString('N'))
        $Writable = $false
        try {
            [IO.File]::WriteAllText($Probe, 'probe', [Text.UTF8Encoding]::new($false))
            $Writable = $true
        }
        catch [UnauthorizedAccessException] { }
        catch [IO.IOException] { }
        finally {
            if (Test-Path -LiteralPath $Probe) { Remove-Item -LiteralPath $Probe -Force -ErrorAction SilentlyContinue }
        }
        if ($Writable) {
            throw "Security check failed: the current Windows user can write to protected log directory $Path. Re-apply the Admin/SYSTEM ACL with scripts\platform\03-setup-logging.ps1."
        }
    }
    return @{ Mode = $Mode; RequestedMode = $RequestedMode; Root = $LogRoot; ComposeRoot = ($LogRoot -replace '\\','/'); PersistRoot = $PersistRoot }
}

function Start-PocLocalLogExporter {
    param(
        [Parameter(Mandatory = $true)][string]$PackageRoot,
        [Parameter(Mandatory = $true)][hashtable]$HostLog
    )
    $Exporter = Join-Path $PackageRoot 'scripts\monitoring\export-docker-logs-to-host.ps1'
    $MonitorRoot = Join-Path $HostLog.Root '.monitoring'
    $StateFile = Join-Path $MonitorRoot 'host-log-export-state.json'
    $PidFile = Join-Path $MonitorRoot 'poc-log-exporter.pid'
    $StdoutFile = Join-Path $MonitorRoot 'poc-log-exporter.out.log'
    $StderrFile = Join-Path $MonitorRoot 'poc-log-exporter.err.log'

    # First pass is synchronous so launcher success means the host-log path and
    # Docker log API are both working before the Developer starts work.
    & pwsh -NoProfile -File $Exporter -LogMode PocLocal -ProjectName 'ai-secure-sandbox' -LogRoot $HostLog.Root -StateFile $StateFile
    if ($LASTEXITCODE -ne 0) { throw 'Initial POC local host-log export failed.' }

    if (Test-Path -LiteralPath $PidFile -PathType Leaf) {
        $ExistingPidText = [string](Get-Content -LiteralPath $PidFile -Raw -ErrorAction SilentlyContinue)
        $ExistingPidText = $ExistingPidText.Trim()
        $ExistingPid = 0
        if ([int]::TryParse($ExistingPidText, [ref]$ExistingPid)) {
            $ExistingProcess = Get-Process -Id $ExistingPid -ErrorAction SilentlyContinue
            if ($ExistingProcess -and $ExistingProcess.ProcessName -like 'pwsh*') {
                Write-Host "[OK] POC local log exporter is already running (PID $ExistingPid)." -ForegroundColor Yellow
                return
            }
        }
        Remove-Item -LiteralPath $PidFile -Force -ErrorAction SilentlyContinue
    }

    $Pwsh = (Get-Command pwsh -ErrorAction Stop).Source
    $Arguments = @(
        '-NoProfile',
        '-File', ('"{0}"' -f $Exporter),
        '-LogMode', 'PocLocal',
        '-ProjectName', 'ai-secure-sandbox',
        '-LogRoot', ('"{0}"' -f $HostLog.Root),
        '-StateFile', ('"{0}"' -f $StateFile),
        '-Continuous',
        '-IntervalSeconds', '30'
    ) -join ' '
    $Process = Start-Process -FilePath $Pwsh -ArgumentList $Arguments -WindowStyle Hidden -PassThru `
        -RedirectStandardOutput $StdoutFile -RedirectStandardError $StderrFile
    [IO.File]::WriteAllText($PidFile, [string]$Process.Id, [Text.ASCIIEncoding]::new())
    Write-Host "[OK] POC local log exporter started in the background (PID $($Process.Id), every 30 seconds)." -ForegroundColor Yellow
}

$Runtime = Read-KeyValueFile -Path $EnvFile
if (-not (Test-ConfiguredValue $Runtime['DEVELOPER_ID'])) {
    throw 'DEVELOPER_ID is missing or still a placeholder in .env'
}
if ($Runtime['DATABRICKS_HOST'] -and $Runtime['DATABRICKS_HOST'] -notmatch '^https://') {
    throw 'DATABRICKS_HOST must use https:// when configured'
}

$Region = if ($Runtime['AWS_REGION']) { $Runtime['AWS_REGION'] } else { 'eu-north-1' }
$Profile = if ($Runtime['SANDBOX_AWS_PROFILE']) { $Runtime['SANDBOX_AWS_PROFILE'] } else { 'sandbox' }

function Clear-AwsCredentialProviderEnvironment {
    # Never allow inherited AWS credential-provider environment variables to
    # override the Admin-selected host profile or flow into Docker/Compose.
    foreach ($Name in @(
        'AWS_ACCESS_KEY_ID','AWS_SECRET_ACCESS_KEY','AWS_SESSION_TOKEN','AWS_SECURITY_TOKEN',
        'AWS_PROFILE','AWS_DEFAULT_PROFILE','AWS_CONFIG_FILE','AWS_SHARED_CREDENTIALS_FILE',
        'AWS_CONTAINER_CREDENTIALS_RELATIVE_URI','AWS_CONTAINER_CREDENTIALS_FULL_URI',
        'AWS_CONTAINER_AUTHORIZATION_TOKEN','AWS_CONTAINER_AUTHORIZATION_TOKEN_FILE',
        'AWS_WEB_IDENTITY_TOKEN_FILE','AWS_ROLE_ARN','AWS_ROLE_SESSION_NAME','AWS_CREDENTIAL_EXPIRATION'
    )) {
        Remove-Item "Env:$Name" -ErrorAction SilentlyContinue
    }
}

function Initialize-BrokerAwsDirectory {
    param(
        [Parameter(Mandatory = $true)][hashtable]$Runtime,
        [Parameter(Mandatory = $true)][string]$EnvFile
    )
    $AwsDir = Join-Path $HOME '.aws'
    New-Item -ItemType Directory -Force -Path $AwsDir | Out-Null
    $ComposeAwsDir = ([IO.Path]::GetFullPath($AwsDir) -replace '\\','/')
    Set-RuntimeEnvValue -Path $EnvFile -Key 'SANDBOX_HOST_AWS_DIR' -Value $ComposeAwsDir
    $Runtime['SANDBOX_HOST_AWS_DIR'] = $ComposeAwsDir
    $env:SANDBOX_HOST_AWS_DIR = $ComposeAwsDir
    return $ComposeAwsDir
}

function Test-StaticAwsProfileCredentials {
    param([Parameter(Mandatory = $true)][string]$Profile)
    $Credentials = Join-Path (Join-Path $HOME '.aws') 'credentials'
    if (-not (Test-Path -LiteralPath $Credentials)) { return $false }

    $Target = if ($Profile -eq 'default') { 'default' } else { $Profile }
    $InTarget = $false
    $HasAccess = $false
    $HasSecret = $false
    $HasSessionToken = $false
    foreach ($Line in Get-Content -LiteralPath $Credentials -Encoding UTF8) {
        if ($Line -match '^\s*\[([^\]]+)\]\s*$') {
            $InTarget = ($matches[1].Trim() -eq $Target)
            continue
        }
        if (-not $InTarget) { continue }
        if ($Line -match '^\s*aws_access_key_id\s*=\s*\S+') { $HasAccess = $true; continue }
        if ($Line -match '^\s*aws_secret_access_key\s*=\s*\S+') { $HasSecret = $true; continue }
        if ($Line -match '^\s*aws_session_token\s*=\s*\S+') { $HasSessionToken = $true; continue }
    }

    # A session token normally indicates a temporary STS/SAML session rather
    # than the requested test key-pair mode. AUTO therefore refreshes through
    # SAML instead of accidentally treating an expired SAML session as static.
    return ($HasAccess -and $HasSecret -and -not $HasSessionToken)
}

function Initialize-AwsAzureSamlProfile {
    param(
        [Parameter(Mandatory = $true)][hashtable]$Runtime,
        [Parameter(Mandatory = $true)][string]$Profile,
        [Parameter(Mandatory = $true)][string]$Region
    )

    $Required = @(
        'AZURE_TENANT_ID',
        'AZURE_APP_ID_URI',
        'AZURE_DEFAULT_USERNAME',
        'AZURE_DEFAULT_ROLE_ARN',
        'AZURE_DEFAULT_DURATION_HOURS',
        'AZURE_DEFAULT_REMEMBER_ME'
    )
    $Missing = @($Required | Where-Object { -not (Test-ConfiguredValue $Runtime[$_]) })
    if ($Missing.Count) {
        throw "Azure/Entra AWS SAML settings are missing from .env: $($Missing -join ', ')"
    }
    if ($Runtime['AZURE_DEFAULT_ROLE_ARN'] -notmatch '^arn:[a-z0-9-]+:iam::[0-9]{12}:role/.+') {
        throw 'AZURE_DEFAULT_ROLE_ARN must be a complete AWS IAM role ARN.'
    }
    $Duration = 0
    if (-not [int]::TryParse($Runtime['AZURE_DEFAULT_DURATION_HOURS'], [ref]$Duration) -or $Duration -lt 1 -or $Duration -gt 12) {
        throw 'AZURE_DEFAULT_DURATION_HOURS must be an integer from 1 to 12.'
    }
    $Remember = $Runtime['AZURE_DEFAULT_REMEMBER_ME'].Trim().ToLowerInvariant()
    if ($Remember -notin @('true','false')) {
        throw 'AZURE_DEFAULT_REMEMBER_ME must be true or false.'
    }
    if (-not (Get-Command aws-azure-login -ErrorAction SilentlyContinue)) {
        throw 'aws-azure-login is not installed on the Windows host. Install the Admin-approved aws-azure-login package, then rerun this launcher.'
    }

    $AwsDir = Join-Path $HOME '.aws'
    $Config = Join-Path $AwsDir 'config'
    New-Item -ItemType Directory -Force -Path $AwsDir | Out-Null

    $SectionName = if ($Profile -eq 'default') { 'default' } else { "profile $Profile" }
    $ExistingLines = if (Test-Path -LiteralPath $Config) { @(Get-Content -LiteralPath $Config -Encoding UTF8) } else { @() }
    $Output = [System.Collections.Generic.List[string]]::new()
    $Skipping = $false
    foreach ($Line in $ExistingLines) {
        if ($Line -match '^\s*\[([^\]]+)\]\s*$') {
            $Skipping = ($matches[1].Trim() -eq $SectionName)
            if (-not $Skipping) { $Output.Add($Line) }
            continue
        }
        if (-not $Skipping) { $Output.Add($Line) }
    }
    while ($Output.Count -gt 0 -and [string]::IsNullOrWhiteSpace($Output[$Output.Count - 1])) { $Output.RemoveAt($Output.Count - 1) }
    if ($Output.Count -gt 0) { $Output.Add('') }
    $Output.Add("[$SectionName]")
    $Output.Add("azure_tenant_id=$($Runtime['AZURE_TENANT_ID'])")
    $Output.Add("azure_app_id_uri=$($Runtime['AZURE_APP_ID_URI'])")
    $Output.Add("azure_default_username=$($Runtime['AZURE_DEFAULT_USERNAME'])")
    $Output.Add("azure_default_role_arn=$($Runtime['AZURE_DEFAULT_ROLE_ARN'])")
    $Output.Add("azure_default_duration_hours=$Duration")
    $Output.Add("azure_default_remember_me=$Remember")
    $Output.Add("region=$Region")
    $Output.Add('output=json')
    [IO.File]::WriteAllLines($Config, $Output, [Text.UTF8Encoding]::new($false))
}

function Invoke-AwsAzureBrowserLogin {
    param([Parameter(Mandatory = $true)][string]$Profile)
    Write-Host "Opening Azure/Entra browser login for AWS profile '$Profile'..." -ForegroundColor Yellow
    & aws-azure-login --profile $Profile --mode gui
    if ($LASTEXITCODE -ne 0) {
        Write-Host 'GUI login failed once; retrying with GPU acceleration disabled for Windows 365 compatibility...' -ForegroundColor Yellow
        & aws-azure-login --profile $Profile --mode gui --disable-gpu
        if ($LASTEXITCODE -ne 0) { throw 'aws-azure-login browser authentication failed.' }
    }
}

function Initialize-AwsAuthentication {
    param(
        [Parameter(Mandatory = $true)][hashtable]$Runtime,
        [Parameter(Mandatory = $true)][string]$Profile,
        [Parameter(Mandatory = $true)][string]$Region,
        [Parameter(Mandatory = $true)][string]$EnvFile
    )

    if (-not (Get-Command aws -ErrorAction SilentlyContinue)) {
        throw 'AWS CLI is not installed on the host.'
    }

    # Raw AWS keys remain forbidden in .env. Static test credentials belong in
    # the host AWS shared-credentials profile (aws configure --profile <name>),
    # which is mounted read-only into secret-broker and never into AI DevContainer.
    foreach ($Key in @('AWS_ACCESS_KEY_ID','AWS_SECRET_ACCESS_KEY','AWS_SESSION_TOKEN')) {
        if (Test-ConfiguredValue $Runtime[$Key]) {
            throw "Do not store $Key in .env. Put the key pair in the host profile with 'aws configure --profile $Profile'."
        }
    }
    foreach ($Key in @('AWS_SSO_SESSION','AWS_SSO_START_URL','AWS_SSO_REGION','AWS_SSO_ACCOUNT_ID','AWS_SSO_ROLE_NAME')) {
        if (Test-ConfiguredValue $Runtime[$Key]) {
            throw "Native IAM Identity Center setting '$Key' is not supported by this package. Use host static profile credentials or Azure/Entra SAML."
        }
    }

    $Requested = if (Test-ConfiguredValue $Runtime['AWS_AUTH_MODE']) { $Runtime['AWS_AUTH_MODE'].Trim().ToLowerInvariant() } else { 'auto' }
    if ($Requested -notin @('auto','static','saml')) {
        throw 'AWS_AUTH_MODE must be auto, static, or saml.'
    }

    Clear-AwsCredentialProviderEnvironment
    $ComposeAwsDir = Initialize-BrokerAwsDirectory -Runtime $Runtime -EnvFile $EnvFile
    $HasStatic = Test-StaticAwsProfileCredentials -Profile $Profile

    if ($Requested -eq 'static' -and -not $HasStatic) {
        throw "AWS_AUTH_MODE=static requires aws_access_key_id and aws_secret_access_key in host profile '$Profile'. Run: aws configure --profile $Profile"
    }

    if ($Requested -eq 'static' -or ($Requested -eq 'auto' -and $HasStatic)) {
        $script:AwsAuthMode = 'static'
        Write-Host "[OK] AWS authentication: host static key profile '$Profile' (browser login skipped)." -ForegroundColor Green
        Write-Host "Host AWS directory is mounted read-only into secret-broker only: $ComposeAwsDir" -ForegroundColor DarkGray
        return
    }

    Initialize-AwsAzureSamlProfile -Runtime $Runtime -Profile $Profile -Region $Region
    Invoke-AwsAzureBrowserLogin -Profile $Profile
    $script:AwsAuthMode = 'saml'
    Write-Host "[OK] Azure/Entra browser authentication completed for host profile '$Profile'." -ForegroundColor Green
    Write-Host "Host AWS directory is mounted read-only into secret-broker only: $ComposeAwsDir" -ForegroundColor DarkGray
}

function Invoke-AwsCli {
    param([Parameter(Mandatory = $true)][string[]]$Arguments)
    & aws --profile $script:Profile @Arguments
}

Initialize-AwsAuthentication -Runtime $Runtime -Profile $Profile -Region $Region -EnvFile $EnvFile

# Runtime records are Docker-owned stdout/stderr first, then a SYSTEM host exporter copies them into the protected Windows log folder. Containers mount that folder read-only.

Write-Host '[1/5] Verifying bundle hashes...' -ForegroundColor Yellow
$ImagesBase = [IO.Path]::GetFullPath($Images) + [IO.Path]::DirectorySeparatorChar
Get-Content (Join-Path $Images 'SHA256SUMS') | ForEach-Object {
    if ($_ -notmatch '^([0-9a-fA-F]{64})\s+\*?(.+)$') {
        throw "Invalid SHA256SUMS line: $_"
    }
    $Expected = $matches[1].ToLowerInvariant()
    $Relative = $matches[2].Trim()
    if ($Relative.StartsWith('./')) { $Relative = $Relative.Substring(2) }
    $Path = [IO.Path]::GetFullPath((Join-Path $Images ($Relative -replace '/', '\')))
    if (-not $Path.StartsWith($ImagesBase, [StringComparison]::OrdinalIgnoreCase)) {
        throw "Unsafe hash path: $Relative"
    }
    $Actual = (Get-FileHash $Path -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($Actual -ne $Expected) { throw "SHA256 mismatch: $Relative" }
}

Write-Host '[2/5] Verifying Admin runtime policy...' -ForegroundColor Yellow
$RootBase = [IO.Path]::GetFullPath($Root) + [IO.Path]::DirectorySeparatorChar
Get-Content (Join-Path $Images 'runtime-policy.sha256') | ForEach-Object {
    if ($_ -notmatch '^([0-9a-fA-F]{64})\s+\*?(.+)$') {
        throw "Invalid runtime-policy line: $_"
    }
    $Expected = $matches[1].ToLowerInvariant()
    $Relative = $matches[2].Trim()
    $Path = [IO.Path]::GetFullPath((Join-Path $Root ($Relative -replace '/', '\')))
    if (-not $Path.StartsWith($RootBase, [StringComparison]::OrdinalIgnoreCase)) {
        throw "Unsafe policy path: $Relative"
    }
    $Actual = (Get-FileHash $Path -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($Actual -ne $Expected) { throw "Runtime policy mismatch: $Relative" }
}

Write-Host '[3/5] Loading approved images...' -ForegroundColor Yellow
foreach ($FileName in @('sandbox-devcontainer.tar', 'sandbox-squid.tar')) {
    & docker load -i (Join-Path $Images $FileName) | Out-Null
    if ($LASTEXITCODE -ne 0) { throw "docker load failed: $FileName" }
}

$Manifest = Read-KeyValueFile -Path (Join-Path $Images 'image-manifest.env')
foreach ($Key in @('SANDBOX_TYPE','DEPLOYMENT_TYPE','DEVCONTAINER_TAG', 'DEVCONTAINER_ID', 'SQUID_TAG', 'SQUID_ID')) {
    if (-not $Manifest[$Key]) { throw "Manifest missing $Key" }
}
if ($Manifest['DEPLOYMENT_TYPE'].ToLowerInvariant() -ne 'tar') { throw 'Bundle deployment type is not TAR.' }
$ManifestSandboxType=$Manifest['SANDBOX_TYPE'].ToLowerInvariant()
if ($ManifestSandboxType -notin @('poc','production')) { throw 'Bundle SANDBOX_TYPE must be poc or production.' }
$HostLog = Initialize-HostLogRoot -Runtime $Runtime -SandboxType $ManifestSandboxType
Set-RuntimeEnvValue -Path $EnvFile -Key 'SANDBOX_ENV' -Value $ManifestSandboxType
$Runtime['SANDBOX_ENV'] = $ManifestSandboxType
Write-Host "[OK] Persisted signed SandboxType for VS Code/Compose recreation: SANDBOX_ENV=$ManifestSandboxType" -ForegroundColor DarkGray
if ($HostLog.PersistRoot) {
    Set-RuntimeEnvValue -Path $EnvFile -Key 'SANDBOX_LOG_ROOT' -Value $HostLog.ComposeRoot
    Write-Host "[OK] Persisted POC host log root in .env for future VS Code/Compose recreation: $($HostLog.ComposeRoot)" -ForegroundColor Yellow
}

function Confirm-ImageId {
    param([string]$Label, [string]$Tag, [string]$ExpectedId)
    $ActualId = (& docker image inspect $Tag --format '{{.Id}}' 2>$null).Trim()
    if ($ActualId -ne $ExpectedId) { throw "$Label image ID mismatch" }
    Write-Host "  [OK] $Label $ActualId" -ForegroundColor Green
}

Write-Host '[4/5] Verifying loaded image IDs...' -ForegroundColor Yellow
Confirm-ImageId -Label 'devcontainer' -Tag $Manifest.DEVCONTAINER_TAG -ExpectedId $Manifest.DEVCONTAINER_ID
Confirm-ImageId -Label 'squid' -Tag $Manifest.SQUID_TAG -ExpectedId $Manifest.SQUID_ID

Write-Host '[5/5] Starting sandbox...' -ForegroundColor Yellow
$PreviousSandboxEnv=$env:SANDBOX_ENV
$PreviousLogRoot=$env:SANDBOX_LOG_ROOT
$PreviousHostAwsDir=$env:SANDBOX_HOST_AWS_DIR
try {
    $env:SANDBOX_ENV=$ManifestSandboxType
    $env:SANDBOX_LOG_ROOT=$HostLog.ComposeRoot
    $env:SANDBOX_HOST_AWS_DIR=$Runtime['SANDBOX_HOST_AWS_DIR']
    & docker compose --env-file $EnvFile -f $Compose config | Out-Null
    if ($LASTEXITCODE -ne 0) { throw 'docker compose config failed' }
    & docker compose --env-file $EnvFile -f $Compose up -d --force-recreate
    if ($LASTEXITCODE -ne 0) { throw 'docker compose up failed' }
}
finally {
    if ($null -eq $PreviousSandboxEnv) { Remove-Item Env:SANDBOX_ENV -ErrorAction SilentlyContinue } else { $env:SANDBOX_ENV=$PreviousSandboxEnv }
    if ($null -eq $PreviousLogRoot) { Remove-Item Env:SANDBOX_LOG_ROOT -ErrorAction SilentlyContinue } else { $env:SANDBOX_LOG_ROOT=$PreviousLogRoot }
    if ($null -eq $PreviousHostAwsDir) { Remove-Item Env:SANDBOX_HOST_AWS_DIR -ErrorAction SilentlyContinue } else { $env:SANDBOX_HOST_AWS_DIR=$PreviousHostAwsDir }
}

Write-Host "[OK] $ManifestSandboxType TAR sandbox started." -ForegroundColor Green
if ($HostLog.Mode -eq 'poc-local') {
    Start-PocLocalLogExporter -PackageRoot $Root -HostLog $HostLog
    Write-Warning "POC local logs are continuously exported to $($HostLog.Root), but the current Windows user can modify/delete those host files."
}
else {
    Write-Host "[OK] Runtime logs are Docker-owned streams and are exported by SYSTEM to $($Runtime['SANDBOX_LOG_ROOT'])." -ForegroundColor Green
}
