#!/usr/bin/env python3
"""Offline structural regression tests for Squid default-deny/SSRF policy."""
from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
CONF = ROOT / "squid" / "squid.conf"
WL = ROOT / "squid" / "whitelist.txt"


def fail(msg: str) -> None:
    raise SystemExit(f"Squid policy regression failed: {msg}")


text = CONF.read_text(encoding="utf-8")
lines = [line.strip() for line in text.splitlines()]

required = (
    "acl private_ip dst 10.0.0.0/8",
    "acl private_ip dst 127.0.0.0/8",
    "acl private_ip dst 169.254.0.0/16",
    "acl private_ip dst 172.16.0.0/12",
    "acl private_ip dst 192.168.0.0/16",
    "acl private_ip dst fc00::/7",
    "acl private_ip dst fe80::/10",
    "http_access deny private_ip",
    "http_access deny dst_is_ip",
    "http_access deny dst_is_ipv6",
    "acl allowed_destination_port port 443",
    "http_access deny !allowed_destination_port",
    "http_access allow whitelist",
)
for item in required:
    if item not in lines:
        fail(f"missing required rule: {item}")

for deny in ("http_access deny private_ip", "http_access deny dst_is_ip", "http_access deny dst_is_ipv6", "http_access deny !allowed_destination_port"):
    if lines.index(deny) > lines.index("http_access allow whitelist"):
        fail(f"{deny} must precede hostname allowlist")

# Squid dstdomain .example.com covers both the apex and every subdomain. A bare
# duplicate/child entry under a dot-prefixed parent is invalid/redundant and can
# make policy maintenance misleading (some Squid builds reject overlaps).
entries: list[str] = []
for raw in WL.read_text(encoding="utf-8").splitlines():
    value = raw.split("#", 1)[0].strip().lower().rstrip(".")
    if not value:
        continue
    if value.startswith("*."):
        fail(f"wildcard syntax is invalid for dstdomain: {value}")
    entries.append(value)

if len(entries) != len(set(entries)):
    fail("duplicate whitelist entries exist")

for i, a in enumerate(entries):
    a_base = a[1:] if a.startswith(".") else a
    for b in entries[i + 1 :]:
        b_base = b[1:] if b.startswith(".") else b
        if a.startswith(".") and (b_base == a_base or b_base.endswith("." + a_base)):
            fail(f"overlapping whitelist entries: {a} and {b}")
        if b.startswith(".") and (a_base == b_base or a_base.endswith("." + b_base)):
            fail(f"overlapping whitelist entries: {a} and {b}")

print("Squid policy regression tests passed")
