#!/usr/bin/env bash
# Offline regression test for direct Claude, direct Gemini, ucode Claude and
# ucode Gemini. All four modes must expose the same Admin-managed MCP set, and
# each MCP executable must run locally in the devcontainer with credentials
# supplied only through fixed localhost HTTP broker routes.
set -euo pipefail
root="$(cd "$(dirname "$0")/../.." && pwd)"
python3 - "$root" <<'PY'
import json
import pathlib
import sys

root = pathlib.Path(sys.argv[1])
claude = json.loads((root / 'policies/claude-mcp.json').read_text())
gemini = json.loads((root / 'policies/gemini-managed-settings.json').read_text())
wrapper = (root / '.devcontainer/scripts/sandbox-command-wrapper.sh').read_text()
config = (root / '.devcontainer/scripts/configure-mcp.sh').read_text()
dockerfile = (root / '.devcontainer/Dockerfile').read_text()
preamble = (root / '.devcontainer/scripts/mcp-wrapper-preamble.sh').read_text()
tavily = (root / '.devcontainer/scripts/tavily-mcp-ssm.sh').read_text()
snyk = (root / '.devcontainer/scripts/snyk-mcp-ssm.sh').read_text()
databricks = (root / '.devcontainer/scripts/databricks-sql-mcp-ssm.sh').read_text()
tar_compose = (root / 'tar/docker-compose.yml').read_text()
ecr_compose = (root / 'ecr/docker-compose.yml').read_text()

desired = {
    'tavily': '/usr/local/bin/tavily-mcp-ssm',
    'snyk': '/usr/local/bin/snyk-mcp-ssm',
    'databricks-sql': '/usr/local/bin/databricks-sql-mcp-ssm',
}

for label, doc in [('Claude', claude), ('Gemini system', gemini)]:
    servers = doc.get('mcpServers', {})
    if set(desired) - set(servers):
        raise SystemExit(f'{label} missing MCP servers: {sorted(set(desired)-set(servers))}')
    for name, command in desired.items():
        item = servers[name]
        if item.get('command') != command:
            raise SystemExit(f'{label} {name} command mismatch: {item.get("command")!r}')
        if item.get('env') is not None:
            raise SystemExit(f'{label} {name} unexpectedly contains env')

required_wrapper = [
    'ensure_gemini_mcp_config()',
    'GEMINI_CLI_SYSTEM_SETTINGS_PATH=/etc/gemini-cli/settings.json',
    'if is_local_only_operation "$agent" "${1:-}"; then',
    '[[ "$agent" == gemini && "${1:-}" == mcp ]] && ensure_gemini_mcp_config',
    'exec "$(real_tool "$agent")" "$@"',
    'ANTHROPIC_MODEL="$model"',
    'GEMINI_MODEL="$model"',
    'run_audited databricks ucode-claude "$model" https "$(real_tool claude)" "$@"',
    'run_audited databricks ucode-gemini "$model" https "$(real_tool gemini)" "$@"',
]
for needle in required_wrapper:
    if needle not in wrapper:
        raise SystemExit(f'wrapper invariant missing: {needle}')

local_idx = wrapper.index('if is_local_only_operation "$agent" "${1:-}"; then')
host_idx = wrapper.index('DATABRICKS_HOST must be configured with https://')
if local_idx > host_idx:
    raise SystemExit('ucode local MCP branch occurs after Databricks validation')

for forbidden in ('set -- --model', 'has_model_arg=', 'secret-broker-client', 'run-with-ssm-secrets'):
    if forbidden in wrapper:
        raise SystemExit(f'local application execution contract violated by: {forbidden}')

for name, command in desired.items():
    if command not in config:
        raise SystemExit(f'configure-mcp missing compatibility entry: {name}')

for token in ('"tavily", "snyk", "databricks-sql"', '.mcp.excluded'):
    if token not in config:
        raise SystemExit(f'configure-mcp stale-filter self-heal missing: {token}')

# Local MCP executables: no broker-side command RPC is allowed.
for label, text in [('Tavily MCP', tavily), ('Snyk MCP', snyk), ('Databricks SQL MCP', databricks)]:
    if 'secret-broker-client' in text or 'run-with-ssm-secrets' in text:
        raise SystemExit(f'{label} still delegates process execution to broker')
if '/usr/local/libexec/ai-sandbox/real/mcp-remote' not in tavily or 'tavily-policy-proxy.py' not in tavily:
    raise SystemExit('Tavily MCP is not a local policy + mcp-remote process')
if '/usr/local/libexec/ai-sandbox/real/snyk' not in snyk:
    raise SystemExit('Snyk MCP real process is not local')
if 'SNYK_API="$SNYK_API_BASE"' not in snyk or 'DEEPROXY_API_URL="$SNYK_CODE_BASE"' not in snyk:
    raise SystemExit('Snyk MCP does not use the validated general/Code credential routes')
if 'http://api.snyk.local:8771' not in snyk or 'http://deeproxy.snyk.local:8771' not in snyk:
    raise SystemExit('Snyk MCP local route aliases are missing')
if 'SNYK_PROXY' in snyk or 'snyk-proxy-ca' in snyk:
    raise SystemExit('retired Snyk transparent proxy remains in MCP launcher')
if '/usr/local/libexec/ai-sandbox/real/mcp-remote' not in databricks or '/databricks/sql-mcp' not in databricks:
    raise SystemExit('Databricks SQL MCP is not a local mcp-remote process')

if 'export AWS_CONFIG_FILE' in preamble or 'export AWS_SHARED_CREDENTIALS_FILE' in preamble or 'aws ssm' in preamble:
    raise SystemExit('MCP preamble exposes/configures broker AWS state')
if 'unset AWS_PROFILE AWS_DEFAULT_PROFILE AWS_CONFIG_FILE AWS_SHARED_CREDENTIALS_FILE' not in preamble:
    raise SystemExit('MCP preamble does not strip AWS profile state')

for label, text in [('Dockerfile', dockerfile), ('TAR compose', tar_compose), ('ECR compose', ecr_compose)]:
    if 'GEMINI_CLI_SYSTEM_SETTINGS_PATH' not in text or '/etc/gemini-cli/settings.json' not in text:
        raise SystemExit(f'{label} does not pin Gemini system settings path')

if gemini.get('general', {}).get('enableAutoUpdate') is not False:
    raise SystemExit('Gemini auto-update must be disabled for pinned builds')
if gemini.get('general', {}).get('enableAutoUpdateNotification') is not False:
    raise SystemExit('Gemini update notifications must be disabled for pinned builds')

print('MCP mode matrix and local-execution policy test passed')
PY
