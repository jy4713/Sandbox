#!/usr/bin/env bash
# Offline regression: ADO credential adapter must preserve native Git argv and
# must never receive the raw PAT. No network access is used.
set -euo pipefail
root="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd -P)"
source_policy="$root/.devcontainer/scripts/ado-git-policy.sh"
admin_policy="$root/policies/ado-policy.json"
command -v git >/dev/null 2>&1 || { echo 'SKIP: git unavailable'; exit 0; }
command -v jq >/dev/null 2>&1 || { echo 'SKIP: jq unavailable'; exit 0; }

tmp="$(mktemp -d)"; trap 'rm -rf "$tmp"' EXIT
policy="$tmp/ado-git-policy.sh"
sed "s|readonly ADO_POLICY_FILE=\"/etc/ai-sandbox/policies/ado-policy.json\"|readonly ADO_POLICY_FILE=\"$admin_policy\"|" "$source_policy" > "$policy"
chmod 0755 "$policy"

cd "$tmp"
git init -q repo
git -C repo config user.name lint
git -C repo config user.email lint@example.invalid
printf 'x\n' > repo/a.txt
git -C repo add a.txt
git -C repo commit -qm init

# Native local commands/global options must pass through instead of being
# rejected by a Sandbox command allowlist.
"$policy" /usr/bin/git --version >/dev/null
"$policy" /usr/bin/git -C repo status --short >/dev/null
"$policy" /usr/bin/git -C repo -c color.ui=false log -1 --oneline >/dev/null
"$policy" /usr/bin/git -C repo config --local test.native yes
[[ "$(git -C repo config --local test.native)" == yes ]]

# Credential isolation remains intact: adapter consumes shared route metadata,
# never a PAT/askpass secret, and does not impose native command restrictions.
grep -Fq 'ADO_POLICY_FILE="/etc/ai-sandbox/policies/ado-policy.json"' "$source_policy"
grep -Fq "'.git.repository_host | ascii_downcase'" "$source_policy"
grep -Fq "'.git.broker_base'" "$source_policy"
grep -Fq "'.git.rewrite_origin'" "$source_policy"
grep -Fq 'exec "$REAL_GIT" "${rewrite_args[@]}" "$@"' "$source_policy"
if grep -Eq 'ADO_PAT|GIT_ASKPASS|secret-broker-client|run-with-ssm-secrets' "$source_policy"; then
  echo 'ERROR: local ADO Git adapter can receive/delegate a raw credential' >&2
  exit 1
fi
if grep -Eq 'allowed_operations|not approved by Sandbox policy|not permitted|GIT_CONFIG_GLOBAL=/dev/null|GIT_CONFIG_NOSYSTEM=1|protocol\.(ext|file|git|ssh)\.allow=never' "$source_policy"; then
  echo 'ERROR: local ADO Git adapter still restricts native Git commands/options/config' >&2
  exit 1
fi
if grep -Eq 'secret-broker-client|run-with-ssm-secrets' "$root/.devcontainer/scripts/git-transparent.sh"; then
  echo 'ERROR: transparent Git still delegates the Git process to the broker' >&2
  exit 1
fi

echo 'ADO Git native-command regression tests passed'
