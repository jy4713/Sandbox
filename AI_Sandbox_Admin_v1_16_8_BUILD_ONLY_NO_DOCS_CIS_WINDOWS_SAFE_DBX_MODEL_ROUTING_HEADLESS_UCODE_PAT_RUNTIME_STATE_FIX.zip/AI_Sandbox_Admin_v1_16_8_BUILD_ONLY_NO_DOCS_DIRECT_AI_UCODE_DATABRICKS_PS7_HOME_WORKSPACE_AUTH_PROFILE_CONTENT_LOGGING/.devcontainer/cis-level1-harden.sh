#!/bin/bash
# =============================================================================
# PACKAGE MAINTENANCE NOTES
# Purpose: Applies additional container-focused security controls to the devcontainer filesystem.
# Admin maintenance: Change only when the hardening baseline changes. Application changes should normally be made in .devcontainer/Dockerfile, not here.
# Safety rule: preserve secret-free images/configuration, immutable version or
# digest pinning where applicable, and update the paired Bash/PowerShell path.
# After any change, run scripts/ci/lint-package.* and the applicable build/QA.
# Full change procedure: docs/ADMIN-COMPLETE-GUIDE.md
# =============================================================================
# =============================================================================
# cis-level1-harden.sh — Internal Ubuntu 24.04 defence-in-depth hardening
#
# sudo is NOT installed (not just restricted) — enforced at package install level.
# This script applies selected controls inspired by the CIS Level 1 baseline.
# It is NOT an authoritative CIS remediation implementation. Final assessment
# evidence is generated separately and must record the benchmark/content version.
#
# GENUINELY EFFECTIVE:
#   1.1  Kernel module blacklist (cramfs, jffs2, dccp, sctp etc.)
#   2.1  Remove risky packages (telnet, rsh, nis, xinetd)
#   5.1  Cron file permissions
#   5.3  PAM password quality config
#   5.5  su: pam_wheel restriction
#   5.6  Password aging (login.defs)
#   5.7  System accounts locked (nologin)
#   6.1  System file permissions
#   6.2  SUID/SGID removal (known binaries — Dockerfile runs full sweep after)
#   1.8  Login warning banner
#   umask 022 (login.defs; profile.d sets 027 after this script)
#
# CONFIG-PRESENT (scanner pass; daemons not running in container):
#   3.3  hosts.deny ALL:ALL (TCP Wrappers deprecated on Ubuntu 24.04)
#   4.2  rsyslog baseline configuration; host forwarding is external to the container
#   4.3  logrotate config (cron not running)
#   5.2  sshd_config (sshd not running)
#
# DEFERRED TO COMPOSE:
#   3.1-3.3  sysctl → sysctls:
#   1.1.x    /tmp,/var/tmp,/run → tmpfs:
#   4.1      audit events → host-mounted protected log directory
# =============================================================================
set -euo pipefail
echo "======================================================"
echo "  Ubuntu 24.04 — Internal Container Hardening"
echo "======================================================"

# CIS 1.1 — Kernel module blacklist
# NOTE: In a container sharing the host kernel, this file prevents the
# MODULE from being loaded if modprobe is called INSIDE the container.
# It does NOT control host kernel modules — those are host OS responsibility.
# Labelled: Effective for in-container modprobe calls; N/A for host kernel control.
echo "[CIS 1.1] Blacklisting unused kernel modules..."
mkdir -p /etc/modprobe.d
cat > /etc/modprobe.d/cis-l1-blacklist.conf << 'MODEOF'
install cramfs   /bin/true
install freevxfs /bin/true
install jffs2    /bin/true
install hfs      /bin/true
install hfsplus  /bin/true
install udf      /bin/true
install dccp     /bin/true
install sctp     /bin/true
install rds      /bin/true
install tipc     /bin/true
MODEOF

# CIS 2.1 — Remove risky packages
echo "[CIS 2.1] Removing risky packages..."
for pkg in telnet rsh-client rsh-server nis talk talkd xinetd; do
    dpkg -l "$pkg" &>/dev/null 2>&1 && apt-get purge -y --auto-remove "$pkg" 2>/dev/null && echo "  removed: $pkg" || true
done

# CIS 3.3 — hosts.deny (scanner compliance; TCP Wrappers deprecated)
echo "[CIS 3.3] Writing hosts.deny (deprecated on 24.04 — scanner pass only)..."
echo "ALL: ALL" > /etc/hosts.deny && chmod 644 /etc/hosts.deny

# CIS 4.2 — rsyslog configuration baseline (host forwarding is external to the container)
echo "[CIS 4.2] rsyslog config (config-present; host forwarding is external)..."
if [ -f /etc/rsyslog.conf ]; then
    grep -q '^\$FileCreateMode' /etc/rsyslog.conf \
        && sed -i 's/^\$FileCreateMode.*/\$FileCreateMode 0640/' /etc/rsyslog.conf \
        || echo '$FileCreateMode 0640' >> /etc/rsyslog.conf
fi
mkdir -p /etc/rsyslog.d
cat > /etc/rsyslog.d/50-sandbox.conf << 'RSYSEOF'
auth,authpriv.* /var/log/sandbox/auth.log
*.warn          /var/log/sandbox/syslog.log
RSYSEOF

# CIS 4.3 — logrotate (cron not running; config-present)
echo "[CIS 4.3] logrotate config (config-present; cron not running)..."
mkdir -p /etc/logrotate.d
cat > /etc/logrotate.d/sandbox << 'LREOF'
/var/log/sandbox/*.log {
    daily
    rotate 7
    compress
    delaycompress
    missingok
    notifempty
    create 0640 root adm
}
LREOF

# CIS 5.1 — Cron permissions (genuine effect)
echo "[CIS 5.1] Cron permissions..."
touch /etc/cron.allow && echo "root" > /etc/cron.allow && chmod 600 /etc/cron.allow
rm -f /etc/cron.deny
for d in /etc/cron.d /etc/cron.daily /etc/cron.hourly /etc/cron.weekly /etc/cron.monthly; do
    [ -d "$d" ] && chmod 700 "$d"
done
[ -f /etc/crontab ] && chmod 600 /etc/crontab

# CIS 5.2 — sshd_config (sshd not running; config-present)
echo "[CIS 5.2] sshd_config (config-present; sshd not running)..."
if [ -f /etc/ssh/sshd_config ]; then
    cp /etc/ssh/sshd_config /etc/ssh/sshd_config.original
    cat >> /etc/ssh/sshd_config << 'SSHEOF'
Protocol 2
LogLevel INFO
MaxAuthTries 4
X11Forwarding no
PermitRootLogin no
PermitEmptyPasswords no
PermitUserEnvironment no
Ciphers aes128-ctr,aes192-ctr,aes256-ctr
MACs hmac-sha2-256,hmac-sha2-512
ClientAliveInterval 300
ClientAliveCountMax 3
LoginGraceTime 60
Banner /etc/issue.net
IgnoreRhosts yes
HostbasedAuthentication no
SSHEOF
fi

# CIS 5.3 — PAM password quality
# libpam-pwquality is installed in Dockerfile apt-get step — this will take effect
echo "[CIS 5.3] PAM password quality..."
dpkg -l libpam-pwquality &>/dev/null 2>&1 && cat > /etc/security/pwquality.conf << 'PAMEOF'
minlen   = 14
dcredit  = -1
ucredit  = -1
ocredit  = -1
lcredit  = -1
PAMEOF

# CIS 5.4 — sudo: NOT INSTALLED — enforced at apt-get level in Dockerfile
echo "[CIS 5.4] sudo not installed — strongest control (no wheel group needed)"

# CIS 5.5 — su restriction
echo "[CIS 5.5] Restricting su..."
[ -f /etc/pam.d/su ] && ! grep -q 'pam_wheel.so' /etc/pam.d/su \
    && sed -i '1a auth required pam_wheel.so use_uid' /etc/pam.d/su || true

# CIS 5.6 — Password aging
echo "[CIS 5.6] Password aging..."
sed -i '/^PASS_MAX_DAYS/c\PASS_MAX_DAYS   365' /etc/login.defs
sed -i '/^PASS_MIN_DAYS/c\PASS_MIN_DAYS   1'   /etc/login.defs
sed -i '/^PASS_WARN_AGE/c\PASS_WARN_AGE   7'   /etc/login.defs

# CIS 5.7 — Lock system accounts
echo "[CIS 5.7] Locking system accounts..."
for user in daemon bin sys sync games man lp mail news uucp proxy \
            www-data backup list irc gnats nobody _apt; do
    id "$user" &>/dev/null && usermod -L -s /usr/sbin/nologin "$user" 2>/dev/null || true
done

# CIS 6.1 — System file permissions
echo "[CIS 6.1] System file permissions..."
chmod 644 /etc/passwd  2>/dev/null || true
chmod 644 /etc/group   2>/dev/null || true
chmod 640 /etc/shadow  2>/dev/null || true
chmod 640 /etc/gshadow 2>/dev/null || true
[ -f /etc/passwd-  ] && chmod 600 /etc/passwd-
[ -f /etc/group-   ] && chmod 600 /etc/group-
[ -f /etc/shadow-  ] && chmod 600 /etc/shadow-
[ -f /etc/gshadow- ] && chmod 600 /etc/gshadow-

# CIS 6.2 — SUID/SGID removal (known binaries)
# Note: Dockerfile runs find / -perm /6000 -exec chmod a-s after this for full sweep
echo "[CIS 6.2] Removing SUID/SGID from known binaries..."
for f in /usr/bin/at /usr/bin/chfn /usr/bin/chsh /usr/bin/gpasswd \
         /usr/bin/newgrp /usr/bin/wall /usr/bin/write \
         /sbin/mount.nfs /sbin/umount.nfs; do
    [ -f "$f" ] && chmod a-s "$f" && echo "  [a-s] $f" || true
done

# CIS 1.8 — Login banner
echo "[CIS 1.8] Login banner..."
cat > /etc/issue.net << 'BANEOF'
+------------------------------------------------------------------+
|                   AUTHORISED ACCESS ONLY                         |
|  This system is for authorised users only. All activity may be  |
|  monitored and recorded. Unauthorised use is prohibited.         |
+------------------------------------------------------------------+
BANEOF
cp /etc/issue.net /etc/issue && chmod 644 /etc/issue /etc/issue.net

# umask
grep -q '^UMASK' /etc/login.defs \
    && sed -i 's/^UMASK.*/UMASK           027/' /etc/login.defs \
    || echo 'UMASK           027' >> /etc/login.defs

apt-get clean && rm -rf /var/lib/apt/lists/* /tmp/* /var/tmp/*

echo
echo "======================================================"
echo "  Selected defence-in-depth controls applied; see final assessment evidence."
echo "  CONFIG-PRESENT: 3.3, 4.2, 4.3, 5.2"
echo "  sudo: NOT INSTALLED"
echo "  SUID/SGID full sweep: runs in Dockerfile AFTER this script"
echo "======================================================"
