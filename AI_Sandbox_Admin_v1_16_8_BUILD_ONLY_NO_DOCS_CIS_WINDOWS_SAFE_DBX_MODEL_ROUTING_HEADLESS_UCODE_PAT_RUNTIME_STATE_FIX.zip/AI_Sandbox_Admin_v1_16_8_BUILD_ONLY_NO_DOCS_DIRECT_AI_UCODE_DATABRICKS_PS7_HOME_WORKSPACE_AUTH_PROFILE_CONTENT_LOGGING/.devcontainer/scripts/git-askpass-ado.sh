#!/bin/sh
# =============================================================================
# PACKAGE MAINTENANCE NOTES
# Purpose: Provides Azure DevOps PAT credentials to Git through GIT_ASKPASS from process memory.
# Admin maintenance: Normally no application maintenance is needed here. Change only if the ADO authentication contract or prompt handling changes.
# Safety rule: preserve secret-free images/configuration, immutable version or
# digest pinning where applicable, and update the paired Bash/PowerShell path.
# After any change, run scripts/ci/lint-package.* and the applicable build/QA.
# Full change procedure: docs/ADMIN-COMPLETE-GUIDE.md
# =============================================================================
# =============================================================================
# git-askpass-ado — Supply the ADO PAT to git from the process environment
#
# Git does not read arbitrary variables such as ADO_PAT. It asks for
# credentials via GIT_ASKPASS. This helper answers those prompts from the
# in-memory environment that run-with-ssm-secrets set up, so the PAT is
# never written to ~/.git-credentials or any other file.
#
# Not intended to be called directly. run-with-ssm-secrets sets:
#   GIT_ASKPASS=/usr/local/bin/git-askpass-ado
#
# Git calls this with a prompt string such as:
#   "Username for 'https://dev.azure.com': "
#   "Password for 'https://sandbox@dev.azure.com': "
# =============================================================================

case "$1" in
    Username*|username*)
        # Azure DevOps ignores the username when a PAT is used as the password
        printf 'sandbox'
        ;;
    Password*|password*)
        if [ -z "${ADO_PAT:-}" ]; then
            echo "ERROR: ADO_PAT not in environment." >&2
            echo "  Run git through: run-with-ssm-secrets --profile ado -- git ..." >&2
            exit 1
        fi
        printf '%s' "$ADO_PAT"
        ;;
    *)
        echo "ERROR: unexpected askpass prompt: $1" >&2
        exit 1
        ;;
esac
