#!/usr/bin/env bash
# =============================================================================
# PACKAGE MAINTENANCE NOTES
# Purpose: Launch Snyk MCP over stdio with SNYK_TOKEN supplied only to the child
#          process and record redacted MCP lifecycle metadata.
# Safety rule: Never log MCP request/response payloads or source-code content.
# =============================================================================
set -euo pipefail
set +x
readonly REAL_SNYK="/usr/local/libexec/ai-sandbox/real/snyk"
[[ -x "$REAL_SNYK" ]] || { echo 'ERROR: real Snyk executable is missing' >&2; exit 1; }
args=("$@")
has_transport=false
for arg in "${args[@]}"; do
  case "$arg" in -t|--transport) has_transport=true ;; esac
done
if [[ "$has_transport" != true ]]; then args=(-t stdio "${args[@]}"); fi
start_ms="$(date +%s%3N)"
application-audit --app mcp --event server_start --operation snyk --target snyk --status started --transport stdio
set +e
run-with-ssm-secrets --profile snyk -- "$REAL_SNYK" mcp "${args[@]}"
ec=$?
set -e
end_ms="$(date +%s%3N)"
status=success; (( ec == 0 )) || status=failure
application-audit --app mcp --event server_end --operation snyk --target snyk --status "$status" --exit-code "$ec" --duration-ms "$((end_ms-start_ms))" --transport stdio || true
exit "$ec"
