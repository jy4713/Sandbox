#!/usr/bin/env bash
# =============================================================================
# PACKAGE MAINTENANCE NOTES
# Purpose: Write shell, Git and security audit metadata to the host-exported
#          Sandbox log directory without copying arbitrary command arguments.
# Admin maintenance: Keep this metadata-only. Secret-bearing arguments, prompts,
#                    search queries, source code and response payloads must not
#                    be written to audit.log/security.log.
# =============================================================================
AUDIT_LOG="/var/log/sandbox/audit.log"
SEC_LOG="/var/log/sandbox/security.log"
DEVELOPER_ID="${DEVELOPER_ID:-unknown}"

_aw() {
  printf '%s | %-16s | user=%-10s | %-50s | %s\n' \
    "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$1" "$DEVELOPER_ID" "$2" "${3:-}" >> "$AUDIT_LOG"
}

_sw() {
  # Arguments to _sw must already be metadata-only. jq is avoided here so the
  # shell hook remains lightweight and available during early shell startup.
  local detail="${3:-}"
  detail="$(printf '%s' "$detail" | tr -cd 'A-Za-z0-9._:@/+\-= ' | cut -c1-160)"
  printf '{"ts":"%s","sev":"%s","event":"%s","user":"%s","detail":"%s","host":"%s"}\n' \
    "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$1" "$2" "$DEVELOPER_ID" "$detail" "$(hostname)" >> "$SEC_LOG"
}

_cmd_metadata() {
  local cmd="${1:-}" first second argc
  # Parse only the first two shell words for attribution. Do not emit the rest.
  read -r first second _ <<< "$cmd"
  first="$(basename -- "${first:-unknown}" 2>/dev/null || printf unknown)"
  argc="$(awk '{print NF}' <<< "$cmd")"
  case "$first" in
    run-with-ssm-secrets)
      printf 'tool=run-with-ssm-secrets argc=%s' "$argc"
      ;;
    claude|claude-code|gemini|gemini-cli|tvly|tavily-mcp|snyk|databricks|ado-trigger|ado-pr-create|ado-auth-setup)
      printf 'tool=%s subcommand=%s argc=%s' "$first" "${second:-none}" "$argc"
      ;;
    git)
      printf 'tool=git subcommand=%s argc=%s' "${second:-none}" "$argc"
      ;;
    *)
      printf 'tool=%s subcommand=%s argc=%s' "$first" "${second:-none}" "$argc"
      ;;
  esac
}

_sandbox_log_cmd() {
  local ec=$? cmd meta
  cmd=$(HISTTIMEFORMAT='' history 1 | sed 's/^[[:space:]]*[0-9]*[[:space:]]*//')
  [[ -z "$cmd" || "$cmd" == "_sandbox_log_cmd" ]] && return
  meta="$(_cmd_metadata "$cmd")"
  _aw "SHELL_CMD" "$meta" "exit=$ec cwd=$(pwd)"

  # Detect high-risk patterns from the in-memory command but record only the
  # category, never the original command string.
  if echo "$cmd" | grep -qE '(sudo|chmod\s+[0-7]*7|curl.*\|.*sh|wget.*\|.*sh|nc |ncat )'; then
    _sw "HIGH" "suspicious_cmd" "$meta"
  fi

  # For direct curl/wget, record only the destination hostname, not the URL path,
  # query string, headers, body or command arguments.
  if echo "$cmd" | grep -qE '(^|[[:space:]])(curl|wget)([[:space:]]|$)'; then
    local url host
    url=$(echo "$cmd" | grep -oE 'https?://[^ ]+' | head -1 || true)
    if [[ -n "$url" ]]; then
      host=$(printf '%s' "$url" | sed -E 's#^https?://([^/@]+@)?([^/:?#]+).*#\2#')
      [[ -n "$host" ]] && _aw "EGRESS_ATTEMPT" "tool=curl-wget" "host=${host:0:120}"
    fi
  fi
}
[[ $- == *i* ]] && PROMPT_COMMAND="_sandbox_log_cmd${PROMPT_COMMAND:+; $PROMPT_COMMAND}"

# Interactive git wrapper. Secret-backed non-interactive ADO git operations are
# separately attributed by run-with-ssm-secrets to ado-events.log.
git() {
  local sub="${1:-none}" start_ms end_ms duration_ms ec status
  _aw "GIT_OP" "git subcommand=${sub:0:32}" "argc=$#"
  if [[ "$sub" == "push" ]]; then
    _sw "INFO" "git_push" "push requested"
  fi
  start_ms="$(date +%s%3N)"
  if command -v application-audit >/dev/null 2>&1; then
    application-audit --app git --event process_start --operation "$sub" --target repository --status started >/dev/null 2>&1 || true
  fi
  command git "$@"
  ec=$?
  end_ms="$(date +%s%3N)"; duration_ms=$((end_ms-start_ms)); status=success; (( ec == 0 )) || status=failure
  if command -v application-audit >/dev/null 2>&1; then
    application-audit --app git --event process_end --operation "$sub" --target repository --status "$status" --exit-code "$ec" --duration-ms "$duration_ms" >/dev/null 2>&1 || true
  fi
  return "$ec"
}

sudo() {
  _sw "HIGH" "sudo_attempt" "sudo requested"
  _aw "SECURITY" "sudo_attempt" "arguments_redacted=true"
  command sudo "$@"
}

# ADO helper functions retained for scripts that source this logger. Free-form PR
# titles, pipeline parameters and repository URLs are intentionally not logged.
log_ado_trigger()    { _aw "ADO_PIPELINE" "trigger" "pipeline_id=${1:-unknown}"; }
log_ado_pr_create()  { _aw "ADO_PR" "create_pr" "metadata_redacted=true"; }
log_ado_git_clone()  { _aw "ADO_GIT" "clone" "remote_redacted=true"; }
export -f log_ado_trigger log_ado_pr_create log_ado_git_clone 2>/dev/null || true

_aw "SESSION_START" "shell=$(basename -- "$SHELL")" "tty=$(tty 2>/dev/null || echo notty)"
