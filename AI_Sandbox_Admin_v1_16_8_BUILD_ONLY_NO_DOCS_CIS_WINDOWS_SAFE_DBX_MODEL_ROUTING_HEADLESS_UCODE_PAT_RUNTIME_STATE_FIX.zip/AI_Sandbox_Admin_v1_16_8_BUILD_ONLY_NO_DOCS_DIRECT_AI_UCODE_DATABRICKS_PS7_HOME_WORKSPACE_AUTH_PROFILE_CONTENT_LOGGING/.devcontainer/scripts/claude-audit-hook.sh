#!/usr/bin/env bash
# =============================================================================
# PACKAGE MAINTENANCE NOTES
# Purpose: Record redacted Claude Code lifecycle/tool-usage metadata and,
#          optionally, user prompt/final assistant response content.
# Default: Content logging is disabled. Metadata-only logging remains enabled.
# Security: Content logs may contain source code, customer data, credentials,
#           internal URLs, tool results, or other sensitive information.
#           Enable SANDBOX_CONTENT_LOGGING=true only with explicit approval.
# =============================================================================
set -u
set +x
umask 077

LOG_FILE="${CLAUDE_AUDIT_LOG:-/var/log/sandbox/claude-events.log}"
DEVELOPER_ID_VALUE="${DEVELOPER_ID:-unknown}"
CONTENT_LOGGING="${SANDBOX_CONTENT_LOGGING:-false}"
AI_ROUTE="${SANDBOX_AI_ROUTE:-direct-anthropic}"

INPUT="$(cat 2>/dev/null || true)"
[[ -n "$INPUT" ]] || exit 0
command -v jq >/dev/null 2>&1 || exit 0

mkdir -p "$(dirname "$LOG_FILE")" 2>/dev/null || true

# Metadata-only audit. Never add prompt/response/tool payload fields here.
printf '%s' "$INPUT" | jq -c \
  --arg ts "$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
  --arg developer_id "$DEVELOPER_ID_VALUE" \
  --arg route "$AI_ROUTE" '
  {
    ts: $ts,
    source: "claude-code-hook",
    developer_id: $developer_id,
    route: $route,
    event: (.hook_event_name // "unknown"),
    session_id: (.session_id // null),
    cwd: (.cwd // null),
    permission_mode: (.permission_mode // null),
    tool_name: (.tool_name // null),
    tool_use_id: (.tool_use_id // null),
    session_source: (.source // null),
    model: (.model // null),
    reason: (.reason // null),
    error_type: (.error_type // null),
    agent_id: (.agent_id // null),
    agent_type: (.agent_type // null),
    prompt_length: (if (.prompt? | type) == "string" then (.prompt | length) else null end)
  }
  | with_entries(select(.value != null and .value != ""))
' >> "$LOG_FILE" 2>/dev/null || true

# Optional content logging. Claude Code hooks expose the submitted user prompt on
# UserPromptSubmit and the final assistant text on Stop. This is not a raw wire
# capture of every Anthropic/Databricks API request; it is the user-facing prompt
# and final assistant response available to the Claude Code hook interface.
if [[ "$CONTENT_LOGGING" == "true" ]]; then
  case "$AI_ROUTE" in
    databricks-claude) CONTENT_LOG_FILE="${UCODE_CLAUDE_CONTENT_LOG:-/var/log/sandbox/content/ucode-claude-content.log}" ;;
    *) CONTENT_LOG_FILE="${CLAUDE_CONTENT_LOG:-/var/log/sandbox/content/claude-content.log}" ;;
  esac
  mkdir -p "$(dirname "$CONTENT_LOG_FILE")" 2>/dev/null || true
  touch "$CONTENT_LOG_FILE" 2>/dev/null || true
  chmod 0600 "$CONTENT_LOG_FILE" 2>/dev/null || true

  printf '%s' "$INPUT" | jq -c \
    --arg ts "$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
    --arg developer_id "$DEVELOPER_ID_VALUE" \
    --arg route "$AI_ROUTE" '
    if .hook_event_name == "UserPromptSubmit" and ((.prompt? | type) == "string") then
      {
        ts:$ts,
        source:"ai-sandbox-content-log",
        app:"claude",
        route:$route,
        developer_id:$developer_id,
        session_id:(.session_id // null),
        event:"request_prompt",
        model:(.model // null),
        content:.prompt
      }
    elif .hook_event_name == "Stop" and ((.last_assistant_message? | type) == "string") then
      {
        ts:$ts,
        source:"ai-sandbox-content-log",
        app:"claude",
        route:$route,
        developer_id:$developer_id,
        session_id:(.session_id // null),
        event:"response",
        model:(.model // null),
        content:.last_assistant_message
      }
    else empty end
    | with_entries(select(.value != null and .value != ""))
  ' >> "$CONTENT_LOG_FILE" 2>/dev/null || true
fi

exit 0
