#!/usr/bin/env bash
# =============================================================================
# PACKAGE MAINTENANCE NOTES
# Purpose: Launch Tavily MCP with TAVILY_API_KEY supplied only to the child
#          process and record redacted MCP lifecycle metadata.
# Safety rule: Never log MCP request/response payloads or Tavily search content.
# =============================================================================
set -euo pipefail
set +x
readonly REAL_TAVILY_MCP="/usr/local/libexec/ai-sandbox/real/tavily-mcp"
[[ -x "$REAL_TAVILY_MCP" ]] || { echo 'ERROR: real Tavily MCP executable is missing' >&2; exit 1; }
start_ms="$(date +%s%3N)"
application-audit --app mcp --event server_start --operation tavily --target tavily --status started --transport stdio
set +e
run-with-ssm-secrets --profile tavily -- "$REAL_TAVILY_MCP" "$@"
ec=$?
set -e
end_ms="$(date +%s%3N)"
status=success; (( ec == 0 )) || status=failure
application-audit --app mcp --event server_end --operation tavily --target tavily --status "$status" --exit-code "$ec" --duration-ms "$((end_ms-start_ms))" --transport stdio || true
exit "$ec"
