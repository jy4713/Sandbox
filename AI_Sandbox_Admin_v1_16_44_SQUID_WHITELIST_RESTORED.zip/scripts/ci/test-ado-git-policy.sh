#!/usr/bin/env bash
set -euo pipefail
root="$(cd "$(dirname "$0")/../.." && pwd)"
source_policy="$root/.devcontainer/scripts/ado-git-policy.sh"
admin_policy="$root/policies/ado-policy.json"
[[ -x "$source_policy" ]] || { echo 'ERROR: ADO Git policy is not executable' >&2; exit 1; }
[[ -r "$admin_policy" ]] || { echo 'ERROR: shared Admin ADO policy is missing' >&2; exit 1; }
command -v git >/dev/null 2>&1 || { echo 'SKIP: git unavailable'; exit 0; }
command -v jq >/dev/null 2>&1 || { echo 'SKIP: jq unavailable'; exit 0; }

tmp="$(mktemp -d)"; trap 'rm -rf "$tmp"' EXIT
# The installed runtime path is intentionally immutable and not environment-overridable.
# For offline source-tree CI only, patch a temporary copy to point at the source policy.
policy="$tmp/ado-git-policy.sh"
sed "s|readonly ADO_POLICY_FILE=\"/etc/ai-sandbox/policies/ado-policy.json\"|readonly ADO_POLICY_FILE=\"$admin_policy\"|" "$source_policy" > "$policy"
chmod 0755 "$policy"

cd "$tmp"
git init -q
git config user.name lint
git config user.email lint@example.invalid
approved="$(jq -r '.git.rewrite_origin' "$admin_policy")approved-org/approved-project/_git/approved-repo"
git remote add origin "$approved"

expect_reject() {
  if "$policy" /usr/bin/git "$@" >/dev/null 2>&1; then
    echo "ERROR: policy unexpectedly accepted: git $*" >&2
    exit 1
  fi
}

# The DevContainer validator must consume the central source, not duplicate its
# host, operation list, broker route or rewrite origin in an independent file.
grep -Fq 'ADO_POLICY_FILE="/etc/ai-sandbox/policies/ado-policy.json"' "$source_policy" || { echo 'ERROR: local ADO policy does not read central runtime policy' >&2; exit 1; }
grep -Fq "'.git.allowed_operations | index(\$op) != null'" "$source_policy" || { echo 'ERROR: local ADO operation gate is not policy-driven' >&2; exit 1; }
grep -Fq "'.git.repository_host | ascii_downcase'" "$source_policy" || { echo 'ERROR: local ADO host gate is not policy-driven' >&2; exit 1; }
grep -Fq "'.git.repository_path_regex'" "$source_policy" || { echo 'ERROR: local ADO repository path gate is not policy-driven' >&2; exit 1; }
grep -Fq "'.git.broker_base'" "$source_policy" || { echo 'ERROR: local ADO broker route is not policy-driven' >&2; exit 1; }
grep -Fq "'.git.rewrite_origin'" "$source_policy" || { echo 'ERROR: local ADO rewrite origin is not policy-driven' >&2; exit 1; }

# Repository identity is deliberately not pinned in Sandbox metadata. The PAT
# and Azure DevOps permissions decide which repositories are authorized.
if grep -Eq 'ADO_(ORG|PROJECT|REPO)([^A-Z0-9_]|$)|Admin-approved repository|outside the Admin-approved repository' "$source_policy"; then
  echo 'ERROR: ADO Git policy still pins repository identity in Sandbox metadata' >&2
  exit 1
fi
if grep -Eq 'ADO_PAT|GIT_ASKPASS|secret-broker-client|run-with-ssm-secrets' "$source_policy"; then
  echo 'ERROR: local ADO Git policy still receives/delegates a raw credential' >&2
  exit 1
fi
if grep -Eq 'secret-broker-client|run-with-ssm-secrets' "$root/.devcontainer/scripts/git-transparent.sh"; then
  echo 'ERROR: transparent Git still delegates the Git process to the broker' >&2
  exit 1
fi

# These all fail before any network request is attempted.
expect_reject push 'ext::sh -c id'
expect_reject clone 'file:///tmp/other'
expect_reject fetch --upload-pack=/tmp/helper origin
expect_reject clone 'https://example.invalid/org/proj/_git/repo'

git remote set-url --push origin 'https://example.invalid/steal'
expect_reject push origin
git remote set-url --delete --push origin 'https://example.invalid/steal' 2>/dev/null || true
git config 'url.https://example.invalid/.insteadOf' 'https://dev.azure.com/'
expect_reject fetch origin

# Repository/branch governance remains delegated to Azure DevOps.
if grep -Eqi 'direct push to main/master|force-push refspecs are not approved|destructive Git push option is not approved' "$source_policy"; then
  echo 'ERROR: sandbox Git policy still contains branch/history governance restrictions' >&2
  exit 1
fi
grep -Fq -- '--force-with-lease=*' "$source_policy" || { echo 'ERROR: force-with-lease parser support missing' >&2; exit 1; }
grep -Fq -- '--mirror' "$source_policy" || { echo 'ERROR: mirror push parser support missing' >&2; exit 1; }
grep -Fq -- '--delete' "$source_policy" || { echo 'ERROR: delete push parser support missing' >&2; exit 1; }

echo 'ADO Git shared-policy regression tests passed'
