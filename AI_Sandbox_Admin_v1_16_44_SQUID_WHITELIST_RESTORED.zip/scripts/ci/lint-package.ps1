#Requires -Version 7.4
[CmdletBinding()]
param([string]$Root = (Split-Path -Parent (Split-Path -Parent $PSScriptRoot)))

$ErrorActionPreference = 'Stop'
$failures = 0

function Pass([string]$Message) { Write-Host "[OK]   $Message" -ForegroundColor Green }
function Fail([string]$Message) { $script:failures++; Write-Host "[FAIL] $Message" -ForegroundColor Red }
function Text([string]$Path) { Get-Content (Join-Path $Root $Path) -Raw -Encoding UTF8 }
function Has([string]$Path, [string]$Needle) { (Text $Path).Contains($Needle) }
function NoMatch([string]$Path, [string]$Regex) { (Text $Path) -notmatch $Regex }
function ServiceBlock([string]$Path, [string]$Service, [string]$NextService) {
    $t = Text $Path
    $pattern = if ($NextService) {
        "(?ms)^  $([regex]::Escape($Service)):\s*.*?(?=^  $([regex]::Escape($NextService)):)"
    } else {
        "(?ms)^  $([regex]::Escape($Service)):\s*.*\z"
    }
    $m = [regex]::Match($t, $pattern)
    if (-not $m.Success) { return '' }
    return $m.Value
}

$required = @(
    '.env.example', '.build.env.example', '.devcontainer\Dockerfile', '.devcontainer\devcontainer.json',
    '.devcontainer\scripts\secret-broker-client.py', '.devcontainer\scripts\secret-broker-server.py',
    '.devcontainer\scripts\provider-loopback-relay.py', '.devcontainer\scripts\run-with-ssm-secrets.sh',
    '.devcontainer\scripts\sandbox-command-wrapper.sh', '.devcontainer\scripts\mcp-wrapper-preamble.sh',
    '.devcontainer\scripts\tavily-mcp-ssm.sh', '.devcontainer\scripts\snyk-mcp-ssm.sh',
    '.devcontainer\scripts\databricks-sql-mcp-ssm.sh', '.devcontainer\scripts\configure-mcp.sh',
    'policies\README.md', 'policies\admin-settings.json', 'policies\gemini-managed-settings.json', 'policies\gemini-web-policy.toml',
    'policies\claude-mcp.json', 'policies\tavily-allowed-domains.json', 'policies\ado-policy.json', 'squid\whitelist.txt', '.devcontainer\scripts\verify-runtime.sh',
    '.devcontainer\scripts\ado-git.sh', '.devcontainer\scripts\ado-git-policy.sh',
    '.devcontainer\scripts\git-transparent.sh', 'tar\docker-compose.yml', 'ecr\docker-compose.yml',
    'scripts\tar\load-and-start.ps1', 'scripts\ecr\pull-and-start.ps1'
)
foreach ($f in $required) {
    if (-not (Test-Path (Join-Path $Root $f))) { Fail "required file exists: $f" }
}

if (Test-Path (Join-Path $Root '.devcontainer\policies')) { Fail 'legacy .devcontainer/policies directory must not exist' }
foreach ($f in @('ado-policy.json','tavily-allowed-domains.json','claude-mcp.json','gemini-managed-settings.json','gemini-web-policy.toml')) {
    if (-not (Has '.devcontainer\Dockerfile' "COPY policies/$f")) { Fail "Dockerfile does not consume central policy source: $f" }
}
if (-not (Has '.devcontainer\Dockerfile' '/etc/ai-sandbox/policies/ado-policy.json')) { Fail 'ADO shared runtime policy path missing' }
if (-not (Has '.devcontainer\scripts\git-transparent.sh' '/etc/ai-sandbox/policies/ado-policy.json')) { Fail 'transparent Git routing does not consume shared ADO policy' }
if (-not (Has '.devcontainer\Dockerfile' '/etc/ai-sandbox/policies/tavily-allowed-domains.json')) { Fail 'Tavily shared runtime policy path missing' }
if (-not (Has 'squid\Dockerfile' 'COPY squid/whitelist.txt /etc/squid/whitelist.txt')) { Fail 'Squid Dockerfile does not consume squid/whitelist.txt' }
if (Test-Path (Join-Path $Root 'policies\squid-egress-allowlist.txt')) { Fail 'duplicate Squid allowlist must not exist under policies/' }
Pass 'shared policy and component-owned Squid policy layout inspected'

foreach ($k in @('AWS_AUTH_MODE','AZURE_TENANT_ID','AZURE_APP_ID_URI','AZURE_DEFAULT_USERNAME','AZURE_DEFAULT_ROLE_ARN','AZURE_DEFAULT_DURATION_HOURS','AZURE_DEFAULT_REMEMBER_ME','SANDBOX_HOST_AWS_DIR')) {
    if (-not (Has '.env.example' "$k=")) { Fail ".env.example exposes required host auth field: $k" }
}
if (NoMatch '.env.example' '(?m)^(AWS_ACCESS_KEY_ID|AWS_SECRET_ACCESS_KEY|AWS_SESSION_TOKEN|AWS_SSO_)=') {
    Pass 'runtime template has no static/native-IAM-SSO credential fields'
} else { Fail 'legacy AWS credential/Identity Center fields remain in runtime template' }

foreach ($f in @('scripts\tar\load-and-start.ps1','scripts\ecr\pull-and-start.ps1')) {
    if (-not (Has $f 'aws-azure-login --profile $Profile --mode gui')) { Fail "host browser aws-azure-login flow missing: $f" }
    if (-not (Has $f 'AWS_AUTH_MODE')) { Fail "host auth mode selection missing: $f" }
    if (-not (Has $f 'aws configure --profile')) { Fail "static host-profile guidance missing: $f" }
    if (-not (NoMatch $f 'aws sso login|sts get-caller-identity')) { Fail "legacy AWS auth or STS preflight remains: $f" }
}
Pass 'host authentication flow inspected'

foreach ($f in @('tar\docker-compose.yml','ecr\docker-compose.yml')) {
    $t = Text $f
    if ($t -match 'AWS_ACCESS_KEY_ID:|AWS_SECRET_ACCESS_KEY:|AWS_SESSION_TOKEN:|AWS_SSO_') { Fail "legacy AWS runtime mapping in $f" }
    if ($t -notmatch 'AI_SANDBOX_ROLE: "client"') { Fail "AI client role missing in $f" }
    if ($t -notmatch 'AI_SANDBOX_ROLE: "broker"') { Fail "credential broker role missing in $f" }
    if (-not $t.Contains('SANDBOX_HOST_AWS_DIR')) { Fail "host .aws broker mount missing in $f" }
    if (([regex]::Matches($t, 'target: /home/vscode/\.aws')).Count -ne 1) { Fail "exactly one .aws bind target required in $f" }
    $brokerBlock = ServiceBlock $f 'secret-broker' 'devcontainer'
    $devBlock = ServiceBlock $f 'devcontainer' ''
    if (-not $brokerBlock) { Fail "secret-broker block not found in $f" }
    if (-not $devBlock) { Fail "devcontainer block not found in $f" }
    if ($brokerBlock.Contains('target: /home/vscode/workspace')) { Fail "broker must not mount workspace: $f" }
    if (-not $devBlock.Contains('target: /home/vscode/workspace')) { Fail "devcontainer must mount workspace: $f" }
    if ($brokerBlock.Contains('/run/ai-sandbox-snyk')) { Fail "broker must not own Snyk executable tmpfs: $f" }
    if (-not $devBlock.Contains('/run/ai-sandbox-snyk')) { Fail "Snyk executable tmpfs must belong to devcontainer: $f" }
    if (-not $t.Contains('cap_drop: [ALL]')) { Fail "capabilities not fully dropped in $f" }
    if (-not $t.Contains('no-new-privileges:true')) { Fail "no-new-privileges missing in $f" }
}
Pass 'Compose credential/workspace boundary inspected'

$runner = '.devcontainer\scripts\run-with-ssm-secrets.sh'
$client = '.devcontainer\scripts\secret-broker-client.py'
$broker = '.devcontainer\scripts\secret-broker-server.py'
$wrapper = '.devcontainer\scripts\sandbox-command-wrapper.sh'
$preamble = '.devcontainer\scripts\mcp-wrapper-preamble.sh'

if (-not (Has $runner 'broker-side command execution is disabled')) { Fail 'retired SSM runner is not fail closed' }
if (-not (Has $runner 'exit 126')) { Fail 'retired SSM runner does not return 126' }
if (-not (NoMatch $runner 'aws\s+ssm|get_parameter|exec\s+.*\$@')) { Fail 'retired SSM runner still fetches credentials or executes a command' }
if (-not (Has $client 'broker-side command execution is disabled')) { Fail 'legacy broker command client is not fail closed' }
if (-not (Has $client 'SystemExit(126)')) { Fail 'legacy broker command client does not return 126' }
if (-not (Has $broker 'command_execution=disabled')) { Fail 'broker does not advertise command execution disabled' }
if (-not (Has $broker '"ssm", "get-parameter"')) { Fail 'broker SSM credential retrieval missing' }
if (-not (NoMatch $broker 'subprocess\.(Popen|call|check_call|check_output)|os\.(system|exec)|run-with-ssm-secrets|secret-broker-client|/home/vscode/workspace')) { Fail 'broker contains application process/workspace execution path' }
if (([regex]::Matches((Text $broker), 'subprocess\.run\(')).Count -ne 1) { Fail 'broker must have exactly one subprocess use (internal AWS SSM read)' }
if (-not (Has $broker '["aws", "--profile", AWS_PROFILE, "ssm", "get-parameter"')) { Fail 'broker subprocess is not pinned to AWS SSM get-parameter' }
foreach ($needle in @('safe_suffix','_enforce_tavily_http','_enforce_tavily_mcp','_ado_request_allowed','ADO_POLICY_PATH','ADO_ROUTES','claude-api-key','gemini-api-key','snyk-token','tavily-api-key','ado-pat','/databricks/anthropic','/databricks/gemini','/databricks/sql-mcp','Authorization')) {
    if (-not (Has $broker $needle)) { Fail "credential-only broker invariant missing: $needle" }
}
if (-not (Has '.devcontainer\scripts\provider-loopback-relay.py' 'LISTEN_HOST = "127.0.0.1"')) { Fail 'provider relay is not loopback-only' }
Pass 'credential-only broker architecture inspected'

if (-not (Has $wrapper 'readonly PROVIDER_BASE="http://127.0.0.1:8771"')) { Fail 'application wrapper does not pin credential route to localhost' }
if (-not (Has $wrapper 'ai-sandbox-broker-placeholder')) { Fail 'non-secret placeholder auth missing' }
if (-not (Has $wrapper 'strip_service_secrets')) { Fail 'application wrapper does not strip caller-injected service credentials' }
if (-not (Has $wrapper 'unset ADO_PAT DATABRICKS_TOKEN DATABRICKS_SQL_MCP_TOKEN')) { Fail 'application wrapper does not strip PAT/token variables' }
if (-not (Has $wrapper 'export NO_PROXY="localhost,127.0.0.1,squid-proxy')) { Fail 'application wrapper does not pin localhost broker bypass' }
if (-not (NoMatch $wrapper 'secret-broker-client|run-with-ssm-secrets')) { Fail 'application wrapper still delegates process execution to broker' }
foreach ($cmd in @('claude','gemini','databricks','tvly','snyk')) {
    if (-not (Has $wrapper "real_tool $cmd")) { Fail "local real executable path missing: $cmd" }
}
if (-not (Has $wrapper 'exec "$(real_tool "$agent")" "$@"')) { Fail 'ucode local agent-control path missing' }
if (-not (Has $wrapper 'run_audited databricks ucode-claude')) { Fail 'ucode Claude does not run locally' }
if (-not (Has $wrapper 'run_audited databricks ucode-gemini')) { Fail 'ucode Gemini does not run locally' }
if (-not (NoMatch $wrapper 'DATABRICKS_TOKEN=.*get_parameter|export DATABRICKS_TOKEN')) { Fail 'ucode can receive a real Databricks PAT' }
if (-not (Has $wrapper '/run/ai-sandbox-snyk')) { Fail 'Snyk local runtime tmpfs missing' }
if (-not (Has $wrapper 'SNYK_API="${PROVIDER_BASE}/snyk"')) { Fail 'Snyk does not use credential-only localhost API route' }
if (-not (Has $wrapper 'tavily-cli-policy.py')) { Fail 'Tavily local CLI policy missing' }
if (-not (Has '.devcontainer\scripts\tavily-sitecustomize.py' 'BROKER_BASE = "http://127.0.0.1:8771/tavily-api"')) { Fail 'Tavily SDK not pinned to credential-only localhost route' }
Pass 'local application execution inspected'

if (-not (NoMatch $preamble 'export AWS_CONFIG_FILE|export AWS_SHARED_CREDENTIALS_FILE|aws\s+ssm')) { Fail 'MCP preamble configures or fetches AWS state' }
if (-not (Has $preamble 'unset AWS_PROFILE AWS_DEFAULT_PROFILE AWS_CONFIG_FILE AWS_SHARED_CREDENTIALS_FILE')) { Fail 'MCP preamble does not strip AWS profile paths' }
if (-not (Has $preamble 'unset ADO_PAT DATABRICKS_TOKEN DATABRICKS_SQL_MCP_TOKEN')) { Fail 'MCP preamble does not strip caller-injected service credentials' }
foreach ($f in @('.devcontainer\scripts\tavily-mcp-ssm.sh','.devcontainer\scripts\snyk-mcp-ssm.sh','.devcontainer\scripts\databricks-sql-mcp-ssm.sh')) {
    if (-not (NoMatch $f 'secret-broker-client|run-with-ssm-secrets')) { Fail "MCP process still executes in broker: $f" }
    if (-not (Has $f 'mcp-wrapper-preamble')) { Fail "MCP wrapper lacks credential-free preamble: $f" }
}
if (-not (Has '.devcontainer\scripts\tavily-mcp-ssm.sh' '/usr/local/libexec/ai-sandbox/real/mcp-remote')) { Fail 'Tavily MCP relay is not local' }
if (-not (Has '.devcontainer\scripts\tavily-mcp-ssm.sh' 'tavily-policy-proxy.py')) { Fail 'Tavily MCP local domain policy missing' }
if (-not (Has '.devcontainer\scripts\snyk-mcp-ssm.sh' '/usr/local/libexec/ai-sandbox/real/snyk')) { Fail 'Snyk MCP real process is not local' }
if (-not (Has '.devcontainer\scripts\databricks-sql-mcp-ssm.sh' '/usr/local/libexec/ai-sandbox/real/mcp-remote')) { Fail 'Databricks SQL MCP relay is not local' }
Pass 'local MCP execution inspected'

$gitWrap = '.devcontainer\scripts\git-transparent.sh'
$gitPolicy = '.devcontainer\scripts\ado-git-policy.sh'
if (-not (Has $gitWrap 'readonly REAL_GIT="/usr/bin/git"')) { Fail 'transparent Git does not pin local /usr/bin/git' }
if (-not (Has $gitWrap 'ado-git-policy')) { Fail 'ADO Git local root-owned policy missing' }
if (-not (NoMatch $gitWrap 'secret-broker-client|run-with-ssm-secrets')) { Fail 'Git process can still be delegated to broker' }
if (-not (Has $gitPolicy 'ADO_POLICY_FILE="/etc/ai-sandbox/policies/ado-policy.json"')) { Fail 'ADO Git does not read the shared immutable runtime policy' }
if (-not (Has $gitPolicy "'.git.allowed_operations | index(`$op) != null'")) { Fail 'ADO Git allowed operations are not policy-driven' }
if (-not (Has $gitPolicy "'.git.repository_host | ascii_downcase'")) { Fail 'ADO Git repository host is not policy-driven' }
if (-not (Has $gitPolicy "'.git.repository_path_regex'")) { Fail 'ADO Git repository path is not policy-driven' }
if (-not (Has $gitPolicy "'.git.broker_base'")) { Fail 'ADO Git broker route is not policy-driven' }
if (-not (Has $gitPolicy "'.git.rewrite_origin'")) { Fail 'ADO Git rewrite origin is not policy-driven' }
if (-not (Has $gitPolicy 'protocol.ext.allow=never')) { Fail 'ADO Git custom transport hardening missing' }
if (-not (NoMatch $gitPolicy 'ADO_PAT|GIT_ASKPASS|secret-broker-client|run-with-ssm-secrets')) { Fail 'local Git can receive PAT/askpass secret path' }
if (-not (NoMatch $gitPolicy 'ADO_(ORG|PROJECT|REPO)([^A-Z0-9_]|$)|Admin-approved repository')) { Fail 'ADO Git policy still pins repo metadata' }
if (-not (Has $gitWrap '--force-with-lease=*')) { Fail 'transparent Git force-with-lease routing missing' }
if (-not (Has '.devcontainer\scripts\ado-git.sh' '/usr/local/libexec/ai-sandbox/ado-git-policy')) { Fail 'legacy ado-git alias is not local-policy based' }
foreach ($f in @('ado-scripts\ado-pr-create.sh','ado-scripts\ado-trigger.sh')) {
    if (-not (Has $f 'http://127.0.0.1:8771')) { Fail "ADO REST helper does not use localhost credential route: $f" }
    if (-not (NoMatch $f 'secret-broker-client|run-with-ssm-secrets|ADO_PAT=')) { Fail "ADO REST helper is not credential-free/local: $f" }
}
Pass 'local Git/ADO execution inspected'

$mcp = '.devcontainer\scripts\configure-mcp.sh'
foreach ($cmd in @('/usr/local/bin/tavily-mcp-ssm','/usr/local/bin/snyk-mcp-ssm','/usr/local/bin/databricks-sql-mcp-ssm')) {
    if (-not (Has $mcp $cmd)) { Fail "Gemini compatibility MCP missing $cmd" }
}
if (-not (Has $mcp 'SYSTEM_GEMINI_SETTINGS="/etc/gemini-cli/settings.json"')) { Fail 'Gemini synchronizer does not validate immutable system settings' }
if (-not (Has $wrapper 'ensure_gemini_mcp_config')) { Fail 'Gemini routes do not self-heal managed MCP registration' }
if (-not (Has $wrapper 'if is_local_only_operation "$agent" "${1:-}"; then')) { Fail 'ucode MCP/help/version commands are not local control operations' }
if (-not (NoMatch $wrapper 'set -- --model|has_model_arg=')) { Fail 'ucode wrapper mutates native Claude/Gemini argv' }
if (-not (Has '.devcontainer\Dockerfile' 'COPY policies/gemini-managed-settings.json')) { Fail 'Gemini managed system settings source not baked into image' }
if (-not (Has '.devcontainer\Dockerfile' '/etc/gemini-cli/settings.json')) { Fail 'Gemini managed system settings target not baked into image' }
foreach ($f in @('tar\docker-compose.yml','ecr\docker-compose.yml')) {
    if (-not (Has $f 'GEMINI_CLI_SYSTEM_SETTINGS_PATH: "/etc/gemini-cli/settings.json"')) { Fail "Gemini system settings path missing in $f" }
}
try {
    $GeminiPolicy = Get-Content (Join-Path $Root 'policies\gemini-managed-settings.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    $Expected = @{ 'tavily'='/usr/local/bin/tavily-mcp-ssm'; 'snyk'='/usr/local/bin/snyk-mcp-ssm'; 'databricks-sql'='/usr/local/bin/databricks-sql-mcp-ssm' }
    foreach ($Name in $Expected.Keys) {
        $Server = $GeminiPolicy.mcpServers.PSObject.Properties[$Name].Value
        if ($null -eq $Server -or $Server.command -ne $Expected[$Name]) { Fail "Gemini system MCP missing/mismatched: $Name" }
        if ($null -ne $Server.env) { Fail "Gemini system MCP contains an env block: $Name" }
    }
    if ($GeminiPolicy.general.enableAutoUpdate -ne $false -or $GeminiPolicy.general.enableAutoUpdateNotification -ne $false) { Fail 'Gemini pinned-build auto-update policy is not disabled' }
} catch { Fail ("Gemini system MCP policy parse/validation failed: " + $_.Exception.Message) }
Pass 'Claude/Gemini/ucode managed MCP consistency inspected'

if (-not (NoMatch 'scripts\applications\application-helper.py' 'AWS_ACCESS_KEY_ID:|AWS_SECRET_ACCESS_KEY:|AWS_SESSION_TOKEN:|SECRET_RUNNER|run-with-ssm-secrets')) { Fail 'application helper can generate legacy credential/process runner paths' }
if (-not (Has 'scripts\applications\application-helper.py' 'forbids generic secret_env onboarding')) { Fail 'generic secret-backed onboarding is not fail closed' }
try {
    $AdoPolicy = Get-Content (Join-Path $Root 'policies\ado-policy.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($AdoPolicy.policy_version -ne 1) { Fail 'ADO policy version is invalid' }
    if ($AdoPolicy.git.repository_host -ne 'dev.azure.com') { Fail 'ADO repository host policy is invalid' }
    if ($AdoPolicy.git.broker_base -ne 'http://127.0.0.1:8771/ado/dev/') { Fail 'ADO broker route policy is invalid' }
    if ($AdoPolicy.git.rewrite_origin -ne 'https://dev.azure.com/') { Fail 'ADO rewrite origin policy is invalid' }
    $Ops = @($AdoPolicy.git.allowed_operations | Sort-Object)
    $ExpectedOps = @('archive','clone','fetch','ls-remote','pull','push','remote','submodule')
    if (($Ops -join ',') -ne ($ExpectedOps -join ',')) { Fail 'ADO Git operation policy changed unexpectedly' }
    $Prefixes = @($AdoPolicy.broker_routes | ForEach-Object { $_.prefix } | Sort-Object)
    if (($Prefixes -join ',') -ne '/ado/dev,/ado/vssps') { Fail 'ADO broker route prefixes are invalid' }
    foreach ($Route in $AdoPolicy.broker_routes) {
        if ($Route.credential_parameter -ne 'ado-pat' -or $Route.auth_kind -ne 'ado') { Fail 'ADO broker route credential/auth policy is invalid' }
    }
} catch { Fail ("ADO shared policy parse/validation failed: " + $_.Exception.Message) }
Pass 'shared ADO policy inspected'

foreach ($f in @('.env.example','ecr\.env.example','tar\.env.example')) {
    if (-not (NoMatch $f '/sandbox/ado-(org|project|repo)')) { Fail "runtime metadata still requires ADO org/project/repo SSM values: $f" }
}
foreach ($f in @('scripts\platform\01-setup-ssm.sh','scripts\platform\01-setup-ssm.ps1')) {
    if (-not (NoMatch $f 'ado-(org|project|repo)')) { Fail "SSM bootstrap still creates ADO org/project/repo metadata: $f" }
}

if (-not (Has '.devcontainer\scripts\tavily-cli-policy.py' 'Tavily auth is disabled in credential-isolated mode')) { Fail 'Tavily auth command is not blocked' }
if (-not (Has '.devcontainer\scripts\tavily-cli-policy.py' 'Tavily research is disabled')) { Fail 'unconstrained Tavily research is not blocked' }
if (-not (Has '.devcontainer\scripts\tavily-policy-proxy.py' 'include_domains')) { Fail 'Tavily MCP policy does not constrain search domains' }
if (-not (Has $broker 'TAVILY_ALLOWED')) { Fail 'broker does not enforce root-owned Tavily allowlist' }

if (-not (Has 'scripts\monitoring\export-docker-logs-to-host.ps1' 'StandardOutputEncoding = $DockerUtf8')) { Fail 'Windows log exporter does not pin stdout UTF-8' }
if (-not (Has 'scripts\monitoring\export-docker-logs-to-host.ps1' 'StandardErrorEncoding = $DockerUtf8')) { Fail 'Windows log exporter does not pin stderr UTF-8' }
if (-not (Has 'scripts\monitoring\export-docker-logs-to-host.ps1' '$DevContentLogRoot')) { Fail 'Windows log exporter lacks dedicated content subtree' }
if (-not (Has 'scripts\monitoring\export-docker-logs-to-host.ps1' "if (`$Stream -eq 'content')")) { Fail 'Windows log exporter does not route content separately' }
if (-not (Has 'docs\SECURITY-LOGGING-AND-SENTINEL.md' 'devcontainer\content\*.log')) { Fail 'Sentinel guide lacks dedicated content collection path' }
Pass 'logging/content separation inspected'

$SquidConf = (Text 'squid\squid.conf') -split "`r?`n" | ForEach-Object { $_.Trim() }
$AllowLine = [Array]::IndexOf($SquidConf, 'http_access allow whitelist')
foreach ($DenyRule in @('http_access deny private_ip','http_access deny dst_is_ip','http_access deny dst_is_ipv6','http_access deny !allowed_destination_port')) {
    $DenyLine = [Array]::IndexOf($SquidConf, $DenyRule)
    if ($DenyLine -lt 0 -or $AllowLine -lt 0 -or $DenyLine -gt $AllowLine) { Fail "Squid rule must precede whitelist: $DenyRule" }
}
if (-not (Has 'squid\squid.conf' 'acl private_ip dst 169.254.0.0/16')) { Fail 'Squid link-local/IMDS block missing' }
if (-not (Has 'squid\squid.conf' 'acl allowed_destination_port port 443')) { Fail 'Squid HTTPS-only destination port restriction missing' }
$Whitelist = @(
    Get-Content (Join-Path $Root 'squid\whitelist.txt') -Encoding UTF8 | ForEach-Object {
        (($_ -split '#',2)[0]).Trim().TrimEnd('.').ToLowerInvariant()
    } | Where-Object { $_ }
)
if (($Whitelist | Where-Object { $_.StartsWith('*.') }).Count) { Fail 'Squid whitelist contains invalid *. wildcard syntax' }
if (($Whitelist | Select-Object -Unique).Count -ne $Whitelist.Count) { Fail 'Squid whitelist contains duplicate entries' }
for ($i=0; $i -lt $Whitelist.Count; $i++) {
    $A=$Whitelist[$i]; $ABase=if($A.StartsWith('.')){$A.Substring(1)}else{$A}
    for ($j=$i+1; $j -lt $Whitelist.Count; $j++) {
        $B=$Whitelist[$j]; $BBase=if($B.StartsWith('.')){$B.Substring(1)}else{$B}
        if (($A.StartsWith('.') -and ($BBase -eq $ABase -or $BBase.EndsWith(".$ABase"))) -or
            ($B.StartsWith('.') -and ($ABase -eq $BBase -or $ABase.EndsWith(".$BBase")))) { Fail "Squid whitelist overlap: $A / $B" }
    }
}
Pass 'Squid/default-deny invariants inspected'

# Parse every PowerShell source without executing it and show precise locations.
$parseErrors = @()
Get-ChildItem $Root -Recurse -File -Filter *.ps1 | ForEach-Object {
    $psFile = $_; $tokens = $null; $errors = $null
    [System.Management.Automation.Language.Parser]::ParseFile($psFile.FullName, [ref]$tokens, [ref]$errors) | Out-Null
    foreach ($parseError in @($errors)) {
        $parseErrors += [pscustomobject]@{
            File=$psFile.FullName; Line=$parseError.Extent.StartLineNumber; Column=$parseError.Extent.StartColumnNumber;
            Text=$parseError.Extent.Text; Message=$parseError.Message
        }
    }
}
if ($parseErrors.Count) {
    foreach ($parseError in $parseErrors) {
        Write-Host ("[PS PARSE] {0}:{1}:{2}" -f $parseError.File,$parseError.Line,$parseError.Column) -ForegroundColor Red
        Write-Host ("  {0}" -f $parseError.Message) -ForegroundColor Red
        if ($parseError.Text) { Write-Host ("  {0}" -f $parseError.Text) -ForegroundColor DarkRed }
    }
    Fail 'one or more PowerShell sources have parse errors'
} else { Pass 'all PowerShell sources parse' }

if ($failures) { throw "$failures lint check(s) failed" }
Pass 'package security/integration invariants hold'
