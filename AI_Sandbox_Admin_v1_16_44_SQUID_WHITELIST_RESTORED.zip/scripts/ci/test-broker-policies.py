#!/usr/bin/env python3
"""Offline regression tests for the v1.16.44 credential-only HTTP broker.

No AWS or vendor network access is used. The tests verify that the broker has no
application-command execution path, that fixed upstream validation is fail
closed, and that ADO/Tavily request-level policy cannot be bypassed by calling
the broker route directly instead of the public wrappers.
"""
from __future__ import annotations

import importlib.util
import json
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
BROKER = ROOT / ".devcontainer" / "scripts" / "secret-broker-server.py"
TAVILY_POLICY = ROOT / "policies" / "tavily-allowed-domains.json"
ADO_POLICY = ROOT / "policies" / "ado-policy.json"
os.environ["TAVILY_POLICY_FILE"] = str(TAVILY_POLICY)
os.environ["ADO_POLICY_FILE"] = str(ADO_POLICY)
os.environ.pop("DATABRICKS_HOST", None)
os.environ.pop("SNYK_API", None)

spec = importlib.util.spec_from_file_location("ai_sandbox_secret_broker", BROKER)
assert spec and spec.loader
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)


def expect_denied(fn, *args):
    try:
        fn(*args)
    except (PermissionError, ValueError, RuntimeError):
        return
    raise AssertionError(f"expected denial: {fn.__name__}{args!r}")


# Broker architecture: AWS SSM retrieval is the only subprocess use.
source = BROKER.read_text(encoding="utf-8")
for forbidden in ("subprocess.Popen", "subprocess.call", "subprocess.check_call", "subprocess.check_output", "os.system(", "os.exec"):
    assert forbidden not in source
assert source.count("subprocess.run(") == 1
assert "run-with-ssm-secrets" not in source
assert "secret-broker-client" not in source
assert "/home/vscode/workspace" not in source
assert '["aws", "--profile", AWS_PROFILE, "ssm", "get-parameter"' in source
assert "command_execution=disabled" in source

# Fixed upstream origins must be HTTPS, approved, no custom path/userinfo/port.
assert mod._validate_https_origin("https://api.snyk.io", (".snyk.io",), "x") == "https://api.snyk.io"
for bad in (
    "http://api.snyk.io",
    "https://user:pass@api.snyk.io",
    "https://api.snyk.io/evil",
    "https://api.snyk.io:8443",
    "https://example.invalid",
):
    expect_denied(mod._validate_https_origin, bad, (".snyk.io",), "x")

# Traversal must be denied before privileged forwarding.
assert mod.safe_suffix("/ado/dev/org/proj", "/ado/dev") == "/org/proj"
for bad in (
    "/ado/dev/../x",
    "/ado/dev/%2e%2e/x",
    "/ado/dev/%252e%252e/x",
    "/ado/dev/a\\..\\b",
):
    expect_denied(mod.safe_suffix, bad, "/ado/dev")

# ADO policy is loaded from the same single source used by the local Git policy.
ado_doc = json.loads(ADO_POLICY.read_text(encoding="utf-8"))
assert mod.ADO_POLICY["policy_version"] == ado_doc["policy_version"]
assert set(mod.ADO_ROUTES) == {r["prefix"] for r in ado_doc["broker_routes"]}
assert mod.ADO_POLICY["git"]["repository_host"] == "dev.azure.com"

# ADO broker route is independently limited to Git smart HTTP plus the two
# reviewed REST helpers. Generic ADO REST is not available through the PAT.
allow = mod._ado_request_allowed
assert allow("/ado/dev", "/ado/dev/org/project/_git/repo/info/refs", "GET", "service=git-upload-pack")
assert allow("/ado/dev", "/ado/dev/org/project/_git/repo/git-upload-pack", "POST", "")
assert allow("/ado/dev", "/ado/dev/org/project/_git/repo/git-receive-pack", "POST", "")
assert allow("/ado/dev", "/ado/dev/org/project/_apis/git/repositories/repo/pullrequests", "POST", "api-version=7.1")
assert allow("/ado/dev", "/ado/dev/org/project/_apis/git/repositories/repo/pullrequests/12", "PATCH", "api-version=7.1")
assert allow("/ado/dev", "/ado/dev/org/project/_apis/pipelines/42/runs", "POST", "api-version=7.1")
assert allow("/ado/dev", "/ado/dev/org/project/_apis/pipelines/42/runs/99", "GET", "api-version=7.1")
assert allow("/ado/vssps", "/ado/vssps/org/_apis/identities", "GET", "api-version=7.1")
assert allow("/ado/vssps", "/ado/vssps/org/_apis/profile/profiles/me", "GET", "api-version=7.1")
assert not allow("/ado/dev", "/ado/dev/org/project/_apis/projects", "GET", "api-version=7.1")
assert not allow("/ado/dev", "/ado/dev/org/project/_git/repo/info/refs", "GET", "service=evil")
assert not allow("/ado/dev", "/ado/dev/org/project/_apis/pipelines/42/runs", "DELETE", "api-version=7.1")

# Tavily policy is enforced again at the broker, so direct HTTP use cannot
# bypass the Admin allowlist even if a Developer ignores the CLI/MCP wrapper.
allowed = json.loads(mod._enforce_tavily_http(
    "/search", json.dumps({"query": "python docs from docs.python.org"}).encode()
).decode())
assert allowed["include_domains"] == ["docs.python.org"]

normalized = json.loads(mod._enforce_tavily_http(
    "/search", json.dumps({"query": "secure coding"}).encode()
).decode())
assert set(normalized["include_domains"]) == set(mod.TAVILY_ALLOWED)

expect_denied(
    mod._enforce_tavily_http,
    "/search",
    json.dumps({"query": "arsenal news from espn.com"}).encode(),
)
expect_denied(
    mod._enforce_tavily_http,
    "/search",
    json.dumps({"query": "test", "include_domains": ["espn.com"]}).encode(),
)
expect_denied(
    mod._enforce_tavily_http,
    "/extract",
    json.dumps({"urls": ["https://espn.com/news"]}).encode(),
)
expect_denied(mod._enforce_tavily_http, "/research", json.dumps({"input": "x"}).encode())
expect_denied(mod._enforce_tavily_http, "/unknown", json.dumps({"x": 1}).encode())

mcp = {
    "jsonrpc": "2.0",
    "id": 1,
    "method": "tools/call",
    "params": {"name": "tavily_search", "arguments": {"query": "docs.python.org asyncio"}},
}
out = json.loads(mod._enforce_tavily_mcp(json.dumps(mcp).encode()).decode())
assert out["params"]["arguments"]["include_domains"] == ["docs.python.org"]
mcp["params"]["arguments"] = {"query": "scores from espn.com"}
expect_denied(mod._enforce_tavily_mcp, json.dumps(mcp).encode())

print("Credential-only broker policy regression tests passed")
