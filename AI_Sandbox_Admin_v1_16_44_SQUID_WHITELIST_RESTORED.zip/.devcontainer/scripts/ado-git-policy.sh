#!/usr/bin/env bash
# Root-owned Azure DevOps Git policy executed locally in the devcontainer.
# The real /usr/bin/git process stays uid/gid 1000 so cloned/updated files are
# owned by vscode. Credentialed HTTP traffic is rewritten to the fixed loopback
# broker route; the ADO PAT never enters this process.
set -euo pipefail
set +x

readonly REAL_GIT="/usr/bin/git"
readonly ADO_POLICY_FILE="/etc/ai-sandbox/policies/ado-policy.json"
[[ "${1:-}" == "$REAL_GIT" ]] || { echo 'ERROR: ADO Git policy requires the pinned git executable' >&2; exit 2; }
shift
(( $# > 0 )) || { echo 'ERROR: ADO Git operation is required' >&2; exit 2; }
command -v jq >/dev/null 2>&1 || { echo 'ERROR: jq is required to load the Admin ADO policy' >&2; exit 2; }
[[ -r "$ADO_POLICY_FILE" ]] || { echo 'ERROR: Admin ADO policy is not readable' >&2; exit 2; }

# Single source of truth: this local DevContainer policy and the credential
# broker both consume the same root-owned JSON baked into the image.
ADO_REPOSITORY_HOST="$(jq -er '.git.repository_host | ascii_downcase' "$ADO_POLICY_FILE")" || { echo 'ERROR: invalid Admin ADO repository host policy' >&2; exit 2; }
ADO_REPOSITORY_PATH_REGEX="$(jq -er '.git.repository_path_regex' "$ADO_POLICY_FILE")" || { echo 'ERROR: invalid Admin ADO repository path policy' >&2; exit 2; }
LOCAL_ADO_BASE="$(jq -er '.git.broker_base' "$ADO_POLICY_FILE")" || { echo 'ERROR: invalid Admin ADO broker route policy' >&2; exit 2; }
ADO_REWRITE_ORIGIN="$(jq -er '.git.rewrite_origin' "$ADO_POLICY_FILE")" || { echo 'ERROR: invalid Admin ADO rewrite-origin policy' >&2; exit 2; }
readonly ADO_REPOSITORY_HOST ADO_REPOSITORY_PATH_REGEX LOCAL_ADO_BASE ADO_REWRITE_ORIGIN

[[ "$ADO_REPOSITORY_HOST" =~ ^[a-z0-9.-]+$ && "$ADO_REPOSITORY_HOST" != *..* ]] || { echo 'ERROR: invalid Admin ADO repository host policy' >&2; exit 2; }
[[ "$ADO_REWRITE_ORIGIN" == "https://${ADO_REPOSITORY_HOST}/" ]] || { echo 'ERROR: ADO rewrite origin and repository host policy are inconsistent' >&2; exit 2; }
[[ "$LOCAL_ADO_BASE" == http://127.0.0.1:8771/ado/*/ ]] || { echo 'ERROR: ADO broker route must remain on the fixed loopback broker' >&2; exit 2; }
ADO_BROKER_PREFIX="/${LOCAL_ADO_BASE#http://127.0.0.1:8771/}"
ADO_BROKER_PREFIX="/${ADO_BROKER_PREFIX#/}"; ADO_BROKER_PREFIX="${ADO_BROKER_PREFIX%/}"
readonly ADO_BROKER_PREFIX
jq -e --arg prefix "$ADO_BROKER_PREFIX" --arg origin "https://${ADO_REPOSITORY_HOST}" \
  '.broker_routes | any(.prefix == $prefix and .upstream_origin == $origin and .credential_parameter == "ado-pat" and .auth_kind == "ado")' \
  "$ADO_POLICY_FILE" >/dev/null || { echo 'ERROR: ADO Git and broker route policy are inconsistent' >&2; exit 2; }

# Repository/project names are intentionally not Admin-pinned in the Sandbox.
# The ADO PAT and Azure DevOps permissions are the authorization boundary.
# This policy constrains credentialed Git traffic to the Admin policy and
# prevents credential redirection.
op="$1"
jq -e --arg op "$op" '.git.allowed_operations | index($op) != null' "$ADO_POLICY_FILE" >/dev/null \
  || { echo 'ERROR: Git operation does not require an approved credentialed Azure DevOps broker path' >&2; exit 2; }

is_ado_https_url() {
  local url="${1%/}" authority host userinfo path
  [[ "$url" == https://* ]] || return 1
  [[ "$url" != *'?'* && "$url" != *'#'* && "$url" != *\\* ]] || return 1

  authority="${url#https://}"
  authority="${authority%%/*}"
  [[ -n "$authority" ]] || return 1

  if [[ "$authority" == *@* ]]; then
    userinfo="${authority%@*}"
    host="${authority##*@}"
    [[ -n "$userinfo" && "$userinfo" != *:* ]] || return 1
  else
    host="$authority"
  fi
  [[ "${host,,}" == "$ADO_REPOSITORY_HOST" ]] || return 1

  path="/${url#https://$authority/}"
  [[ "$path" =~ $ADO_REPOSITORY_PATH_REGEX ]] || return 1
  return 0
}

reject_transport_like_value() {
  local value="${1:-}" lower
  lower="${value,,}"
  case "$lower" in
    ext::*|file://*|ssh://*|git://*) return 0 ;;
  esac
  return 1
}

# Never allow caller-controlled executable/configuration paths in the local
# Git process. These could redirect the credentialed HTTP exchange or execute
# unreviewed helpers. Recursive submodule traversal is also blocked because
# nested .gitmodules files have not been prevalidated.
for a in "$@"; do
  lower="${a,,}"
  case "$lower" in
    -c|-c=*|--config-env|--config-env=*|--exec-path|--exec-path=*|\
    --upload-pack|--upload-pack=*|--receive-pack|--receive-pack=*|\
    --git-dir|--git-dir=*|--work-tree|--work-tree=*|--namespace|--namespace=*|\
    --reference|--reference=*|--reference-if-able|--reference-if-able=*|\
    --separate-git-dir|--separate-git-dir=*|--template|--template=*|\
    --recurse-submodules|--recurse-submodules=*|--recursive|--exec|--exec=*)
      echo 'ERROR: Git execution/configuration override is not approved by Sandbox policy' >&2; exit 2 ;;
  esac
  if reject_transport_like_value "$a"; then
    echo 'ERROR: non-HTTPS Git transport is not approved by Sandbox policy' >&2; exit 2
  fi
done


# The workspace is Developer/agent writable. Local Git config cannot be trusted
# to define helpers, URL rewrites, hooks, filters, custom transports or proxy
# destinations while Git is allowed to use the brokered ADO authentication route.
reject_unsafe_local_config() {
  local keys
  keys="$($REAL_GIT config --local --name-only --get-regexp \
    '^(url\..*\.(insteadof|pushinsteadof)|http\.(proxy|sslverify|curloptresolve)|http\..*\.(proxy|sslverify|curloptresolve)|credential\.(helper|usehttppath)|credential\..*\.helper|core\.(hookspath|fsmonitor|sshcommand|gitproxy)|filter\..*\.(clean|smudge|process|required)|merge\..*\.driver|submodule\..*\.update|remote\..*\.(proxy|uploadpack|receivepack)|protocol\..*\.allow|fetch\.recursesubmodules|submodule\.recurse)$' \
    2>/dev/null || true)"
  if [[ -n "$keys" ]]; then
    echo 'ERROR: repository-local Git configuration contains a setting unsafe for credentialed broker execution.' >&2
    echo '       Remove URL rewrites/helpers/hooks/filters/custom transports and retry.' >&2
    return 1
  fi
}

validate_url() {
  local url="${1:-}"
  [[ "$url" == https://* ]] || { echo 'ERROR: an Azure DevOps HTTPS repository URL is required' >&2; return 1; }
  is_ado_https_url "$url" || { echo "ERROR: repository URL is outside the Admin ADO policy for ${ADO_REPOSITORY_HOST}" >&2; return 1; }
}

validate_all_configured_remotes() {
  local found=false name url
  while IFS= read -r name; do
    [[ -n "$name" ]] || continue
    while IFS= read -r url; do
      [[ -n "$url" ]] || continue
      found=true
      validate_url "$url" || return 1
    done < <($REAL_GIT remote get-url --all "$name" 2>/dev/null || true)
    while IFS= read -r url; do
      [[ -n "$url" ]] || continue
      found=true
      validate_url "$url" || return 1
    done < <($REAL_GIT remote get-url --push --all "$name" 2>/dev/null || true)
  done < <($REAL_GIT remote 2>/dev/null || true)
  return 0
}

# Return the first repository operand for clone/ls-remote while supporting the
# common non-dangerous Git options used by normal developer workflows.
first_repository_operand() {
  local mode="$1"; shift
  while (( $# > 0 )); do
    case "$1" in
      --branch|-b|--depth|--origin|-o|--filter|--shallow-since|--shallow-exclude|--jobs|-j|--server-option|--sort)
        (( $# >= 2 )) || return 1; shift 2 ;;
      --branch=*|--depth=*|--origin=*|--filter=*|--shallow-since=*|--shallow-exclude=*|--jobs=*|--server-option=*|--sort=*|\
      --single-branch|--no-single-branch|--no-tags|--tags|--heads|--refs|--symref|--exit-code|--get-url|\
      --no-checkout|-n|--bare|--quiet|-q|--verbose|-v|--progress|--no-hardlinks|--dissociate)
        shift ;;
      --)
        shift; (( $# > 0 )) || return 1; printf '%s' "$1"; return 0 ;;
      -*) return 1 ;;
      *) printf '%s' "$1"; return 0 ;;
    esac
  done
  return 1
}

validate_explicit_https_args() {
  local a
  for a in "$@"; do
    if [[ "$a" == https://* ]]; then validate_url "$a" || return 1; fi
    case "$a" in /*|./*|../*|~/*) echo 'ERROR: local-path Git transports are not approved for credentialed operations' >&2; return 1 ;; esac
  done
}

validate_push_args() {
  local -a positional=()
  local a i=0 repo_override first
  local -a rest=("${@:1}")

  # Preserve ordinary Git push semantics. Branch/history governance belongs to
  # Azure DevOps repository permissions and branch policies, not this credential
  # isolation layer. We only parse enough to validate the effective destination
  # and to keep caller-controlled execution/configuration overrides out of the
  # PAT-bearing process. The high-risk overrides are rejected earlier as a
  # second fail-closed layer.
  while (( i < ${#rest[@]} )); do
    a="${rest[$i]}"
    case "$a" in
      -u|--set-upstream|--porcelain|--no-verify|--follow-tags|--atomic|--no-atomic|\
      --dry-run|-n|--progress|--quiet|-q|--verbose|-v|--prune|--no-prune|\
      --tags|--no-tags|--force|-f|--force=*|--force-with-lease|--force-with-lease=*|\
      --force-if-includes|--all|--mirror|--delete|--thin|--no-thin|--signed|--signed=*|\
      --no-signed|-4|--ipv4|-6|--ipv6)
        i=$((i+1)); continue ;;
      --push-option|-o)
        (( i + 1 < ${#rest[@]} )) || return 1; i=$((i+2)); continue ;;
      --push-option=*)
        i=$((i+1)); continue ;;
      --repo)
        (( i + 1 < ${#rest[@]} )) || return 1
        repo_override="${rest[$((i+1))]}"
        if [[ "$repo_override" == https://* ]]; then
          validate_url "$repo_override" || return 1
        elif [[ "$repo_override" == *://* || "$repo_override" == *::* || "$repo_override" == /* || "$repo_override" == ./* || "$repo_override" == ../* || "$repo_override" == ~/* ]]; then
          echo 'ERROR: non-HTTPS/custom --repo destination is not permitted' >&2; return 1
        fi
        i=$((i+2)); continue ;;
      --repo=*)
        repo_override="${a#--repo=}"
        if [[ "$repo_override" == https://* ]]; then
          validate_url "$repo_override" || return 1
        elif [[ "$repo_override" == *://* || "$repo_override" == *::* || "$repo_override" == /* || "$repo_override" == ./* || "$repo_override" == ../* || "$repo_override" == ~/* ]]; then
          echo 'ERROR: non-HTTPS/custom --repo destination is not permitted' >&2; return 1
        fi
        i=$((i+1)); continue ;;
      --)
        i=$((i+1)); while (( i < ${#rest[@]} )); do positional+=("${rest[$i]}"); i=$((i+1)); done; break ;;
      -*) echo 'ERROR: push option is not approved by Sandbox credential policy' >&2; return 1 ;;
      *) positional+=("$a"); i=$((i+1)) ;;
    esac
  done

  # Positional[0] is the optional remote/URL. Refspecs are intentionally left
  # to native Git/Azure DevOps semantics: main/master, force refspecs (+ref),
  # deletes (:ref), wildcard refspecs, and implicit pushes are not blocked here.
  if (( ${#positional[@]} > 0 )); then
    first="${positional[0]}"
    if [[ "$first" == https://* ]]; then
      validate_url "$first" || return 1
    elif [[ "$first" == *://* || "$first" == *::* || "$first" == /* || "$first" == ./* || "$first" == ../* || "$first" == ~/* ]]; then
      echo 'ERROR: non-HTTPS/custom Git remote is not permitted' >&2; return 1
    fi
  fi
  return 0
}

validate_submodule_urls() {
  local url
  if [[ -f .gitmodules ]]; then
    while IFS= read -r url; do
      [[ -n "$url" ]] || continue
      validate_url "$url" || return 1
    done < <($REAL_GIT config -f .gitmodules --get-regexp '^submodule\..*\.url$' 2>/dev/null | awk '{print $2}' || true)
  fi
  # `git submodule init` copies URLs into .git/config and a writable workspace
  # can override them. Validate those effective local values as well.
  while IFS= read -r url; do
    [[ -n "$url" ]] || continue
    validate_url "$url" || return 1
  done < <($REAL_GIT config --local --get-regexp '^submodule\..*\.url$' 2>/dev/null | awk '{print $2}' || true)
  return 0
}

case "$op" in
  clone|ls-remote)
    repo="$(first_repository_operand "$op" "${@:2}" || true)"
    [[ -n "$repo" ]] || { echo 'ERROR: cannot identify Git repository operand safely' >&2; exit 2; }
    validate_url "$repo" || exit 2
    ;;

  fetch|pull)
    reject_unsafe_local_config || exit 2
    validate_explicit_https_args "${@:2}" || exit 2
    validate_all_configured_remotes || exit 2
    ;;

  push)
    reject_unsafe_local_config || exit 2
    validate_all_configured_remotes || exit 2
    validate_push_args "${@:2}" || exit 2
    ;;

  remote)
    reject_unsafe_local_config || exit 2
    sub="${2:-}"
    case "$sub" in
      update|prune|show)
        validate_explicit_https_args "${@:3}" || exit 2
        validate_all_configured_remotes || exit 2
        ;;
      set-head)
        # The transparent wrapper sends set-head here only for --auto/-a.
        validate_all_configured_remotes || exit 2
        ;;
      *) echo 'ERROR: this git remote operation does not require broker credentials' >&2; exit 2 ;;
    esac
    ;;

  submodule)
    reject_unsafe_local_config || exit 2
    sub="${2:-}"
    case "$sub" in
      add)
        repo="$(first_repository_operand clone "${@:3}" || true)"
        [[ -n "$repo" ]] || { echo 'ERROR: cannot identify submodule repository operand safely' >&2; exit 2; }
        validate_url "$repo" || exit 2
        ;;
      update)
        validate_submodule_urls || exit 2
        ;;
      *) echo 'ERROR: this git submodule operation does not require broker credentials' >&2; exit 2 ;;
    esac
    ;;

  archive)
    reject_unsafe_local_config || exit 2
    remote_url=''
    prev=''
    for a in "${@:2}"; do
      if [[ "$prev" == --remote ]]; then remote_url="$a"; prev=''; continue; fi
      case "$a" in --remote=*) remote_url="${a#--remote=}" ;; --remote) prev=--remote ;; esac
    done
    [[ -n "$remote_url" ]] || { echo 'ERROR: local git archive does not require broker credentials' >&2; exit 2; }
    validate_url "$remote_url" || exit 2
    ;;
  *)
    echo 'ERROR: Admin ADO policy names a Git operation that has no local validator implementation' >&2
    exit 2
    ;;
esac

# Never inherit system/global execution customizations into the credentialed
# process. The only credential-bearing component is the HTTP broker; Git sees no
# PAT. Rewrite only the Admin-approved ADO origin to the fixed local route.
export GIT_CONFIG_NOSYSTEM=1
export GIT_CONFIG_GLOBAL=/dev/null
export GIT_TERMINAL_PROMPT=0
export NO_PROXY="localhost,127.0.0.1${NO_PROXY:+,$NO_PROXY}"
export no_proxy="$NO_PROXY"

# Support both modern URLs and the common username-only ADO form without placing
# any secret in URL/config. Host and rewrite target come from the shared policy.
rewrite_args=(-c "url.${LOCAL_ADO_BASE}.insteadOf=${ADO_REWRITE_ORIGIN}")
collect_user_prefix() {
  local u="${1:-}" authority userinfo host
  [[ "$u" == https://* ]] || return 0
  authority="${u#https://}"; authority="${authority%%/*}"
  [[ "$authority" == *@* ]] || return 0
  userinfo="${authority%@*}"; host="${authority##*@}"
  [[ "${host,,}" == "$ADO_REPOSITORY_HOST" ]] || return 0
  [[ -n "$userinfo" && "$userinfo" != *:* ]] || return 0
  rewrite_args+=(-c "url.${LOCAL_ADO_BASE}.insteadOf=https://${userinfo}@${ADO_REPOSITORY_HOST}/")
}
for a in "$@"; do collect_user_prefix "$a"; done
while IFS= read -r r; do
  while IFS= read -r u; do collect_user_prefix "$u"; done < <("$REAL_GIT" remote get-url --all "$r" 2>/dev/null || true)
  while IFS= read -r u; do collect_user_prefix "$u"; done < <("$REAL_GIT" remote get-url --push --all "$r" 2>/dev/null || true)
done < <("$REAL_GIT" remote 2>/dev/null || true)

exec "$REAL_GIT" \
  "${rewrite_args[@]}" \
  -c core.hooksPath=/dev/null \
  -c core.fsmonitor=false \
  -c credential.helper= \
  -c protocol.allow=never \
  -c protocol.http.allow=always \
  -c protocol.https.allow=always \
  -c protocol.ext.allow=never \
  -c protocol.file.allow=never \
  -c protocol.git.allow=never \
  -c protocol.ssh.allow=never \
  -c fetch.recurseSubmodules=false \
  -c submodule.recurse=false \
  -c http.sslVerify=true \
  "$@"
