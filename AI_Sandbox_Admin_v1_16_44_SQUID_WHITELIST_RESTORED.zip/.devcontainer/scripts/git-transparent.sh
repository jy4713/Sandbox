#!/usr/bin/env bash
# Transparent Git front-end for the AI DevContainer.
#
# Every Git operation executes with /usr/bin/git inside the AI devcontainer.
# Azure DevOps network operations pass through a local policy that rewrites only
# validated Admin-policy Azure DevOps HTTPS traffic to the credential broker HTTP route.
# The PAT remains broker-only and repository files remain vscode-owned.
set -euo pipefail
set +x

readonly REAL_GIT="/usr/bin/git"
readonly ADO_POLICY="/usr/local/libexec/ai-sandbox/ado-git-policy"
readonly ADO_POLICY_FILE="/etc/ai-sandbox/policies/ado-policy.json"

# Non-client roles never use the developer wrapper.
if [[ "${AI_SANDBOX_ROLE:-client}" != "client" ]]; then exec "$REAL_GIT" "$@"; fi

command -v jq >/dev/null 2>&1 || exec "$REAL_GIT" "$@"
[[ -r "$ADO_POLICY_FILE" ]] || exec "$REAL_GIT" "$@"
ADO_REPOSITORY_HOST="$(jq -er '.git.repository_host | ascii_downcase' "$ADO_POLICY_FILE" 2>/dev/null)" || exec "$REAL_GIT" "$@"
readonly ADO_REPOSITORY_HOST

# No arguments, version/help-only invocations and any command that does not
# require ADO network authentication retain native Git behaviour.
(( $# > 0 )) || exec "$REAL_GIT"

original=("$@")
workdir="$(pwd -P)"
command_name=""
command_index=-1
blocked_network_global=""

i=0
while (( i < ${#original[@]} )); do
  a="${original[$i]}"
  case "$a" in
    -C)
      (( i + 1 < ${#original[@]} )) || exec "$REAL_GIT" "${original[@]}"
      p="${original[$((i+1))]}"
      if [[ "$p" == /* ]]; then
        next="$p"
      else
        next="$workdir/$p"
      fi
      if ! workdir="$(cd "$next" 2>/dev/null && pwd -P)"; then
        # Let native Git produce its standard -C error message.
        exec "$REAL_GIT" "${original[@]}"
      fi
      i=$((i+2))
      ;;
    -C?*)
      p="${a#-C}"
      if [[ "$p" == /* ]]; then next="$p"; else next="$workdir/$p"; fi
      if ! workdir="$(cd "$next" 2>/dev/null && pwd -P)"; then
        exec "$REAL_GIT" "${original[@]}"
      fi
      i=$((i+1))
      ;;
    -c|--config-env|--git-dir|--work-tree|--namespace)
      blocked_network_global="$a"
      # Consume the associated value so we can still identify the subcommand.
      (( i + 1 < ${#original[@]} )) || exec "$REAL_GIT" "${original[@]}"
      i=$((i+2))
      ;;
    -c=*|--config-env=*|--git-dir=*|--work-tree=*|--namespace=*)
      blocked_network_global="$a"
      i=$((i+1))
      ;;
    --exec-path|--exec-path=*)
      # --exec-path is informational when used alone and an execution override
      # when combined with a command. Keep it native; it is never brokered.
      exec "$REAL_GIT" "${original[@]}"
      ;;
    -p|--paginate|-P|--no-pager|--no-replace-objects|--literal-pathspecs|--glob-pathspecs|--noglob-pathspecs|--icase-pathspecs|--no-optional-locks)
      # Harmless global presentation/pathspec switches. They are not needed by
      # the credentialed transport process, so they are intentionally omitted
      # from the broker invocation.
      i=$((i+1))
      ;;
    --version|version|--help|-h|--html-path|--man-path|--info-path)
      exec "$REAL_GIT" "${original[@]}"
      ;;
    --)
      i=$((i+1))
      if (( i < ${#original[@]} )); then
        command_name="${original[$i]}"; command_index=$i
      fi
      break
      ;;
    -*)
      # Unknown Git-global option: preserve exact native behaviour. This avoids
      # incorrectly treating an option value as a subcommand.
      exec "$REAL_GIT" "${original[@]}"
      ;;
    *)
      command_name="$a"; command_index=$i
      break
      ;;
  esac
done

[[ -n "$command_name" && $command_index -ge 0 ]] || exec "$REAL_GIT" "${original[@]}"

# Determine whether this invocation targets Azure DevOps. Public/non-ADO Git
# keeps native behaviour (and remains subject to the Sandbox proxy allowlist).
# Only ADO operations are routed through the credential proxy.
looks_like_ado_url() {
  local value="${1:-}" authority host
  [[ "${value,,}" == https://* ]] || return 1
  authority="${value#*://}"
  authority="${authority%%/*}"
  [[ -n "$authority" ]] || return 1
  host="${authority##*@}"
  # Routing only: the root-owned ado-git-policy performs the authoritative
  # scheme/userinfo/port/path validation before the PAT-backed route is used.
  [[ "${host,,}" == "$ADO_REPOSITORY_HOST" ]]
}

remote_is_ado() {
  local remote="${1:-}" url
  [[ -n "$remote" ]] || return 1
  if looks_like_ado_url "$remote"; then return 0; fi
  case "$remote" in *://*|*::*|/*|./*|../*|~/*) return 1 ;; esac
  while IFS= read -r url; do
    looks_like_ado_url "$url" && return 0
  done < <("$REAL_GIT" remote get-url --all "$remote" 2>/dev/null || true)
  while IFS= read -r url; do
    looks_like_ado_url "$url" && return 0
  done < <("$REAL_GIT" remote get-url --push --all "$remote" 2>/dev/null || true)
  return 1
}

# Find the repository/remote operand after common fetch/pull/push options.
# This is only routing logic; the local root-owned policy performs authoritative
# validation before any PAT-backed Git process runs.
first_remote_operand() {
  local mode="$1"; shift
  while (( $# > 0 )); do
    case "$1" in
      --repo)
        (( $# >= 2 )) || return 1; printf '%s' "$2"; return 0 ;;
      --repo=*)
        printf '%s' "${1#--repo=}"; return 0 ;;
      --depth|--deepen|--shallow-since|--shallow-exclude|--jobs|-j|--server-option|--negotiation-tip|--refmap|--filter|--upload-pack|--receive-pack|--exec|--push-option|-o)
        (( $# >= 2 )) || return 1; shift 2 ;;
      --depth=*|--deepen=*|--shallow-since=*|--shallow-exclude=*|--jobs=*|--server-option=*|--negotiation-tip=*|--refmap=*|--filter=*|--upload-pack=*|--receive-pack=*|--exec=*|--push-option=*)
        shift ;;
      -u|--set-upstream|--porcelain|--no-verify|--follow-tags|--atomic|--no-atomic|--dry-run|-n|--progress|--quiet|-q|--verbose|-v|--prune|--no-prune|--tags|--no-tags|--force|-f|--force=*|--force-with-lease|--force-with-lease=*|--force-if-includes|--all|--mirror|--delete|--thin|--no-thin|--signed|--signed=*|--no-signed|-4|--ipv4|-6|--ipv6)
        shift ;;
      --)
        shift; (( $# > 0 )) || return 1; printf '%s' "$1"; return 0 ;;
      -*)
        # Unknown option: do not risk routing a non-ADO target through the ADO
        # credential route. Native Git will handle it; if ADO auth is needed it fails
        # closed because terminal credential prompting is disabled.
        return 1 ;;
      *) printf '%s' "$1"; return 0 ;;
    esac
  done
  return 1
}

default_remote_for() {
  local mode="$1" branch remote=''
  branch="$($REAL_GIT symbolic-ref --quiet --short HEAD 2>/dev/null || true)"
  if [[ "$mode" == push && -n "$branch" ]]; then
    remote="$($REAL_GIT config --get "branch.${branch}.pushRemote" 2>/dev/null || true)"
    [[ -n "$remote" ]] || remote="$($REAL_GIT config --get remote.pushDefault 2>/dev/null || true)"
  fi
  if [[ -z "$remote" && -n "$branch" ]]; then
    remote="$($REAL_GIT config --get "branch.${branch}.remote" 2>/dev/null || true)"
  fi
  [[ -n "$remote" ]] || remote=origin
  printf '%s' "$remote"
}

needs_credential_route=false
case "$command_name" in
  clone|ls-remote)
    for ((j=command_index+1; j<${#original[@]}; j++)); do
      if looks_like_ado_url "${original[$j]}"; then needs_credential_route=true; break; fi
    done
    ;;
  fetch|pull|push)
    candidate="$(first_remote_operand "$command_name" "${original[@]:$((command_index+1))}" || true)"
    if [[ -n "$candidate" ]]; then
      remote_is_ado "$candidate" && needs_credential_route=true
    else
      candidate="$(default_remote_for "$command_name")"
      remote_is_ado "$candidate" && needs_credential_route=true
    fi
    ;;
  remote)
    sub="${original[$((command_index+1))]:-}"
    case "$sub" in
      update|prune|show|set-head)
        # These forms may contact one or more configured remotes. Broker them
        # when any configured target is Azure DevOps; the broker then validates
        # every effective URL before exposing the PAT to Git.
        while IFS= read -r r; do
          if remote_is_ado "$r"; then needs_credential_route=true; break; fi
        done < <("$REAL_GIT" remote 2>/dev/null || true)
        ;;
    esac
    ;;
  submodule)
    sub="${original[$((command_index+1))]:-}"
    case "$sub" in
      add)
        for ((j=command_index+2; j<${#original[@]}; j++)); do
          if looks_like_ado_url "${original[$j]}"; then needs_credential_route=true; break; fi
        done
        ;;
      update)
        while read -r _key submodule_url; do
          if looks_like_ado_url "$submodule_url"; then needs_credential_route=true; break; fi
        done < <(
          { [[ ! -f .gitmodules ]] || "$REAL_GIT" config -f .gitmodules --get-regexp '^submodule\..*\.url$' 2>/dev/null || true; }
          "$REAL_GIT" config --local --get-regexp '^submodule\..*\.url$' 2>/dev/null || true
        )
        ;;
    esac
    ;;
  archive)
    for ((j=command_index+1; j<${#original[@]}; j++)); do
      case "${original[$j]}" in
        --remote=*) looks_like_ado_url "${original[$j]#--remote=}" && needs_credential_route=true ;;
        --remote)
          if (( j + 1 < ${#original[@]} )) && looks_like_ado_url "${original[$((j+1))]}"; then needs_credential_route=true; fi
          ;;
      esac
    done
    ;;
esac

[[ "$needs_credential_route" == true ]] || exec "$REAL_GIT" "${original[@]}"

if [[ -n "$blocked_network_global" ]]; then
  echo "ERROR: Git global override '$blocked_network_global' is not permitted for credentialed Azure DevOps operations." >&2
  echo "       Run the normal Git command without -c/--config-env/--git-dir/--work-tree/--namespace overrides." >&2
  exit 2
fi

# Rebuild arguments from the actual subcommand onward. Any -C options were
# already applied to workdir. The policy and real Git both run locally here.
local_args=("${original[@]:$command_index}")
cd "$workdir"
exec "$ADO_POLICY" "$REAL_GIT" "${local_args[@]}"
