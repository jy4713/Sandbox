# Shared Admin policy source of truth

This directory contains Admin-managed policy/configuration sources that are shared by more than one runtime component or are baked into the DevContainer as managed settings.

- `ado-policy.json` - shared Azure DevOps credential-use policy. Both local DevContainer Git validation and the credential broker consume the same baked copy.
- `tavily-allowed-domains.json` - shared Tavily domain allowlist. Both local Tavily validation and broker enforcement consume the same baked copy.
- `claude-mcp.json` - Admin-managed Claude MCP configuration.
- `gemini-managed-settings.json` - Admin-managed Gemini settings/MCP configuration.
- `gemini-web-policy.toml` - Admin Gemini native-web/shell policy.
- `admin-settings.json` - Docker Desktop/Admin host-policy example.

Shared runtime security policies are installed under `/etc/ai-sandbox/policies/` as `root:root` mode `0444`, so DevContainer first-line validation and broker final enforcement consume the same immutable policy source.

Component-owned policy files remain with the component when they are not shared across runtime trust boundaries. In particular, Squid's destination ACL is intentionally kept at `squid/whitelist.txt`, next to `squid/squid.conf` and `squid/Dockerfile`. It is the single source of truth for Squid egress destinations and is copied to `/etc/squid/whitelist.txt` when the Squid image is built.

Do not create duplicate ADO/Tavily policy copies under `.devcontainer/`, and do not create a second Squid allowlist under `policies/`; package lint rejects those drift-prone layouts.
