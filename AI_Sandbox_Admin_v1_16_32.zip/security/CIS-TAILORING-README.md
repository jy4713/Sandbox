# CIS Level 1 assessment and tailoring - v1.16.32

The Golden Image is hardened by `.devcontainer/cis-level1-harden.sh` and is then
assessed externally with **OpenSCAP** using pinned **ComplianceAsCode** Ubuntu
24.04 CIS Level 1 content.

Important: this is independent SCAP assessment evidence. It is **not** CIS-CAT,
CIS certification, or proof that every OS benchmark control is applicable inside
a container. The final report must be reviewed and each non-pass result classified
as one of: applicable/fix-required, container-not-applicable, approved exception,
or compensating control.

If Cyber Security approves an XCCDF tailoring file, place it at:

`security/cis-tailoring.xml`

Both `assess-cis-l1.sh` and `assess-cis-l1.ps1` detect the file automatically.
Do not disable rules merely to improve a score; every change requires an approved
rationale and compensating-control reference.

For POC, `REQUIRE_CIS_PASS=false` allows the build to emit evidence even when
rules fail. Set `REQUIRE_CIS_PASS=true` only after the tailoring/exception set has
been approved and the final Golden Image passes all remaining applicable rules.

## Container logging tailoring (CIS 4.1-4.3)

The development image intentionally does **not** install or run `rsyslog`,
`logrotate`, or an in-container audit daemon. Creating local files under
`/var/log/sandbox` would conflict with the sandbox's read-only root filesystem
and with the requirement that Developers cannot edit retained audit/access/content
records.

For this container, the compensating control is:

- managed audit, application, AI-content and security records are emitted to
  PID1 stdout through the immutable `sandbox-log-emit` image component;
- Squid access/runtime records are emitted to stdout/stderr;
- Docker Desktop uses the `local` logging driver with bounded rotation;
- no Developer-visible Windows host directory is bind-mounted as a runtime log
  sink; and
- POST-POC authoritative evidence must be forwarded promptly to a centrally
  administered Sentinel/immutable or WORM retention destination.

Any CIS rule that specifically requires a host-style rsyslog/auditd/logrotate
file architecture should therefore be classified as **container-not-applicable**
or **approved compensating control**, subject to Cyber Security approval. Do not
add writable file-log destinations merely to satisfy a scanner rule.
