#Requires -Version 7.4
# =============================================================================
# AI Secure Sandbox v1.16.32
# Purpose:
#   Export Docker-owned Sandbox stdout/stderr into a protected Windows host
#   directory. This script is designed to run as LOCALSYSTEM from Task Scheduler.
#
# Security model:
#   - Containers never receive a read-write mount of the Windows log directory.
#   - The Developer account receives read-only NTFS access to the host log tree.
#   - LOCALSYSTEM is the only normal writer to the host log tree.
#   - Runtime containers see the same host files only through read-only mounts.
#   - A Windows local Administrator can still take ownership/reset ACLs; remote
#     Sentinel/immutable retention is required for administrator-proof evidence.
# =============================================================================
[CmdletBinding()]
param(
    [string]$ProjectName = 'ai-secure-sandbox',
    [string]$LogRoot = 'C:\ProgramData\AI-Sandbox\Logs',
    [string]$StateFile = 'C:\ProgramData\AI-Sandbox\Monitoring\host-log-export-state.json',
    [string]$DockerCli = 'docker.exe',
    [ValidateRange(1, 1440)][int]$InitialLookbackMinutes = 15,
    [ValidateSet('Protected','PocLocal')][string]$LogMode = 'Protected',
    [switch]$Continuous,
    [ValidateRange(5, 3600)][int]$IntervalSeconds = 30
)

$ErrorActionPreference = 'Stop'
if (-not (Test-Path -LiteralPath $DockerCli -PathType Leaf)) {
    $ResolvedDocker = Get-Command $DockerCli -ErrorAction SilentlyContinue
    if (-not $ResolvedDocker) { throw "Docker CLI not found for LOCALSYSTEM exporter: $DockerCli" }
    $DockerCli = $ResolvedDocker.Source
}

function Test-IsLocalSystem {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    return $identity.User -and $identity.User.Value -eq 'S-1-5-18'
}

$PocLocal = $LogMode -eq 'PocLocal'
if ($Continuous -and -not $PocLocal) { throw '-Continuous is supported only with -LogMode PocLocal.' }
if ($PocLocal -and -not $PSBoundParameters.ContainsKey('LogRoot')) {
    $LogRoot = Join-Path $env:USERPROFILE 'AI-Sandbox\Logs'
}
if ($PocLocal -and -not $PSBoundParameters.ContainsKey('StateFile')) {
    $StateFile = Join-Path $LogRoot '.monitoring\host-log-export-state.json'
}
if (-not $PocLocal -and -not (Test-IsLocalSystem)) {
    throw 'Protected host log export must run as LOCALSYSTEM. Use scripts\platform\03-setup-logging.ps1 to install the SYSTEM scheduled task.'
}

$DevLogRoot = Join-Path $LogRoot 'devcontainer'
$SquidLogRoot = Join-Path $LogRoot 'squid'
$StateRoot = Split-Path -Parent $StateFile
foreach ($Path in @($LogRoot, $DevLogRoot, $SquidLogRoot, $StateRoot)) {
    if ($PocLocal) {
        New-Item -ItemType Directory -Force -Path $Path | Out-Null
    }
    elseif (-not (Test-Path -LiteralPath $Path -PathType Container)) {
        throw "Required protected directory is missing: $Path"
    }
}

$SystemSidValue = 'S-1-5-18'
$WriteMask = [Security.AccessControl.FileSystemRights]::WriteData `
    -bor [Security.AccessControl.FileSystemRights]::AppendData `
    -bor [Security.AccessControl.FileSystemRights]::CreateDirectories `
    -bor [Security.AccessControl.FileSystemRights]::WriteAttributes `
    -bor [Security.AccessControl.FileSystemRights]::WriteExtendedAttributes `
    -bor [Security.AccessControl.FileSystemRights]::Delete `
    -bor [Security.AccessControl.FileSystemRights]::DeleteSubdirectoriesAndFiles `
    -bor [Security.AccessControl.FileSystemRights]::ChangePermissions `
    -bor [Security.AccessControl.FileSystemRights]::TakeOwnership

function Get-RuleSid([Security.Principal.IdentityReference]$IdentityReference) {
    try {
        return $IdentityReference.Translate([Security.Principal.SecurityIdentifier]).Value
    }
    catch {
        return $IdentityReference.Value
    }
}

function Assert-SystemOnlyWriter([string]$Path) {
    $Acl = Get-Acl -LiteralPath $Path
    try { $OwnerSid = ([Security.Principal.NTAccount]::new($Acl.Owner)).Translate([Security.Principal.SecurityIdentifier]).Value }
    catch { $OwnerSid = $Acl.Owner }
    if ($OwnerSid -ne $SystemSidValue -and $Acl.Owner -notmatch 'SYSTEM') {
        throw "Protected log ACL drift: owner of '$Path' is '$($Acl.Owner)', expected LOCALSYSTEM."
    }
    foreach ($Rule in $Acl.Access) {
        if ($Rule.AccessControlType -ne [Security.AccessControl.AccessControlType]::Allow) { continue }
        $RuleSid = Get-RuleSid -IdentityReference $Rule.IdentityReference
        $HasWrite = (([int64]$Rule.FileSystemRights -band [int64]$WriteMask) -ne 0)
        if ($HasWrite -and $RuleSid -ne $SystemSidValue) {
            throw "Protected log ACL drift: '$($Rule.IdentityReference)' has write/delete rights on '$Path'. Export stopped."
        }
    }
}

# Fail closed if a Developer or another non-SYSTEM principal has gained
# write/modify/delete rights. Sentinel/AMA can read as SYSTEM without granting
# Developer write access.
if (-not $PocLocal) {
    Assert-SystemOnlyWriter -Path $LogRoot
    Assert-SystemOnlyWriter -Path $DevLogRoot
    Assert-SystemOnlyWriter -Path $SquidLogRoot
}
else {
    Write-Warning 'POC LOCAL LOG MODE: exporting as the current Windows user; host log files are mutable by that user.'
}

function Read-State {
    $result = @{}
    if (Test-Path -LiteralPath $StateFile -PathType Leaf) {
        try {
            $saved = Get-Content -LiteralPath $StateFile -Raw -Encoding UTF8 | ConvertFrom-Json -AsHashtable
            if ($saved) { $result = $saved }
        }
        catch {
            Write-Warning "Ignoring invalid exporter state file: $StateFile"
        }
    }
    if (-not $result.ContainsKey('services')) { $result['services'] = @{} }
    return $result
}

function Save-State([hashtable]$State) {
    $temp = "$StateFile.tmp"
    $json = $State | ConvertTo-Json -Depth 6
    [IO.File]::WriteAllText($temp, $json, [Text.UTF8Encoding]::new($false))
    Move-Item -LiteralPath $temp -Destination $StateFile -Force
}

function Get-ContainerId([string]$ServiceName) {
    $ids = @(& $DockerCli ps `
        --filter "label=com.docker.compose.project=$ProjectName" `
        --filter "label=com.docker.compose.service=$ServiceName" `
        --format '{{.ID}}' 2>$null)
    if ($LASTEXITCODE -ne 0) {
        throw "Unable to query Docker for service: $ServiceName"
    }
    $First = $ids | Where-Object { -not [string]::IsNullOrWhiteSpace($_) } | Select-Object -First 1
    if ($null -eq $First) { return '' }
    return $First.ToString().Trim()
}

function Get-LineDate([string]$Line, [DateTimeOffset]$Fallback) {
    if ($Line -match '^(?<date>[0-9]{4}-[0-9]{2}-[0-9]{2})T') {
        return $Matches['date']
    }
    return $Fallback.UtcDateTime.ToString('yyyy-MM-dd')
}

function Add-Record([hashtable]$Buckets, [string]$Path, [string]$Line) {
    if (-not $Buckets.ContainsKey($Path)) {
        $Buckets[$Path] = [System.Collections.Generic.List[string]]::new()
    }
    $Buckets[$Path].Add($Line)
}

function Write-Buckets([hashtable]$Buckets) {
    $encoding = [Text.UTF8Encoding]::new($false)
    foreach ($Path in $Buckets.Keys) {
        $parent = Split-Path -Parent $Path
        if (-not (Test-Path -LiteralPath $parent -PathType Container)) {
            throw "Host log subdirectory is missing: $parent"
        }
        [IO.File]::AppendAllLines($Path, [string[]]$Buckets[$Path], $encoding)
    }
}

$StreamFileMap = @{
    'audit'            = 'audit'
    'security'         = 'security'
    'application'      = 'application'
    'claude-events'    = 'claude-events'
    'content'          = 'content'
    'gemini-telemetry' = 'gemini-telemetry'
    'verification'     = 'verification'
}

function Invoke-ExportPass {
    $State = Read-State
    $Until = [DateTimeOffset]::UtcNow
    $Services = @('devcontainer', 'squid-proxy')
    $TotalRecords = 0

    foreach ($Service in $Services) {
        $ContainerId = Get-ContainerId -ServiceName $Service
        if ([string]::IsNullOrWhiteSpace($ContainerId)) {
            Write-Warning "No running container found for $ProjectName/$Service; state was not advanced for this service."
            continue
        }
    
        $Since = $Until.AddMinutes(-$InitialLookbackMinutes)
        if ($State.services.ContainsKey($Service) -and $State.services[$Service].last_success_utc) {
            try {
                # Add one DateTime tick (100 ns) so the previous boundary record is
                # not emitted twice on the next scheduled run.
                $Since = [DateTimeOffset]::Parse($State.services[$Service].last_success_utc).AddTicks(1)
            }
            catch {
                Write-Warning "Invalid saved timestamp for $Service; using initial lookback."
            }
        }
    
        if ($Since -gt $Until) { $Since = $Until }
    
        $RawLines = @(& $DockerCli logs `
            --timestamps `
            --since $Since.ToString('o') `
            --until $Until.ToString('o') `
            $ContainerId 2>&1)
        $DockerExit = $LASTEXITCODE
        if ($DockerExit -ne 0) {
            throw "docker logs failed for $Service (container $ContainerId), exit code $DockerExit"
        }
    
        $Buckets = @{}
        foreach ($Item in $RawLines) {
            $Line = [string]$Item
            if ([string]::IsNullOrWhiteSpace($Line)) { continue }
            $DatePart = Get-LineDate -Line $Line -Fallback $Until
    
            if ($Service -eq 'devcontainer') {
                Add-Record -Buckets $Buckets -Path (Join-Path $DevLogRoot "all-$DatePart.log") -Line $Line
    
                if ($Line -match 'AI_SANDBOX_LOG\|(?<stream>[A-Za-z0-9._-]+)\|(?<source>[^|]+)\|(?<payload>.*)$') {
                    $Stream = $Matches['stream']
                    if ($StreamFileMap.ContainsKey($Stream)) {
                        $BaseName = $StreamFileMap[$Stream]
                    }
                    else {
                        $BaseName = 'unclassified-stream'
                    }
                    Add-Record -Buckets $Buckets -Path (Join-Path $DevLogRoot "$BaseName-$DatePart.log") -Line $Line
                }
                else {
                    Add-Record -Buckets $Buckets -Path (Join-Path $DevLogRoot "runtime-$DatePart.log") -Line $Line
                }
            }
            else {
                Add-Record -Buckets $Buckets -Path (Join-Path $SquidLogRoot "all-$DatePart.log") -Line $Line
    
                # Squid native access format begins with epoch seconds.milliseconds
                # after Docker's RFC3339 timestamp. Runtime/cache messages do not.
                $Body = $Line -replace '^[^ ]+\s+', ''
                if ($Body -match '^[0-9]{10}\.[0-9]{3}\s+') {
                    Add-Record -Buckets $Buckets -Path (Join-Path $SquidLogRoot "access-$DatePart.log") -Line $Line
                }
                else {
                    Add-Record -Buckets $Buckets -Path (Join-Path $SquidLogRoot "runtime-$DatePart.log") -Line $Line
                }
            }
        }
    
        Write-Buckets -Buckets $Buckets
        $TotalRecords += $RawLines.Count
        $State.services[$Service] = @{
            last_success_utc = $Until.ToString('o')
            container_id     = $ContainerId
        }
    }
    

    $State['updated_utc'] = $Until.ToString('o')
    Save-State -State $State
    return $TotalRecords
}

do {
    try {
        $TotalRecords = Invoke-ExportPass
        if ($PocLocal) {
            Write-Host "[OK] POC local host log export complete. Records observed: $TotalRecords" -ForegroundColor Yellow
        }
        else {
            Write-Host "[OK] Protected host log export complete. Records observed: $TotalRecords" -ForegroundColor Green
        }
    }
    catch {
        if (-not $Continuous) { throw }
        Write-Warning ("Continuous POC log export pass failed: " + $_.Exception.Message)
    }

    if (-not $Continuous) { break }
    Start-Sleep -Seconds $IntervalSeconds
} while ($true)
