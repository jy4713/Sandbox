# AI Secure Sandbox v1.16.21 — Release Notes

## Summary

v1.16.21 is a correctness and cross-file consistency release on top of the v1.16.20 runtime/security baseline. It does not add persistent-volume cleanup or migration behavior.

## Fixed

- **Databricks SQL MCP audit namespace mismatch**
  - `run-with-ssm-secrets --profile databricks-sql-mcp` remains an internal least-capability SSM profile.
  - Generic authentication/SSM failure events now map that internal profile to the approved `databricks` audit namespace before invoking `application-audit`.
  - This prevents the prior `ERROR: unsupported audit application: databricks-sql-mcp` failure before the MCP bridge could start.
  - Successful SQL MCP credential events continue to be written to `databricks-events.log`; MCP lifecycle events continue to use the separate `mcp` audit namespace.

- **Admin application-helper MCP consistency**
  - Helper-added Claude MCP servers are now written to `.devcontainer/policies/claude-mcp.json`, which is baked into root-owned `/etc/claude-code/managed-mcp.json`.
  - The helper no longer generates legacy Claude user-scope `mcp add-json` registration.
  - Gemini helper onboarding continues to write only the approved literal AWS runtime references required by Gemini stdio MCP child sanitization.
  - Helper add/validate/remove now validates the managed Claude MCP entry as part of the source contract.

- **Helper profile insertion stability**
  - The initial `run-with-ssm-secrets` profile allowlist is formatted as a normal multi-line `case`, preserving the documented insertion anchor used by Admin application onboarding.

- **Tavily policy fail-closed hardening**
  - Unknown future `tavily_*` tools are denied until an Admin explicitly implements a domain-policy rule for them.
  - A valid Tavily `tools/call` that encounters an internal policy-evaluation exception is denied rather than forwarded unfiltered.
  - Existing search behavior is unchanged: generic search is constrained to the Admin allowlist; explicit unapproved domains are denied.

## Retained from v1.16.20

- No explicit STS `get-caller-identity` dependency in active runtime/ECR paths.
- `tavily-mcp` and `mcp-remote` build validation uses `command -v`, not `--help` execution.
- Databricks SQL MCP uses the dedicated SSM path `/sandbox/databricks-sql-mcp-token` and the pinned `mcp-remote` bridge to `${DATABRICKS_HOST}/api/2.0/mcp/sql`.
- Claude uses root-owned managed MCP/policy files; Gemini and ucode Gemini receive the equivalent Admin-managed MCP wrappers.
- No automatic cleanup/migration of `ai-claude`, `~/.claude`, or other persistent developer volumes is included.

## Validation performed for this release

- Package lint (`scripts/ci/lint-package.sh`).
- Bash syntax validation for every `.sh` file.
- Python bytecode compilation for every `.py` file.
- JSON parsing for every `.json` file.
- Tavily policy regression tests, including unknown future Tavily tool denial.
- Databricks SQL MCP audit-mapping early-failure path test using a non-secret AWS CLI stub.
- Admin application helper add → validate → remove regression test on a disposable package copy.
- Static cross-file checks for SSM parameter names, MCP wrapper registrations, active STS references, managed Claude MCP entries, and destructive persistent-volume cleanup patterns.

PowerShell 7, ShellCheck, and a Docker Engine are not available in the package-audit container, so native PowerShell parsing and a full Docker image build must still be run on the Windows/Docker Admin workstation as final platform acceptance.
