# AI Secure Sandbox v1.16.20

## Scope

v1.16.20 retains the v1.16.19 runtime/security fixes but deliberately removes all persistent Claude/Tavily cleanup and migration behavior. Container startup does not delete or rewrite developer persistent state.

## Changes

- Removed the persistent-state migration script, startup invocation, post-create invocation, runtime checks, and migration regression test.
- The `ai-claude` named volume and `~/.claude` user state are never cleaned or migrated by Sandbox startup code.
- Retained root-owned Claude managed settings and `allowManagedHooksOnly: true`; security enforcement remains under `/etc/claude-code` and `/usr/local/libexec/ai-sandbox`, not in the persistent user volume.
- Retained root-owned `/etc/claude-code/managed-mcp.json` for Claude and ucode Claude MCP deployment.
- Retained Databricks SQL MCP through `/usr/local/bin/databricks-sql-mcp-ssm` and SSM parameter `${SSM_PREFIX}/databricks-sql-mcp-token`.
- Retained Tavily allowlist enforcement for Claude, Gemini, ucode Claude, ucode Gemini, and direct `tvly` paths.
- Retained removal of explicit STS `get-caller-identity` preflight calls; SSM/ECR requests validate AWS authentication directly.
- Retained Docker build validation using `command -v tavily-mcp` and `command -v mcp-remote`.

## Upgrade note

Existing files in persistent Docker volumes are intentionally left untouched. If an Administrator wants to remove legacy files from an old `ai-claude` volume, that must be a separate explicit maintenance action outside normal container startup.
