# AI Secure Sandbox v1.16.18

## Scope

v1.16.18 is a runtime reliability and policy-enforcement maintenance release based on v1.16.17.

## Changes

- Removed explicit `aws sts get-caller-identity` preflights from DevContainer secret injection, AWS login helpers, runtime verification/information helpers, and Production ECR launchers. Static credentials and IAM Identity Center sessions are now validated by the first required SSM/ECR request instead of a redundant STS call.
- Removed `sts.eu-west-2.amazonaws.com` from the Squid allowlist. No `AssumeRole`/credential-issuing STS workflow is used by this package.
- Kept Docker build verification for `tavily-mcp` and `mcp-remote` as `command -v` checks; `--help` is not used as a build health check for these MCP executables.
- Added the official root-owned Claude enterprise MCP deployment at `/etc/claude-code/managed-mcp.json`, containing Tavily, Snyk, and Databricks SQL registrations.
- Direct Claude and `ucode claude` now rely on the fixed managed MCP deployment rather than user/project MCP state, so isolated ucode HOME/config directories do not hide the Databricks SQL MCP server.
- Hardened Tavily domain policy: `tavily_search` is always constrained to the Admin allowlist; an explicitly requested hostname outside the allowlist is denied rather than silently rewritten. Approved explicit hostnames are narrowed to that hostname. Extract/crawl/map remain fail-closed and unconstrained research remains disabled.
- Updated runtime verification and lint checks for the Admin MCP config, STS-free runtime paths, Tavily enforcement, and `command -v` MCP validation.

## Compatibility

- Static AWS access key/secret key mode remains supported. `AWS_SESSION_TOKEN` remains optional for temporary static credentials.
- IAM Identity Center / AWS SSO remains supported. Interactive login is attempted only when required by an actual SSM access path; MCP stdio processes remain non-interactive.
- Databricks SQL MCP token path remains `${SSM_PREFIX}/databricks-sql-mcp-token` (default `/sandbox/databricks-sql-mcp-token`).
