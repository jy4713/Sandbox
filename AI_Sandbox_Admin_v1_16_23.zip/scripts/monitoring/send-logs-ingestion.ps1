#Requires -Version 7.4
# =============================================================================
# AI Secure Sandbox v1.16.23
# Purpose: Optional direct path that reads Docker-owned Sandbox stdout/stderr
#          streams and forwards them to Azure Monitor Logs Ingestion API.
#          v1.16.23 also creates protected Windows host files through the
#          LOCALSYSTEM exporter for Sentinel/AMA file collection.
# Security: Run as an approved Admin/SYSTEM task. The local state file contains
#           only a forwarding checkpoint, never runtime log content.
# =============================================================================
[CmdletBinding()]
param(
    [string]$ComposeFile,
    [Parameter(Mandatory = $true)][string]$Endpoint,
    [Parameter(Mandatory = $true)][string]$DcrImmutableId,
    [string]$StreamName = 'Custom-AISandboxHostLogs',
    [Parameter(Mandatory = $true)][string]$TenantId,
    [Parameter(Mandatory = $true)][string]$ClientId,
    [string]$ClientSecret = $env:AZURE_CLIENT_SECRET,
    [string]$ClientSecretSsmParameter,
    [string]$AwsProfile = 'sandbox',
    [string]$AwsRegion = 'eu-west-2',
    [string]$StateFile = 'C:\ProgramData\AI-Sandbox\Monitoring\docker-log-state.json',
    [ValidateRange(1, 1440)][int]$InitialLookbackMinutes = 15,
    [ValidateRange(1, 1000)][int]$BatchSize = 200
)

$ErrorActionPreference = 'Stop'
$Root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path

if (-not $ComposeFile) {
    $ComposeFile = Join-Path $Root 'poc\docker-compose.yml'
}
elseif (-not [IO.Path]::IsPathRooted($ComposeFile)) {
    $ComposeFile = Join-Path $Root $ComposeFile
}
$ComposeFile = [IO.Path]::GetFullPath($ComposeFile)

$StateRoot = Split-Path -Parent $StateFile
New-Item -ItemType Directory -Force -Path $StateRoot | Out-Null

# Optional POC helper. Production should prefer the client's approved host
# identity/credential mechanism and must not place the secret in Developer files.
if (-not $ClientSecret -and $ClientSecretSsmParameter) {
    $ClientSecret = & aws ssm get-parameter `
        --name $ClientSecretSsmParameter `
        --with-decryption `
        --profile $AwsProfile `
        --region $AwsRegion `
        --query Parameter.Value `
        --output text
    if ($LASTEXITCODE -ne 0) {
        throw 'Unable to fetch Azure Monitor client secret from AWS SSM.'
    }
    $ClientSecret = $ClientSecret.Trim()
}
if (-not $ClientSecret) {
    throw 'Provide the Azure Monitor client secret using approved host credential handling.'
}

$TokenResponse = Invoke-RestMethod `
    -Method Post `
    -Uri "https://login.microsoftonline.com/$TenantId/oauth2/v2.0/token" `
    -ContentType 'application/x-www-form-urlencoded' `
    -Body @{
        client_id     = $ClientId
        scope         = 'https://monitor.azure.com/.default'
        client_secret = $ClientSecret
        grant_type    = 'client_credentials'
    }
if (-not $TokenResponse.access_token) {
    throw 'Microsoft Entra token response did not contain an access token.'
}

$Headers = @{
    Authorization  = "Bearer $($TokenResponse.access_token)"
    'Content-Type' = 'application/json'
}
$Uri = "$($Endpoint.TrimEnd('/'))/dataCollectionRules/$DcrImmutableId/streams/$StreamName?api-version=2023-01-01"

$Now = (Get-Date).ToUniversalTime()
$Since = $Now.AddMinutes(-$InitialLookbackMinutes)
if (Test-Path $StateFile) {
    try {
        $Saved = Get-Content $StateFile -Raw | ConvertFrom-Json
        if ($Saved.last_success_utc) {
            $Since = [DateTimeOffset]::Parse($Saved.last_success_utc).UtcDateTime.AddSeconds(-2)
        }
    }
    catch {
        Write-Warning "Ignoring invalid state file: $StateFile"
    }
}
$SinceArg = $Since.ToString('o')

$RawLines = @(& docker compose -f $ComposeFile logs `
    --no-color `
    --timestamps `
    --since $SinceArg `
    devcontainer squid-proxy)
if ($LASTEXITCODE -ne 0) {
    throw 'Unable to read Docker Sandbox logs.'
}

$Records = @()
foreach ($Line in $RawLines) {
    if (-not [string]::IsNullOrWhiteSpace($Line)) {
        $Records += [ordered]@{
            Time    = $Now.ToString('o')
            RawData = $Line
        }
    }
}

for ($Offset = 0; $Offset -lt $Records.Count; $Offset += $BatchSize) {
    $Last = [Math]::Min($Offset + $BatchSize - 1, $Records.Count - 1)
    $Body = ConvertTo-Json -InputObject @($Records[$Offset..$Last]) -Compress -Depth 4
    Invoke-RestMethod -Method Post -Uri $Uri -Headers $Headers -Body $Body | Out-Null
}

@{ last_success_utc = $Now.ToString('o') } |
    ConvertTo-Json |
    Set-Content $StateFile -Encoding UTF8

$ClientSecret = $null
$TokenResponse = $null
Write-Host "[OK] Docker log forwarding complete. Records sent: $($Records.Count)" -ForegroundColor Green
