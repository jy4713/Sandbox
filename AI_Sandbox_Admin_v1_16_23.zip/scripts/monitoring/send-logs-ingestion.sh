#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)";COMPOSE="${SANDBOX_COMPOSE_FILE:-$ROOT/poc/docker-compose.yml}";STATE="${AZURE_LOG_STATE_FILE:-/var/lib/ai-sandbox-monitoring/docker-log-state.json}"
: "${AZURE_MONITOR_ENDPOINT:?}";: "${AZURE_DCR_IMMUTABLE_ID:?}";: "${AZURE_TENANT_ID:?}";: "${AZURE_CLIENT_ID:?}";: "${AZURE_CLIENT_SECRET:?}";STREAM="${AZURE_DCR_STREAM_NAME:-Custom-AISandboxHostLogs}"
mkdir -p "$(dirname "$STATE")";chmod 0700 "$(dirname "$STATE")"
TOKEN="$(curl -fsS -X POST "https://login.microsoftonline.com/$AZURE_TENANT_ID/oauth2/v2.0/token" -H 'Content-Type: application/x-www-form-urlencoded' --data-urlencode "client_id=$AZURE_CLIENT_ID" --data-urlencode 'scope=https://monitor.azure.com/.default' --data-urlencode "client_secret=$AZURE_CLIENT_SECRET" --data-urlencode 'grant_type=client_credentials'|python3 -c 'import json,sys;print(json.load(sys.stdin)["access_token"])')"
python3 - "$COMPOSE" "$STATE" "$AZURE_MONITOR_ENDPOINT" "$AZURE_DCR_IMMUTABLE_ID" "$STREAM" "$TOKEN" <<'PYLOG'
import datetime,json,os,subprocess,sys,urllib.request
compose,state_path,endpoint,dcr,stream,token=sys.argv[1:];now=datetime.datetime.now(datetime.timezone.utc);since=now-datetime.timedelta(minutes=15)
try:
 st=json.load(open(state_path));since=datetime.datetime.fromisoformat(st.get('last_success_utc','').replace('Z','+00:00'))-datetime.timedelta(seconds=2) if st.get('last_success_utc') else since
except Exception: pass
r=subprocess.run(['docker','compose','-f',compose,'logs','--no-color','--timestamps','--since',since.isoformat(),'devcontainer','squid-proxy'],text=True,capture_output=True)
if r.returncode: raise SystemExit(r.stderr or 'docker compose logs failed')
records=[{'Time':now.isoformat(),'RawData':x} for x in r.stdout.splitlines() if x.strip()]
for i in range(0,len(records),200):
 req=urllib.request.Request(endpoint.rstrip('/')+f'/dataCollectionRules/{dcr}/streams/{stream}?api-version=2023-01-01',data=json.dumps(records[i:i+200]).encode(),method='POST',headers={'Authorization':'Bearer '+token,'Content-Type':'application/json'});urllib.request.urlopen(req,timeout=30).read()
os.makedirs(os.path.dirname(state_path),exist_ok=True);json.dump({'last_success_utc':now.isoformat()},open(state_path,'w'));print(f'[OK] Docker log forwarding complete. Records sent: {len(records)}')
PYLOG
