#Requires -Version 7.4
# =============================================================================
# AI Secure Sandbox v1.16.23
# Verify protected Windows host log export and read-only container mounts.
# =============================================================================
[CmdletBinding()]
param(
    [string]$ComposeFile,
    [string]$EnvFile,
    [string]$LogRoot = 'C:\ProgramData\AI-Sandbox\Logs',
    [string]$TaskName = 'AI-Sandbox-Protected-Log-Export'
)

$ErrorActionPreference = 'Stop'
$Root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
if (-not $ComposeFile) { $ComposeFile = Join-Path $Root 'poc\docker-compose.yml' }
elseif (-not [IO.Path]::IsPathRooted($ComposeFile)) { $ComposeFile = Join-Path $Root $ComposeFile }
if (-not $EnvFile) { $EnvFile = Join-Path $Root '.env' }
elseif (-not [IO.Path]::IsPathRooted($EnvFile)) { $EnvFile = Join-Path $Root $EnvFile }
$ComposeFile = [IO.Path]::GetFullPath($ComposeFile)
$EnvFile = [IO.Path]::GetFullPath($EnvFile)

foreach ($Path in @($LogRoot, (Join-Path $LogRoot 'devcontainer'), (Join-Path $LogRoot 'squid'))) {
    if (-not (Test-Path -LiteralPath $Path -PathType Container)) { throw "Protected host log directory missing: $Path" }
}

function Assert-CurrentUserCannotWrite([string]$Path) {
    $Probe = Join-Path $Path ('.verify-write-probe-' + [guid]::NewGuid().ToString('N'))
    $Writable = $false
    try {
        [IO.File]::WriteAllText($Probe, 'probe', [Text.UTF8Encoding]::new($false))
        $Writable = $true
    }
    catch [UnauthorizedAccessException] { }
    catch [IO.IOException] { }
    finally {
        if (Test-Path -LiteralPath $Probe) { Remove-Item -LiteralPath $Probe -Force -ErrorAction SilentlyContinue }
    }
    if ($Writable) { throw "Host log path is writable by the current user: $Path" }
}

Assert-CurrentUserCannotWrite -Path (Join-Path $LogRoot 'devcontainer')
Assert-CurrentUserCannotWrite -Path (Join-Path $LogRoot 'squid')

$SystemSidValue = 'S-1-5-18'
$WriteMask = [Security.AccessControl.FileSystemRights]::WriteData `
    -bor [Security.AccessControl.FileSystemRights]::AppendData `
    -bor [Security.AccessControl.FileSystemRights]::CreateDirectories `
    -bor [Security.AccessControl.FileSystemRights]::WriteAttributes `
    -bor [Security.AccessControl.FileSystemRights]::WriteExtendedAttributes `
    -bor [Security.AccessControl.FileSystemRights]::Delete `
    -bor [Security.AccessControl.FileSystemRights]::DeleteSubdirectoriesAndFiles `
    -bor [Security.AccessControl.FileSystemRights]::ChangePermissions `
    -bor [Security.AccessControl.FileSystemRights]::TakeOwnership

function Get-RuleSid([Security.Principal.IdentityReference]$IdentityReference) {
    try { return $IdentityReference.Translate([Security.Principal.SecurityIdentifier]).Value }
    catch { return $IdentityReference.Value }
}

function Assert-SystemOnlyWriterAcl([string]$Path) {
    $Acl = Get-Acl -LiteralPath $Path
    try { $OwnerSid = ([Security.Principal.NTAccount]::new($Acl.Owner)).Translate([Security.Principal.SecurityIdentifier]).Value }
    catch { $OwnerSid = $Acl.Owner }
    if ($OwnerSid -ne $SystemSidValue -and $Acl.Owner -notmatch 'SYSTEM') {
        throw "Protected log root owner is '$($Acl.Owner)' for '$Path'; expected LOCALSYSTEM."
    }
    foreach ($Rule in $Acl.Access) {
        if ($Rule.AccessControlType -ne [Security.AccessControl.AccessControlType]::Allow) { continue }
        $RuleSid = Get-RuleSid -IdentityReference $Rule.IdentityReference
        if ((([int64]$Rule.FileSystemRights -band [int64]$WriteMask) -ne 0) -and $RuleSid -ne $SystemSidValue) {
            throw "Non-SYSTEM principal '$($Rule.IdentityReference)' has write/modify/delete rights on protected log path '$Path'."
        }
    }
}

Assert-SystemOnlyWriterAcl -Path $LogRoot
Assert-SystemOnlyWriterAcl -Path (Join-Path $LogRoot 'devcontainer')
Assert-SystemOnlyWriterAcl -Path (Join-Path $LogRoot 'squid')

$Marker = "protected_host_log_test_$([guid]::NewGuid().ToString('N'))"
$Marker | & docker compose --env-file $EnvFile -f $ComposeFile exec -T devcontainer `
    /usr/local/bin/sandbox-log-emit verification verify
if ($LASTEXITCODE -ne 0) { throw 'Unable to emit verification marker into the DevContainer Docker stream.' }

$ClaudeMarker = "claude_hook_test_$([guid]::NewGuid().ToString('N'))"
$SensitiveText = "DO-NOT-LOG-$ClaudeMarker"
$HookJson = @{
    session_id      = $ClaudeMarker
    cwd             = '/home/vscode/workspace'
    hook_event_name = 'UserPromptSubmit'
    prompt          = $SensitiveText
} | ConvertTo-Json -Compress
$HookJson | & docker compose --env-file $EnvFile -f $ComposeFile exec -T devcontainer /usr/local/bin/claude-audit-hook
if ($LASTEXITCODE -ne 0) { throw 'Claude audit hook verification failed.' }

$Applications = @('anthropic','gemini','databricks','tavily','snyk','ado','git','hiddenlayer','mcp')
foreach ($App in $Applications) {
    & docker compose --env-file $EnvFile -f $ComposeFile exec -T devcontainer /usr/local/bin/application-audit `
        --app $App --event verification --operation host-log --target test --status success
    if ($LASTEXITCODE -ne 0) { throw "Unable to emit $App application audit marker." }
}

$Task = Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
if (-not $Task) {
    throw "SYSTEM log-export task '$TaskName' is not installed. Run scripts\platform\03-setup-logging.ps1 elevated."
}
Start-ScheduledTask -TaskName $TaskName

$Deadline = (Get-Date).AddSeconds(20)
$Found = $false
while ((Get-Date) -lt $Deadline -and -not $Found) {
    Start-Sleep -Seconds 1
    $Candidates = @(Get-ChildItem -LiteralPath (Join-Path $LogRoot 'devcontainer') -Filter 'verification-*.log' -File -ErrorAction SilentlyContinue)
    foreach ($File in $Candidates) {
        if (Select-String -LiteralPath $File.FullName -SimpleMatch $Marker -Quiet -ErrorAction SilentlyContinue) {
            $Found = $true
            break
        }
    }
}
if (-not $Found) { throw 'Verification marker did not reach the protected Windows host log file within 20 seconds.' }

$HostDevLines = @(Get-ChildItem -LiteralPath (Join-Path $LogRoot 'devcontainer') -Filter '*.log' -File |
    ForEach-Object { Get-Content -LiteralPath $_.FullName -ErrorAction SilentlyContinue }) -join "`n"
if ($HostDevLines -like "*$SensitiveText*") { throw 'Claude metadata audit copied prompt content into protected host logs.' }
foreach ($App in $Applications) {
    if ($HostDevLines -notlike "*AI_SANDBOX_LOG|application|$App|*") {
        throw "Protected host application stream missing: $App"
    }
}

& docker compose --env-file $EnvFile -f $ComposeFile exec -T devcontainer sh -c `
    'test ! -w /var/log/sandbox && test ! -e /var/run/docker.sock'
if ($LASTEXITCODE -ne 0) { throw 'DevContainer has a writable host-log path or exposes the Docker socket.' }
& docker compose --env-file $EnvFile -f $ComposeFile exec -T squid-proxy sh -c 'test ! -w /var/log/squid'
if ($LASTEXITCODE -ne 0) { throw 'Squid container has a writable host-log path.' }

$ExpectedMount = @{
    'devcontainer' = '/var/log/sandbox'
    'squid-proxy'  = '/var/log/squid'
}
foreach ($Service in $ExpectedMount.Keys) {
    $Cid = (& docker compose --env-file $EnvFile -f $ComposeFile ps -q $Service | Select-Object -Last 1).ToString().Trim()
    if (-not $Cid) { throw "No running container ID for $Service" }
    $Driver = (& docker inspect --format '{{.HostConfig.LogConfig.Type}}' $Cid | Select-Object -Last 1).ToString().Trim()
    if ($Driver -ne 'local') { throw "$Service logging driver is '$Driver'; expected 'local'." }

    $MountRows = @(& docker inspect --format '{{range .Mounts}}{{println .Destination .RW}}{{end}}' $Cid)
    $Target = $ExpectedMount[$Service]
    $Row = $MountRows | Where-Object { $_.ToString().Trim().StartsWith("$Target ") } | Select-Object -First 1
    if (-not $Row) { throw "$Service does not expose the protected host log directory at $Target." }
    if ($Row.ToString().Trim() -notmatch ('^' + [regex]::Escape($Target) + '\s+false$')) {
        throw "$Service host log mount is not read-only: $($Row.ToString().Trim())"
    }
}

Write-Host '[PASS] Protected Windows host logging verified: SYSTEM export + host read-only ACL + container read-only mounts.' -ForegroundColor Green
