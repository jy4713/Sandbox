# AI Secure Sandbox v1.16.23 Release Notes

## Protected Windows host logging for Sentinel

v1.16.23 restores Windows host log files without restoring a Developer-writable bind mount.

### New logging flow

```text
DevContainer/Squid stdout+stderr
  -> Docker local logging driver
  -> LOCALSYSTEM scheduled exporter
  -> C:\ProgramData\AI-Sandbox\Logs
  -> Sentinel/AMA collection
```

The protected host folders are mounted back into the containers read-only:

```text
C:\ProgramData\AI-Sandbox\Logs\devcontainer -> /var/log/sandbox  RO
C:\ProgramData\AI-Sandbox\Logs\squid        -> /var/log/squid    RO
```

### Windows protection

`scripts/platform/03-setup-logging.ps1` now:

- creates the protected Windows log and monitoring directories;
- sets LOCALSYSTEM as the owner/writer of the log tree;
- grants local Administrators and the configured Developer/read principal read-only access through the normal ACL;
- installs `AI-Sandbox-Protected-Log-Export` as a LOCALSYSTEM scheduled task;
- records the resolved Docker CLI path for the SYSTEM task.

`scripts/monitoring/export-docker-logs-to-host.ps1`:

- refuses normal non-SYSTEM execution;
- reads Docker Compose service streams through Docker Desktop;
- writes daily audit/security/application/content/telemetry/runtime and Squid access/runtime files;
- fails closed if the protected log directories are no longer SYSTEM-owned or a non-SYSTEM allow rule gains write/append/delete/ACL-change rights.

### Developer protection

The POC and Production launchers refuse to start when:

- `SANDBOX_LOG_ROOT` is not configured;
- required protected host log directories are missing; or
- the current Windows user can write to the protected log folders.

Runtime verification now checks:

- host ACL write restrictions;
- SYSTEM owner/write policy;
- protected host export functionality;
- read-only `/var/log/sandbox` and `/var/log/squid` mounts;
- Docker `local` logging;
- absence of the Docker socket from the DevContainer.

### Administrator boundary

The local ACL is intended to prevent normal Developer tampering. It does not claim that a Windows local Administrator is cryptographically unable to alter endpoint-local evidence. A local Administrator can ultimately take ownership/reset ACLs or stop endpoint components. Production authoritative evidence should be forwarded promptly to Sentinel/Log Analytics, with immutable/WORM retention and separation of duties where administrator-resistant deletion protection is required.

### Other v1.16.23 functionality retained

- Docker Desktop Business ECI-compatible read-only root filesystem model.
- `cap_drop: ALL` and `no-new-privileges` runtime controls.
- AWS static-key-first / IAM Identity Center SSO fallback.
- Direct Claude/Gemini provider routing and explicit `ucode` Databricks routing.
- Databricks SQL MCP with SSM-backed token.
- Admin-owned Tavily domain allowlist enforcement.
- Claude/Gemini native web-tool restrictions.
