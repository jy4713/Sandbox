# AI Secure Sandbox v1.16.22 Release Notes

## Tamper-resistant runtime logging

- Removed writable Windows bind mounts for DevContainer and Squid runtime logs.
- Added `sandbox-log-emit`, which hardcodes managed audit/application/Claude records to PID1 stdout; the Developer cannot redirect the retained sink through an environment variable.
- Routed Gemini native telemetry to PID1 stdout.
- Routed Squid access records to stdout and cache/runtime records to stderr.
- Set both services to Docker's `local` logging driver with rotation.
- Kept `/var/log/sandbox` and `/var/log/squid` non-writable to prevent accidental/legacy file logging.
- Updated runtime verification to check the log driver, stream readback, redaction, non-writable legacy paths and Docker-socket absence.
- Updated Azure Monitor Logs Ingestion forwarding to read `docker compose logs` directly; no Windows runtime `*.log` file is staged.
- Removed the old AMA Custom Text Log example because that design required writable host log files.
- Updated Sentinel KQL examples for the managed `AI_SANDBOX_LOG|...` stream prefix.
- Removed the dormant CIS rsyslog/logrotate file-sink configuration so hardening cannot reintroduce `/var/log/sandbox/*.log`; CIS 4.1-4.3 are documented as container-tailored/compensating controls.
- Runtime verification now also fails if either container exposes `/var/log/sandbox` or `/var/log/squid` as a filesystem mount.

## Administrator boundary

A Developer no longer has a supported Windows/container file path in which to edit existing audit/access/content records. Local Docker retention is still not administrator-proof: a Docker/Windows administrator can remove containers or reset local Docker data. Production evidence must be forwarded promptly to Sentinel/central retention; use immutable/WORM storage plus separation of duties when logs must be undeletable even by endpoint/platform administrators.

## Upgrade note

Existing v1.16.21 host log files should be archived separately if they are required as evidence. v1.16.22 does not write to the old `logs\devcontainer` or `logs\squid` bind-mount paths.
