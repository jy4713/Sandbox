#!/usr/bin/env bash
# =============================================================================
# PACKAGE MAINTENANCE NOTES
# Purpose: Fetch the minimum required AWS SSM values, inject them into one child
#          process, and write redacted application/integration audit metadata.
# Routing contract:
#   claude       -> Anthropic official API via /sandbox/claude-api-key
#   gemini       -> Google Gemini official API via /sandbox/gemini-api-key
#   ucode ...    -> Databricks via /sandbox/databricks-token
#   databricks   -> Databricks via /sandbox/databricks-token
# Safety rule: Never log secret values, prompts, responses, source-code content,
#              search queries, complete command lines or tool payloads.
# =============================================================================
set -euo pipefail
set +x
umask 077

usage() {
  cat >&2 <<'USAGE'
Internal usage (normally invoked by sandbox command wrappers):
  run-with-ssm-secrets --profile <ado|anthropic|gemini|databricks|tavily|snyk|hiddenlayer> -- <command> [args...]

Admin/debug examples:
  run-with-ssm-secrets --profile anthropic -- claude
  run-with-ssm-secrets --profile gemini -- gemini
  run-with-ssm-secrets --profile databricks -- ucode claude
  run-with-ssm-secrets --profile databricks -- ucode gemini
  run-with-ssm-secrets --profile databricks -- databricks current-user me
  run-with-ssm-secrets --profile ado -- git push origin main
  run-with-ssm-secrets --profile tavily -- tvly search "security news" --json
  run-with-ssm-secrets --profile snyk -- snyk test
  run-with-ssm-secrets --profile hiddenlayer -- /opt/company/bin/hiddenlayer-client
USAGE
  exit 2
}

[[ "${1:-}" == "--profile" ]] || usage
profile="${2:-}"; [[ -n "$profile" ]] || usage
case "$profile" in ado|anthropic|gemini|databricks|tavily|snyk|hiddenlayer) ;; *) echo "ERROR: unknown profile: $profile" >&2; usage ;; esac
shift 2; [[ "${1:-}" == "--" ]] || usage; shift
(( $# > 0 )) || usage

prefix="${SSM_PREFIX:-/sandbox}"
region="${AWS_REGION:-eu-west-2}"
command -v aws >/dev/null 2>&1 || { echo "ERROR: aws CLI not found" >&2; exit 1; }
command -v application-audit >/dev/null 2>&1 || { echo "ERROR: application-audit helper not found" >&2; exit 1; }

audit_safe() {
  local app="$1" event="$2" operation="${3:-}" target="${4:-}" status="${5:-info}" exit_code="${6:-}" duration_ms="${7:-}" transport="${8:-}"
  local args=(--app "$app" --event "$event" --status "$status")
  [[ -n "$operation" ]] && args+=(--operation "$operation")
  [[ -n "$target" ]] && args+=(--target "$target")
  [[ -n "$exit_code" ]] && args+=(--exit-code "$exit_code")
  [[ -n "$duration_ms" ]] && args+=(--duration-ms "$duration_ms")
  [[ -n "$transport" ]] && args+=(--transport "$transport")
  if ! application-audit "${args[@]}"; then
    [[ "${SANDBOX_AUDIT_REQUIRED:-true}" == "true" ]] && return 1
  fi
  return 0
}

aws_profile="${SANDBOX_AWS_PROFILE:-sandbox}"
access_key="${AWS_ACCESS_KEY_ID:-}"
secret_key="${AWS_SECRET_ACCESS_KEY:-}"
session_token="${AWS_SESSION_TOKEN:-}"
aws_auth_mode="sso"

if [[ -n "$access_key" || -n "$secret_key" || -n "$session_token" ]]; then
  if [[ -z "$access_key" || -z "$secret_key" ]]; then
    audit_safe "$profile" "aws_auth" "ssm" "aws-sts" "failure" || true
    echo 'ERROR: AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY must be configured together.' >&2
    exit 1
  fi
  aws_auth_mode="static"
fi

# AWS_PROFILE is intentionally not injected into the DevContainer. SANDBOX_AWS_PROFILE
# is only the Sandbox-selected SSO profile name. In static-key mode, AWS CLI credential
# resolution therefore uses AWS_ACCESS_KEY_ID/AWS_SECRET_ACCESS_KEY directly. A
# non-secret default/named config stub is still created for region/output consistency.
if [[ "$aws_auth_mode" == "static" ]] && command -v configure-aws-sso >/dev/null 2>&1; then
  configure-aws-sso >/dev/null || {
    echo 'ERROR: could not prepare the non-secret AWS CLI compatibility profile for static credential mode.' >&2
    exit 1
  }
fi

aws_cli() {
  if [[ "$aws_auth_mode" == "static" ]]; then
    env -u AWS_PROFILE -u AWS_DEFAULT_PROFILE aws "$@"
  else
    aws --profile "$aws_profile" "$@"
  fi
}

drop_aws_bootstrap_credentials() {
  if [[ "$aws_auth_mode" == "static" ]]; then
    unset AWS_ACCESS_KEY_ID AWS_SECRET_ACCESS_KEY AWS_SESSION_TOKEN AWS_SECURITY_TOKEN
  fi
}

if ! aws_cli sts get-caller-identity --region "$region" >/dev/null 2>&1; then
  audit_safe "$profile" "aws_auth" "ssm" "aws-sts" "failure" || true
  if [[ "$aws_auth_mode" == "static" ]]; then
    echo 'ERROR: static AWS environment credentials are configured but STS validation failed; SSO fallback is intentionally not attempted.' >&2
    exit 1
  fi
  if command -v sandbox-aws-login >/dev/null 2>&1; then
    echo "[AWS SSO] Session missing/expired. Starting Windows-host browser sign-in flow..." >&2
    sandbox-aws-login || exit 1
  else
    echo "ERROR: no valid AWS SSO session and sandbox-aws-login is unavailable" >&2
    exit 1
  fi
fi

aws_cli sts get-caller-identity --region "$region" >/dev/null 2>&1 || {
  echo 'ERROR: AWS authentication did not produce a valid STS identity' >&2
  exit 1
}
audit_safe "$profile" "aws_auth" "ssm" "aws-sts" "success"

get_parameter() {
  local name="$1" value
  value="$(aws_cli ssm get-parameter --name "${prefix}/${name}" --with-decryption \
    --region "$region" --query 'Parameter.Value' --output text 2>/dev/null)" || {
      audit_safe "$profile" "credential_fetch" "ssm_get_parameter" "aws-ssm" "failure" || true
      echo "ERROR: cannot read required SSM parameter for profile '$profile'" >&2
      return 1
    }
  [[ -n "$value" && "$value" != "None" ]] || {
      audit_safe "$profile" "credential_fetch" "ssm_get_parameter" "aws-ssm" "failure" || true
      echo "ERROR: required SSM parameter for profile '$profile' is empty" >&2
      return 1
    }
  printf '%s' "$value"
}

configured() { local v="${1:-}"; [[ -n "$v" && "$v" != *'<'* && "$v" != *'>'* && "$v" != *REPLACE_* ]]; }
normalize_databricks_host() {
  configured "${DATABRICKS_HOST:-}" || { echo "ERROR: DATABRICKS_HOST is not configured" >&2; return 1; }
  [[ "$DATABRICKS_HOST" == https://* ]] || { echo "ERROR: DATABRICKS_HOST must start with https://" >&2; return 1; }
  printf '%s' "${DATABRICKS_HOST%/}"
}

safe_operation_from_command() {
  local cmd="$(basename -- "${1:-unknown}")" op="${2:-}"
  case "$cmd" in
    git)
      case "$op" in clone|fetch|pull|push|ls-remote|submodule) printf 'git-%s' "$op" ;; *) printf 'git' ;; esac
      ;;
    tvly)
      case "$op" in search|extract|crawl|map|research) printf '%s' "$op" ;; *) printf 'cli' ;; esac
      ;;
    tavily-mcp) printf 'mcp' ;;
    snyk)
      case "$op" in test|monitor|code|container|iac|mcp|auth) printf '%s' "$op" ;; *) printf 'cli' ;; esac
      ;;
    databricks) printf 'cli' ;;
    ucode) printf 'ucode-%s' "${op:-cli}" ;;
    claude) printf 'cli' ;;
    gemini) printf 'cli' ;;
    ado-trigger) printf 'pipeline-trigger' ;;
    ado-pr-create) printf 'pr-create' ;;
    *) printf '%s' "$cmd" ;;
  esac
}

run_logged() {
  local app="$1" operation="$2" target="$3" transport="$4"; shift 4
  local start_ms end_ms duration_ms ec status
  start_ms="$(date +%s%3N)"
  audit_safe "$app" "process_start" "$operation" "$target" "started" "" "" "$transport"
  set +e
  "$@"
  ec=$?
  set -e
  end_ms="$(date +%s%3N)"
  duration_ms=$((end_ms-start_ms))
  status="success"; (( ec == 0 )) || status="failure"
  local audit_end_ec=0
  audit_safe "$app" "process_end" "$operation" "$target" "$status" "$ec" "$duration_ms" "$transport" || audit_end_ec=$?
  if (( ec == 0 && audit_end_ec != 0 )); then return "$audit_end_ec"; fi
  return "$ec"
}

has_arg() {
  local needle="$1"; shift
  local a
  for a in "$@"; do [[ "$a" == "$needle" ]] && return 0; done
  return 1
}

content_logging_enabled() {
  [[ "${SANDBOX_CONTENT_LOGGING:-false}" == "true" ]]
}

# Run CLIs that require writable HOME/cache state in a short-lived tmpfs-backed
# directory. The caller's workspace/cwd is preserved; only user-state paths are
# redirected. This prevents read-only HOME failures without making /home/vscode
# writable or persisting vendor credential/cache files.
run_logged_ephemeral_home() {
  local state_name="$1" app="$2" operation="$3" target="$4" transport="$5"; shift 5
  local tmp_home ec
  tmp_home="$(mktemp -d "/tmp/ai-sandbox-${state_name}.XXXXXX")"
  chmod 0700 "$tmp_home"
  mkdir -p "$tmp_home/.cache" "$tmp_home/.config"
  chmod 0700 "$tmp_home/.cache" "$tmp_home/.config"
  set +e
  run_logged "$app" "$operation" "$target" "$transport" \
    env HOME="$tmp_home" \
        XDG_CACHE_HOME="$tmp_home/.cache" \
        XDG_CONFIG_HOME="$tmp_home/.config" \
        "$@"
  ec=$?
  set -e
  rm -rf "$tmp_home"
  return "$ec"
}

# Snyk is different from Tavily: the Snyk CLI downloads a versioned native
# executable under its cache and then fork/execs it. /tmp is deliberately
# mounted noexec, so Snyk receives its own short-lived exec-enabled tmpfs.
# The mount remains nodev,nosuid, UID 1000 only, and is never persisted.
run_logged_snyk_exec_home() {
  local app="$1" operation="$2" target="$3" transport="$4"; shift 4
  local runtime_root="/run/ai-sandbox-snyk" tmp_home ec opts

  [[ -d "$runtime_root" && -w "$runtime_root" ]] || {
    echo "ERROR: Snyk executable runtime tmpfs is unavailable: $runtime_root" >&2
    return 1
  }
  opts="$(findmnt -no OPTIONS "$runtime_root" 2>/dev/null || true)"
  [[ ",$opts," != *,noexec,* ]] || {
    echo "ERROR: Snyk runtime tmpfs is mounted noexec; rebuild/recreate the v1.16.11 container." >&2
    return 1
  }

  tmp_home="$(mktemp -d "$runtime_root/home.XXXXXX")"
  chmod 0700 "$tmp_home"
  mkdir -p "$tmp_home/.cache" "$tmp_home/.config"
  chmod 0700 "$tmp_home/.cache" "$tmp_home/.config"

  set +e
  run_logged "$app" "$operation" "$target" "$transport" \
    env HOME="$tmp_home" \
        XDG_CACHE_HOME="$tmp_home/.cache" \
        XDG_CONFIG_HOME="$tmp_home/.config" \
        "$@"
  ec=$?
  set -e
  rm -rf "$tmp_home"
  return "$ec"
}

prepare_gemini_telemetry() {
  local route="${1:-direct}" outfile
  export GEMINI_TELEMETRY_ENABLED="true"
  export GEMINI_TELEMETRY_TARGET="local"
  if content_logging_enabled; then
    if [[ "$route" == "databricks" ]]; then
      outfile="/var/log/sandbox/content/ucode-gemini-content.log"
    else
      outfile="/var/log/sandbox/content/gemini-content.log"
    fi
    mkdir -p "$(dirname "$outfile")" 2>/dev/null || true
    touch "$outfile" 2>/dev/null || true
    chmod 0600 "$outfile" 2>/dev/null || true
    export GEMINI_TELEMETRY_OUTFILE="$outfile"
    export GEMINI_TELEMETRY_LOG_PROMPTS="true"
    export GEMINI_TELEMETRY_TRACES_ENABLED="true"
  else
    export GEMINI_TELEMETRY_OUTFILE="/var/log/sandbox/gemini-telemetry.log"
    export GEMINI_TELEMETRY_LOG_PROMPTS="false"
    export GEMINI_TELEMETRY_TRACES_ENABLED="false"
  fi
}

# ----------------------------------------------------------------------------
# APPLICATION MAINTENANCE ZONE - SSM PROFILES + AUDIT ROUTING
# Each branch fetches only its own credentials and records metadata only.
# Raw command arguments are deliberately not sent to application-audit.
# ----------------------------------------------------------------------------
case "$profile" in
  ado)
    ADO_ORG="$(get_parameter ado-org)"; ADO_PROJECT="$(get_parameter ado-project)"; ADO_REPO="$(get_parameter ado-repo)"
    ADO_PAT="$(get_parameter ado-pat)"
    drop_aws_bootstrap_credentials
    export ADO_ORG ADO_PROJECT ADO_REPO ADO_PAT GIT_ASKPASS=/usr/local/bin/git-askpass-ado GIT_TERMINAL_PROMPT=0
    audit_safe ado "credential_fetch" "ssm_get_parameter" "aws-ssm" "success"
    op="$(safe_operation_from_command "$1" "${2:-}")"
    run_logged ado "$op" "azure-devops" "https" "$@"
    ;;

  anthropic)
    # Bare `claude` always means the official Anthropic API. Force provider
    # routing variables at process level so a previous `ucode claude` session
    # cannot leave a Databricks base URL/header in user configuration that
    # changes the meaning of the direct command.
    ANTHROPIC_API_KEY="$(get_parameter claude-api-key)"
    export ANTHROPIC_API_KEY
    export ANTHROPIC_BASE_URL="https://api.anthropic.com"
    export ANTHROPIC_AUTH_TOKEN=""
    export ANTHROPIC_CUSTOM_HEADERS=""
    export CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC=1 DISABLE_AUTOUPDATER=1
    unset CLAUDE_CODE_USE_BEDROCK CLAUDE_CODE_USE_VERTEX CLAUDE_CODE_USE_FOUNDRY
    unset ANTHROPIC_BEDROCK_BASE_URL ANTHROPIC_VERTEX_BASE_URL
    export SANDBOX_AI_ROUTE="direct-anthropic"
    # Keep AWS bootstrap authentication available to the Claude process tree so
    # Tavily/Snyk MCP wrappers can fetch their own SSM secrets later in session.
    audit_safe anthropic "credential_fetch" "ssm_get_parameter" "aws-ssm" "success"
    run_logged anthropic "claude-direct" "api.anthropic.com" "https" "$@"
    ;;

  gemini)
    # Bare `gemini` always means the official Google Gemini API. Explicitly
    # neutralize Databricks gateway variables because ucode may maintain a
    # ~/.gemini/.env for its own routed sessions.
    GEMINI_API_KEY="$(get_parameter gemini-api-key)"
    export GEMINI_API_KEY
    # An exported empty base URL prevents a ucode-managed ~/.gemini/.env
    # gateway URL from taking precedence over GEMINI_API_KEY in Gemini CLI.
    export GOOGLE_GEMINI_BASE_URL=""
    # Likewise, neutralize any ucode-persisted Databricks model selection so
    # the direct CLI uses Google Gemini's normal default unless the Developer
    # explicitly chooses a model in the direct session.
    export GEMINI_MODEL=""
    export GOOGLE_GENAI_USE_VERTEXAI="false"
    export GOOGLE_GENAI_USE_GCA="false"
    export GOOGLE_API_KEY=""
    export GOOGLE_CLOUD_PROJECT="" GOOGLE_CLOUD_PROJECT_ID="" GOOGLE_CLOUD_LOCATION=""
    export SANDBOX_AI_ROUTE="direct-gemini"
    prepare_gemini_telemetry direct
    # Keep AWS bootstrap authentication for nested Tavily/Snyk MCP wrappers.
    audit_safe gemini "credential_fetch" "ssm_get_parameter" "aws-ssm" "success"
    run_logged gemini "gemini-direct" "generativelanguage.googleapis.com" "https" "$@"
    ;;

  databricks)
    DATABRICKS_HOST="$(normalize_databricks_host)"; DATABRICKS_TOKEN="$(get_parameter databricks-token)"
    export DATABRICKS_HOST DATABRICKS_TOKEN
    audit_safe databricks "credential_fetch" "ssm_get_parameter" "aws-ssm" "success"
    cmd="$(basename -- "$1")"
    case "$cmd" in
      ucode)
        # `ucode` is the explicit Databricks-routed launcher. It must never fall
        # into ucode's interactive browser-login/bootstrap flow inside this
        # read-only Sandbox. Build a short-lived PAT profile from the SSM token,
        # configure ucode headlessly, run the selected agent, then delete all
        # generated Databricks/ucode/agent auth state from tmpfs.
        agent="${2:-cli}"
        target="workspace"
        ucode_args=("$@")
        if [[ "$agent" == "claude" ]]; then
          configured "${DATABRICKS_CLAUDE_MODEL:-}" || {
            echo "ERROR: DATABRICKS_CLAUDE_MODEL is required for 'ucode claude'" >&2
            exit 1
          }
          # Pin the approved Databricks-provided Claude model service.
          # ucode forwards the model selection to Claude Code, matching the
          # explicit model-service routing used for ucode gemini.
          if ! has_arg --model "${ucode_args[@]:2}" && ! has_arg -m "${ucode_args[@]:2}"; then
            ucode_args=("${ucode_args[0]}" "${ucode_args[1]}" --model "$DATABRICKS_CLAUDE_MODEL" "${ucode_args[@]:2}")
          fi
          target="$DATABRICKS_CLAUDE_MODEL"
        elif [[ "$agent" == "gemini" ]]; then
          configured "${DATABRICKS_GEMINI_MODEL:-}" || {
            echo "ERROR: DATABRICKS_GEMINI_MODEL is required for 'ucode gemini'" >&2
            exit 1
          }
          # Pin the approved Databricks model for the underlying Gemini CLI.
          # ucode forwards unknown flags to the agent, so use --model explicitly
          # and also export GEMINI_MODEL for compatible Gemini CLI releases.
          if ! has_arg --model "${ucode_args[@]:2}" && ! has_arg -m "${ucode_args[@]:2}"; then
            ucode_args=("${ucode_args[0]}" "${ucode_args[1]}" --model "$DATABRICKS_GEMINI_MODEL" "${ucode_args[@]:2}")
          fi
          export GEMINI_MODEL="$DATABRICKS_GEMINI_MODEL"
          target="$DATABRICKS_GEMINI_MODEL"
        fi

        if [[ "$agent" == "claude" || "$agent" == "gemini" ]]; then
          ucode_home="$(mktemp -d /tmp/ai-sandbox-ucode.XXXXXX)"
          chmod 0700 "$ucode_home"
          ucode_cfg="$ucode_home/.databrickscfg"
          cat >"$ucode_cfg" <<EOF
[DEFAULT]
host = $DATABRICKS_HOST
token = $DATABRICKS_TOKEN
auth_type = pat
EOF
          chmod 0600 "$ucode_cfg"

          # Fail closed if the pinned ucode build does not support headless PAT
          # configuration. Never fall back to interactive `databricks auth login`.
          # Capture the complete help output before checking capabilities. Piping
          # directly to `grep -q` under `set -o pipefail` can produce a false
          # negative when grep exits early and ucode receives SIGPIPE.
          ucode_configure_help="$(
            env HOME="$ucode_home" \
                PATH="/usr/local/libexec/ai-sandbox/real:${PATH}" \
                "${ucode_args[0]}" configure --help 2>&1
          )" || {
            rm -rf "$ucode_home"
            echo "ERROR: unable to inspect installed ucode configure capabilities" >&2
            exit 1
          }

          for required_option in \
            '--profiles' \
            '--use-pat' \
            '--skip-validate' \
            '--skip-upgrade'
          do
            if [[ "$ucode_configure_help" != *"$required_option"* ]]; then
              rm -rf "$ucode_home"
              echo "ERROR: installed ucode configure does not support ${required_option}" >&2
              exit 1
            fi
          done

          audit_safe databricks "ucode_configure" "headless-pat" "workspace" "started"
          set +e
          env -u DATABRICKS_HOST -u DATABRICKS_TOKEN -u DATABRICKS_CONFIG_PROFILE \
            HOME="$ucode_home" \
            DATABRICKS_CONFIG_FILE="$ucode_cfg" \
            PATH="/usr/local/libexec/ai-sandbox/real:${PATH}" \
            "${ucode_args[0]}" configure \
              --profiles DEFAULT \
              --agents "$agent" \
              --use-pat \
              --skip-validate \
              --skip-upgrade
          configure_ec=$?
          set -e
          if (( configure_ec != 0 )); then
            audit_safe databricks "ucode_configure" "headless-pat" "workspace" "failure" "$configure_ec" || true
            rm -rf "$ucode_home"
            echo "ERROR: headless ucode Databricks configuration failed" >&2
            exit "$configure_ec"
          fi
          audit_safe databricks "ucode_configure" "headless-pat" "workspace" "success"

          # Retain AWS bootstrap credentials in the launched AI-agent process tree
          # so Admin-managed Tavily/Snyk MCP wrappers can fetch their own SSM
          # secrets later in the session. The Databricks PAT stays in temporary
          # runtime storage and is removed when the agent exits.
          if [[ "$agent" == "claude" ]]; then
            export SANDBOX_AI_ROUTE="databricks-claude"
            agent_config_env=(CLAUDE_CONFIG_DIR="$ucode_home/.claude")
          else
            export SANDBOX_AI_ROUTE="databricks-gemini"
            prepare_gemini_telemetry databricks
            agent_config_env=()
          fi

          set +e
          run_logged databricks "ucode-${agent}" "$target" "https" \
            env -u DATABRICKS_HOST -u DATABRICKS_TOKEN \
                HOME="$ucode_home" \
                DATABRICKS_CONFIG_FILE="$ucode_cfg" \
                DATABRICKS_CONFIG_PROFILE=DEFAULT \
                PATH="/usr/local/libexec/ai-sandbox/real:${PATH}" \
                "${agent_config_env[@]}" \
                "${ucode_args[@]}"
          ucode_ec=$?
          set -e
          rm -rf "$ucode_home"
          exit "$ucode_ec"
        fi

        # Non-agent ucode subcommands use the normal Databricks profile path.
        drop_aws_bootstrap_credentials
        export SANDBOX_AI_ROUTE="databricks-${agent}"
        run_logged databricks "ucode-${agent}" "$target" "https" \
          env PATH="/usr/local/libexec/ai-sandbox/real:${PATH}" "${ucode_args[@]}"
        ;;
      databricks)
        drop_aws_bootstrap_credentials
        run_logged databricks "cli" "workspace" "https" "$@"
        ;;
      *)
        drop_aws_bootstrap_credentials
        op="$(safe_operation_from_command "$1" "${2:-}")"
        run_logged databricks "$op" "workspace" "https" "$@"
        ;;
    esac
    ;;

  tavily)
    TAVILY_API_KEY="$(get_parameter tavily-api-key)"; drop_aws_bootstrap_credentials; export TAVILY_API_KEY
    audit_safe tavily "credential_fetch" "ssm_get_parameter" "aws-ssm" "success"
    op="$(safe_operation_from_command "$1" "${2:-}")"
    transport="https"; [[ "$(basename -- "$1")" == "tavily-mcp" ]] && transport="stdio"
    # tvly/tavily-mcp can create ~/.tavily/config.json on first use. Keep that
    # vendor state ephemeral instead of weakening the read-only HOME boundary.
    run_logged_ephemeral_home tavily tavily "$op" "tavily" "$transport" "$@"
    ;;

  snyk)
    SNYK_TOKEN="$(get_parameter snyk-token)"; drop_aws_bootstrap_credentials; export SNYK_TOKEN
    if configured "${SNYK_API:-}"; then export SNYK_API; fi
    audit_safe snyk "credential_fetch" "ssm_get_parameter" "aws-ssm" "success"
    op="$(safe_operation_from_command "$1" "${2:-}")"
    transport="https"; [[ "$op" == "mcp" ]] && transport="stdio"
    # Snyk creates and executes a versioned native binary under ~/.cache/snyk.
    # Use the dedicated exec-enabled, nodev/nosuid tmpfs instead of /tmp(noexec).
    run_logged_snyk_exec_home snyk "$op" "snyk" "$transport" "$@"
    ;;

  hiddenlayer)
    configured "${HIDDENLAYER_API_URL:-}" || { echo "ERROR: HIDDENLAYER_API_URL is not configured in .env" >&2; exit 1; }
    [[ "$HIDDENLAYER_API_URL" == https://* ]] || { echo "ERROR: HIDDENLAYER_API_URL must use https://" >&2; exit 1; }
    HIDDENLAYER_CLIENT_ID="$(get_parameter hiddenlayer-client-id)"
    HIDDENLAYER_CLIENT_SECRET="$(get_parameter hiddenlayer-client-secret)"
    drop_aws_bootstrap_credentials
    export HIDDENLAYER_API_URL HIDDENLAYER_CLIENT_ID HIDDENLAYER_CLIENT_SECRET
    audit_safe hiddenlayer "credential_fetch" "ssm_get_parameter" "aws-ssm" "success"
    op="$(safe_operation_from_command "$1" "${2:-}")"
    run_logged hiddenlayer "$op" "hiddenlayer" "https" "$@"
    ;;

  *) echo "ERROR: unknown profile: $profile" >&2; usage ;;
esac
