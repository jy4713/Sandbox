# AI Secure Sandbox v1.16.44 — Complete Package, Build, Runtime and Maintenance Guide

> **Document status:** This is the authoritative detailed operational guide for the v1.16.44 Admin package. The active build package intentionally excludes release-history, package-cleanup, language-audit, and QA-evidence files. Those records belong in source control, release storage, change management, or an external evidence repository when required. The `docs/` directory is documentation-only and is not a build, export, deploy, or lint dependency.

## 1. What this package is

AI Secure Sandbox v1.16.44 is an Admin-built development environment for Windows 365 and Docker Desktop. The Admin validates/pins build inputs, creates a hardened Ubuntu 24.04 base, builds the DevContainer and Squid proxy, assesses the final DevContainer, and distributes the release through TAR or ECR.

v1.16.44 uses a **credential-only secret broker** and enforces local application execution. The runtime boundary is:

```text
Windows 365 host
  |
  +-- Developer host AWS profile
  |     |-- static Access Key + Secret Access Key (POC test option)
  |     `-- or aws-azure-login -> Azure-Entra MFA -> temporary AWS role credentials
  |
  +-- Docker Desktop
  |     |
  |     +-- secret-broker
  |     |     - internal Docker network only
  |     |     - ONLY service with read-only host ~/.aws bind mount
  |     |     - AWS SSM GetParameter for approved parameter names
  |     |     - injects authentication at fixed HTTP routes only
  |     |     - NO workspace mount and NO application child processes
  |     |
  |     +-- DevContainer
  |     |     - internal Docker network only
  |     |     - ONLY service with workspace bind mount
  |     |     - every Claude/Gemini/ucode/Git/Snyk/Tavily/Databricks/MCP process runs here as vscode
  |     |     - no ~/.aws mount or AWS credential environment
  |     |     - no direct SSM authentication or raw service secret
  |     |     - non-root vscode user, read-only root, no Docker socket
  |     |
  |     `-- Squid proxy
  |           - internal + external Docker networks
  |           - default-deny outbound policy
  |
  `-- Docker-owned stdout/stderr -> host exporter -> Sentinel/DCR as configured
```

Important security boundaries:

- Raw AWS access keys are not supported in runtime `.env`; for POC testing, a static key pair may exist only in the selected host `~/.aws/credentials` profile.
- AWS authentication is host-only. `AWS_AUTH_MODE=auto` uses a static host profile first when present, otherwise Azure/Entra SAML via `aws-azure-login --profile <name> --mode gui`.
- The selected host AWS profile directory is mounted read-only into `secret-broker` only, never the AI DevContainer.
- The former `run-with-ssm-secrets` command runner and `secret-broker-client` are retired fail-closed guards and return 126 in every role.
- Direct Claude/Gemini and `ucode claude/gemini` execute locally and receive only fixed placeholder authentication; the real provider/Databricks credential is injected by the broker into the approved upstream HTTP request.
- Git, Tavily, Snyk, Databricks CLI, ADO helpers and the three managed MCP processes execute locally as `vscode`; their fixed HTTP routes are credentialed broker-side.
- Only the DevContainer mounts the workspace, preventing cross-container UID ownership such as `nobody:nogroup` on cloned/generated source.
- The DevContainer has no Docker socket, all Linux capabilities are dropped, `no-new-privileges` is enabled, and the root filesystem is read-only.
- External traffic is default-deny through Squid.

# Part A — Package structure and configuration ownership

## 2. Top-level layout

```text
AI_Sandbox_Admin_v1_16_44
|-- README.md
|-- .build.env.example
|-- .env.example
|-- .dockerignore
|-- .devcontainer/
|-- ado-scripts/
|-- docs/                    # optional human-readable Admin documentation only
|-- ecr/
|-- tar/
|-- policies/
|-- scripts/
|-- security/
|-- sentinel/
|-- squid/
|-- templates/               # active Developer package generation inputs
|   `-- developer/
`-- workspace/
```

`README.md` is the short entry point. `docs/ADMIN-COMPLETE-GUIDE.md`, `docs/ADMIN-APPLICATION-ADD-REMOVE.md`, and `docs/SECURITY-LOGGING-AND-SENTINEL.md` are optional operational references. They are not required by the image build, Developer package export, direct ECR deployment, or package lint. The files under `templates/developer/` are different: they are active package-generation inputs and therefore are linted and must remain present.

The repository-root `.dockerignore` is authoritative because the DevContainer Docker build context is the repository root. Nested `.dockerignore` files do not control that build context.

## 3. `.build.env.example` — Admin build inputs

`.build.env.example` defines release-controlled build-time values. It is not a secret store. Major groups include release identity, immutable base-image/tool inputs, CIS/OpenSCAP settings, ECR publication settings, and non-secret Developer Azure/Entra federation defaults.

The Developer authentication defaults are:

```text
DEVELOPER_AWS_PROFILE
DEVELOPER_AWS_REGION
DEVELOPER_AZURE_TENANT_ID
DEVELOPER_AZURE_APP_ID_URI
DEVELOPER_AZURE_DEFAULT_USERNAME
DEVELOPER_AZURE_DEFAULT_ROLE_ARN
DEVELOPER_AZURE_DEFAULT_DURATION_HOURS
DEVELOPER_AZURE_DEFAULT_REMEMBER_ME
```

Rules:

1. Do not place AWS access keys, PATs, API keys or passwords in `.build.env`.
2. Base images should resolve to immutable digests.
3. Downloaded artifacts must use approved hashes where supported.
4. `UCODE_GIT_REF` remains an immutable source pin even though the secure runtime route does not expose a Databricks PAT to upstream ucode.
5. Azure/Entra values are non-secret federation metadata and may be stamped into Developer templates where permitted.

## 4. `.env.example` — runtime configuration and host AWS federation

The deployment-local `.env` contains **non-secret** runtime configuration. v1.16.44 rejects raw AWS keys in `.env` and the old native IAM Identity Center `AWS_SSO_*` bootstrap fields. Static test keys, when used, stay in the host AWS shared-credentials profile only.

Important values:

```text
DATABRICKS_HOST
DATABRICKS_CLAUDE_MODEL
DATABRICKS_GEMINI_MODEL
SANDBOX_AWS_PROFILE
AWS_REGION
SSM_PREFIX
AZURE_TENANT_ID
AZURE_APP_ID_URI
AZURE_DEFAULT_USERNAME
AZURE_DEFAULT_ROLE_ARN
AZURE_DEFAULT_DURATION_HOURS
AZURE_DEFAULT_REMEMBER_ME
SANDBOX_HOST_AWS_DIR        # launcher-managed host path, not a secret value
DEVELOPER_ID
SANDBOX_AUDIT_REQUIRED
SNYK_API
HIDDENLAYER_API_URL
APPROVED_IMAGES_SSM_PARAMETER
```

The Windows launcher creates/updates the named host profile with the equivalent `aws-azure-login` keys:

```ini
azure_tenant_id=...
azure_app_id_uri=...
azure_default_username=...
azure_default_role_arn=arn:aws:iam::<account>:role/<role>
azure_default_duration_hours=1
azure_default_remember_me=true
```

The launcher invokes `aws-azure-login --profile <profile> --mode gui` and the Developer completes Azure/Entra authentication/MFA in the Windows browser. There is no separate STS preflight; the subsequent SSM/ECR operation validates the permissions actually required by the package.

Application secrets remain in SSM. They must never be copied to `.env`, source, workspace files, MCP configuration or AI-agent user configuration.

# Part B — Admin build orchestration

> **Windows shell requirement:** all `.ps1` entry points in this baseline require PowerShell 7.4+ (`pwsh`). Windows PowerShell 5.1 is not a supported host for this package.

## 5. Primary Admin entry point

The supported orchestration entry point is:

```powershell
.\scripts\admin\build-sandbox.ps1 -SandboxType POC
```

or for Production:

```powershell
.\scripts\admin\build-sandbox.ps1 -SandboxType Production
```

The Bash peer is `scripts/admin/build-sandbox.sh`.

Build-selection matrix:

| SandboxType | DeploymentType omitted | Explicit DeploymentType | Result |
|---|---|---|---|
| `POC` | `Tar` | `Tar` or `Ecr` | Self-hardened Ubuntu 24.04 image |
| `Production` | `Ecr` | `Tar` or `Ecr` | Ubuntu Pro + USG image |

Examples:

```powershell
# Production-grade image exported as TAR while ECR is not yet ready
pwsh -NoProfile -File .\scripts\admin\build-sandbox.ps1 -SandboxType Production -DeploymentType Tar

# POC image published to ECR
pwsh -NoProfile -File .\scripts\admin\build-sandbox.ps1 -SandboxType POC -DeploymentType Ecr
```

The Ubuntu Pro token requirement follows `SandboxType=Production`, not ECR. ECR configuration/credentials are required only when `DeploymentType=Ecr`.

The orchestration script intentionally remains thin. `SandboxType` selects only the hardening path and `DeploymentType` selects only the distribution path. It delegates detailed work to supply-chain, hardening, TAR, ECR, and security scripts.

Before the first build, the Admin normally performs:

```powershell
Copy-Item .build.env.example .build.env
.\scripts\ci\lint-package.ps1
```

The build script also creates `.build.env` automatically if it is missing, but explicit creation is useful because the Admin can review and populate organization-specific values before the first release.

### 5.1 Fast iterative builds with `-ReuseHardenedBase`

v1.16.44 adds an explicit hardened-base reuse mode for repeated POC or Production image builds where the OS hardening baseline has not changed. This is useful when testing DevContainer scripts, application wrappers, Dockerfile application layers, Squid configuration, logging, or other changes above the hardened OS layer.

The safest workflow is to copy the previously resolved `.build.env` from the last successful build into the new v1.16.44 Admin package and then request reuse:

```powershell
Copy-Item 'C:\path\to\previous-package\.build.env' .\.build.env
.\scripts\admin\build-sandbox.ps1 -SandboxType POC -ReuseHardenedBase
```

The same operation can be done in one command:

```powershell
pwsh -NoProfile -File .\scripts\admin\build-sandbox.ps1 `
  -SandboxType POC `
  -ReuseHardenedBase `
  -BuildEnvSource 'C:\path\to\previous-package\.build.env'
```

Bash equivalent:

```bash
bash scripts/admin/build-sandbox.sh POC \
  --reuse-hardened-base \
  --build-env-source ../previous-package/.build.env
```

Reuse is **never assumed**. The Admin entry point performs all of these checks before skipping hardening:

1. `.build.env` exists and passes normal strict validation.
2. `BASE_IMAGE` and `SQUID_BASE_IMAGE` are exactly the same digest-pinned reference.
3. The exact hardened digest can be inspected/pulled, **or** a local image can be cryptographically matched by the persisted `HARDENED_CONFIG_ID`.
4. `hardening.method` matches the requested SandboxType and `hardening.profile` is `cis_level1_server`.
5. Recorded source-image and ComplianceAsCode SSG provenance, when present, match the image labels.
6. If the localhost scratch registry must be re-materialized, the re-pushed image resolves to the same Docker config ID before a newly resolved manifest digest is accepted. Labels alone are never accepted as proof of identity.

If any check fails, the script prints the reuse failure reason and automatically returns to the standard workflow. The fallback is transactional in v1.16.44: resolver output is written to a temporary build-env, and the active `.build.env` is replaced only after the new hardened base has completed and validated successfully. An interrupted or failed hardening run therefore leaves the previous reusable hardened reference intact:

```text
resolve base/tool inputs
  -> rebuild hardened base
  -> update BASE_IMAGE/SQUID_BASE_IMAGE
  -> build DevContainer/Squid
```

This means `-ReuseHardenedBase` is an optimization request, not a command to bypass validation. New full builds persist both the registry manifest digest and `HARDENED_CONFIG_ID`. The latter is the Docker image config digest and remains stable if the Admin-only scratch registry container or volume is recreated. When a verified local image must be re-pushed, the registry manifest digest may change; v1.16.44 accepts that new digest only after the config ID and hardening provenance have been verified, then writes the new digest and refreshed tool hashes to a staged build-env.

Legacy copied build state without `HARDENED_CONFIG_ID` remains compatible when the exact old digest is still available. If the exact digest is gone and only a local tag remains, recovery intentionally fails closed and a full hardening build is performed rather than trusting labels alone.

Package/release metadata is also updated transactionally: `SANDBOX_VERSION` becomes `v1.16.44`, and `RELEASE_TAG` follows it only when it previously tracked the package version. A failed reuse refresh or hardening run leaves the prior active `.build.env` unchanged.

For Production, a valid reused Production hardened base does not require the Ubuntu Pro token again. If reuse validation fails and a new Production hardened base is required, the Ubuntu Pro token becomes mandatory as in the normal build path.

Without `-ReuseHardenedBase`, behavior is unchanged: the hardened base is rebuilt.

## 6. POC build call graph

The POC path is:

```text
scripts/admin/build-sandbox.ps1 -SandboxType POC
  |
  |-- [0] Ensure .build.env exists and stamp v1.16.44
  |
  |-- [reuse requested?] Validate complete .build.env + exact labelled hardened digest
  |      |-- PASS -> skip [1]-[4] and continue to final runtime-image build
  |      `-- FAIL -> automatically run the normal full path below
  |
  |-- [1] scripts/supply-chain/resolve-base-digests.ps1 -Write
  |      |-- resolve Ubuntu base digest
  |      |-- resolve Node image digest
  |      `-- update .build.env
  |
  |-- [2] scripts/supply-chain/resolve-tool-artifacts.ps1 -Write
  |      |-- resolve AWS CLI SHA-256
  |      |-- resolve Databricks CLI SHA-256
  |      |-- resolve ComplianceAsCode/SSG SHA-256
  |      |-- resolve GCM hash when configured
  |      |-- resolve ucode Git reference to immutable commit
  |      `-- update .build.env
  |
  |-- [3] scripts/hardening/build-hardened-base.ps1 -SandboxType POC
  |      |-- load and validate .build.env
  |      |-- obtain pinned SSG content
  |      |-- create temporary hardening build context
  |      |-- build candidate Ubuntu base
  |      |-- run OpenSCAP assessment/remediation workflow
  |      |-- remove hardening-only tooling from final base
  |      |-- publish through the configured scratch/local registry path when needed
  |      |-- obtain immutable hardened image digest
  |      `-- write hardened-base-build/hardened-base.env
  |
  |-- [4] Apply-HardenedBaseEnvironment
  |      |-- read hardened-base.env
  |      |-- set BASE_IMAGE to hardened digest
  |      `-- set SQUID_BASE_IMAGE to the same hardened digest
  |
  `-- [5] scripts/tar/build-and-export.ps1
         |-- load/validate .build.env
         |-- build final DevContainer
         |-- assess final DevContainer with separate OpenSCAP scanner image
         |-- copy security evidence
         |-- build Squid from the same hardened base digest
         |-- docker save both images
         |-- capture immutable Docker image IDs
         |-- create image-manifest.env
         |-- create image-manifest.json
         |-- create runtime-policy.sha256
         `-- create SHA256SUMS
```

### TAR outputs

For either SandboxType, `DeploymentType=Tar` writes release artifacts beneath `tar/images/`:

```text
tar/images/
|-- sandbox-devcontainer.tar
|-- sandbox-squid.tar
|-- image-manifest.env
|-- image-manifest.json
|-- runtime-policy.sha256
|-- SHA256SUMS
`-- security/
    `-- OpenSCAP/CIS assessment evidence
```

After a successful TAR build, the Admin creates the distributable Developer package with:

```powershell
.\scripts\admin\export-developer-packages.ps1 -IncludeTarImages
```

The TAR package is distribution-specific, not hardening-specific: it can contain either a POC-hardened or Production-hardened image set.

## 7. Production build call graph

`SandboxType=Production` begins with the same supply-chain resolution steps and switches to Ubuntu Pro/USG hardening. Distribution is then selected independently by `DeploymentType`:

```text
scripts/admin/build-sandbox.ps1 -SandboxType Production
  |
  |-- ensure .build.env exists and stamp v1.16.44
  |-- if -ReuseHardenedBase: validate complete .build.env + exact Production hardened digest
  |      |-- PASS -> skip resolver/hardening and continue to ECR final-image build
  |      `-- FAIL -> automatically continue with full Production hardening path
  |-- resolve base image digests
  |-- resolve tool hashes and ucode commit
  |
  |-- scripts/hardening/build-hardened-base.ps1
  |      |-- Ubuntu Pro token supplied as BuildKit secret
  |      |-- Ubuntu Pro / USG hardening
  |      |-- hardening evidence
  |      |-- removal of build-only hardening tooling
  |      `-- hardened-base-build/hardened-base.env
  |
  |-- update BASE_IMAGE and SQUID_BASE_IMAGE
  |-- force REQUIRE_CIS_PASS=true
  |
  `-- scripts/platform/02-setup-ecr.ps1
         |-- ensure ECR repositories/policies
         |-- build final DevContainer
         |-- run final-image CIS/OpenSCAP gate
         |-- build Squid
         |-- push images to ECR
         |-- obtain immutable ECR digests
         |-- create approved-images manifest
         `-- optionally publish approved manifest to SSM
```

ECR Developers do not receive Docker build inputs. Their launcher resolves the centrally approved image manifest, pulls exact ECR digests, tags them to local approved runtime names, and starts Compose with `pull_policy: never`.

---

# Part C — Supply-chain resolution

## 8. `scripts/supply-chain/resolve-base-digests.*`

Purpose: convert mutable upstream base references into immutable digest-pinned references before image construction.

The resolver updates values such as:

```text
BASE_IMAGE=ubuntu:24.04@sha256:<resolved digest>
NODE_IMAGE=node:20-bookworm-slim@sha256:<resolved digest>
SQUID_BASE_IMAGE=ubuntu:24.04@sha256:<resolved digest>
```

The hardened-base stage later replaces both runtime base references with the immutable digest of the internally hardened base.

## 9. `scripts/supply-chain/resolve-tool-artifacts.*`

Purpose: resolve or validate immutable artifact metadata used by the Docker build.

Typical responsibilities:

- AWS CLI archive SHA-256.
- Databricks CLI release SHA-256.
- ComplianceAsCode/SSG archive SHA-256.
- Git Credential Manager hash when configured.
- `UCODE_GIT_REF` normalization to an immutable Git commit.

This keeps network-dependent discovery in an Admin-controlled pre-build step rather than hiding mutable downloads inside runtime initialization.

## 10. `scripts/common/Load-BuildEnv.ps1` and `load-build-env.sh`

These are shared parsers for `.build.env`. They read the file as data rather than executing it as arbitrary shell/PowerShell code, validate required values, and expose the resulting build configuration to downstream scripts.

When a new required build variable is added, both implementations must remain synchronized.

---

# Part D — Hardened base creation

## 11. `scripts/hardening/build-hardened-base.*`

The hardened-base builder is deliberately separate from the final DevContainer Dockerfile. The goal is to establish a reusable security baseline and then layer application/runtime content on top.

### POC mode

POC uses a self-hardening workflow based on Ubuntu 24.04 and OpenSCAP/ComplianceAsCode content. It is designed to produce repeatable hardening evidence without requiring the Production Ubuntu Pro entitlement path.

Conceptually:

```text
Pinned Ubuntu base
  -> hardening build context
  -> OpenSCAP/SSG content
  -> candidate base
  -> assessment/remediation
  -> remove hardening-only toolchain
  -> immutable hardened base digest
```

### Production mode

Production uses Ubuntu Pro and USG. The Ubuntu Pro token is treated as a build secret rather than a normal Docker build argument so it is not intentionally persisted in image metadata or layers.

Conceptually:

```text
Pinned Ubuntu base
  -> Ubuntu Pro attach during build
  -> USG/CIS hardening
  -> evidence
  -> detach/cleanup as required by implementation
  -> remove hardening-only tooling
  -> immutable hardened base digest
```

### Scratch/local registry rationale

A local or scratch registry may be used during the build to convert an internally created image into a stable digest reference that subsequent Dockerfiles can consume with `FROM repository@sha256:...`. This is a build-time mechanism; it is not the Production distribution boundary. Final distribution is selected independently with `DeploymentType=Tar|Ecr`.

### `hardened-base-build/hardened-base.env`

The builder writes:

```text
BASE_IMAGE=<hardened repository@sha256:digest>
SQUID_BASE_IMAGE=<same hardened repository@sha256:digest>
```

`build-sandbox.*` copies only these two values back into `.build.env`, ensuring the DevContainer and Squid are based on the same approved hardened root.

---

# Part E — Why OpenSCAP appears twice

## 12. Two distinct OpenSCAP roles

OpenSCAP appears in two different phases and the distinction is important.

### Role A — hardened-base creation and evidence

The hardened-base builder uses OpenSCAP/SSG or Ubuntu Pro/USG depending on the selected build mode to produce the security baseline.

### Role B — final DevContainer assessment

After application tools, runtime wrappers, users, writable-path preparation, and other DevContainer content have been added, `scripts/security/assess-cis-l1.*` assesses the **final** DevContainer image.

This catches regressions introduced after the base was hardened. A hardened base alone is not evidence that the final application image still meets the expected security baseline.

The final assessment uses a separate scanner image rather than installing OpenSCAP into the production DevContainer. This keeps scanning tools out of the runtime image and reduces runtime attack surface.

## 13. `security/cis-scanner/Dockerfile`

This Dockerfile builds the dedicated OpenSCAP/ComplianceAsCode scanner used by the final-image assessment scripts. It is a build/assessment utility image and is not delivered as a Developer runtime service.

## 14. `security/CIS-TAILORING-README.md`

This document describes how an organization-approved tailoring file can be introduced when specific CIS controls require formally reviewed exceptions. Production should fail closed when required assessment criteria are not met.

---

# Part F — Final DevContainer build

## 15. `.devcontainer/Dockerfile`

The Dockerfile constructs the application runtime on top of the hardened base.

### 15.1 Node source stage

A digest-pinned Node image is used as a controlled source for the Node runtime rather than running an unverified remote installation script.

### 15.2 Hardened runtime stage

The final stage starts from `BASE_IMAGE`, which should already point to the immutable hardened-base digest produced earlier.

### 15.3 Build parameter validation

Required versions, URLs, hashes, and immutable references are checked early so a build fails before expensive package installation when configuration is incomplete.

### 15.4 System dependencies

Only packages required by the approved development/runtime toolchain are installed. Package changes must be reviewed as supply-chain and attack-surface changes.

### 15.5 Approved CLI and agent installation

The Dockerfile installs the approved toolset, including the configured versions of Claude Code, Gemini CLI, Tavily CLI/MCP, Snyk CLI, AWS CLI, Databricks CLI, ucode, Azure CLI, Git Credential Manager, and supporting runtimes.

Different tools use different approved installation methods. The package does not pretend that every vendor tool has the same installer. Direct archive downloads are verified with SHA-256 where implemented; npm tools use exact package versions; ucode uses an immutable Git commit.

### 15.6 Real executable stash

Vendor executables that require Admin command wrapping are preserved under:

```text
/usr/local/libexec/ai-sandbox/real/
```

The public command names point to the Admin-controlled `sandbox-command-wrapper`. This prevents Developers from accidentally bypassing the SSM/audit path by invoking the normal command name.

Typical mapping:

```text
/usr/local/bin/claude      -> sandbox-command-wrapper
/usr/local/bin/gemini      -> sandbox-command-wrapper
/usr/local/bin/tvly        -> sandbox-command-wrapper
/usr/local/bin/snyk        -> sandbox-command-wrapper
/usr/local/bin/databricks  -> sandbox-command-wrapper

/usr/local/libexec/ai-sandbox/real/claude
/usr/local/libexec/ai-sandbox/real/gemini
/usr/local/libexec/ai-sandbox/real/tvly
/usr/local/libexec/ai-sandbox/real/snyk
/usr/local/libexec/ai-sandbox/real/databricks
```

### 15.7 Non-root user and writable directories

The Dockerfile prepares the `vscode` user and only the specific home/config/cache locations required by runtime tools. The runtime root filesystem is read-only, so writable state must live in approved volume-mounted paths or tmpfs.

### 15.8 `cis-level1-harden.sh`

This is an image-level hardening script applied during DevContainer construction. It complements, rather than replaces, the separate final OpenSCAP assessment.

### 15.9 Runtime security scripts copied into the image

Key runtime programs include:

```text
/usr/local/bin/application-audit
/usr/local/bin/claude-audit-hook
host launcher Azure/Entra profile initialization
/usr/local/bin/configure-mcp
/usr/local/bin/run-with-ssm-secrets
host aws-azure-login browser flow
/usr/local/bin/sandbox-info
/usr/local/bin/tavily-mcp-ssm
/usr/local/bin/snyk-mcp-ssm
/usr/local/bin/verify-runtime
/usr/local/libexec/ai-sandbox/sandbox-command-wrapper
```

### 15.10 Claude managed hook policy

The image writes the Admin-controlled Claude managed settings under:

```text
/etc/claude-code/managed-settings.json
```

This is separate from Developer-owned `~/.claude` state. The managed policy registers lifecycle/tool audit hooks while excluding prompt/response/tool payload content from the host audit stream.

### 15.11 Build information

v1.16.44 includes read-only, non-secret build provenance under:

```text
/etc/ai-sandbox/build-info.json
```

Developers can inspect effective runtime and build information through:

```bash
sandbox-info
```

### 15.12 Build targets

`DEVCONTAINER_TARGET` selects the Docker build target used by Admin build scripts. Production/POC release tooling controls the target; Developers do not choose it.

---

# Part G — Squid build and egress control

## 16. `squid/Dockerfile`

Squid is built internally from the same hardened base digest used by the DevContainer. It is not consumed as an arbitrary third-party Docker Hub proxy appliance.

The image installs the approved Ubuntu Squid package, copies the Drax-managed configuration and allowlist, and runs with restricted privileges.

## 17. `squid/squid.conf`

The Squid policy implements the controlled egress boundary. Important characteristics include:

- Default deny.
- Approved destination-domain ACLs.
- HTTPS CONNECT restriction.
- No general open-proxy host port exposure in the Compose definitions.
- Cache disabled for this security use case.
- Squid access/cache records go to Docker stdout/stderr first; a LOCALSYSTEM host exporter copies them into the protected Windows log tree. The Squid host-log folder is mounted read-only.
- Restricted manager access.

Squid does not perform TLS payload interception in the current design. It controls destination/connection metadata. If corporate policy requires TLS inspection or DLP, that function should normally be provided by the organization-approved secure web gateway or equivalent upstream control.

## 18. `squid/whitelist.txt`

This is the authoritative approved outbound destination list for the Squid image. Changes require security review and a new Squid image release.

Avoid overlapping Squid `dstdomain` entries. For example, `.example.com` already covers the apex/subdomains in the intended policy pattern, so a duplicate overlapping `example.com` entry should not also be added. Package lint checks this condition.

---

# Part H — TAR distribution and Developer start

## 19. `scripts/tar/build-and-export.*`

`scripts/tar/build-and-export.*` is the TAR release builder called by `build-sandbox.*` for either SandboxType. It builds and assesses the final DevContainer, builds Squid, exports both images as TAR files, and generates integrity metadata. Production TAR builds force the CIS pass gate.

It is an Admin workflow. Developers do not build images from source.

## 20. `scripts/tar/load-and-start.*`

The TAR Developer launcher performs package/hash validation, resolves the host `.aws` path, selects host authentication (`auto`, `static`, or `saml`), and then starts Compose. AUTO uses a static key pair already present in the selected host profile; otherwise it configures/refreshes the Azure/Entra-to-AWS SAML profile.

```text
Developer runs load-and-start
  -> ensure deployment-local .env exists
  -> reject raw AWS keys in .env and native AWS_SSO_* bootstrap fields
  -> inspect host [sandbox] shared-credentials profile
  -> if static key pair exists (or AWS_AUTH_MODE=static), use it without browser login
  -> otherwise validate Azure tenant/app/username/role values
  -> create/update host [profile sandbox] aws-azure-login configuration
  -> open `aws-azure-login --profile sandbox --mode gui`
  -> validate required AWS authorization with the subsequent SSM/ECR operation
  -> verify TAR/image integrity
  -> start squid-proxy + secret-broker + devcontainer
```

Only `secret-broker` receives `${SANDBOX_HOST_AWS_DIR}` as a read-only `/home/vscode/.aws` mount. The AI DevContainer has no AWS credential mount.

## 21. `scripts/tar/verify-sandbox.*`

The TAR verification workflow checks the running environment: container state, network topology, read-only behavior, security options, expected proxy behavior, Docker-owned log streams, and other runtime controls that cannot be proven by static package lint alone.

---

# Part I — ECR distribution

## 22. `scripts/platform/02-setup-ecr.*`

This is the ECR image build and publication workflow for either SandboxType. It is responsible for approved ECR repositories/policies, final image builds, security gates, pushes, immutable digest capture, and approved-image manifest generation/publication.

The approved manifest is non-secret. It tells Developer launchers exactly which image digests are approved.

## 23. `scripts/ecr/pull-and-start.*`

The ECR Developer launcher uses the same host authentication selector. A static host profile or the temporary SAML role session is used for approved-image manifest/ECR operations before containers exist. It then starts the same three-service runtime. AWS state is not copied into the AI DevContainer.

## 24. `scripts/ecr/deploy-ecr.*`

This is an optional host/runtime provisioning helper, not the image build/push path. The authoritative ECR image release path is `scripts/platform/02-setup-ecr.*`, normally reached through `scripts/admin/build-sandbox.*`.

---

# Part J — Runtime startup sequence

## 25. What Compose starts

Runtime services:

1. `squid-proxy` — only service with an external Docker network; enforces approved destination egress.
2. `secret-broker` — internal network only; receives read-only host `.aws`; owns SSM access and fixed secret-backed integrations.
3. `devcontainer` — internal network only; AI/developer workspace; no `.aws`, no AWS credential environment, no direct SSM authentication.

Both broker and DevContainer use a read-only root filesystem, drop all Linux capabilities and enable `no-new-privileges`. The broker is not a generic shell service: its control protocol maps fixed tool names to pinned Admin-approved executables and validators.

## 26. `.devcontainer/devcontainer.json`

VS Code uses this file to select the Compose service, workspace path, non-root remote user, post-create command, forwarded development ports, extensions, and editor settings.

Important values:

```text
service            devcontainer
workspaceFolder    /home/vscode/workspace
remoteUser         vscode
postCreateCommand  post-create
```

The Windows Developer package still contains a top-level `workspace/` directory. Compose bind-mounts that host folder to `/home/vscode/workspace` inside the DevContainer. The project therefore lives under the `vscode` user's home in the container without changing the package layout on the Windows host.

## 27. `.devcontainer/post-create.sh`

Post-create performs DevContainer-only initialization and verification. It does **not** configure or log into AWS. Expected credential checks include absence of AWS environment credentials, absence of `~/.aws/credentials`/SSO cache, fail-closed rejection of both retired command-runner interfaces, confirmation that local Git creates uid/gid 1000 workspace content, and failure of a direct SSM read.

### 27.1 Host Azure/Entra browser login

AWS login occurs before/around Compose startup on Windows, not inside the DevContainer:

```text
host .env Azure federation metadata
  -> launcher updates ~/.aws/config [profile sandbox]
  -> `aws-azure-login --profile sandbox --mode gui`
  -> subsequent SSM/ECR operation validates the required AWS authorization
  -> Azure/Entra browser + MFA
  -> temporary AWS role credentials in host ~/.aws
  -> read-only mount to secret-broker only
```

The values supplied by the federation administrator are tenant ID, Azure App ID URI, username, AWS role ARN, duration and remember-me flag. No AWS IAM Identity Center start URL/account-id/permission-set metadata is used by this flow.

### 27.2 `sandbox-info`

`sandbox-info` exposes non-secret runtime/build state and explicitly reports the credential boundary. It must never print host AWS credentials or SSM secret values.

# Part K — Runtime commands and SSM secrets

## 28. `sandbox-command-wrapper.sh`

The public wrapper is the DevContainer execution boundary. **Every real application process stays in the DevContainer as `vscode` uid/gid 1000.** The broker never executes the application.

```text
claude              -> local Claude -> localhost credential route -> broker -> Anthropic
gemini              -> local Gemini -> localhost credential route -> broker -> Gemini API
ucode claude        -> local Claude -> localhost Databricks route -> broker -> AI Gateway Anthropic
ucode gemini        -> local Gemini -> localhost Databricks route -> broker -> AI Gateway Gemini
databricks          -> local approved Databricks CLI -> localhost credential route -> broker
tvly                 -> local tvly + Admin policy -> localhost credential route -> broker
snyk                 -> local Snyk + local workspace -> localhost credential route -> broker
Git / ADO helpers    -> local Git/curl -> validated localhost ADO route -> broker
managed MCP          -> local MCP processes -> localhost credential routes -> broker
```

Before launching any application or MCP process, AWS credential/profile/config environment variables are removed. Vendor CLIs receive only fixed non-secret placeholders when their authentication libraries require a value. The broker discards caller authentication headers and injects the SSM-backed credential only in the outbound request to the fixed approved service origin.

The `ucode claude/gemini` command name remains the explicit Databricks route. Upstream ucode PAT injection is intentionally not used at runtime because that would place PAT-derived authentication in the agent process. Native Claude/Gemini arguments are preserved without wrapper-added `--model` flags; approved default models are provided by environment variables.

## 29. Retired command-runner compatibility guards

`run-with-ssm-secrets` and `secret-broker-client` are intentionally still present so stale scripts fail clearly rather than silently bypass the new boundary. Both return exit code 126 for every invocation and contain no supported SSM-fetch/application-execution path. `git-askpass-ado` is likewise retired and fail closed.

The credential broker's only subprocess is its internal AWS CLI `ssm get-parameter` call. It has no tool-control socket, no generic command API, no workspace mount, and no application child-process launcher. A new secret-backed integration must therefore use this pattern:

```text
local reviewed executable in DevContainer
  -> fixed local HTTP route
  -> credential-only broker validates route/policy
  -> broker reads exact approved SSM parameter
  -> broker injects authentication upstream
```

## 30. Current SSM parameter mapping

Default prefix: `/sandbox`.

| Integration | Parameter | Type | Secret location at runtime |
|---|---|---|---|
| Anthropic direct Claude | `/sandbox/claude-api-key` | SecureString | credential broker memory/upstream request only |
| Google direct Gemini | `/sandbox/gemini-api-key` | SecureString | credential broker memory/upstream request only |
| Databricks coding route / approved CLI | `/sandbox/databricks-token` | SecureString | credential broker memory/upstream request only |
| Databricks SQL MCP | `/sandbox/databricks-sql-mcp-token` | SecureString | credential broker memory/upstream request only |
| Tavily | `/sandbox/tavily-api-key` | SecureString | credential broker memory/upstream request only |
| Snyk | `/sandbox/snyk-token` | SecureString | credential broker memory/upstream request only |
| ADO PAT | `/sandbox/ado-pat` | SecureString | credential broker memory/upstream request only |
| HiddenLayer | `/sandbox/hiddenlayer-client-id` | SecureString | reserved for a future reviewed credential-only adapter |
| HiddenLayer | `/sandbox/hiddenlayer-client-secret` | SecureString | reserved for a future reviewed credential-only adapter |

ADO organisation/project/repository identifiers are intentionally absent from `.env`, `.build.env`, and SSM. Git access is constrained to validated HTTPS `dev.azure.com` transport; the PAT and Azure DevOps permissions determine repository/branch authorization. No secret value is returned to the DevContainer, stored in workspace files, or exported into application environments.

## 31. Direct Claude and Gemini execution flows

Bare Claude:

```text
claude wrapper (DevContainer uid 1000)
  -> real Claude process (DevContainer uid 1000)
  -> ANTHROPIC_BASE_URL=http://127.0.0.1:8771/anthropic
  -> non-secret placeholder auth
  -> provider-loopback-relay
  -> credential-only secret-broker
  -> SSM /sandbox/claude-api-key
  -> real key inserted only in upstream request
  -> api.anthropic.com
```

Bare Gemini follows the same pattern with `/gemini` and `/sandbox/gemini-api-key`. The real Claude/Gemini process is always local, so files generated or edited by the AI process are created under the same `vscode` identity as the Developer.

## 32. ucode / Databricks execution flow

```text
ucode claude
  -> sandbox-command-wrapper
  -> real Claude process locally + DATABRICKS_CLAUDE_MODEL
  -> http://127.0.0.1:8771/databricks/anthropic
  -> credential-only broker -> SSM /sandbox/databricks-token
  -> Authorization: Bearer <PAT> inserted only upstream
  -> <DATABRICKS_HOST>/ai-gateway/anthropic
```

```text
ucode gemini
  -> sandbox-command-wrapper
  -> real Gemini process locally + DATABRICKS_GEMINI_MODEL
  -> http://127.0.0.1:8771/databricks/gemini
  -> credential-only broker -> SSM /sandbox/databricks-token
  -> Authorization: Bearer <PAT> inserted only upstream
  -> <DATABRICKS_HOST>/ai-gateway/gemini
```

The agent sees only a placeholder value. No PAT-bearing `.databrickscfg`, ucode agent environment, or broker-side agent process exists. `ucode claude mcp ...` and `ucode gemini mcp ...` remain local management operations and expose the same Admin-managed MCP set as their direct counterparts.

## 33. Tavily CLI and MCP

Direct approved troubleshooting remains normal CLI syntax:

```bash
tvly search "query" --json
```

The real `tvly` process runs locally. A root-owned local policy constrains approved operations/domains, and the Tavily SDK is pinned to `http://127.0.0.1:8771/tavily-api`. The broker independently enforces the Tavily domain policy again before inserting `/sandbox/tavily-api-key` and forwarding to Tavily.

For AI-agent use, Tavily MCP is also local:

```text
Claude/Gemini
  -> /usr/local/bin/tavily-mcp-ssm
  -> local Tavily policy proxy + local mcp-remote
  -> http://127.0.0.1:8771/tavily-mcp
  -> broker applies policy + injects key
  -> Tavily MCP
```

The MCP registration contains no Tavily API key.

## 34. Snyk CLI and MCP

```bash
snyk code test
```

The real Snyk process executes **inside the DevContainer** and scans `/home/vscode/workspace` using the same uid/gid 1000 identity that owns Developer/AI-created source. Its temporary HOME/cache lives on the DevContainer-only `/run/ai-sandbox-snyk` tmpfs. Snyk receives a non-secret placeholder token and uses `http://127.0.0.1:8771/snyk`; the broker injects `/sandbox/snyk-token` only into the upstream Snyk HTTP request.

Snyk MCP follows the same model: the real Snyk MCP process is local, while only authentication is brokered. This removes the previous cross-container workspace visibility/ownership failure mode.

---

# Part L — Claude hooks and tamper-resistant runtime logging

## 35. `claude-audit-hook.sh`

Claude Code managed hooks are configured through `/etc/claude-code/managed-settings.json`. The hook receives lifecycle/tool event JSON on stdin and emits an allowlisted metadata subset through `/usr/local/bin/sandbox-log-emit` to PID1 stdout. The sink is hardcoded in the immutable image and is not selected from a Developer environment variable.

Relevant event classes include `SessionStart`, `UserPromptSubmit`, `PreToolUse`, `PostToolUse`, `PostToolUseFailure`, `Stop`, and `SessionEnd`. Metadata records intentionally avoid prompt text, assistant responses, tool payloads and transcript content. Prompt/response content is emitted only when `SANDBOX_CONTENT_LOGGING=true` has been explicitly approved.

## 36. `application-audit.sh`

This helper emits structured, sanitized lifecycle events for Databricks, Tavily, Snyk, ADO, HiddenLayer, Git and MCP integrations. Records go to the Docker-owned DevContainer stream and are tagged with the approved application name. No Developer-writable `<app>-events.log` file is created.

If `SANDBOX_AUDIT_REQUIRED=true`, secret-backed application execution fails closed when its required audit emission cannot be completed.

## 37. `sandbox-audit-logger.sh` and `sandbox-log-emit`

`sandbox-audit-logger.sh` captures higher-level shell/Git/security metadata without copying sensitive full command arguments. `sandbox-log-emit` serializes managed records and writes them to `/proc/1/fd/1`. Serialization is record-scoped: a long-lived producer such as Gemini telemetry releases the lock after every record instead of monopolizing it for the lifetime of the process. Interactive shell audit/security records wait at most 200 ms for the serialization lock, while required application audit retains the one-second fail-closed window. The hot Bash prompt path uses built-in history parsing, metadata attribution, timestamps and `$PWD`, and avoids the former `sed`, metadata command-substitution and `printf | emitter` pipeline overhead. The interactive Bash hook is installed only once per shell. This keeps normal commands responsive while preserving required application-audit fail-closed behavior. The PID1 sink is a non-seekable stream from inside the container, so the Developer cannot edit or truncate previously emitted records through the container filesystem. A LOCALSYSTEM Windows exporter subsequently appends the retained Docker records to the SYSTEM-owned host log tree; `/var/log/sandbox` is a read-only view of that protected host copy.

This is a tamper-resistant storage boundary, not a claim that every user-space event source is unbypassable. High-assurance Production monitoring must also rely on enforcement points outside the Developer process, including Squid, Docker/platform controls, identity-provider logs and central SIEM retention.

## 38. Docker log layout

Both services use Docker's `local` logging driver with rotation. The logical runtime streams are:

```text
devcontainer stdout/stderr
  AI_SANDBOX_LOG|audit|...
  AI_SANDBOX_LOG|security|...
  AI_SANDBOX_LOG|application|<app>|...
  AI_SANDBOX_LOG|claude-events|...
  AI_SANDBOX_LOG|content|...        # only when approved
  Gemini native telemetry/traces

squid-proxy stdout/stderr
  Squid access records
  Squid cache/runtime records
```

The Windows host retains protected files under `C:\ProgramData\AI-Sandbox\Logs`. `devcontainer` and `squid-proxy` mount their respective host folders read-only at `/var/log/sandbox` and `/var/log/squid`. Developers can view those files and `docker compose logs`, but the normal Developer identity has no Windows or Linux write/delete path to the protected files.

---

# Part M — Sentinel forwarding and administrator boundary

## 39. `scripts/platform/03-setup-logging.*`

These scripts create the protected Windows host log tree and monitoring state, enforce a SYSTEM-owner/read-only-Developer ACL, install the LOCALSYSTEM exporter, and configure the scheduled task `AI-Sandbox-Protected-Log-Export`. The monitoring state contains exporter checkpoints; runtime log content is written only under the protected log root.

For a non-admin functional POC, the default `SANDBOX_LOG_MODE=auto` resolves a validated POC manifest to `poc-local`; no elevated setup is required. The launcher creates a user-writable root (default `%USERPROFILE%\AI-Sandbox\Logs` when the common ProgramData template path is unchanged), validates an initial export, and starts a current-user exporter every 30 seconds. `03-setup-logging.ps1 -Mode PocLocal` remains available for explicit pre-creation. This fallback preserves read-only Linux mounts but provides no Windows host tamper resistance. Production manifests resolve `auto` to `protected` and fail closed until the SYSTEM-owned tree/task are provisioned.

## 40. `scripts/monitoring/verify-host-log-export.*`

The historical filename is retained for compatibility. The scripts verify Docker-owned log streams, transfer into the protected Windows host files, SYSTEM-only write ACLs, read-only `/var/log/sandbox` and `/var/log/squid` mounts, redaction behavior, and absence of the Docker socket from the DevContainer.

## 41. Sentinel/AMA collection boundary

The package intentionally uses one host-side collection path: Docker stdout/stderr -> LOCALSYSTEM exporter -> protected Windows files -> client-approved Windows monitoring agent/DCR -> Log Analytics/Sentinel. A second direct Logs Ingestion API sender is not shipped because it duplicates this path and introduces additional client-secret and endpoint configuration.

## 42. `sentinel/`

The Sentinel directory contains onboarding notes and KQL detection content. The client-specific Windows file-collection DCR/AMA configuration is deliberately not shipped as a generic Direct Logs Ingestion template.

---

# Part N — Azure DevOps helpers

## 43. ADO helper files

```text
ado-scripts/ado-auth-setup.*
ado-scripts/ado-pr-create.*
ado-scripts/ado-trigger.*
.devcontainer/scripts/git-askpass-ado.sh
```

### `ado-auth-setup.*`

Provides supported ADO authentication setup/check behavior according to the current package scope.

### `git-askpass-ado.sh`

Retired fail-closed compatibility guard. v1.16.44 does not place `ADO_PAT` in the Git process and does not use `GIT_ASKPASS`; validated Git HTTP traffic is rewritten to the credential-only broker route instead.

### `ado-pr-create.*`

Optional helper for creating Azure DevOps pull requests. Only the PAT is broker-managed; `--org`, `--project`, and `--repo` are explicit target arguments and are not SSM parameters.

### `ado-trigger.*`

Optional helper for Azure DevOps pipeline trigger operations. Only the PAT is broker-managed; `--org` and `--project` are explicit target arguments and are not SSM parameters.

### ADO authentication scope

The SSM-backed ADO runtime path in v1.16.44 is PAT-only. `/sandbox/ado-pat` is the only ADO parameter required by the Sandbox. Organisation, project, repository, branch and force-push authorization are delegated to Azure DevOps permissions/policies; the Sandbox no longer stores or compares `ado-org`, `ado-project`, or `ado-repo`.

---

# Part O — What Developers can and cannot change

## 44. Runtime immutable areas

The following are intended to remain Admin/image-controlled because the root filesystem is read-only and the Developer is non-root:

```text
/etc/claude-code/managed-settings.json
/etc/ai-sandbox/*
/usr/local/bin/run-with-ssm-secrets
/usr/local/bin/claude-audit-hook
/usr/local/bin/configure-mcp
host launcher Azure/Entra profile initialization
host aws-azure-login browser flow
/usr/local/libexec/ai-sandbox/sandbox-command-wrapper
/usr/local/libexec/ai-sandbox/real/*
```

Developers should not be able to replace the approved wrapper, alter the managed Claude hook policy, modify installed global vendor binaries, or change the Squid image configuration from inside the running DevContainer.

## 45. Writable areas

Approved writable state is provided through workspace bind mounts, persistent Docker volumes, and tmpfs. Examples include:

```text
/home/vscode/workspace
/home/vscode/.claude
/home/vscode/.gemini
/home/vscode/.azure
/home/vscode/.config/git
/home/vscode/.config/gh
/home/vscode/.cache
/home/vscode/.local
/home/vscode/.npm
/home/vscode/.vscode-server
/tmp
/var/tmp
/run
```

User-level application configuration may therefore be changed where the product normally stores it. That does not grant permission to modify the Admin-controlled system/security configuration.

### AWS authentication state note

The Windows host launcher selects the configured host AWS profile. In static mode the Developer preconfigures the key pair with `aws configure`; in SAML mode the launcher creates the non-secret Azure/Entra profile metadata and `aws-azure-login` writes temporary role credentials. Only `secret-broker` receives the host `.aws` directory as a read-only bind mount. `/home/vscode/.aws` is intentionally absent from the AI DevContainer, and the AI process environment contains no AWS profile/config path or AWS access-key variables. Claude, Gemini and ucode therefore cannot authenticate directly to SSM; only the trusted broker can retrieve approved SSM parameters and inject them into pinned broker-side integrations. Static host-profile key mode is supported for testing; raw key environment/.env injection and native IAM Identity Center bootstrap mode remain unsupported in v1.16.44.

---

# Part P — Developer package export boundary

## 46. `scripts/admin/export-developer-packages.*`

The export scripts enforce separation between the Admin source package and the minimal Developer runtime package.

### TAR Developer package

Contains only the files required to load/start the approved TAR images, runtime policy/integrity metadata, Developer-facing configuration/documentation, workspace content, and the built TAR images when `-IncludeTarImages` is used.

The TAR Developer package does not contain Admin build/hardening/supply-chain source that the Developer does not need.

### ECR Developer package

Contains the ECR Compose/runtime launcher, minimal configuration, Developer guide, runtime policy, workspace, and other files required to resolve the centrally approved ECR digests and start the environment.

It does not contain Admin build source, image-build secrets, Ubuntu Pro material, or the full security engineering package.

---

# Part Q — Static QA and package lint

## 47. `scripts/ci/lint-package.*`

Package lint is the static regression gate. It validates, among other things:

- Bash syntax.
- PowerShell/script contract where supported by the running environment.
- JSON/YAML parsing.
- Required files.
- Three-service DevContainer + secret-broker + Squid contract.
- Absence of obsolete monitoring-sidecar patterns.
- Absence of writable DevContainer/Squid log bind mounts and presence of Docker-owned log streams.
- Gemini prompt logging disabled.
- Claude managed audit hook wiring.
- Application audit helper presence.
- Credential-only broker plus local application/MCP wrapper installation.
- Tavily MCP secret-free registration.
- Databricks/Tavily/Snyk routing invariants.
- Required application audit defaults.
- Redaction regression rules.
- Unsafe Docker runtime patterns.
- Obvious committed-secret patterns.
- Bash/PowerShell workflow-pair coverage.
- Squid allowlist overlap.

Static lint does not replace real Docker build, runtime, SSO, SSM, network, SaaS, ECR, or Sentinel acceptance testing.

---

# Part R — Change impact and application maintenance

## 48. Adding a new application

Use `docs/ADMIN-APPLICATION-ADD-REMOVE.md` as the authoritative runbook.

v1.16.44 provides Admin-only helpers:

```text
scripts/applications/add-application.ps1/.sh
scripts/applications/remove-application.ps1/.sh
scripts/applications/validate-application.ps1/.sh
scripts/applications/application-helper.py
```

The helper does **not** introduce a runtime application catalog. It writes explicit reviewed blocks into the same Dockerfile/wrapper/SSM/audit/Squid/verification source files used by the v1.16.3 architecture.

Operational pattern:

```text
collect vendor/security inputs
  -> run add helper in Preview mode
  -> review proposed source edits
  -> Apply
  -> validate application integration
  -> run full package lint
  -> build POC
  -> perform runtime/security acceptance
  -> release new immutable Production image digest
```

Typical integration points for a secret-backed CLI are:

```text
.build.env.example                 optional build version/source/hash
scripts/common/Load-BuildEnv.*    required build-value validation
scripts/tar/build-and-export.*     TAR Docker build args for either SandboxType
scripts/platform/02-setup-ecr.*   ECR Docker build/push args for either SandboxType
.devcontainer/Dockerfile          install/stash/writable paths/wrappers
sandbox-command-wrapper.sh        public local command route
secret-broker-server.py           fixed credential-injection HTTP adapter when secret-backed
scripts/platform/01-setup-ssm.*   Admin SSM parameter provisioning
application-audit.sh              application audit allowlisting
configure-mcp.sh                  credential-free MCP registration when applicable
<app>-mcp-ssm.sh                  local MCP launcher when applicable
squid/whitelist.txt               external destinations when required
verify-runtime.sh                 runtime invariant checks
scripts/ci/lint-package.*         static regression checks
```

Installation methods differ by vendor. Do not force every application into one generic installer when the vendor supply-chain method is materially different. Exact npm versions, exact uv/Python versions, reviewed apt packages, SHA-256 verified archives, and reviewed custom vendor installation steps are all valid patterns when approved.

## 49. Removing an application

Removal must reverse every integration point and must not delete a credential too early.

Preferred sequence:

```text
review dependencies/shared domains/shared parameters
  -> Preview helper removal when helper-managed
  -> remove image/wrapper/SSM/audit/MCP/Squid/verification integration
  -> lint
  -> build/test new image
  -> publish new approved digest
  -> retire old image instances
  -> revoke vendor credential/delete SSM parameter only after retirement
```

Built-in applications or exceptional manually integrated applications should follow the manual removal section of the application runbook.

## 50. Base/tool version update

A version update is a release change even when no new feature is added. Re-run supply-chain resolution, update exact hashes/commits, rebuild the image, rerun final security assessment, regenerate release evidence, and publish a new immutable digest.

## 51. Squid allowlist change

A Squid allowlist change requires a new Squid image because the allowlist is baked into the Squid image. Review whether the destination is least-privilege, whether it overlaps an existing suffix rule, and whether an upstream corporate web-control layer is also required.

---

# Part S — Known constraints and technical debt

## 52. ADO authentication scope

The package now documents the SSM-backed ADO path as PAT-only. This is intentionally simpler and clearer than retaining unused Service Principal variables that were not connected end to end.

## 53. Installer pinning differences

Not every package ecosystem provides the same level of immutable pinning. Direct downloads should use SHA-256. npm packages use exact versions. ucode uses an immutable Git commit. Ubuntu apt packages and some vendor installers require organization-specific repository snapshotting/version-control policy if exact package reproducibility is a strict requirement.

## 54. Local scratch registry references

The hardened-base workflow may use a local registry to obtain an immutable digest reference during the Admin build. The scratch registry is only a build-time digest mechanism; final distribution is controlled independently by DeploymentType (`Tar` or `Ecr`).

## 55. Build cache

Some security-sensitive release builds intentionally use `--no-cache`. This improves reproducibility/audit clarity at the cost of build time. If build caching is later introduced, cache provenance and invalidation behavior should be reviewed as part of the supply-chain policy.

---

# Part T — Troubleshooting order

## 56. Build fails early

Check in this order:

1. `.build.env` exists.
2. Required placeholder values have been replaced or resolvers can replace them.
3. Docker Desktop is running and the Admin can build/pull images.
4. Base digest resolver succeeds.
5. Tool artifact resolver succeeds.
6. `scripts/ci/lint-package.*` passes.
7. Required organization proxy/registry access is available.

## 57. Hardened-base build fails

Check:

1. Selected SandboxType.
2. Ubuntu Pro token only for non-POC builds.
3. SSG URL/version/hash consistency.
4. Docker BuildKit support.
5. Scratch/local registry availability when used.
6. OpenSCAP/USG report output for the actual failed rule.
7. Approved CIS tailoring status.

## 58. Final OpenSCAP assessment fails

Do not assume the hardened base is wrong. The final assessment happens after application/tool layers are added. Review the final report for changes introduced by package installation, file permissions, users/groups, service state, SUID/SGID files, or runtime preparation.

## 59. `claude`, `gemini`, `snyk`, `databricks`, or `tvly` fails at runtime

Check:

```text
Windows host:
  aws-azure-login --profile <configured profile> --mode gui
  aws --profile <configured profile> ssm get-parameter --name /sandbox/tavily-api-key --with-decryption --query 'Parameter.Name' --output text   # name-only authorization check; does not print the secret value

AI DevContainer:
  sandbox-info
  verify-runtime
  # direct aws ssm get-parameter must FAIL because the AI has no AWS credentials

Also check:
  SSM parameter existence and broker-role GetParameter/KMS permission
  Docker-owned DevContainer/broker audit stream availability
  Docker-owned Squid access stream
  application-tagged metadata records
  public command -> wrapper mapping
  real executable presence
```

Do not debug by copying AWS credentials, application/service secrets, PATs, or API keys into `.env` or an AI-process shell. Runtime `.env` is non-secret; only the Windows host `.aws` directory may contain the temporary AWS role session, and it is mounted read-only into `secret-broker` only.

## 60. Databricks route fails

Check:

```text
DATABRICKS_HOST
DATABRICKS_CLAUDE_MODEL
DATABRICKS_GEMINI_MODEL
/sandbox/databricks-token
/sandbox/databricks-sql-mcp-token (for managed SQL MCP)
AWS profile/region/SSM prefix
ucode installation/status
Databricks hostname in Squid allowlist
Docker-owned Squid access stream
Databricks-tagged application audit stream
```

The Workspace/provider values are non-secret runtime values. The Databricks token remains SSM-managed. Bare `claude` and `gemini` are separate direct-provider routes and should be debugged against `/sandbox/claude-api-key` or `/sandbox/gemini-api-key` plus their official provider egress.

---

# Part U — Authoritative document and source inventory

## 61. Documentation and active templates

The package deliberately separates optional human documentation from active generation inputs.

| File | Classification | Purpose |
|---|---|---|
| `README.md` | Package entry point | Short architecture and package-boundary summary. |
| `docs/ADMIN-COMPLETE-GUIDE.md` | Optional documentation | This complete architecture/build/runtime/maintenance guide. |
| `docs/ADMIN-APPLICATION-ADD-REMOVE.md` | Optional documentation | Detailed application add/remove runbook. |
| `docs/SECURITY-LOGGING-AND-SENTINEL.md` | Optional documentation | Security boundary, Docker-owned runtime audit/content streams, Sentinel forwarding. |
| `.env.example` | Active runtime template | Single canonical source for exported Developer `.env.example`. |
| `templates/developer/devcontainer-ecr.json` | Active template | Source for the exported ECR Developer DevContainer definition. |

Release-history, QA-evidence, language-audit, and package-cleanup reports are intentionally not part of the active Admin build package.

## 62. DevContainer runtime source

The authoritative runtime source is under `.devcontainer/`. The Dockerfile installs the approved stack and bakes the scripts into read-only system locations. `devcontainer.json` defines VS Code behavior. `post-create.sh` performs repeatable initialization. `.devcontainer/scripts/` contains the SSM, audit, MCP, SSO, command-wrapper, and runtime-verification controls.

## 63. Admin build orchestration

`scripts/admin/` contains the top-level build and Developer-package export entry points. `scripts/supply-chain/` resolves external immutable inputs. `scripts/hardening/` creates the base. `scripts/security/` assesses the final image. `scripts/tar/` builds/exports/starts TAR deployments; `scripts/platform/` handles SSM/ECR/logging platform setup. `scripts/ecr/` contains ECR Developer pull/start and supporting host provisioning.

## 64. Application Admin helpers

`scripts/applications/` contains only Admin-side source editing/validation helpers. These helpers are not a runtime plugin framework and should not be shipped as a way for Developers to install arbitrary approved/unapproved applications at runtime.

## 65. Runtime/platform/security assets

`squid/` defines the controlled egress image and owns its authoritative `whitelist.txt` destination ACL. `security/` defines CIS/OpenSCAP content and scanner build assets. `policies/` contains shared cross-component Admin policies and managed client settings, including the shared ADO/Tavily runtime policies, Claude/Gemini managed MCP/settings policies, Gemini web policy, and Docker Desktop/Admin host-policy example. Shared runtime security policies are baked read-only under `/etc/ai-sandbox/policies/`. `sentinel/` contains SIEM onboarding/detection reference assets. `workspace/` is the Developer work area template.

---

# Part V — Operational summary

## 70. Eight steps an Admin should remember

1. Review `.build.env` and organization-specific non-secret values.
2. Run package lint.
3. Resolve upstream image digests and tool hashes/commits.
4. Build the hardened base, or explicitly use `-ReuseHardenedBase` and confirm the reuse validation passes.
5. Build the final DevContainer and Squid from the same hardened base digest.
6. Run final-image security assessment and preserve evidence.
7. Distribute the selected hardening image through TAR or ECR according to DeploymentType.
8. Provision the protected host log root/SYSTEM exporter on each target Windows 365 host, export only the minimal Developer package, and complete target-environment acceptance.

## 71. Five steps a Developer should remember

1. Use the provided Developer package; do not build the Admin image source.
2. Set required non-secret Developer values such as `DEVELOPER_ID` when instructed.
3. Start the Sandbox with the provided TAR or ECR launcher.
4. Use the Azure/Entra browser federation flow on the Windows host when the temporary AWS role session is absent or expired.
5. Use approved commands normally: `claude`, `gemini`, `ucode claude`, `ucode gemini`, `snyk`, `databricks`, and approved MCP tools.

## 72. Five control planes a security reviewer should remember

1. **Host control plane:** Windows 365, endpoint controls, Docker Desktop Business/ECI/settings enforcement.
2. **Image control plane:** hardened base, immutable build inputs, final OpenSCAP assessment, ECR/TAR integrity evidence.
3. **Runtime privilege control plane:** non-root, read-only rootfs, capability drop, no-new-privileges, no Docker socket.
4. **Identity/secret control plane:** host-only Azure/Entra SAML role session feeds the trusted broker; the AI container has no AWS/SSM credential path.
5. **Network/audit control plane:** internal-only DevContainer network, Squid default-deny egress, Docker-owned redacted audit streams, LOCALSYSTEM-protected Windows log files, and Sentinel forwarding.

---

# Appendix A — Complete file inventory, execution point, and role

The table below describes every source file currently present in the cleaned Admin package. Generated build outputs such as `.build.env`, hardened-base artifacts, security reports, TAR bundles, and approved ECR image manifests are listed separately after the source inventory.

| File | Category | Execution/use point | Role |

|---|---|---|---|

| `.build.env.example` | Admin build configuration | Before every release build | Template for pinned versions, hashes, image references, security gates, and optional non-secret Developer Azure/Entra federation defaults. |

| `.devcontainer/Dockerfile` | DevContainer image | Admin image build | Builds approved Developer runtime from hardened base, installs tools, stashes real executables, and bakes security controls. |

| `.devcontainer/cis-level1-harden.sh` | DevContainer hardening | Image build | Applies reviewed image-level hardening before final assessment. |

| `.devcontainer/devcontainer.json` | VS Code Dev Container | VS Code open/reopen | Selects Compose service, workspace, remote user, extensions, ports, and post-create command. |

| `.devcontainer/post-create.sh` | DevContainer initialization | After container creation | Prepares Git/MCP definitions, validates credential isolation, runtime controls, broker reachability, and egress probes. |

| `.devcontainer/scripts/application-audit.sh` | DevContainer runtime control | Image build and/or runtime | Writes structured redacted application lifecycle audit events. |

| `.devcontainer/scripts/claude-audit-hook.sh` | DevContainer runtime control | Image build and/or runtime | Processes Claude Code managed-hook events and records allowlisted metadata only. |

| `.devcontainer/scripts/configure-mcp.sh` | DevContainer runtime control | Image build and/or runtime | Registers secret-free Tavily/Snyk MCP commands for Claude/Gemini. |

| `.devcontainer/scripts/secret-broker-client.py` | Retired compatibility guard | Any runtime | Fail-closed legacy interface; always returns 126 so stale configurations cannot restore broker-side application execution. |

| `.devcontainer/scripts/secret-broker-server.py` | Credential-only secret broker | Broker container runtime | Sole runtime service with host AWS profile access; reads approved SSM parameters and injects authentication at fixed HTTP routes. It has no workspace mount or application child-process path. |

| `.devcontainer/scripts/provider-loopback-relay.py` | AI provider relay | AI DevContainer runtime | Localhost-only relay used by Claude/Gemini-compatible provider base URLs to reach the broker without placing provider or Databricks credentials in AI environment/config. |

| `.devcontainer/scripts/git-transparent.sh` | Transparent Git front-end | AI DevContainer runtime | Installed as `/usr/local/bin/git`; every Git command executes local `/usr/bin/git`. Validated ADO HTTP transport is rewritten to the localhost credential route without exposing the PAT. |

| `.devcontainer/scripts/ado-git.sh` | Legacy ADO Git bridge | AI DevContainer runtime | Backward-compatible explicit bridge; normal developer usage should use standard `git` commands. |

| `.devcontainer/scripts/ado-git-policy.sh` | Root-owned local ADO Git policy | AI DevContainer runtime | Validates credentialed ADO operations and structurally valid `dev.azure.com` HTTPS targets, blocks credential/config/custom-transport redirection, then executes local Git with an execution-time localhost URL rewrite. |

| `.devcontainer/scripts/databricks-sql-mcp-ssm.sh` | Local Databricks SQL MCP launcher | AI DevContainer runtime | Runs pinned `mcp-remote` locally against the localhost credential route; no Databricks token enters the MCP process. |

| `.devcontainer/scripts/git-askpass-ado.sh` | Retired compatibility guard | Any runtime | Always fails closed. v1.16.44 Git does not use askpass because the local Git process never receives the PAT. |

| `.devcontainer/scripts/run-with-ssm-secrets.sh` | Retired compatibility guard | Any runtime | Always returns 126; it no longer retrieves SSM values or starts application processes. |

| `.devcontainer/scripts/sandbox-audit-logger.sh` | DevContainer runtime control | Image build and/or runtime | General Sandbox/Git lifecycle metadata logger. |

| `.devcontainer/scripts/sandbox-command-wrapper.sh` | AI DevContainer runtime control | Runtime | Runs approved real Claude/Gemini/ucode/Databricks/Tavily/Snyk processes locally and points their HTTP authentication at fixed credential-broker routes; it never retrieves SSM secrets. |

| `.devcontainer/scripts/sandbox-info.sh` | DevContainer runtime control | Image build and/or runtime | Displays non-secret runtime/build diagnostics to Developers. |

| `.devcontainer/scripts/snyk-mcp-ssm.sh` | Local Snyk MCP launcher | AI DevContainer runtime | Runs the real Snyk MCP process locally on DevContainer tmpfs/workspace; authentication alone is inserted by the credential broker upstream. |

| `.devcontainer/scripts/tavily-mcp-ssm.sh` | Local Tavily MCP launcher | AI DevContainer runtime | Runs the Tavily policy relay and `mcp-remote` locally; the credential broker enforces domain policy again and injects only the upstream key. |

| `.devcontainer/scripts/verify-runtime.sh` | DevContainer runtime control | Image build and/or runtime | Checks runtime security invariants, wrapper wiring, files, mounts, and expected configuration. |

| `.dockerignore` | Docker build hygiene | Docker build context creation | Excludes non-build files/secrets/artifacts from repository-root Docker build context. |

| `.env.example` | Runtime configuration | Developer package startup | Non-secret template for AWS auth mode/profile/region, optional Azure/Entra federation metadata, broker routing, model/endpoint settings, audit identity, and optional service endpoints. Raw AWS keys and native IAM Identity Center bootstrap fields are not supported in `.env`. |


| `README.md` | Documentation | Package entry | Short architecture summary, supported entry points, and authoritative document index. |

| `ado-scripts/ado-auth-setup.ps1` | Azure DevOps helper | Admin/Developer approved ADO operation | ADO authentication/check, PR creation, or pipeline trigger helper with current supported auth scope. |

| `ado-scripts/ado-auth-setup.sh` | Azure DevOps helper | Admin/Developer approved ADO operation | ADO authentication/check, PR creation, or pipeline trigger helper with current supported auth scope. |

| `ado-scripts/ado-pr-create.ps1` | Azure DevOps helper | Admin/Developer approved ADO operation | ADO authentication/check, PR creation, or pipeline trigger helper with current supported auth scope. |

| `ado-scripts/ado-pr-create.sh` | Azure DevOps helper | Admin/Developer approved ADO operation | ADO authentication/check, PR creation, or pipeline trigger helper with current supported auth scope. |

| `ado-scripts/ado-trigger.ps1` | Azure DevOps helper | Admin/Developer approved ADO operation | ADO authentication/check, PR creation, or pipeline trigger helper with current supported auth scope. |

| `ado-scripts/ado-trigger.sh` | Azure DevOps helper | Admin/Developer approved ADO operation | ADO authentication/check, PR creation, or pipeline trigger helper with current supported auth scope. |

| `docs/ADMIN-APPLICATION-ADD-REMOVE.md` | Documentation | Review/operations/acceptance | Detailed Admin application add/remove helper and manual fallback runbook. |

| `templates/developer/devcontainer-ecr.json` | Developer package template | Developer package export/direct deployment | ECR Developer DevContainer definition used as an active generation input. |

| `.env.example` | Developer runtime template | Developer package export/direct deployment | Single canonical non-secret runtime environment template used for both TAR and ECR exports. |




| `docs/SECURITY-LOGGING-AND-SENTINEL.md` | Documentation | Review/operations/acceptance | Security boundaries, audit/content stream policy, and Sentinel forwarding. |


| `ecr/docker-compose.yml` | ECR Compose/runtime | ECR Developer startup | Three-service Compose definition (AI DevContainer, trusted secret broker, Squid) using locally tagged approved immutable images resolved from the approved ECR manifest. |


| `policies/README.md` | Admin policy index | Admin build/review | Documents the single source-of-truth policy directory and runtime installation model. |
| `policies/ado-policy.json` | Shared ADO credential-use policy | DevContainer + credential broker | One policy drives local Git host/operation/repository validation and broker-side Git/PR/Pipeline PAT authorization. |
| `policies/tavily-allowed-domains.json` | Shared Tavily search policy | DevContainer + credential broker | One Admin domain allowlist is used by local Tavily validation and broker-side final enforcement. |
| `policies/claude-mcp.json` | Claude managed MCP policy | DevContainer image build | Defines the approved Admin-managed MCP set for Claude. |
| `policies/gemini-managed-settings.json` | Gemini managed settings/MCP policy | DevContainer image build | Defines the approved Admin-managed MCP set and update behavior for Gemini. |
| `policies/gemini-web-policy.toml` | Gemini web/shell policy | DevContainer image build | Disables native Gemini web paths that could bypass approved Tavily policy. |
| `policies/admin-settings.json` | Host/Docker policy | Endpoint provisioning | Example centrally managed Docker Desktop/Admin security settings. |

| `scripts/admin/build-sandbox.ps1` | Admin orchestration | Admin release workflow | Top-level Sandbox build orchestration, including validated `-ReuseHardenedBase` optimization and automatic full-build fallback. |

| `scripts/admin/build-sandbox.sh` | Admin orchestration | Admin release workflow | Top-level Sandbox build orchestration, including validated `-ReuseHardenedBase` optimization and automatic full-build fallback. |

| `scripts/admin/export-developer-packages.ps1` | Admin orchestration | Admin release workflow | Top-level Sandbox build orchestration, including validated `-ReuseHardenedBase` optimization and automatic full-build fallback. |

| `scripts/admin/export-developer-packages.sh` | Admin orchestration | Admin release workflow | Top-level Sandbox build orchestration, including validated `-ReuseHardenedBase` optimization and automatic full-build fallback. |

| `scripts/applications/add-application.ps1` | Application maintenance | Admin add/remove/validate workflow | Admin-only helper for explicit source integration changes; not a runtime application catalog. |

| `scripts/applications/add-application.sh` | Application maintenance | Admin add/remove/validate workflow | Admin-only helper for explicit source integration changes; not a runtime application catalog. |

| `scripts/applications/application-helper.py` | Application maintenance | Admin add/remove/validate workflow | Admin-only helper for explicit source integration changes; not a runtime application catalog. |

| `scripts/applications/records/README.md` | Application maintenance | Admin add/remove/validate workflow | Admin-only helper for explicit source integration changes; not a runtime application catalog. |

| `scripts/applications/remove-application.ps1` | Application maintenance | Admin add/remove/validate workflow | Admin-only helper for explicit source integration changes; not a runtime application catalog. |

| `scripts/applications/remove-application.sh` | Application maintenance | Admin add/remove/validate workflow | Admin-only helper for explicit source integration changes; not a runtime application catalog. |

| `scripts/applications/validate-application.ps1` | Application maintenance | Admin add/remove/validate workflow | Admin-only helper for explicit source integration changes; not a runtime application catalog. |

| `scripts/applications/validate-application.sh` | Application maintenance | Admin add/remove/validate workflow | Admin-only helper for explicit source integration changes; not a runtime application catalog. |

| `scripts/ci/lint-package.ps1` | Static QA | Before/after package changes and release build | Static syntax, structure, security, redaction, wrapper, package-boundary, and Squid regression checks. |

| `scripts/ci/lint-package.sh` | Static QA | Before/after package changes and release build | Static syntax, structure, security, redaction, wrapper, package-boundary, and Squid regression checks. |

| `scripts/common/Load-BuildEnv.ps1` | Build configuration | Called by Admin build scripts | Safe parser/validator for .build.env shared by platform build workflows. |

| `scripts/common/load-build-env.sh` | Build configuration | Called by Admin build scripts | Safe parser/validator for .build.env shared by platform build workflows. |

| `scripts/ecr/deploy-ecr.ps1` | ECR host provisioning | Optional Admin/host setup | Supporting ECR runtime provisioning helper; not the image build/push entry point. |

| `scripts/ecr/deploy-ecr.sh` | ECR host provisioning | Optional Admin/host setup | Supporting ECR runtime provisioning helper; not the image build/push entry point. |

| `scripts/ecr/pull-and-start.ps1` | ECR Developer runtime | Developer startup | Performs static-key-or-SSO authentication, SSM/ECR approved-digest resolution, and starts ECR Compose. |

| `scripts/ecr/pull-and-start.sh` | ECR Developer runtime | Developer startup | Performs static-key-or-SSO authentication, SSM/ECR approved-digest resolution, and starts ECR Compose. |

| `scripts/hardening/build-hardened-base.ps1` | Base hardening | Admin POC/Production build | Creates hardened base image/evidence using POC OpenSCAP or Production Ubuntu Pro/USG path. |

| `scripts/hardening/build-hardened-base.sh` | Base hardening | Admin POC/Production build | Creates hardened base image/evidence using POC OpenSCAP or Production Ubuntu Pro/USG path. |



| `scripts/monitoring/verify-host-log-export.ps1` | Host logging QA | Acceptance testing | Verifies Docker streams, SYSTEM-only host write ACLs, protected file export, redaction, and read-only container mounts. |

| `scripts/monitoring/verify-host-log-export.sh` | Host logging QA | Acceptance testing | Verifies Docker streams, protected host files, and read-only container mounts on Linux hosts. |

| `scripts/platform/01-setup-ssm.ps1` | SSM provisioning | Admin environment setup | Creates/updates expected application SSM parameter names and prompts Admin for real values. |

| `scripts/platform/01-setup-ssm.sh` | SSM provisioning | Admin environment setup | Creates/updates expected application SSM parameter names and prompts Admin for real values. |

| `scripts/platform/02-setup-ecr.ps1` | ECR image release | Admin ECR build | Builds/assesses/pushes DevContainer and Squid for the selected SandboxType, captures ECR digests, and publishes the approved manifest. |

| `scripts/platform/02-setup-ecr.sh` | ECR image release | Admin ECR build | Builds/assesses/pushes DevContainer and Squid for the selected SandboxType, captures ECR digests, and publishes the approved manifest. |

| `scripts/platform/03-setup-logging.ps1` | Host logging setup | Security/endpoint provisioning | Creates the SYSTEM-owned protected Windows log tree, read-only Developer ACLs, and the LOCALSYSTEM scheduled exporter. |

| `scripts/platform/03-setup-logging.sh` | Host logging setup | Security/endpoint provisioning | Creates a root-owned protected host log tree and documents root exporter scheduling for Linux hosts. |

| `scripts/tar/build-and-export.ps1` | TAR image release | Admin POC/Production build | Builds final images, applies the SandboxType-specific CIS gate, exports TARs, and generates integrity metadata. |

| `scripts/tar/build-and-export.sh` | TAR image release | Admin POC/Production build | Builds final images, applies the SandboxType-specific CIS gate, exports TARs, and generates integrity metadata. |





| `scripts/security/assess-cis-l1.ps1` | Final image security gate | POC/Production image release | Runs final DevContainer OpenSCAP/CIS assessment using a dedicated scanner image. |

| `scripts/security/assess-cis-l1.sh` | Final image security gate | POC/Production image release | Runs final DevContainer OpenSCAP/CIS assessment using a dedicated scanner image. |

| `scripts/supply-chain/resolve-base-digests.ps1` | Supply-chain resolution | Early Admin build | Resolves immutable upstream image digests or downloadable tool hashes/commits and updates .build.env. |

| `scripts/supply-chain/resolve-base-digests.sh` | Supply-chain resolution | Early Admin build | Resolves immutable upstream image digests or downloadable tool hashes/commits and updates .build.env. |

| `scripts/supply-chain/resolve-tool-artifacts.ps1` | Supply-chain resolution | Early Admin build | Resolves immutable upstream image digests or downloadable tool hashes/commits and updates .build.env. |

| `scripts/supply-chain/resolve-tool-artifacts.sh` | Supply-chain resolution | Early Admin build | Resolves immutable upstream image digests or downloadable tool hashes/commits and updates .build.env. |

| `security/CIS-TAILORING-README.md` | Security guidance | CIS review/acceptance | CIS tailoring and security assessment guidance. |

| `security/cis-scanner/Dockerfile` | Security scanner image | Final image assessment | Dedicated OpenSCAP/ComplianceAsCode scanner image; not part of Developer runtime. |

| `sentinel/README.md` | Sentinel asset | SIEM onboarding/detection engineering | Reference Sentinel/KQL content for Sandbox Docker runtime logs. |


| `sentinel/detection-rules.kql` | Sentinel asset | SIEM onboarding/detection engineering | Reference Sentinel/KQL content for Sandbox Docker runtime logs. |

| `squid/Dockerfile` | Squid image | POC/Production build | Builds internally controlled Squid proxy image from the approved hardened base. |

| `squid/squid.conf` | Egress policy | Squid runtime | Default-deny proxy ACL, CONNECT, cache, manager, and logging policy. |

| `squid/whitelist.txt` | Egress allowlist | Squid build/runtime | Approved outbound destination domains; changes require Squid rebuild/release. |

| `workspace/README.md` | Developer workspace | Developer runtime | Documents the writable project workspace boundary. |



## Appendix A.1 Generated files not present in the source ZIP

| Generated artifact | Created by | Meaning |
|---|---|---|
| `.build.env` | Admin / `build-sandbox.*` first run | Actual release build inputs after review/resolution. Normally excluded from source distribution. |
| `hardened-base-build/hardened-base.env` | `build-hardened-base.*` | Passes immutable hardened base references back to the parent build. |
| `security/reports/*` | OpenSCAP/USG workflows | Security assessment evidence. |
| `tar/images/sandbox-devcontainer.tar` | `build-and-export.*` | Approved TAR-delivered DevContainer image bundle for the selected SandboxType. |
| `tar/images/sandbox-squid.tar` | `build-and-export.*` | Approved TAR-delivered Squid image bundle for the selected SandboxType. |
| `tar/images/image-manifest.*` | `build-and-export.*` | Approved image IDs and release metadata. |
| `tar/images/runtime-policy.sha256` | `build-and-export.*` | Hashes of runtime policy files delivered with the TAR release. |
| `tar/images/SHA256SUMS` | `build-and-export.*` | Integrity list for the TAR image/evidence bundle. |
| `approved-images.json` or equivalent manifest output | ECR workflow | Immutable approved ECR DevContainer/Squid digests for Developer runtime resolution. |
| Host `~/.aws/config` managed profile | Windows TAR/ECR launcher | Non-secret AWS profile/SAML federation metadata when SAML mode is used; the host `.aws` directory is mounted read-only into broker only. |
| Host `~/.aws/credentials` | Developer host (`aws configure`) or `aws-azure-login` | Static POC key pair or temporary SAML/STS credentials for the selected profile; mounted read-only into the trusted broker only and never mounted into the AI DevContainer. |
| `~/.claude/*`, `~/.gemini/*` | Vendor tools/runtime configuration | Developer-owned persistent user-level state where the tools create it. |
| Docker `devcontainer` and `squid-proxy` stdout/stderr streams | Runtime containers | Tamper-resistant local runtime records for central forwarding/retention. |

---

# Appendix B — Application add/remove quick reference

For complete procedures use `docs/ADMIN-APPLICATION-ADD-REMOVE.md`.

### Add

```text
1. Collect approval, owner, exact version/source/hash, commands, secrets, domains, MCP needs.
2. Run add helper in Preview mode where supported.
3. Review every proposed source change.
4. Apply.
5. Validate application integration.
6. Run package lint.
7. Build the selected SandboxType images with the required DeploymentType.
8. Test real approved operation with non-production/dummy credentials where appropriate.
9. Confirm audit contains no secret/query/prompt/source-code leakage.
10. Run security gates.
11. Publish the resulting immutable TAR bundle or ECR digests and update release evidence.
```

### Remove

```text
1. Identify shared dependencies/domains/parameters first.
2. Preview removal where helper-managed.
3. Remove all image/wrapper/SSM/audit/MCP/Squid/verification references.
4. Lint and rebuild.
5. Test and publish new immutable image.
6. Retire old image instances.
7. Only then revoke/delete application credentials and obsolete SSM parameters.
```

---

# Appendix C — Final acceptance checklist

Before a Production release, confirm at minimum:

- Admin package lint passes in Bash and PowerShell-capable environments.
- Pinned/resolved external inputs match the approved change record.
- Hardened-base evidence is preserved.
- Final DevContainer OpenSCAP/CIS gate passes according to Production policy.
- Squid starts healthy and only approved egress destinations work.
- Direct DevContainer Internet bypass is not available through the intended Docker network topology.
- Docker Desktop/Windows host policy prevents Developers from bypassing the approved Sandbox with arbitrary unmanaged runtime paths according to organizational policy.
- AWS authentication works through the selected host profile: static key pair for approved POC testing or Azure/Entra SAML; raw AWS keys in `.env`/container environment remain rejected.
- SSM `GetParameter` least-privilege access works for required parameters.
- Bare Claude reaches the Anthropic official API end to end.
- Bare Gemini reaches the Google Gemini official API end to end.
- `ucode claude` and `ucode gemini` reach Databricks AI Gateway through the credential-isolated broker route; the PAT remains broker-side.
- Tavily MCP and Snyk paths work end to end.
- Application audit and Claude/Gemini telemetry behave as documented.
- Prompt/query/secret/source-code redaction tests pass.
- Docker-owned DevContainer/Squid streams are populated, the SYSTEM exporter writes protected Windows files, and both container log mounts are read-only.
- Sentinel/AMA collection from the protected Windows host log tree (or another approved central forwarding path) is verified where required.
- ECR image digests and approved manifest match the release evidence.
- Developer package contains only the intended runtime boundary.

This guide is intentionally English-only so the Admin source, comments, operational documentation, and security review material use one consistent language.

## v1.16.44 optional AI content logging

The Developer runtime template includes `SANDBOX_CONTENT_LOGGING=false`. Keep the default for normal secure development. To enable approved POC/debug capture, set:

```env
SANDBOX_CONTENT_LOGGING=true
```

Recreate/restart the DevContainer so Compose passes the changed value. No SSM secret or image rebuild is required when only toggling this runtime flag.

Content-bearing records remain in the Docker-owned stream first and are then exported by LOCALSYSTEM into the protected `devcontainer\content` subtree. They are not duplicated into the top-level `all-*.log` aggregate. The Windows exporter explicitly decodes Docker stdout/stderr as UTF-8 before persisting files. Developers can read but cannot modify those exported files. Claude records carry route/source tags, and Gemini telemetry is correlated with the metadata application stream. Metadata audit records remain content-free.

The Admin must treat content-bearing records differently from ordinary audit metadata. Before enabling, approve scope, RBAC, retention, Sentinel forwarding behavior, incident-access procedure, and whether customer/source-code content may leave the Windows 365 endpoint.


## POC fast iteration: skip final CIS/OpenSCAP assessment

For repeated POC-only development builds on constrained Admin workstations, the final DevContainer CIS/OpenSCAP scanner can be skipped explicitly:

```powershell
pwsh -NoProfile -File .\scripts\admin\build-sandbox.ps1 `
  -SandboxType POC `
  -ReuseHardenedBase `
  -SkipCisAssessment
```

`-SkipCisAssessment` is rejected for Production builds. A POC-hardened TAR bundle created with this option contains `tar/images/security/CIS-ASSESSMENT-SKIPPED.txt` and must not be treated as security-assessed release evidence. Omit the switch for release/security-evidence builds.


## v1.16.44 runtime compatibility update

- Snyk now uses `/run/ai-sandbox-snyk`, a dedicated ephemeral `exec,nosuid,nodev` tmpfs, because the Snyk CLI downloads and executes a versioned native runtime from its cache. `/tmp` and `/var/tmp` remain `noexec`.
- When `-ReuseHardenedBase`/`--reuse-hardened-base` is used, the build refreshes only the immutable `UCODE_GIT_REF` from Databricks ucode `main`; the hardened Ubuntu base is still reused.
- The DevContainer Dockerfile fails the Admin build unless the pinned ucode commit supports `--profiles`, `--use-pat`, `--skip-validate`, and `--skip-upgrade`, preventing the old interactive-browser-login regression from reaching Developers.


### v1.16.44: Databricks SQL MCP and managed Tavily search policy

- Claude and Gemini receive an additional `databricks-sql` MCP registration. The wrapper fetches `<SSM_PREFIX>/databricks-sql-mcp-token` at runtime and connects to `${DATABRICKS_HOST}/api/2.0/mcp/sql`; the PAT is not stored in MCP settings.
- Tavily MCP calls are enforced by the root-owned `/etc/ai-sandbox/policies/tavily-allowed-domains.json` policy. Search without `include_domains` is automatically constrained to the Admin allowlist; an out-of-policy domain is denied.
- Claude managed settings deny native `WebSearch`/`WebFetch`; Gemini system policy denies `google_web_search`/`web_fetch`. Developers cannot edit the system policy files because they are root-owned and the container root filesystem is read-only.
- To change the allowed Tavily domains, the Admin edits `policies/tavily-allowed-domains.json`, rebuilds the image, and redistributes/redeploys it.
