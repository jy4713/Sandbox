#!/usr/bin/env python3
"""Claude PreToolUse guard preventing direct web/Tavily policy bypass via Bash."""
import json
import re
import sys


def deny(reason: str) -> None:
    print(json.dumps({'hookSpecificOutput': {
        'hookEventName': 'PreToolUse',
        'permissionDecision': 'deny',
        'permissionDecisionReason': reason,
    }}))
    raise SystemExit(0)


data = json.load(sys.stdin)
if data.get('tool_name') != 'Bash':
    print('{}')
    raise SystemExit(0)
command = str((data.get('tool_input') or {}).get('command', ''))
# This is intentionally narrow: block only obvious ways the model could bypass
# the managed Tavily MCP path or directly fetch an SSM service secret. It does
# not try to be a general-purpose shell firewall.
patterns = [
    r'(^|[;&|]\s*)(?:/usr/local/bin/)?tvly(?:\s|$)',
    r'(^|[;&|]\s*)(?:/usr/local/bin/)?tavily-mcp(?:\s|$)',
    r'/usr/local/libexec/ai-sandbox/real/(?:tvly|tavily-mcp)(?:\s|$)',
    r'(?:/usr/local/bin/)?secret-broker-client\s+--tool\s+tavily-cli(?:\s|$)',
]
if any(re.search(p, command) for p in patterns):
    deny('Admin web policy: direct Tavily shell execution is disabled for Claude. Use the managed Tavily MCP server.')
print('{}')
