#!/usr/bin/env bash
# Offline regression: non-Tavily public CLI wrappers must not reject native
# subcommands/options. SSM-backed credentials remain broker-only; this test uses
# stubs and no network.
set -euo pipefail
root="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd -P)"
tmp="$(mktemp -d)"; trap 'rm -rf "$tmp"' EXIT
mkdir -p "$tmp/real" "$tmp/bin" "$tmp/snyk-root"

cat > "$tmp/bin/application-audit" <<'SH'
#!/usr/bin/env bash
exit 0
SH
chmod +x "$tmp/bin/application-audit"

make_stub() {
  local name="$1"
  cat > "$tmp/real/$name" <<'SH'
#!/usr/bin/env bash
printf '%s\n' "$0" > "${NATIVE_CAPTURE:?}"
printf '%s\n' "$@" >> "${NATIVE_CAPTURE:?}"
SH
  chmod +x "$tmp/real/$name"
}
for c in claude gemini ucode snyk databricks tvly; do make_stub "$c"; done

wrapper="$tmp/bin/sandbox-command-wrapper"
sed \
  -e "s|readonly REAL_DIR=\"/usr/local/libexec/ai-sandbox/real\"|readonly REAL_DIR=\"$tmp/real\"|" \
  -e "s|local root=/run/ai-sandbox-snyk h ec|local root=$tmp/snyk-root h ec|" \
  "$root/.devcontainer/scripts/sandbox-command-wrapper.sh" > "$wrapper"
chmod +x "$wrapper"
for c in claude gemini snyk databricks ucode; do ln -s "$wrapper" "$tmp/bin/$c"; done
export PATH="$tmp/bin:/usr/bin:/bin"

capture="$tmp/capture"
export NATIVE_CAPTURE="$capture"

"$tmp/bin/claude" --help --native-test=value
mapfile -t got < "$capture"
[[ "${got[1]:-}" == --help && "${got[2]:-}" == --native-test=value ]] || { echo 'ERROR: claude native help/options changed/rejected' >&2; exit 1; }

"$tmp/bin/gemini" --help --native-test=value
mapfile -t got < "$capture"
[[ "${got[1]:-}" == --help && "${got[2]:-}" == --native-test=value ]] || { echo 'ERROR: gemini native help/options changed/rejected' >&2; exit 1; }

"$tmp/bin/ucode" claude --help --native-agent-flag=value
mapfile -t got < "$capture"
[[ "${got[0]:-}" == "$tmp/real/claude" && "${got[1]:-}" == --help && "${got[2]:-}" == --native-agent-flag=value ]] || { echo 'ERROR: ucode claude agent argv changed/rejected' >&2; exit 1; }

"$tmp/bin/ucode" gemini --help --native-agent-flag=value
mapfile -t got < "$capture"
[[ "${got[0]:-}" == "$tmp/real/gemini" && "${got[1]:-}" == --help && "${got[2]:-}" == --native-agent-flag=value ]] || { echo 'ERROR: ucode gemini agent argv changed/rejected' >&2; exit 1; }

printf 'diagnostic-input\n' | "$tmp/bin/snyk" doctor --stdin
mapfile -t got < "$capture"
[[ "${got[1]:-}" == doctor && "${got[2]:-}" == --stdin ]] || { echo 'ERROR: snyk doctor argv changed/rejected' >&2; exit 1; }

"$tmp/bin/snyk" code test -d --severity-threshold=high
mapfile -t got < "$capture"
[[ "${got[1]:-}" == code && "${got[2]:-}" == test && "${got[3]:-}" == -d && "${got[4]:-}" == --severity-threshold=high ]] || { echo 'ERROR: snyk native options changed/rejected' >&2; exit 1; }

"$tmp/bin/databricks" workspace list /
mapfile -t got < "$capture"
[[ "${got[1]:-}" == workspace && "${got[2]:-}" == list && "${got[3]:-}" == / ]] || { echo 'ERROR: databricks native command changed/rejected' >&2; exit 1; }

"$tmp/bin/ucode" arbitrary-native-subcommand --flag value
mapfile -t got < "$capture"
[[ "${got[1]:-}" == arbitrary-native-subcommand && "${got[2]:-}" == --flag && "${got[3]:-}" == value ]] || { echo 'ERROR: native ucode fallback changed/rejected' >&2; exit 1; }

"$tmp/bin/ucode" status --json
mapfile -t got < "$capture"
[[ "${got[1]:-}" == status && "${got[2]:-}" == --json ]] || { echo 'ERROR: ucode status was intercepted instead of preserving native argv' >&2; exit 1; }

"$tmp/bin/snyk" mcp --help
mapfile -t got < "$capture"
[[ "${got[1]:-}" == mcp && "${got[2]:-}" == --help ]] || { echo 'ERROR: snyk mcp argv changed/rejected' >&2; exit 1; }

# Tavily is the sole application-policy exception: domain-bearing operations are
# constrained, but native non-domain commands must pass through unchanged.
tavily_policy="$tmp/tavily-cli-policy.py"
tavily_policy_json="$tmp/tavily-policy.json"
printf '%s\n' '{"allowed_domains":["docs.databricks.com","github.com"]}' > "$tavily_policy_json"
sed "s|POLICY = Path('/etc/ai-sandbox/policies/tavily-allowed-domains.json')|POLICY = Path('$tavily_policy_json')|" \
  "$root/.devcontainer/scripts/tavily-cli-policy.py" > "$tavily_policy"
chmod +x "$tavily_policy"

python3 "$tavily_policy" "$tmp/real/tvly" auth --json
mapfile -t got < "$capture"
[[ "${got[1]:-}" == auth && "${got[2]:-}" == --json ]] || { echo 'ERROR: Tavily auth native argv changed/rejected' >&2; exit 1; }

python3 "$tavily_policy" "$tmp/real/tvly" login --api-key placeholder-user-supplied
mapfile -t got < "$capture"
[[ "${got[1]:-}" == login && "${got[2]:-}" == --api-key && "${got[3]:-}" == placeholder-user-supplied ]] || { echo 'ERROR: Tavily login native argv changed/rejected' >&2; exit 1; }

python3 "$tavily_policy" "$tmp/real/tvly" logout --json
mapfile -t got < "$capture"
[[ "${got[1]:-}" == logout && "${got[2]:-}" == --json ]] || { echo 'ERROR: Tavily logout native argv changed/rejected' >&2; exit 1; }

python3 "$tavily_policy" "$tmp/real/tvly" search 'Databricks docs' --json
mapfile -t got < "$capture"
[[ "${got[1]:-}" == search && "${got[2]:-}" == 'Databricks docs' ]] || { echo 'ERROR: Tavily search native argv prefix changed' >&2; exit 1; }
printf '%s\n' "${got[@]}" | grep -Fq -- '--include-domains' || { echo 'ERROR: Tavily search did not enforce Admin domains' >&2; exit 1; }

if python3 "$tavily_policy" "$tmp/real/tvly" research 'unconstrained research' >/dev/null 2>&1; then
  echo 'ERROR: Tavily research bypassed Admin domain policy' >&2; exit 1
fi
if python3 "$tavily_policy" "$tmp/real/tvly" >/dev/null 2>&1; then
  echo 'ERROR: Tavily interactive REPL bypassed Admin domain policy' >&2; exit 1
fi

echo 'Native command contract regression tests passed'
