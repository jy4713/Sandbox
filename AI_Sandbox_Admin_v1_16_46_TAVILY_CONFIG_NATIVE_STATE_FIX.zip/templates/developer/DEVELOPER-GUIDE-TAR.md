# Developer Guide - TAR - AI Secure Sandbox v1.16.44

### Static key test mode (host only)

For temporary POC testing when SAML is unavailable, store the Access Key and Secret Access Key in the Windows host profile, not in `.env`:

```powershell
aws configure --profile sandbox
```

Set `AWS_AUTH_MODE=auto` (default) or `AWS_AUTH_MODE=static`. The host `.aws` directory is mounted read-only into `secret-broker` only; it is not mounted into the AI DevContainer.


## Purpose

The TAR package starts a credential-isolated AI Dev Container. AWS authentication is performed on the Windows 365 host. AUTO mode uses an existing static `sandbox` host profile first and otherwise uses `aws-azure-login` with the corporate Azure/Entra browser/MFA flow. The AI container never receives the host `.aws` directory or raw application secrets.

## Prerequisites

- Docker Desktop / approved Docker runtime
- VS Code + Dev Containers
- AWS CLI v2
- `aws-azure-login` on the Windows host
- Browser access to Azure/Entra

If approved and not already installed:

```powershell
npm install -g aws-azure-login
```


## Git usage

Use normal Git commands exactly as usual. Every Git process runs locally in the Dev Container as `vscode`; for ADO operations that need authentication, only Git HTTP traffic is rewritten to the trusted credential broker:

```bash
git clone "https://dev.azure.com/ORG/PROJECT/_git/REPO"
git fetch --prune
git pull
git push -u origin feature/my-change
```

The wrapper preserves normal Git push semantics. Commands such as `git push origin main`, `git push --force origin feature/x`, `git push --force-with-lease origin feature/x`, and `git push --delete origin feature/old` still execute the local `/usr/bin/git`; only their validated `dev.azure.com` HTTP requests cross the credential broker, where the ADO PAT is injected upstream. Whether Azure DevOps accepts them is controlled by ADO repository/branch permissions and policies. The Sandbox still blocks attempts to redirect authentication through custom credential helpers, execution/config overrides, or alternate/non-ADO transports. It does not pin a specific ADO organisation/project/repository; access is decided by the PAT and Azure DevOps permissions.

Local-only operations such as `git status`, `git diff`, `git add`, `git commit`, `git branch`, `git switch`, `git checkout`, `git log`, `git merge`, `git rebase`, `git tag`, and `git stash` also execute locally. In other words, **all Git filesystem I/O is performed by the Dev Container user**, so cloned and updated source remains `vscode:vscode`. The ADO PAT is never placed in the DevContainer environment or Git credential files. `ado-git` remains a backward-compatible local-policy alias but is not required.

## Configure `.env`

The launcher creates `.env` from `.env.example` when required. Fill only non-secret settings, especially:

```ini
DEVELOPER_ID=<your-id>
SANDBOX_AWS_PROFILE=sandbox
AWS_REGION=eu-west-2
AZURE_TENANT_ID=<tenant-id>
AZURE_APP_ID_URI=<app-id-uri>
AZURE_DEFAULT_USERNAME=<your-email>
AZURE_DEFAULT_ROLE_ARN=arn:aws:iam::<account>:role/<role>
AZURE_DEFAULT_DURATION_HOURS=1
AZURE_DEFAULT_REMEMBER_ME=true
DATABRICKS_HOST=https://<approved-workspace>
DATABRICKS_CLAUDE_MODEL=<approved-model>
DATABRICKS_GEMINI_MODEL=<approved-model>
```

Never add AWS access keys, SSM secret values, PATs, or provider API keys to `.env`.

## Start

```powershell
.\scripts\tar\load-and-start.ps1
```

The launcher:

1. validates package/image hashes;
2. writes the non-secret Azure SAML settings into the host named AWS profile;
3. validates the current temporary AWS session;
4. opens `aws-azure-login --profile sandbox --mode gui` when login is required;
5. mounts host `~/.aws` read-only into `secret-broker` only;
6. starts the proxy, broker, and AI Dev Container.

## Use

```bash
claude
gemini
ucode claude
ucode gemini
snyk code test
snyk test
tvly search "example query"
databricks current-user me
```

Tavily, Snyk, Databricks, Git/ADO, Claude, Gemini, `ucode claude`, `ucode gemini`, and all managed MCP processes run in the Dev Container as `vscode`. The broker fetches only the required SSM credential and injects it into a fixed outbound HTTP route; raw credentials are never placed in the local application process. `ucode claude/gemini` use the same model with a fixed Databricks AI Gateway route.

## Verify credential isolation

```bash
verify-runtime
```

Expected security properties:

- no `~/.aws/credentials` or AWS SSO/SAML cache in the AI container;
- no AWS access-key environment variables;
- no Tavily/Snyk/Databricks/ADO raw secret environment variables;
- direct `aws ssm get-parameter ... --with-decryption` fails;
- MCP/provider broker health checks succeed, while the MCP/vendor processes themselves execute locally in the Dev Container.
- a local Git ownership smoke test creates files/directories as uid/gid 1000 (`vscode:vscode`).

## Refresh AWS login

If the broker reports that the host AWS session expired, return to Windows PowerShell and run:

```powershell
aws-azure-login --profile sandbox --mode gui
# load-and-start then relies on the broker's first SSM call as the required-permission check; no STS preflight is required
```

Then restart/recreate the sandbox so the broker reopens the current host credential files.

## Notes

`aws-azure-login` can store temporary AWS role credentials on the Windows host. The Developer can inspect their own host session. Those files are intentionally not mounted into the AI Dev Container.
### v1.16.44 MCP smoke test

After the new image/container is started, verify the Admin-managed MCP set from every supported entry point:

```bash
claude mcp list
gemini mcp list
ucode claude mcp list
ucode gemini mcp list
```

All four modes must register `tavily`, `snyk`, and `databricks-sql`. Gemini also synchronizes the persistent user MCP state from the root-owned system policy at launch. No AWS/service credential is written to the Gemini or Claude configuration.

