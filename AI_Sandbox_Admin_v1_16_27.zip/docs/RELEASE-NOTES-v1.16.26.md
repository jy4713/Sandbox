# AI Secure Sandbox v1.16.26 - Release Notes

## ECI-safe hardened-base builder

v1.16.26 fixes hardened-base builds on Docker Desktop Business when Enhanced Container Isolation (ECI) is enabled. The previous hardening workflow used `docker cp` twice after the Sysbox-protected hardening container was created: once to export OpenSCAP evidence and once to inject the cleanup script. On affected Docker Desktop/Sysbox combinations this could fail while traversing Docker-managed files such as `/etc/resolv.conf` with `openat ... directory not empty`.

Changes:

- Removes all `docker cp` usage from both `build-hardened-base.ps1` and `build-hardened-base.sh`.
- Mounts the Admin `hardened-base-build/results` directory directly at `/results`, so OpenSCAP/USG evidence is persisted to the host as it is generated.
- Cleans stale evidence before each hardening run to prevent old results being mistaken for the current build.
- Adds an early `/results` write test with a clear failure if the host evidence mount is not writable.
- Bakes `cleanup-toolchain.sh` into the raw hardening image and runs it with `docker exec`; `/opt/hardening` is removed last.
- Prints the hardening builder runtime (`sysbox-runc` when ECI is active) for troubleshooting.
- Retains the v1.16.25 split between `SandboxType` (POC/Production hardening) and `DeploymentType` (Tar/Ecr distribution).
- Retains transactional `.build.env` updates: the active build environment is committed only after a newly built hardened base completes successfully.

This change addresses the observed ECI failure before `docker commit`; it is unrelated to `.build.env` transaction timing.
