# AI Secure Sandbox v1.16.25 Release Notes

## Independent hardening and deployment selection

- `SandboxType` now controls **image hardening only**:
  - `POC` -> self-hardened Ubuntu 24.04.
  - `Production` -> Ubuntu Pro + USG.
- New optional `DeploymentType` controls **distribution only**:
  - `Tar` -> local TAR bundle under `tar/images`.
  - `Ecr` -> build/push immutable ECR images and approved manifest.
- Default behavior is backward-compatible:
  - `POC` with no DeploymentType -> `Tar`.
  - `Production` with no DeploymentType -> `Ecr`.
- New combinations are supported, including `Production + Tar` for environments where ECR is not ready and `POC + Ecr` when registry distribution is desired.
- Production CIS gating follows `SandboxType`, so a Production image exported as TAR still uses the Production fail-closed CIS release gate.
- ECR configuration is required only for `DeploymentType=Ecr`.

## Reuse path supply-chain fix

When `ReuseHardenedBase` is used, the Admin orchestrator now refreshes downloadable-tool SHA-256 values as well as the ucode immutable commit. This prevents stale checksum failures for mutable vendor URLs such as the AWS CLI `latest` archive.

## Examples

```powershell
# POC default: self-hardened + TAR
.\scripts\admin\build-sandbox.ps1 -SandboxType POC

# Production default: Ubuntu Pro + USG + ECR
.\scripts\admin\build-sandbox.ps1 -SandboxType Production

# Production image + TAR distribution
.\scripts\admin\build-sandbox.ps1 -SandboxType Production -DeploymentType Tar

# POC image + ECR distribution
.\scripts\admin\build-sandbox.ps1 -SandboxType POC -DeploymentType Ecr
```
