#Requires -Version 7.4
# =============================================================================
# PACKAGE MAINTENANCE NOTES
# Purpose: Single Windows Admin entry point that selects POC self-hardening or
# Production Ubuntu Pro + USG and then distributes images.
# v1.16.27 separates image hardening (SandboxType) from distribution (DeploymentType) while preserving hardened-base reuse.
# Admin maintenance: Keep this orchestration thin. New applications should
# normally be wired through the devcontainer Dockerfile and shared validation,
# not hard-coded here.
# Safety rule: preserve secret-free images/configuration, immutable version or
# digest pinning where applicable, and update the paired Bash/PowerShell path.
# =============================================================================
<#
.SYNOPSIS
  Unified Administrator build entry point for the AI Secure Sandbox.

.DESCRIPTION
  Normal mode always resolves external build inputs and rebuilds the hardened
  Ubuntu base before building the DevContainer and Squid images.

  -ReuseHardenedBase enables a faster iterative path. The hardened base is reused
  only when ALL of the following are true:
    - .build.env exists and passes the normal strict build-env validation;
    - BASE_IMAGE and SQUID_BASE_IMAGE are identical digest-pinned references;
    - the exact hardened image reference is available locally/pullable, or a
      local candidate matches the persisted HARDENED_CONFIG_ID;
    - the image carries the expected hardening.method label for SandboxType;
    - the image carries hardening.profile=cis_level1_server.

  If any reuse requirement fails, the script automatically falls back to the
  normal full resolver + hardened-base build path. No manual cleanup is needed.

  A .build.env from the previous package can be copied into this package before
  invoking -ReuseHardenedBase. Alternatively, -BuildEnvSource can copy it for
  you. After a successful full-build or reuse transaction, v1.16.27 updates
  SANDBOX_VERSION automatically and updates RELEASE_TAG when it still equals
  the previous package version. Failed transactions preserve the old file.

.PARAMETER SandboxType
  Selects image hardening only: POC = self-hardened Ubuntu 24.04; Production = Ubuntu Pro + USG.

.PARAMETER DeploymentType
  Selects distribution only: Tar or Ecr. If omitted, POC defaults to Tar and Production defaults to Ecr.

.PARAMETER UbuntuProToken
  Required only when a non-POC hardened base must actually be rebuilt. A valid
  reused Production hardened base does not require the token again.

.PARAMETER ReuseHardenedBase
  Attempt to reuse the exact hardened BASE_IMAGE/SQUID_BASE_IMAGE already
  recorded in .build.env. Invalid or incomplete state falls back to a rebuild.

.PARAMETER SkipCisAssessment
  POC-only fast-iteration option. Skips the final DevContainer CIS/OpenSCAP
  scanner build and assessment. This option is rejected for Production builds.
  A skipped build is not security-assessed release evidence.

.PARAMETER BuildEnvSource
  Optional path to an existing .build.env from another package directory. The
  file is copied into this package before reuse validation. The source file is
  treated as build configuration, never executed as code.
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidateSet('POC','Production')]
    [string]$SandboxType,

    [string]$DeploymentType = '',

    [string]$UbuntuProToken = $env:UBUNTU_PRO_TOKEN,

    [switch]$ReuseHardenedBase,

    [switch]$SkipCisAssessment,

    [string]$BuildEnvSource = ''
)

$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
Set-Location $Root
$BuildEnvPath = Join-Path $Root '.build.env'
$PackageVersion = 'v1.16.27'
$ExpectedHardeningMode = $SandboxType.ToLowerInvariant()
$DeploymentWasDefaulted = [string]::IsNullOrWhiteSpace($DeploymentType)
if ($DeploymentWasDefaulted) {
    $ResolvedDeploymentType = if ($ExpectedHardeningMode -eq 'poc') { 'tar' } else { 'ecr' }
}
else {
    $ResolvedDeploymentType = $DeploymentType.ToLowerInvariant()
    if ($ResolvedDeploymentType -notin @('tar','ecr')) {
        throw "-DeploymentType must be Tar or Ecr. Received: $DeploymentType"
    }
}
$DeploymentSource = if ($DeploymentWasDefaulted) { 'default' } else { 'explicit' }
Write-Host "[selection] SandboxType=$SandboxType -> hardening=$ExpectedHardeningMode" -ForegroundColor Cyan
Write-Host "[selection] DeploymentType=$ResolvedDeploymentType ($DeploymentSource)" -ForegroundColor Cyan

if ($SkipCisAssessment -and $ExpectedHardeningMode -ne 'poc') {
    throw '-SkipCisAssessment is permitted only with -SandboxType POC.'
}
if ($SkipCisAssessment) {
    Write-Warning 'SECURITY NOTICE: CIS/OpenSCAP assessment will be skipped. This build is for POC/test use only and must not be promoted as security-assessed release evidence.'
}

function Write-Utf8NoBomLines {
    param([string]$Path, [string[]]$Lines)
    [IO.File]::WriteAllLines($Path, $Lines, [Text.UTF8Encoding]::new($false))
}

function Set-BuildEnvValue {
    param([string]$Key, [string]$Value, [string]$Path = '')
    if ([string]::IsNullOrWhiteSpace($Path)) { $Path = $BuildEnvPath }
    $Lines = if (Test-Path $Path) { @(Get-Content $Path -Encoding UTF8) } else { @() }
    $Found = $false
    $Updated = foreach ($Line in $Lines) {
        if ($Line -match "^$([regex]::Escape($Key))=") {
            $Found = $true
            "$Key=$Value"
        }
        else { $Line }
    }
    if (-not $Found) { $Updated += "$Key=$Value" }
    Write-Utf8NoBomLines -Path $Path -Lines $Updated
}

function Get-BuildEnvValue {
    param([string]$Key, [string]$Path = '')
    if ([string]::IsNullOrWhiteSpace($Path)) { $Path = $BuildEnvPath }
    if (-not (Test-Path $Path)) { return '' }
    foreach ($Line in Get-Content $Path -Encoding UTF8) {
        if ($Line -match "^$([regex]::Escape($Key))=(.*)$") { return $Matches[1] }
    }
    return ''
}

function Update-PackageVersionInBuildEnv {
    param([string]$Path = '')
    if ([string]::IsNullOrWhiteSpace($Path)) { $Path = $BuildEnvPath }
    if (-not (Test-Path $Path)) { return }
    $OldVersion = Get-BuildEnvValue -Key 'SANDBOX_VERSION' -Path $Path
    $OldRelease = Get-BuildEnvValue -Key 'RELEASE_TAG' -Path $Path
    Set-BuildEnvValue -Key 'SANDBOX_VERSION' -Value $PackageVersion -Path $Path
    # A release tag that followed the old package version follows the new package.
    # A deliberately custom release tag is preserved.
    if ([string]::IsNullOrWhiteSpace($OldRelease) -or $OldRelease -eq $OldVersion) {
        Set-BuildEnvValue -Key 'RELEASE_TAG' -Value $PackageVersion -Path $Path
    }
}

function Apply-HardenedBaseEnvironment {
    param([string]$TargetPath = '')
    if ([string]::IsNullOrWhiteSpace($TargetPath)) { $TargetPath = $BuildEnvPath }
    $HardenedEnv = Join-Path $Root 'hardened-base-build\hardened-base.env'
    if (-not (Test-Path $HardenedEnv)) {
        throw "Hardened base environment file not found: $HardenedEnv"
    }

    $Values = @{}
    foreach ($Line in Get-Content $HardenedEnv -Encoding UTF8) {
        if ($Line -match '^(BASE_IMAGE|SQUID_BASE_IMAGE|HARDENED_SOURCE_IMAGE|HARDENED_SSG_SHA256|HARDENED_METHOD|HARDENED_PROFILE|HARDENED_CONFIG_ID)=(.*)$') {
            $Values[$Matches[1]] = $Matches[2]
        }
    }

    foreach ($RequiredKey in @('BASE_IMAGE', 'SQUID_BASE_IMAGE')) {
        if (-not $Values.ContainsKey($RequiredKey) -or [string]::IsNullOrWhiteSpace($Values[$RequiredKey])) {
            throw "$RequiredKey was not produced by the hardened-base builder."
        }
    }
    foreach ($Key in @('BASE_IMAGE','SQUID_BASE_IMAGE','HARDENED_SOURCE_IMAGE','HARDENED_SSG_SHA256','HARDENED_METHOD','HARDENED_PROFILE','HARDENED_CONFIG_ID')) {
        if ($Values.ContainsKey($Key)) {
            Set-BuildEnvValue -Key $Key -Value $Values[$Key] -Path $TargetPath
        }
    }
}

$script:ReuseResolvedRef = ''
$script:ReuseResolvedConfigId = ''

function Get-RegistryDigest {
    param(
        [Parameter(Mandatory = $true)][string]$Registry,
        [Parameter(Mandatory = $true)][string]$Repo,
        [Parameter(Mandatory = $true)][string]$Tag,
        [Parameter(Mandatory = $true)][string]$ImageRef
    )

    # Local scratch registries are intentionally HTTP-only and bound to
    # localhost. Query the Registry V2 API first because buildx imagetools can
    # be unreliable against an insecure localhost registry on Docker Desktop.
    if ($Registry -match '^localhost:(?<Port>\d+)$') {
        $Port = $Matches['Port']
        try {
            $Accept = @(
                'application/vnd.oci.image.manifest.v1+json',
                'application/vnd.docker.distribution.manifest.v2+json',
                'application/vnd.oci.image.index.v1+json',
                'application/vnd.docker.distribution.manifest.list.v2+json'
            ) -join ', '
            $Response = Invoke-WebRequest `
                -Uri "http://localhost:${Port}/v2/${Repo}/manifests/${Tag}" `
                -Headers @{ Accept = $Accept } `
                -Method Head `
                -UseBasicParsing `
                -ErrorAction Stop
            $Header = $Response.Headers['Docker-Content-Digest']
            if ($Header) {
                $Digest = if ($Header -is [array]) { "$($Header[0])".Trim() } else { "$Header".Trim() }
                if ($Digest -match '^sha256:[0-9a-fA-F]{64}$') { return $Digest.ToLowerInvariant() }
            }
        }
        catch { <# fall through to Docker-side methods #> }
    }

    $RepoDigest = (& docker image inspect $ImageRef --format '{{index .RepoDigests 0}}' 2>$null | Out-String).Trim()
    if ($RepoDigest -match '@(sha256:[0-9a-fA-F]{64})$') { return $Matches[1].ToLowerInvariant() }

    $BuildxDigest = (& docker buildx imagetools inspect $ImageRef --format '{{json .Manifest.Digest}}' 2>$null | Out-String).Trim().Trim('"')
    if ($BuildxDigest -match '^sha256:[0-9a-fA-F]{64}$') { return $BuildxDigest.ToLowerInvariant() }
    return ''
}

function Test-HardenedImageProvenance {
    param(
        [Parameter(Mandatory = $true)][string]$ImageRef,
        [string]$ExpectedConfigId = ''
    )

    $ConfigId = (& docker image inspect $ImageRef --format '{{.Id}}' 2>$null | Out-String).Trim().ToLowerInvariant()
    if ($ConfigId -notmatch '^sha256:[0-9a-f]{64}$') {
        Write-Warning "[reuse] Unable to read a valid image config ID from $ImageRef."
        return $false
    }
    if (-not [string]::IsNullOrWhiteSpace($ExpectedConfigId) -and $ConfigId -ne $ExpectedConfigId.ToLowerInvariant()) {
        Write-Warning "[reuse] Hardened image config ID mismatch. Expected '$ExpectedConfigId', found '$ConfigId'."
        return $false
    }

    $Method = (& docker image inspect $ImageRef --format '{{ index .Config.Labels "hardening.method" }}' 2>$null | Out-String).Trim()
    $Profile = (& docker image inspect $ImageRef --format '{{ index .Config.Labels "hardening.profile" }}' 2>$null | Out-String).Trim()
    if ($Method -ne $ExpectedHardeningMode) {
        Write-Warning "[reuse] Hardened base mode mismatch. Expected '$ExpectedHardeningMode', found '$Method'."
        return $false
    }
    if ($Profile -ne 'cis_level1_server') {
        Write-Warning "[reuse] Hardened base profile mismatch. Expected 'cis_level1_server', found '$Profile'."
        return $false
    }

    $ExpectedSource = Get-BuildEnvValue -Key 'HARDENED_SOURCE_IMAGE'
    if (-not [string]::IsNullOrWhiteSpace($ExpectedSource)) {
        $ActualSource = (& docker image inspect $ImageRef --format '{{ index .Config.Labels "hardening.source.image" }}' 2>$null | Out-String).Trim()
        if ($ActualSource -ne $ExpectedSource) {
            Write-Warning "[reuse] Hardened source-image provenance mismatch. Expected '$ExpectedSource', found '$ActualSource'."
            return $false
        }
    }

    $ExpectedSsg = Get-BuildEnvValue -Key 'HARDENED_SSG_SHA256'
    if (-not [string]::IsNullOrWhiteSpace($ExpectedSsg)) {
        $ActualSsg = (& docker image inspect $ImageRef --format '{{ index .Config.Labels "hardening.ssg.sha256" }}' 2>$null | Out-String).Trim()
        if ($ActualSsg -ne $ExpectedSsg) {
            Write-Warning '[reuse] Hardened SSG provenance mismatch.'
            return $false
        }
    }

    $script:ReuseResolvedConfigId = $ConfigId
    return $true
}

function Restore-LocalScratchDigestReference {
    param([Parameter(Mandatory = $true)][string]$Ref)

    # Recovery is intentionally limited to the Admin-host-only localhost
    # registry. A local candidate is accepted only when it is cryptographically
    # tied to the previous state by either the exact RepoDigest or the persisted
    # Docker image config ID. Labels alone are never sufficient for recovery.
    if ($Ref -notmatch '^(?<Registry>localhost:(?<Port>\d+))/(?<Repo>[^@]+)@(?<Digest>sha256:[0-9a-fA-F]{64})$') {
        return $false
    }

    $Registry = $Matches['Registry']
    $Port = $Matches['Port']
    $Repo = $Matches['Repo']
    $ExpectedDigest = $Matches['Digest'].ToLowerInvariant()
    $ExpectedConfigId = (Get-BuildEnvValue -Key 'HARDENED_CONFIG_ID').ToLowerInvariant()
    if ($ExpectedConfigId -and $ExpectedConfigId -notmatch '^sha256:[0-9a-f]{64}$') {
        Write-Warning '[reuse] HARDENED_CONFIG_ID is present but malformed; refusing local recovery.'
        return $false
    }

    $Candidate = ''
    $CandidateConfigId = ''
    $ImageRefs = @(& docker image ls --format '{{.Repository}}:{{.Tag}}' 2>$null)

    # Strategy 1: an existing RepoDigest exactly matches the old pinned ref.
    foreach ($ImageRef in $ImageRefs) {
        $ImageRef = "$ImageRef".Trim()
        if ([string]::IsNullOrWhiteSpace($ImageRef) -or $ImageRef -match '<none>') { continue }
        $RepoDigests = (& docker image inspect $ImageRef --format '{{json .RepoDigests}}' 2>$null | Out-String).Trim()
        if ($RepoDigests -like "*$Ref*") {
            $Candidate = $ImageRef
            $CandidateConfigId = (& docker image inspect $ImageRef --format '{{.Id}}' 2>$null | Out-String).Trim().ToLowerInvariant()
            Write-Host "[reuse] Local candidate matched the previous RepoDigest: $Candidate" -ForegroundColor DarkGray
            break
        }
    }

    # Strategy 2: v1.16.27+ persists the image config ID. The config digest
    # cryptographically commits to the image configuration and rootfs diff IDs,
    # and remains stable when a scratch registry container/volume is recreated.
    if ([string]::IsNullOrWhiteSpace($Candidate) -and -not [string]::IsNullOrWhiteSpace($ExpectedConfigId)) {
        foreach ($ImageRef in $ImageRefs) {
            $ImageRef = "$ImageRef".Trim()
            if ([string]::IsNullOrWhiteSpace($ImageRef) -or $ImageRef -match '<none>') { continue }
            $LastColon = $ImageRef.LastIndexOf(':')
            if ($LastColon -lt 0) { continue }
            $CandidateRepo = $ImageRef.Substring(0, $LastColon) -replace '^localhost:\d+/', ''
            if ($CandidateRepo -ne $Repo) { continue }
            $ConfigId = (& docker image inspect $ImageRef --format '{{.Id}}' 2>$null | Out-String).Trim().ToLowerInvariant()
            if ($ConfigId -eq $ExpectedConfigId) {
                $Candidate = $ImageRef
                $CandidateConfigId = $ConfigId
                Write-Host "[reuse] Local candidate matched HARDENED_CONFIG_ID: $Candidate" -ForegroundColor DarkGray
                break
            }
        }
    }

    if ([string]::IsNullOrWhiteSpace($Candidate)) {
        if ([string]::IsNullOrWhiteSpace($ExpectedConfigId)) {
            Write-Host '[reuse] Legacy build state has no HARDENED_CONFIG_ID and no exact local RepoDigest; local recovery is intentionally fail-closed.' -ForegroundColor DarkGray
        }
        else {
            Write-Host '[reuse] No local image matches the persisted hardened image config ID.' -ForegroundColor DarkGray
        }
        return $false
    }

    if ($CandidateConfigId -notmatch '^sha256:[0-9a-f]{64}$') {
        Write-Warning '[reuse] Candidate image config ID is invalid.'
        return $false
    }
    if (-not (Test-HardenedImageProvenance -ImageRef $Candidate -ExpectedConfigId $ExpectedConfigId)) { return $false }
    $CandidateConfigId = $script:ReuseResolvedConfigId

    $RegistryName = 'ai-sandbox-hardened-base-digest-scratch-registry'
    $RegistryVolume = 'ai-sandbox-hardened-base-registry-data'
    & docker container inspect $RegistryName *> $null
    if ($LASTEXITCODE -eq 0) {
        $PortMapping = (& docker port $RegistryName '5000/tcp' 2>$null | Out-String).Trim()
        if ($PortMapping -and $PortMapping -notmatch "(^|\s)127\.0\.0\.1:${Port}($|\s)") {
            Write-Warning "[reuse] Existing scratch registry uses a different host port: '$PortMapping'."
            return $false
        }
        $Running = (& docker inspect $RegistryName --format '{{.State.Running}}' 2>$null | Out-String).Trim()
        if ($Running -ne 'true') {
            & docker start $RegistryName *> $null
            if ($LASTEXITCODE -ne 0) { return $false }
        }
    }
    else {
        $PortFree = $true
        try {
            $Tcp = [Net.Sockets.TcpClient]::new()
            $Tcp.Connect('127.0.0.1', [int]$Port)
            $Tcp.Close()
            $PortFree = $false
        }
        catch { }
        if (-not $PortFree) {
            Write-Warning "[reuse] Port $Port is already in use; scratch registry cannot be recreated safely."
            return $false
        }
        & docker volume create $RegistryVolume *> $null
        if ($LASTEXITCODE -ne 0) { return $false }
        & docker run -d --restart unless-stopped --name $RegistryName `
            -p "127.0.0.1:${Port}:5000" `
            -v "${RegistryVolume}:/var/lib/registry" registry:2 *> $null
        if ($LASTEXITCODE -ne 0) { return $false }
        Start-Sleep -Seconds 2
    }

    $ShortConfig = $CandidateConfigId.Substring(7, 12)
    $RecoveryTag = "$Registry/${Repo}:reuse-recovery-$ShortConfig"
    Write-Host "[reuse] Re-materializing the verified local image through $Registry..." -ForegroundColor DarkGray
    & docker tag $Candidate $RecoveryTag *> $null
    if ($LASTEXITCODE -ne 0) { return $false }
    & docker push $RecoveryTag *> $null
    if ($LASTEXITCODE -ne 0) { return $false }

    $ActualDigest = Get-RegistryDigest -Registry $Registry -Repo $Repo -Tag "reuse-recovery-$ShortConfig" -ImageRef $RecoveryTag
    if ([string]::IsNullOrWhiteSpace($ActualDigest)) {
        Write-Warning '[reuse] Re-push succeeded but no registry digest could be resolved.'
        return $false
    }

    # A registry manifest digest may legitimately change when the local scratch
    # registry/containerd representation is recreated. Because the candidate is
    # already tied to the persisted config ID (or exact old RepoDigest), use the
    # newly resolved immutable manifest digest rather than forcing a rebuild.
    $ResolvedRef = "$Registry/$Repo@$ActualDigest"
    & docker pull $ResolvedRef *> $null
    if ($LASTEXITCODE -ne 0) { return $false }
    $PulledConfigId = (& docker image inspect $ResolvedRef --format '{{.Id}}' 2>$null | Out-String).Trim().ToLowerInvariant()
    if ($PulledConfigId -ne $CandidateConfigId) {
        Write-Warning '[reuse] Re-materialized registry reference does not resolve to the verified image config ID.'
        return $false
    }

    if ($ActualDigest -ne $ExpectedDigest) {
        Write-Host "[reuse] Scratch-registry manifest digest changed: $ExpectedDigest -> $ActualDigest" -ForegroundColor Yellow
        Write-Host '[reuse] Image config ID is unchanged; the new digest will be committed transactionally to .build.env.' -ForegroundColor Yellow
    }
    else {
        Write-Host '[reuse] Exact localhost hardened digest was re-materialized.' -ForegroundColor Green
    }

    $script:ReuseResolvedRef = $ResolvedRef
    $script:ReuseResolvedConfigId = $CandidateConfigId
    return $true
}

function Ensure-ReusableImageAvailable {
    param([Parameter(Mandatory = $true)][string]$Ref)

    $script:ReuseResolvedRef = ''
    $script:ReuseResolvedConfigId = ''

    & docker image inspect $Ref *> $null
    if ($LASTEXITCODE -eq 0) {
        $script:ReuseResolvedRef = $Ref
        $script:ReuseResolvedConfigId = (& docker image inspect $Ref --format '{{.Id}}' 2>$null | Out-String).Trim().ToLowerInvariant()
        return $true
    }

    Write-Host "[reuse] Exact digest is not materialized locally; attempting docker pull: $Ref" -ForegroundColor DarkGray
    & docker pull $Ref *> $null
    if ($LASTEXITCODE -eq 0) {
        $script:ReuseResolvedRef = $Ref
        $script:ReuseResolvedConfigId = (& docker image inspect $Ref --format '{{.Id}}' 2>$null | Out-String).Trim().ToLowerInvariant()
        return $true
    }

    return (Restore-LocalScratchDigestReference -Ref $Ref)
}

function Test-ReusableHardenedBase {
    Write-Host '[reuse] Checking whether the existing hardened base can be reused...' -ForegroundColor Cyan

    try {
        $Build = & (Join-Path $Root 'scripts\common\Load-BuildEnv.ps1') -EnvFile $BuildEnvPath
    }
    catch {
        Write-Warning "[reuse] .build.env is incomplete or invalid: $($_.Exception.Message)"
        return $false
    }

    if ($Build['BASE_IMAGE'] -ne $Build['SQUID_BASE_IMAGE']) {
        Write-Warning '[reuse] BASE_IMAGE and SQUID_BASE_IMAGE are not the same digest.'
        return $false
    }

    $OriginalRef = $Build['BASE_IMAGE']
    if (-not (Get-Command docker -ErrorAction SilentlyContinue)) {
        Write-Warning '[reuse] docker is unavailable; hardened-base reuse cannot be verified.'
        return $false
    }

    if (-not (Ensure-ReusableImageAvailable -Ref $OriginalRef)) {
        Write-Warning "[reuse] Hardened base digest is not available and could not be safely restored: $OriginalRef"
        return $false
    }

    $ResolvedRef = $script:ReuseResolvedRef
    $ExpectedConfigId = "$($Build['HARDENED_CONFIG_ID'])".Trim().ToLowerInvariant()
    if ($ExpectedConfigId -and $ExpectedConfigId -notmatch '^sha256:[0-9a-f]{64}$') {
        Write-Warning '[reuse] HARDENED_CONFIG_ID is malformed.'
        return $false
    }
    if (-not (Test-HardenedImageProvenance -ImageRef $ResolvedRef -ExpectedConfigId $ExpectedConfigId)) { return $false }

    if ([string]::IsNullOrWhiteSpace($ExpectedConfigId)) {
        Write-Host '[reuse] Legacy build state verified by exact digest; HARDENED_CONFIG_ID will be added transactionally for future recovery.' -ForegroundColor DarkGray
    }

    Write-Host '[reuse] Existing hardened base passed validation.' -ForegroundColor Green
    Write-Host "[reuse] BASE_IMAGE = $ResolvedRef" -ForegroundColor Green
    return $true
}

function Commit-ReuseStateAndRefreshTools {
    $WorkingBuildEnv = Join-Path $Root ('.build.env.reuse.{0}.{1}.tmp' -f $PID, [guid]::NewGuid().ToString('N'))
    Copy-Item -LiteralPath $BuildEnvPath -Destination $WorkingBuildEnv -Force
    $PreviousBuildEnvFile = $env:BUILD_ENV_FILE
    $HadBuildEnvFile = Test-Path Env:BUILD_ENV_FILE

    try {
        Set-BuildEnvValue -Key 'BASE_IMAGE' -Value $script:ReuseResolvedRef -Path $WorkingBuildEnv
        Set-BuildEnvValue -Key 'SQUID_BASE_IMAGE' -Value $script:ReuseResolvedRef -Path $WorkingBuildEnv
        if ($script:ReuseResolvedConfigId -match '^sha256:[0-9a-f]{64}$') {
            Set-BuildEnvValue -Key 'HARDENED_CONFIG_ID' -Value $script:ReuseResolvedConfigId -Path $WorkingBuildEnv
        }
        Update-PackageVersionInBuildEnv -Path $WorkingBuildEnv

        $env:BUILD_ENV_FILE = $WorkingBuildEnv
        Write-Host '[reuse] Refreshing downloadable-tool hashes and the current ucode immutable commit in a staged build-env...' -ForegroundColor Cyan
        & scripts\supply-chain\resolve-tool-artifacts.ps1 -Write
        if ($LASTEXITCODE -ne 0) { throw 'tool-artifact refresh failed.' }

        $null = & (Join-Path $Root 'scripts\common\Load-BuildEnv.ps1') -EnvFile $WorkingBuildEnv
        Move-Item -LiteralPath $WorkingBuildEnv -Destination $BuildEnvPath -Force
        Write-Host '[reuse] Verified hardened-base state and refreshed tool pins committed to .build.env.' -ForegroundColor Green
    }
    finally {
        if ($HadBuildEnvFile) { $env:BUILD_ENV_FILE = $PreviousBuildEnvFile }
        else { Remove-Item Env:BUILD_ENV_FILE -ErrorAction SilentlyContinue }
        if (Test-Path $WorkingBuildEnv) { Remove-Item -LiteralPath $WorkingBuildEnv -Force -ErrorAction SilentlyContinue }
    }
}

function Invoke-FullInputResolutionAndHardening {
    Write-Host '[build] Running full resolver + hardened-base build path.' -ForegroundColor Cyan
    Write-Host '[build] Resolver changes are staged in a temporary build-env and committed only after hardening succeeds.' -ForegroundColor DarkGray

    $WorkingBuildEnv = Join-Path $Root ('.build.env.full-build.{0}.{1}.tmp' -f $PID, [guid]::NewGuid().ToString('N'))
    Copy-Item -LiteralPath $BuildEnvPath -Destination $WorkingBuildEnv -Force
    $PreviousBuildEnvFile = $env:BUILD_ENV_FILE
    $HadBuildEnvFile = Test-Path Env:BUILD_ENV_FILE

    try {
        $env:BUILD_ENV_FILE = $WorkingBuildEnv

        & scripts\supply-chain\resolve-base-digests.ps1 -Write
        if ($LASTEXITCODE -ne 0) { throw 'Base digest resolver failed.' }
        & scripts\supply-chain\resolve-tool-artifacts.ps1 -Write
        if ($LASTEXITCODE -ne 0) { throw 'Tool artifact resolver failed.' }

        # Capture the immutable upstream Ubuntu digest from the staged env. The
        # active .build.env still points at the previous hardened base until the
        # new hardened base has completed successfully.
        $ResolvedInputs = & (Join-Path $Root 'scripts\common\Load-BuildEnv.ps1') -EnvFile $WorkingBuildEnv
        $SourceImage = $ResolvedInputs['BASE_IMAGE']

        if ($ExpectedHardeningMode -eq 'poc') {
            & scripts\hardening\build-hardened-base.ps1 -SandboxType 'POC' -SourceImage $SourceImage -BuildEnvFile $WorkingBuildEnv
            if ($LASTEXITCODE -ne 0) { throw 'POC hardened-base build failed.' }
        }
        else {
            if ([string]::IsNullOrWhiteSpace($UbuntuProToken)) {
                throw 'Ubuntu Pro token is required because the Production hardened base must be rebuilt.'
            }
            & scripts\hardening\build-hardened-base.ps1 `
                -SandboxType $SandboxType `
                -UbuntuProToken $UbuntuProToken `
                -SourceImage $SourceImage `
                -BuildEnvFile $WorkingBuildEnv
            if ($LASTEXITCODE -ne 0) { throw 'Production hardened-base build failed.' }
        }

        Apply-HardenedBaseEnvironment -TargetPath $WorkingBuildEnv
        Update-PackageVersionInBuildEnv -Path $WorkingBuildEnv
        $null = & (Join-Path $Root 'scripts\common\Load-BuildEnv.ps1') -EnvFile $WorkingBuildEnv

        # Same-directory rename/replace: the previous active build env is not
        # touched until the entire resolver + hardening transaction is valid.
        Move-Item -LiteralPath $WorkingBuildEnv -Destination $BuildEnvPath -Force
        Write-Host '[build] New hardened-base state committed to .build.env.' -ForegroundColor Green
    }
    finally {
        if ($HadBuildEnvFile) { $env:BUILD_ENV_FILE = $PreviousBuildEnvFile }
        else { Remove-Item Env:BUILD_ENV_FILE -ErrorAction SilentlyContinue }
        if (Test-Path $WorkingBuildEnv) { Remove-Item -LiteralPath $WorkingBuildEnv -Force -ErrorAction SilentlyContinue }
    }
}

# -----------------------------------------------------------------------------
# [0] Optional migration of a previously resolved .build.env.
# -----------------------------------------------------------------------------
if (-not [string]::IsNullOrWhiteSpace($BuildEnvSource)) {
    $ResolvedSource = (Resolve-Path $BuildEnvSource).Path
    $ResolvedTarget = [IO.Path]::GetFullPath($BuildEnvPath)
    if ($ResolvedSource -ne $ResolvedTarget) {
        Copy-Item -LiteralPath $ResolvedSource -Destination $BuildEnvPath -Force
        Write-Host "[INFO] Copied existing build configuration: $ResolvedSource -> $BuildEnvPath" -ForegroundColor Yellow
    }
}

if (-not (Test-Path $BuildEnvPath)) {
    Copy-Item '.build.env.example' $BuildEnvPath
    Write-Host '[INFO] Created .build.env from .build.env.example.' -ForegroundColor Yellow
}
# Package/release metadata is updated only when a full-build or reuse transaction succeeds.

# -----------------------------------------------------------------------------
# [1] Attempt reuse only when explicitly requested.
# -----------------------------------------------------------------------------
$UsingReusedHardenedBase = $false
if ($ReuseHardenedBase) {
    $UsingReusedHardenedBase = Test-ReusableHardenedBase
    if ($UsingReusedHardenedBase) {
        Commit-ReuseStateAndRefreshTools
    }
    else {
        Write-Warning '[reuse] Reuse requirements were not met. Falling back automatically to a new hardened-base build.'
    }
}

# -----------------------------------------------------------------------------
# [2] Normal path or automatic fallback.
# -----------------------------------------------------------------------------
if (-not $UsingReusedHardenedBase) {
    Invoke-FullInputResolutionAndHardening
}
else {
    Write-Host '[reuse] Skipping upstream base-image resolution and hardened-base generation for this iterative build.' -ForegroundColor Green
    Write-Host '[reuse] Tool hashes and any restored scratch-registry digest were already committed transactionally.' -ForegroundColor DarkGray
}

# Final strict validation before building runtime images, regardless of path.
$null = & (Join-Path $Root 'scripts\common\Load-BuildEnv.ps1') -EnvFile $BuildEnvPath

# -----------------------------------------------------------------------------
# [3] Build/distribute final images.
# -----------------------------------------------------------------------------
if ($ResolvedDeploymentType -eq 'tar') {
    Write-Host "=== Admin image: $SandboxType / deployment: TAR ===" -ForegroundColor Cyan
    if ($UsingReusedHardenedBase) { Write-Host "[reuse] $SandboxType hardened base reused." -ForegroundColor Green }

    & scripts\tar\build-and-export.ps1 -SandboxType $SandboxType -SkipCisAssessment:$SkipCisAssessment
    if ($LASTEXITCODE -ne 0) { throw "$SandboxType TAR build/export failed." }

    Write-Host '[OK] TAR bundle ready under tar\images.' -ForegroundColor Green
    Write-Host 'Developer action: use the TAR Developer package and scripts\tar\load-and-start.ps1.' -ForegroundColor Green
    exit 0
}

Write-Host "=== Admin image: $SandboxType / deployment: ECR ===" -ForegroundColor Cyan
if ($UsingReusedHardenedBase) { Write-Host "[reuse] $SandboxType hardened base reused; hardening was not rerun." -ForegroundColor Green }

& scripts\platform\02-setup-ecr.ps1 -SandboxType $SandboxType -SkipCisAssessment:$SkipCisAssessment
if ($LASTEXITCODE -ne 0) { throw "$SandboxType ECR build/push failed." }

Write-Host "[OK] $SandboxType images pushed to ECR with approved digests." -ForegroundColor Green
Write-Host '[OK] Central approved-image manifest published to SSM when publication is enabled.' -ForegroundColor Green
