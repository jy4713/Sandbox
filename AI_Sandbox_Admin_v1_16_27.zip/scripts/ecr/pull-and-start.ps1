#Requires -Version 7.4
# =============================================================================
# PACKAGE MAINTENANCE NOTES
# Purpose:
#   Developer Production launcher. Fetches the centrally approved two-image
#   manifest from AWS SSM, validates it, pulls exact ECR digests, and starts
#   DevContainer + Squid.
#
# Logging:
#   Requires the Admin-prepared SYSTEM-owned Windows log root. Runtime containers
#   mount it read-only; a SYSTEM scheduled task exports Docker streams to it.
# =============================================================================
[CmdletBinding()]
param(
    [string]$SandboxDir = (Split-Path -Parent (Split-Path -Parent $PSScriptRoot))
)

$ErrorActionPreference = 'Stop'
$ComposeFile = Join-Path $SandboxDir 'docker-compose.yml'
$EnvFile = Join-Path $SandboxDir '.env'
$EnvTemplate = Join-Path $SandboxDir '.env.example'

function Read-KeyValueFile {
    param([Parameter(Mandatory = $true)][string]$Path)
    $Map = @{}
    Get-Content $Path | ForEach-Object {
        $Line = $_.TrimEnd("`r")
        if ($Line -and -not $Line.TrimStart().StartsWith('#')) {
            $Index = $Line.IndexOf('=')
            if ($Index -gt 0) {
                $Map[$Line.Substring(0, $Index).Trim()] = $Line.Substring($Index + 1).Trim()
            }
        }
    }
    return $Map
}

function Test-ConfiguredValue {
    param([string]$Value)
    return (
        -not [string]::IsNullOrWhiteSpace($Value) -and
        $Value -notmatch '[<>]' -and
        $Value -notlike '*REPLACE_*' -and
        $Value -ne 'yourname'
    )
}

if (-not (Test-Path $ComposeFile)) { throw "Missing $ComposeFile" }
if (-not (Test-Path $EnvFile)) {
    Copy-Item $EnvTemplate $EnvFile
    Write-Host "Created $EnvFile. Configure runtime values and rerun. Protect .env if AWS static credentials are used." -ForegroundColor Yellow
    exit 2
}


$ProtectedLogSystemSid = 'S-1-5-18'
$ProtectedLogWriteMask = [Security.AccessControl.FileSystemRights]::WriteData `
    -bor [Security.AccessControl.FileSystemRights]::AppendData `
    -bor [Security.AccessControl.FileSystemRights]::CreateDirectories `
    -bor [Security.AccessControl.FileSystemRights]::WriteAttributes `
    -bor [Security.AccessControl.FileSystemRights]::WriteExtendedAttributes `
    -bor [Security.AccessControl.FileSystemRights]::Delete `
    -bor [Security.AccessControl.FileSystemRights]::DeleteSubdirectoriesAndFiles `
    -bor [Security.AccessControl.FileSystemRights]::ChangePermissions `
    -bor [Security.AccessControl.FileSystemRights]::TakeOwnership

function Get-ProtectedLogRuleSid([Security.Principal.IdentityReference]$IdentityReference) {
    try { return $IdentityReference.Translate([Security.Principal.SecurityIdentifier]).Value }
    catch { return $IdentityReference.Value }
}

function Assert-ProtectedLogAcl([string]$Path) {
    $Acl = Get-Acl -LiteralPath $Path
    try { $OwnerSid = ([Security.Principal.NTAccount]::new($Acl.Owner)).Translate([Security.Principal.SecurityIdentifier]).Value }
    catch { $OwnerSid = $Acl.Owner }
    if ($OwnerSid -ne $ProtectedLogSystemSid -and $Acl.Owner -notmatch 'SYSTEM') {
        throw "Security check failed: protected log path '$Path' is not owned by LOCALSYSTEM."
    }
    foreach ($Rule in $Acl.Access) {
        if ($Rule.AccessControlType -ne [Security.AccessControl.AccessControlType]::Allow) { continue }
        $RuleSid = Get-ProtectedLogRuleSid -IdentityReference $Rule.IdentityReference
        if ((([int64]$Rule.FileSystemRights -band [int64]$ProtectedLogWriteMask) -ne 0) -and $RuleSid -ne $ProtectedLogSystemSid) {
            throw "Security check failed: non-SYSTEM principal '$($Rule.IdentityReference)' has write/modify/delete rights on protected log path '$Path'."
        }
    }
}

function Assert-ProtectedLogRoot {
    param([hashtable]$Runtime)
    if (-not (Test-ConfiguredValue $Runtime['SANDBOX_LOG_ROOT'])) {
        throw 'SANDBOX_LOG_ROOT is missing or still a placeholder in .env. Ask the Sandbox Admin to run scripts\platform\03-setup-logging.ps1 first.'
    }
    $LogRoot = [IO.Path]::GetFullPath($Runtime['SANDBOX_LOG_ROOT'].Replace('/', '\'))
    if (-not (Test-Path -LiteralPath $LogRoot -PathType Container)) {
        throw "Protected host log root is missing: $LogRoot. Ask the Sandbox Admin to run scripts\platform\03-setup-logging.ps1."
    }
    Assert-ProtectedLogAcl -Path $LogRoot
    foreach ($Subdir in @('devcontainer','squid')) {
        $Path = Join-Path $LogRoot $Subdir
        if (-not (Test-Path -LiteralPath $Path -PathType Container)) {
            throw "Protected host log directory is missing: $Path. Ask the Sandbox Admin to run scripts\platform\03-setup-logging.ps1."
        }
        Assert-ProtectedLogAcl -Path $Path
        $Probe = Join-Path $Path ('.developer-write-probe-' + [guid]::NewGuid().ToString('N'))
        $Writable = $false
        try {
            [IO.File]::WriteAllText($Probe, 'probe', [Text.UTF8Encoding]::new($false))
            $Writable = $true
        }
        catch [UnauthorizedAccessException] { }
        catch [IO.IOException] { }
        finally {
            if (Test-Path -LiteralPath $Probe) { Remove-Item -LiteralPath $Probe -Force -ErrorAction SilentlyContinue }
        }
        if ($Writable) {
            throw "Security check failed: the current Windows user can write to protected log directory $Path. Re-apply the Admin/SYSTEM ACL with scripts\platform\03-setup-logging.ps1."
        }
    }
}

$Runtime = Read-KeyValueFile -Path $EnvFile
Assert-ProtectedLogRoot -Runtime $Runtime
foreach ($Key in @('DEVELOPER_ID', 'ECR_REGISTRY')) {
    if (-not (Test-ConfiguredValue $Runtime[$Key])) {
        throw "$Key is missing or still a placeholder in .env"
    }
}

$Region = if ($Runtime.AWS_REGION) { $Runtime.AWS_REGION } else { 'eu-west-2' }
$Profile = if ($Runtime.SANDBOX_AWS_PROFILE) { $Runtime.SANDBOX_AWS_PROFILE } else { 'sandbox' }
$Prefix = if ($Runtime.SSM_PREFIX) { $Runtime.SSM_PREFIX.TrimEnd('/') } else { '/sandbox' }
$Registry = $Runtime.ECR_REGISTRY.TrimEnd('/')
$ManifestParameter = if ($Runtime.APPROVED_IMAGES_SSM_PARAMETER) {
    $Runtime.APPROVED_IMAGES_SSM_PARAMETER
}
else {
    "$Prefix/runtime/approved-images-json"
}

$HasAccessKey = Test-ConfiguredValue $Runtime.AWS_ACCESS_KEY_ID
$HasSecretKey = Test-ConfiguredValue $Runtime.AWS_SECRET_ACCESS_KEY
$HasSessionToken = Test-ConfiguredValue $Runtime.AWS_SESSION_TOKEN
if ($HasAccessKey -xor $HasSecretKey) { throw 'AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY must be configured together. Partial static credentials do not fall back to SSO.' }
if ($HasSessionToken -and -not ($HasAccessKey -and $HasSecretKey)) { throw 'AWS_SESSION_TOKEN requires AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY.' }
$UseStaticAws = $HasAccessKey -and $HasSecretKey

function Invoke-AwsCli {
    param([Parameter(Mandatory = $true)][string[]]$Arguments)
    if ($script:UseStaticAws) { & aws @Arguments } else { & aws --profile $script:Profile @Arguments }
}

function Initialize-AwsSsoProfile {
    param([hashtable]$Runtime,[string]$Profile,[string]$Region)
    $Required=@('AWS_SSO_START_URL','AWS_SSO_REGION','AWS_SSO_ACCOUNT_ID','AWS_SSO_ROLE_NAME')
    $Missing=@($Required | Where-Object { -not (Test-ConfiguredValue $Runtime[$_]) })
    if($Missing.Count){
        throw "Admin SSO bootstrap values are missing from .env: $($Missing -join ', '). Developers should not need to run aws configure sso manually."
    }
    if($Runtime.AWS_SSO_ACCOUNT_ID -notmatch '^[0-9]{12}$'){throw 'AWS_SSO_ACCOUNT_ID must be a 12-digit account ID'}
    if($Runtime.AWS_SSO_START_URL -notmatch '^https://'){throw 'AWS_SSO_START_URL must use https://'}
    $Session=if(Test-ConfiguredValue $Runtime.AWS_SSO_SESSION){$Runtime.AWS_SSO_SESSION}else{$Profile}
    $AwsDir=Join-Path $HOME '.aws'; $Config=Join-Path $AwsDir 'config'
    New-Item -ItemType Directory -Force -Path $AwsDir | Out-Null
    $Existing=if(Test-Path $Config){Get-Content $Config -Raw}else{''}
    $Existing=[regex]::Replace($Existing,'(?ms)^# BEGIN AI-SANDBOX MANAGED SSO\r?\n.*?^# END AI-SANDBOX MANAGED SSO\r?\n?','')
    $Block=@"
# BEGIN AI-SANDBOX MANAGED SSO
# Non-secret profile generated by the AI Sandbox Production launcher.
[sso-session $Session]
sso_start_url = $($Runtime.AWS_SSO_START_URL)
sso_region = $($Runtime.AWS_SSO_REGION)
sso_registration_scopes = sso:account:access

[default]
sso_session = $Session
sso_account_id = $($Runtime.AWS_SSO_ACCOUNT_ID)
sso_role_name = $($Runtime.AWS_SSO_ROLE_NAME)
region = $Region
output = json

[profile $Profile]
sso_session = $Session
sso_account_id = $($Runtime.AWS_SSO_ACCOUNT_ID)
sso_role_name = $($Runtime.AWS_SSO_ROLE_NAME)
region = $Region
output = json
# END AI-SANDBOX MANAGED SSO
"@
    [IO.File]::WriteAllText($Config,($Existing.TrimEnd()+"`r`n"+$Block),[Text.UTF8Encoding]::new($false))
}

# Runtime records are Docker-owned stdout/stderr first, then a SYSTEM host exporter copies them into the protected Windows log folder. Containers mount that folder read-only.

# Authentication priority: static environment credentials first; SSO fallback.
# No redundant AWS identity preflight is used. The first required
# SSM read is the real authentication/authorization check for this launcher.
if ($UseStaticAws) {
    $env:AWS_ACCESS_KEY_ID = $Runtime.AWS_ACCESS_KEY_ID
    $env:AWS_SECRET_ACCESS_KEY = $Runtime.AWS_SECRET_ACCESS_KEY
    if ($HasSessionToken) { $env:AWS_SESSION_TOKEN = $Runtime.AWS_SESSION_TOKEN } else { Remove-Item Env:AWS_SESSION_TOKEN -ErrorAction SilentlyContinue }
    Remove-Item Env:AWS_PROFILE,Env:AWS_DEFAULT_PROFILE -ErrorAction SilentlyContinue
    Write-Host 'AWS authentication mode: static environment credentials. Validation is deferred to SSM/ECR.' -ForegroundColor Cyan
}
else {
    Remove-Item Env:AWS_ACCESS_KEY_ID,Env:AWS_SECRET_ACCESS_KEY,Env:AWS_SESSION_TOKEN -ErrorAction SilentlyContinue
    Initialize-AwsSsoProfile -Runtime $Runtime -Profile $Profile -Region $Region
    Write-Host "AWS authentication mode: IAM Identity Center profile '$Profile'. Validation is deferred to SSM/ECR." -ForegroundColor Cyan
}

$script:SsoLoginAttempted = $false
function Test-AwsAuthenticationFailure {
    param([string]$Text)
    if ([string]::IsNullOrWhiteSpace($Text)) { return $false }
    return $Text -match '(?i)SSO session|Error loading SSO Token|token.*(expired|invalid|does not exist)|expired.*token|invalid_grant|login required|credentials.*(expired|invalid|not found|unable)|UnauthorizedException'
}
function Invoke-SandboxSsoLogin {
    if ($script:UseStaticAws) { return }
    if ($script:SsoLoginAttempted) { return }
    $script:SsoLoginAttempted = $true
    Write-Host "AWS SSO login required for profile '$($script:Profile)'. Opening the host browser..." -ForegroundColor Yellow
    & aws sso login --profile $script:Profile
    if ($LASTEXITCODE -ne 0) {
        Write-Host 'Automatic browser launch failed; falling back to device-code login.' -ForegroundColor Yellow
        & aws sso login --profile $script:Profile --use-device-code --no-browser
        if ($LASTEXITCODE -ne 0) { throw 'AWS SSO login failed' }
    }
}

function Get-SsmValue {
    param([Parameter(Mandatory = $true)][string]$Name)
    $Value = @(Invoke-AwsCli -Arguments @(
        'ssm','get-parameter',
        '--name',$Name,
        '--region',$Region,
        '--query','Parameter.Value',
        '--output','text'
    ) 2>&1)
    $FirstExit = $LASTEXITCODE
    $FirstText = ($Value | ForEach-Object { $_.ToString() }) -join "`n"
    if ($FirstExit -ne 0 -and -not $script:UseStaticAws -and -not $script:SsoLoginAttempted -and (Test-AwsAuthenticationFailure $FirstText)) {
        Write-Warning $FirstText
        Invoke-SandboxSsoLogin
        $Value = @(Invoke-AwsCli -Arguments @(
            'ssm','get-parameter',
            '--name',$Name,
            '--region',$Region,
            '--query','Parameter.Value',
            '--output','text'
        ) 2>&1)
    }
    if ($LASTEXITCODE -ne 0) { throw "Cannot read SSM parameter: $Name" }
    return (($Value | ForEach-Object { $_.ToString() }) -join "`n").Trim()
}

$ManifestJson = Get-SsmValue -Name $ManifestParameter
$ExpectedHash = (Get-SsmValue -Name "$ManifestParameter-sha256").ToLowerInvariant()
$Sha = [Security.Cryptography.SHA256]::Create()
try {
    $ActualHash = ([BitConverter]::ToString(
        $Sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($ManifestJson))
    )).Replace('-', '').ToLowerInvariant()
}
finally {
    $Sha.Dispose()
}
if ($ExpectedHash -ne $ActualHash) {
    throw 'Approved manifest SHA-256 validation failed'
}

$Manifest = $ManifestJson | ConvertFrom-Json
if ([string]$Manifest.registry -ne $Registry) { throw 'Manifest registry mismatch' }
$ManifestSandboxType=([string]$Manifest.sandboxType).ToLowerInvariant()
if($ManifestSandboxType -notin @('poc','production')){throw 'Approved manifest sandboxType must be poc or production.'}
if(([string]$Manifest.deploymentType).ToLowerInvariant() -ne 'ecr'){throw 'Approved manifest deploymentType must be ecr.'}

function Assert-ApprovedImageReference {
    param([string]$Image, [string]$Repository)
    $Prefix = "$Registry/ai-sandbox/$Repository@sha256:"
    if (-not $Image.StartsWith($Prefix, [StringComparison]::Ordinal)) {
        throw "Invalid approved $Repository image reference"
    }
    $DigestHex = $Image.Substring($Prefix.Length)
    if ($DigestHex -notmatch '^[0-9a-f]{64}$') {
        throw "Invalid approved $Repository digest"
    }
}

$DevImage = [string]$Manifest.images.devcontainer.full
$SquidImage = [string]$Manifest.images.squid.full
Assert-ApprovedImageReference -Image $DevImage -Repository 'devcontainer'
Assert-ApprovedImageReference -Image $SquidImage -Repository 'squid'
Write-Host "Approved release: $($Manifest.releaseTag)" -ForegroundColor Green

$Password = Invoke-AwsCli -Arguments @('ecr','get-login-password','--region',$Region)
if ($LASTEXITCODE -ne 0) { throw 'Unable to obtain ECR login password' }
$Password | docker login --username AWS --password-stdin $Registry | Out-Null
if ($LASTEXITCODE -ne 0) { throw 'ECR login failed' }

$Images = @(
    @($DevImage, 'sandbox/approved-devcontainer:current'),
    @($SquidImage, 'sandbox/approved-squid:current')
)
foreach ($Pair in $Images) {
    & docker pull $Pair[0] | Out-Null
    if ($LASTEXITCODE -ne 0) { throw "Pull failed: $($Pair[0])" }
    & docker tag $Pair[0] $Pair[1]
    if ($LASTEXITCODE -ne 0) { throw "Local runtime tag failed: $($Pair[1])" }
}

$PreviousSandboxEnv=$env:SANDBOX_ENV
try {
    $env:SANDBOX_ENV=$ManifestSandboxType
    & docker compose --env-file $EnvFile -f $ComposeFile config | Out-Null
    if ($LASTEXITCODE -ne 0) { throw 'Compose validation failed' }
    & docker compose --env-file $EnvFile -f $ComposeFile up -d --force-recreate
    if ($LASTEXITCODE -ne 0) { throw 'Compose start failed' }
}
finally {
    if ($null -eq $PreviousSandboxEnv) { Remove-Item Env:SANDBOX_ENV -ErrorAction SilentlyContinue } else { $env:SANDBOX_ENV=$PreviousSandboxEnv }
}

Write-Host "[OK] Approved $ManifestSandboxType ECR sandbox started." -ForegroundColor Green
Write-Host "[OK] Runtime logs are Docker-owned streams and are exported by SYSTEM to $($Runtime['SANDBOX_LOG_ROOT'])." -ForegroundColor Green
