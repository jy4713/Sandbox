#!/usr/bin/env python3
"""Fail-closed Admin policy proxy for the local Tavily MCP server.

The proxy sits between the MCP client and the real Tavily MCP process. It
normalizes every supported web operation to the root-owned allowlist and blocks
an explicit hostname in the search query when that hostname is not approved.
No prompt/query/result content is logged.
"""
from __future__ import annotations

import json
import os
import re
import subprocess
import sys
import threading
from pathlib import Path
from urllib.parse import urlparse

POLICY_PATH = Path(os.environ.get("TAVILY_POLICY_FILE", "/etc/ai-sandbox/tavily-allowed-domains.json"))
DOMAIN_TOKEN_RE = re.compile(
    r"(?i)(?<![@a-z0-9_.-])(?:https?://)?(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}(?::\d+)?(?:/[^\s\"'<>]*)?"
)


def fail(message: str) -> None:
    print(f"ERROR: {message}", file=sys.stderr)
    raise SystemExit(1)


def load_allowed_domains() -> tuple[str, ...]:
    try:
        data = json.loads(POLICY_PATH.read_text(encoding="utf-8"))
    except Exception as exc:
        fail(f"cannot load Tavily policy: {exc}")
    raw = data.get("allowed_domains")
    if not isinstance(raw, list) or not raw:
        fail("Tavily policy contains no allowed_domains")
    out: list[str] = []
    for item in raw:
        if not isinstance(item, str):
            fail("Tavily policy contains a non-string domain")
        d = item.strip().lower().rstrip(".")
        if not re.fullmatch(r"[a-z0-9.-]+", d) or ".." in d or d.startswith("-"):
            fail("Tavily policy contains an invalid domain")
        out.append(d)
    return tuple(dict.fromkeys(out))


ALLOWED = load_allowed_domains()


def hostname_from_domain(value: str) -> str:
    value = value.strip().lower()
    if value.startswith("*."):
        value = value[2:]
    if "://" in value:
        parsed = urlparse(value)
        return (parsed.hostname or "").lower().rstrip(".")
    value = value.split("/", 1)[0]
    value = value.split(":", 1)[0]
    return value.rstrip(".")


def is_allowed_host(host: str) -> bool:
    host = host.lower().rstrip(".")
    return any(host == allowed or host.endswith("." + allowed) for allowed in ALLOWED)


def explicit_domains_from_query(value: object) -> list[str]:
    if not isinstance(value, str):
        return []
    out: list[str] = []
    for match in DOMAIN_TOKEN_RE.finditer(value):
        host = hostname_from_domain(match.group(0))
        if host:
            out.append(host)
    return list(dict.fromkeys(out))


def validate_domain_list(values: object) -> tuple[list[str], list[str]]:
    if not isinstance(values, list):
        return [], ["<invalid include_domains type>"]
    good: list[str] = []
    bad: list[str] = []
    for item in values:
        if not isinstance(item, str):
            bad.append("<non-string domain>")
            continue
        host = hostname_from_domain(item)
        if host and is_allowed_host(host):
            good.append(host)
        else:
            bad.append(item)
    return list(dict.fromkeys(good)), bad


def include_covers(host: str, include_domain: str) -> bool:
    return host == include_domain or host.endswith("." + include_domain)


def validate_url(value: object) -> tuple[bool, str]:
    if not isinstance(value, str):
        return False, "<non-string URL>"
    parsed = urlparse(value)
    host = (parsed.hostname or "").lower().rstrip(".")
    if parsed.scheme != "https" or not host or not is_allowed_host(host):
        return False, value
    return True, host


def denial(request_id: object, reason: str) -> dict:
    return {
        "jsonrpc": "2.0",
        "id": request_id,
        "error": {
            "code": -32001,
            "message": "Tavily request denied by Admin domain policy",
            "data": {"reason": reason, "allowed_domains": list(ALLOWED)},
        },
    }


def enforce_tool_call(message: dict) -> tuple[dict | None, dict | None]:
    if message.get("method") != "tools/call":
        return message, None
    params = message.get("params")
    if not isinstance(params, dict):
        return message, None
    name = params.get("name")
    arguments = params.get("arguments")
    if not isinstance(arguments, dict):
        arguments = {}
        params["arguments"] = arguments

    if name == "tavily_search":
        query_domains = explicit_domains_from_query(arguments.get("query"))
        blocked_query_domains = [d for d in query_domains if not is_allowed_host(d)]
        if blocked_query_domains:
            return None, denial(
                message.get("id"),
                "search query explicitly requests a domain outside the Admin allowlist",
            )

        requested = arguments.get("include_domains")
        if requested in (None, []):
            # If the user explicitly named an approved hostname, constrain the
            # search to that hostname. Otherwise constrain it to the full Admin
            # allowlist. An unconstrained public-web search is never emitted.
            arguments["include_domains"] = query_domains or list(ALLOWED)
            return message, None

        approved, rejected = validate_domain_list(requested)
        if rejected or not approved:
            return None, denial(message.get("id"), "include_domains contains a domain outside the Admin allowlist")

        # If the query explicitly names an approved domain, the include list
        # must cover it. Then narrow the call to exactly the explicit approved
        # hostname(s), preventing a model from silently searching other allowed
        # sites when the user requested one specific site.
        if query_domains:
            if any(not any(include_covers(q, inc) for inc in approved) for q in query_domains):
                return None, denial(message.get("id"), "include_domains does not match the explicitly requested domain")
            arguments["include_domains"] = query_domains
        else:
            arguments["include_domains"] = approved
        return message, None

    if name == "tavily_extract":
        urls = arguments.get("urls")
        if not isinstance(urls, list) or not urls:
            return None, denial(message.get("id"), "extract requires one or more approved HTTPS URLs")
        if any(not validate_url(u)[0] for u in urls):
            return None, denial(message.get("id"), "extract URL is outside the Admin allowlist")
        return message, None

    if name in {"tavily_crawl", "tavily_map"}:
        ok, host_or_value = validate_url(arguments.get("url"))
        if not ok:
            return None, denial(message.get("id"), "crawl/map root URL is outside the Admin allowlist")
        arguments["allow_external"] = False
        arguments["select_domains"] = [rf"^{re.escape(host_or_value)}$"]
        return message, None

    if name == "tavily_research":
        # v0.2.21 research has no enforceable domain constraint.
        return None, denial(message.get("id"), "tavily_research has no domain constraint and is disabled by policy")

    return message, None


def main() -> int:
    if len(sys.argv) < 2:
        fail("usage: tavily-policy-proxy.py <real-tavily-mcp> [args...]")
    child = subprocess.Popen(
        sys.argv[1:],
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=None,
        env=os.environ.copy(),
        bufsize=0,
    )
    assert child.stdin is not None and child.stdout is not None

    def server_to_client() -> None:
        try:
            for raw in iter(child.stdout.readline, b""):
                sys.stdout.buffer.write(raw)
                sys.stdout.buffer.flush()
        finally:
            try:
                sys.stdout.buffer.flush()
            except Exception:
                pass

    relay = threading.Thread(target=server_to_client, name="tavily-mcp-relay", daemon=True)
    relay.start()

    try:
        for raw in iter(sys.stdin.buffer.readline, b""):
            outbound = raw
            try:
                msg = json.loads(raw.decode("utf-8"))
                if isinstance(msg, dict):
                    allowed_msg, denied_msg = enforce_tool_call(msg)
                    if denied_msg is not None:
                        if denied_msg.get("id") is not None:
                            sys.stdout.write(json.dumps(denied_msg, separators=(",", ":")) + "\n")
                            sys.stdout.flush()
                        continue
                    if allowed_msg is not None:
                        outbound = (json.dumps(allowed_msg, separators=(",", ":")) + "\n").encode("utf-8")
            except Exception:
                # Protocol parse failures are left to the real MCP server; never
                # reinterpret arbitrary payload text as policy input.
                outbound = raw
            try:
                child.stdin.write(outbound)
                child.stdin.flush()
            except BrokenPipeError:
                break
    finally:
        try:
            child.stdin.close()
        except Exception:
            pass
    return child.wait()


if __name__ == "__main__":
    raise SystemExit(main())
