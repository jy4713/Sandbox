# AI Secure Sandbox v1.16.17 Release Notes

## Scope

v1.16.17 is a hardened-base reuse reliability and lint-maintainability release. It does not intentionally change the two-container runtime architecture, SSM secret model, MCP routing, Tavily domain policy, or Developer workflow.

## Hardened-base reuse fixes

- Full fallback builds are now transactional. Base/tool resolvers write to a temporary build-env and the active `.build.env` is replaced only after the new hardened base succeeds and validates.
- A failed or interrupted fallback therefore preserves the previous `BASE_IMAGE` / `SQUID_BASE_IMAGE` hardened digest instead of leaving Ubuntu upstream digests behind.
- The Admin-host-only localhost digest registry uses a persistent Docker volume, `--restart unless-stopped`, and a loopback-only host binding.
- When an exact localhost digest is not materialized, reuse can recover it from a local image only when that image can be tied to the requested digest; the repushed manifest digest is verified before reuse.
- Newly built hardened images carry `hardening.source.image` and `hardening.ssg.sha256` provenance labels, with matching non-secret provenance values recorded in `.build.env`.
- Existing v1.16.16 hardened images remain reusable through the legacy exact-digest + `hardening.method` + `hardening.profile` validation path.

## Lint fixes

- Removed hard-coded package-version assertions from lint logic. Lint now derives the package version from `.build.env.example` and checks cross-file consistency dynamically.
- Removed the stale PowerShell `v1.16.5` check.
- Moved late content-logging checks before the final lint result so they can actually fail the lint when a regression is detected.

## Build-env migration

`SANDBOX_VERSION` and `RELEASE_TAG` migration no longer contains special cases for specific old releases. A blank release tag or a tag equal to the copied build env's previous `SANDBOX_VERSION` follows the new package version; deliberately custom release tags are preserved.
