#!/usr/bin/env bash
# =============================================================================
# PACKAGE MAINTENANCE NOTES
# Purpose: Initializes a newly opened VS Code devcontainer without persisting
#          long-lived secrets. Public application commands are SSM-aware wrappers.
# Admin maintenance: Add post-create configuration only when it is safe to repeat.
#                    Application installation belongs in the Dockerfile.
# =============================================================================
set -uo pipefail
umask 027
echo '=============================================='
echo '  AI Secure Sandbox v1.16.17 - Container Init'
echo '=============================================='

git config --global safe.directory /home/vscode/workspace 2>/dev/null && echo '[1/5] Git safe.directory set' || echo '[1/5] WARN: could not set git safe.directory'

echo; echo '[2/5] Preparing AWS authentication'
if [[ -n "${AWS_ACCESS_KEY_ID:-}" || -n "${AWS_SECRET_ACCESS_KEY:-}" || -n "${AWS_SESSION_TOKEN:-}" ]]; then
  if configure-aws-sso; then
    echo '  [OK] Static AWS environment credential mode selected; SSO bootstrap is not required.'
  else
    echo '  [FAIL] Static AWS credential configuration is incomplete.'
  fi
else
  if configure-aws-sso; then
    echo '  [OK] SSO fallback profile is ready. Login will use the host-browser flow when first required.'
  else
    echo '  [WARN] No static key pair is present and SSO bootstrap values are incomplete.'
  fi
fi

echo; echo '[3/5] Configuring credential-value-free MCP definitions'
if configure-mcp; then
  echo '  [OK] Tavily/Snyk/Databricks SQL MCP configured (Gemini stores runtime AWS references only; no credential values)'
else
  echo '  [FAIL] MCP configuration failed'
fi

# MCP servers cannot start an interactive sign-in. Pre-warming the IAM Identity
# Center token cache here removes the first-tool-call stall in SSO mode.
if [[ -z "${AWS_ACCESS_KEY_ID:-}" && -z "${AWS_SECRET_ACCESS_KEY:-}" ]]; then
  if env HOME="${SANDBOX_AWS_HOME:-/home/vscode}" aws sts get-caller-identity \
       --profile "${SANDBOX_AWS_PROFILE:-sandbox}" --region "${AWS_REGION:-eu-west-2}" >/dev/null 2>&1; then
    echo '  [OK] IAM Identity Center session is already valid; MCP servers can start immediately.'
  else
    echo '  [ACTION] SSO mode detected with no active session.'
    echo '           Run `sandbox-aws-login` in this terminal BEFORE using Tavily/Snyk/Databricks SQL MCP.'
    echo '           MCP stdio servers cannot display a device-code prompt themselves.'
  fi
fi

echo; echo '[4/5] Runtime security verification'
if verify-runtime; then verify_status=PASSED; else verify_status=FAILED; fi

echo; echo '[5/5] Egress checks'
probe_allow(){ local l="$1" u="$2" c; c=$(curl -s -o /dev/null -w '%{http_code}' --max-time 8 "$u" 2>/dev/null || echo 000); if [[ "$c" =~ ^[234] ]]; then echo "  [OK]   allowed: $l"; elif [[ "$c" == 403 || "$c" == 407 ]]; then echo "  [FAIL] blocked but should be allowed: $l (HTTP $c)"; else echo "  [WARN] $l response HTTP $c"; fi; }
probe_block(){ local l="$1" u="$2" c; c=$(curl -s -o /dev/null -w '%{http_code}' --max-time 8 "$u" 2>/dev/null || echo 000); if [[ "$c" == 000 || "$c" == 403 || "$c" == 407 ]]; then echo "  [OK]   blocked: $l"; else echo "  [FAIL] NOT blocked: $l (HTTP $c)"; fi; }
probe_allow 'GitHub' 'https://github.com'
probe_allow 'npm registry' 'https://registry.npmjs.org'
probe_allow 'Azure DevOps' 'https://dev.azure.com'
probe_allow 'AWS SSM' "https://ssm.${AWS_REGION:-eu-west-2}.amazonaws.com"
probe_allow 'Tavily' 'https://api.tavily.com'
probe_allow 'Snyk' 'https://api.snyk.io'
probe_allow 'Anthropic API' 'https://api.anthropic.com'
probe_allow 'Google Gemini API' 'https://generativelanguage.googleapis.com'
probe_block 'arbitrary internet' 'https://example.com'
[[ -n "${DATABRICKS_HOST:-}" ]] && probe_allow 'Databricks AI Gateway' "${DATABRICKS_HOST%/}" || true
[[ -n "${HIDDENLAYER_API_URL:-}" ]] && probe_allow 'HiddenLayer approved API' "${HIDDENLAYER_API_URL%/}" || echo '  [SKIP] HiddenLayer - HIDDENLAYER_API_URL not configured'

echo; echo "Verification: $verify_status"
echo 'Developer workflow:'
echo '  1. AWS auth priority: complete AWS_ACCESS_KEY_ID/AWS_SECRET_ACCESS_KEY pair first;'
echo '     otherwise IAM Identity Center SSO is used as the fallback.'
echo '     In SSO mode, sandbox-aws-login displays a URL/code for the WINDOWS HOST browser.'
echo '  2. Command routing is explicit:'
echo '       claude       -> Anthropic official API (SSM claude-api-key)'
echo '       gemini       -> Google Gemini official API (SSM gemini-api-key)'
echo '       ucode claude -> Databricks AI Gateway (SSM databricks-token)'
echo '       ucode gemini -> Databricks AI Gateway (SSM databricks-token)'
echo '       databricks current-user me -> Databricks CLI'
echo '       snyk test    -> Snyk'
echo '  3. Tavily/Snyk/Databricks SQL are configured as MCP for Claude/Gemini automatically.'
echo '     MCP settings contain no credential values; Gemini carries only approved AWS runtime references.'
echo '     AWS auth is resolved at launch time (static key pair first, IAM Identity Center SSO otherwise).'
echo '     Tavily searches are restricted to the Admin-managed domain allowlist.
     Direct CLI is optional and follows the same allowlist: tvly search "query" --json'
echo '  Application service secrets remain child-process scoped. Static AWS bootstrap'
echo '  credentials, when selected, are runtime environment secrets and must be protected.'
[[ "$verify_status" == FAILED ]] && exit 1
