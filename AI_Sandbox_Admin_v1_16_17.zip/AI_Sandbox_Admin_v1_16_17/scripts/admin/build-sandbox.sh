#!/usr/bin/env bash
# =============================================================================
# ADMIN unified build entry point.
# v1.16.17 adds --skip-cis-assessment for POC-only fast iteration and preserves --reuse-hardened-base.
# Reuse is accepted only when .build.env is complete and the exact hardened
# digest is available and labelled for the requested hardening mode/profile.
# Otherwise the script automatically falls back to the full hardening path.
# =============================================================================
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
cd "$ROOT"
PACKAGE_VERSION='v1.16.17'

usage(){
  cat >&2 <<'EOF'
Usage:
  build-sandbox.sh <SandboxType> [UbuntuProToken] [--reuse-hardened-base] [--skip-cis-assessment] [--build-env-source PATH]

Examples:
  bash scripts/admin/build-sandbox.sh POC --reuse-hardened-base --skip-cis-assessment
  bash scripts/admin/build-sandbox.sh POC --reuse-hardened-base --build-env-source ../previous-package/.build.env
  bash scripts/admin/build-sandbox.sh Production --reuse-hardened-base
  bash scripts/admin/build-sandbox.sh Production "$UBUNTU_PRO_TOKEN"
EOF
}

TYPE="${1:-}"
[[ -n "$TYPE" ]] || { usage; exit 2; }
shift

TOKEN="${UBUNTU_PRO_TOKEN:-}"
REUSE=false
SKIP_CIS=false
BUILD_ENV_SOURCE=''
while (($#)); do
  case "$1" in
    --reuse-hardened-base)
      REUSE=true; shift ;;
    --skip-cis-assessment)
      SKIP_CIS=true; shift ;;
    --build-env-source)
      [[ $# -ge 2 ]] || { echo 'ERROR: --build-env-source requires a path.' >&2; exit 2; }
      BUILD_ENV_SOURCE="$2"; shift 2 ;;
    --ubuntu-pro-token)
      [[ $# -ge 2 ]] || { echo 'ERROR: --ubuntu-pro-token requires a value.' >&2; exit 2; }
      TOKEN="$2"; shift 2 ;;
    -h|--help)
      usage; exit 0 ;;
    --*)
      echo "ERROR: unknown option: $1" >&2; usage; exit 2 ;;
    *)
      if [[ -z "$TOKEN" ]]; then TOKEN="$1"; shift; else echo "ERROR: unexpected argument: $1" >&2; usage; exit 2; fi ;;
  esac
done

BUILD_ENV="$ROOT/.build.env"
EXPECTED_MODE='production'
[[ "${TYPE,,}" == 'poc' ]] && EXPECTED_MODE='poc'

if [[ "$SKIP_CIS" == true && "$EXPECTED_MODE" != 'poc' ]]; then
  echo 'ERROR: --skip-cis-assessment is permitted only with SandboxType POC.' >&2
  exit 2
fi
[[ "$SKIP_CIS" == true ]] && echo 'WARNING: CIS/OpenSCAP assessment will be skipped. POC/test use only; not security-assessed release evidence.' >&2

set_env_value(){
  local key="$1" value="$2" file="${3:-$BUILD_ENV}" tmp="${3:-$BUILD_ENV}.tmp.$$"
  awk -v k="$key" -v v="$value" '
    BEGIN{found=0}
    index($0,k"=")==1 {$0=k"="v; found=1}
    {print}
    END{if(!found) print k"="v}
  ' "$file" > "$tmp"
  mv "$tmp" "$file"
}

get_env_value(){
  local key="$1" file="${2:-$BUILD_ENV}"
  awk -F= -v k="$key" '$1==k {sub(/^[^=]*=/,""); print; exit}' "$file" 2>/dev/null || true
}

update_package_version(){
  local file="${1:-$BUILD_ENV}"
  [[ -f "$file" ]] || return 0
  local old_version old_release
  old_version="$(get_env_value SANDBOX_VERSION "$file")"
  old_release="$(get_env_value RELEASE_TAG "$file")"
  set_env_value SANDBOX_VERSION "$PACKAGE_VERSION" "$file"
  # Follow the package version only when RELEASE_TAG was blank or tracked the
  # previous SANDBOX_VERSION. Deliberately custom release tags are preserved.
  if [[ -z "$old_release" || "$old_release" == "$old_version" ]]; then
    set_env_value RELEASE_TAG "$PACKAGE_VERSION" "$file"
  fi
}

apply_hardened_env(){
  local target="${1:-$BUILD_ENV}" src="$ROOT/hardened-base-build/hardened-base.env" line key value
  [[ -f "$src" ]] || { echo "ERROR: hardened base environment file not found: $src" >&2; return 1; }
  local base='' squid=''
  while IFS= read -r line; do
    case "$line" in
      BASE_IMAGE=*) base="${line#*=}" ;;
      SQUID_BASE_IMAGE=*) squid="${line#*=}" ;;
      HARDENED_SOURCE_IMAGE=*|HARDENED_SSG_SHA256=*|HARDENED_METHOD=*|HARDENED_PROFILE=*)
        key="${line%%=*}"; value="${line#*=}"; set_env_value "$key" "$value" "$target" ;;
    esac
  done < "$src"
  [[ -n "$base" && -n "$squid" ]] || { echo 'ERROR: hardened-base builder did not produce BASE_IMAGE and SQUID_BASE_IMAGE.' >&2; return 1; }
  set_env_value BASE_IMAGE "$base" "$target"
  set_env_value SQUID_BASE_IMAGE "$squid" "$target"
}

validate_build_env(){
  local file="${1:-$BUILD_ENV}"
  BUILD_ENV_FILE="$file" bash -c 'source scripts/common/load-build-env.sh >/dev/null'
}

restore_local_scratch_digest_reference(){
  local ref="$1"
  if [[ ! "$ref" =~ ^(localhost:([0-9]+))/([^@]+)@(sha256:[0-9a-fA-F]{64})$ ]]; then
    return 1
  fi
  local registry="${BASH_REMATCH[1]}" port="${BASH_REMATCH[2]}" repo="${BASH_REMATCH[3]}" expected="${BASH_REMATCH[4],,}"
  local candidate='' image_ref name_without_tag candidate_repo image_id repo_digests
  while IFS= read -r image_ref; do
    [[ -n "$image_ref" && "$image_ref" != *'<none>'* ]] || continue
    name_without_tag="${image_ref%:*}"
    candidate_repo="${name_without_tag#localhost:*/}"
    [[ "$candidate_repo" == "$repo" ]] || continue
    image_id="$(docker image inspect "$image_ref" --format '{{.Id}}' 2>/dev/null || true)"
    repo_digests="$(docker image inspect "$image_ref" --format '{{json .RepoDigests}}' 2>/dev/null || true)"
    if [[ "${image_id,,}" == "$expected" || "$repo_digests" == *"$ref"* ]]; then
      candidate="$image_ref"
      break
    fi
  done < <(docker image ls --format '{{.Repository}}:{{.Tag}}' 2>/dev/null || true)

  if [[ -z "$candidate" ]]; then
    echo '[reuse] No local image can be cryptographically tied to the requested localhost digest.' >&2
    return 1
  fi

  local registry_name='ai-sandbox-hardened-base-digest-scratch-registry'
  local registry_volume='ai-sandbox-hardened-base-registry-data'
  if docker container inspect "$registry_name" >/dev/null 2>&1; then
    if [[ "$(docker inspect "$registry_name" --format '{{.State.Running}}' 2>/dev/null || true)" != 'true' ]]; then
      docker start "$registry_name" >/dev/null || return 1
    fi
  else
    docker volume create "$registry_volume" >/dev/null || return 1
    docker run -d --restart unless-stopped --name "$registry_name" \
      -p "127.0.0.1:${port}:5000" -v "${registry_volume}:/var/lib/registry" registry:2 >/dev/null || return 1
    sleep 2
  fi

  local short_digest="${expected#sha256:}" recovery_tag actual
  short_digest="${short_digest:0:12}"
  recovery_tag="${registry}/${repo}:reuse-recovery-${short_digest}"
  echo "[reuse] Restoring localhost digest from verified local image: $candidate"
  docker tag "$candidate" "$recovery_tag" >/dev/null || return 1
  docker push "$recovery_tag" >/dev/null || return 1
  actual="$(docker buildx imagetools inspect "$recovery_tag" --format '{{json .Manifest.Digest}}' 2>/dev/null | tr -d '"' || true)"
  actual="${actual,,}"
  if [[ "$actual" != "$expected" ]]; then
    echo "[reuse] Local recovery candidate produced digest '$actual', expected '$expected'; refusing reuse." >&2
    return 1
  fi
  docker pull "$ref" >/dev/null 2>&1 || return 1
  echo '[reuse] Exact localhost hardened digest was safely re-materialized.'
}

ensure_image_available(){
  local ref="$1"
  docker image inspect "$ref" >/dev/null 2>&1 && return 0
  echo "[reuse] Exact digest is not materialized locally; attempting docker pull: $ref"
  docker pull "$ref" >/dev/null 2>&1 && return 0
  restore_local_scratch_digest_reference "$ref"
}

can_reuse_hardened_base(){
  echo '[reuse] Checking whether the existing hardened base can be reused...'
  if ! validate_build_env; then
    echo '[reuse] .build.env is incomplete or invalid.' >&2
    return 1
  fi

  local base squid method profile expected_source expected_ssg actual_source actual_ssg
  base="$(get_env_value BASE_IMAGE)"
  squid="$(get_env_value SQUID_BASE_IMAGE)"
  if [[ "$base" != "$squid" ]]; then
    echo '[reuse] BASE_IMAGE and SQUID_BASE_IMAGE are not the same digest.' >&2
    return 1
  fi

  command -v docker >/dev/null 2>&1 || { echo '[reuse] docker is unavailable.' >&2; return 1; }
  if ! ensure_image_available "$base"; then
    echo "[reuse] Hardened base digest is unavailable and could not be safely restored: $base" >&2
    return 1
  fi

  method="$(docker image inspect "$base" --format '{{ index .Config.Labels "hardening.method" }}' 2>/dev/null || true)"
  profile="$(docker image inspect "$base" --format '{{ index .Config.Labels "hardening.profile" }}' 2>/dev/null || true)"
  if [[ "$method" != "$EXPECTED_MODE" ]]; then
    echo "[reuse] Hardened base mode mismatch. Expected '$EXPECTED_MODE', found '$method'." >&2
    return 1
  fi
  if [[ "$profile" != 'cis_level1_server' ]]; then
    echo "[reuse] Hardened base profile mismatch. Expected 'cis_level1_server', found '$profile'." >&2
    return 1
  fi

  expected_source="$(get_env_value HARDENED_SOURCE_IMAGE)"
  expected_ssg="$(get_env_value HARDENED_SSG_SHA256)"
  if [[ -n "$expected_source" ]]; then
    actual_source="$(docker image inspect "$base" --format '{{ index .Config.Labels "hardening.source.image" }}' 2>/dev/null || true)"
    [[ "$actual_source" == "$expected_source" ]] || { echo "[reuse] Hardened source-image provenance mismatch. Expected '$expected_source', found '$actual_source'." >&2; return 1; }
  else
    echo '[reuse] Legacy hardened base: source-image provenance key is absent; exact digest + hardening labels will be used.'
  fi
  if [[ -n "$expected_ssg" ]]; then
    actual_ssg="$(docker image inspect "$base" --format '{{ index .Config.Labels "hardening.ssg.sha256" }}' 2>/dev/null || true)"
    [[ "$actual_ssg" == "$expected_ssg" ]] || { echo '[reuse] Hardened SSG provenance mismatch.' >&2; return 1; }
  fi

  echo '[reuse] Existing hardened base passed validation.'
  echo "[reuse] BASE_IMAGE = $base"
  return 0
}

full_resolve_and_harden(){
  echo '[build] Running full resolver + hardened-base build path.'
  echo '[build] Resolver changes are staged and committed to .build.env only after hardening succeeds.'
  local work_env="$ROOT/.build.env.full-build.$$.$RANDOM.tmp"
  cp "$BUILD_ENV" "$work_env"

  if (
    trap 'rm -f "$work_env"' EXIT

    BUILD_ENV_FILE="$work_env" bash scripts/supply-chain/resolve-base-digests.sh --write || exit $?
    BUILD_ENV_FILE="$work_env" bash scripts/supply-chain/resolve-tool-artifacts.sh --write || exit $?
    validate_build_env "$work_env" || exit $?

    source_image="$(get_env_value BASE_IMAGE "$work_env")"
    if [[ "$EXPECTED_MODE" == 'poc' ]]; then
      bash scripts/hardening/build-hardened-base.sh --sandbox-type poc --source-image "$source_image" --build-env-file "$work_env" || exit $?
    else
      [[ -n "$TOKEN" ]] || { echo 'ERROR: Ubuntu Pro token is required because the Production hardened base must be rebuilt.' >&2; exit 2; }
      UBUNTU_PRO_TOKEN="$TOKEN" bash scripts/hardening/build-hardened-base.sh --sandbox-type "$TYPE" --source-image "$source_image" --build-env-file "$work_env" || exit $?
    fi

    apply_hardened_env "$work_env" || exit $?
    update_package_version "$work_env" || exit $?
    validate_build_env "$work_env" || exit $?
    mv "$work_env" "$BUILD_ENV" || exit $?
  ); then
    echo '[build] New hardened-base state committed to .build.env.'
  else
    local rc=$?
    rm -f "$work_env"
    echo '[build] Full resolver/hardening transaction failed; existing .build.env was preserved.' >&2
    return "$rc"
  fi
}

if [[ -n "$BUILD_ENV_SOURCE" ]]; then
  [[ -f "$BUILD_ENV_SOURCE" ]] || { echo "ERROR: build env source not found: $BUILD_ENV_SOURCE" >&2; exit 2; }
  src_abs="$(cd "$(dirname "$BUILD_ENV_SOURCE")" && pwd)/$(basename "$BUILD_ENV_SOURCE")"
  dst_abs="$BUILD_ENV"
  if [[ "$src_abs" != "$dst_abs" ]]; then
    cp "$BUILD_ENV_SOURCE" "$BUILD_ENV"
    echo "[INFO] Copied existing build configuration: $BUILD_ENV_SOURCE -> $BUILD_ENV"
  fi
fi

if [[ ! -f "$BUILD_ENV" ]]; then
  cp .build.env.example "$BUILD_ENV"
  echo '[INFO] Created .build.env from .build.env.example.'
fi
update_package_version

USING_REUSED=false
if [[ "$REUSE" == true ]]; then
  if can_reuse_hardened_base; then
    USING_REUSED=true
    echo '[reuse] Skipping upstream base-image resolution and hardened-base generation for this iterative build.'
    echo '[reuse] Refreshing and pinning the current ucode main commit required for headless PAT support...'
    bash scripts/supply-chain/resolve-tool-artifacts.sh --write --ucode-only
  else
    echo '[reuse] Reuse requirements were not met. Falling back automatically to a new hardened-base build.' >&2
  fi
fi

if [[ "$USING_REUSED" != true ]]; then
  full_resolve_and_harden
fi

validate_build_env

if [[ "$EXPECTED_MODE" == 'poc' ]]; then
  echo '=== Admin build: POC / self-hardened Ubuntu 24.04 ==='
  [[ "$USING_REUSED" == true ]] && echo '[reuse] POC hardened base reused.'
  SKIP_CIS_ASSESSMENT="$SKIP_CIS" bash scripts/poc/build-and-export.sh
  echo '[OK] Admin POC bundle is ready under poc/images/. Developer runs scripts/poc/load-and-start.*'
else
  echo "=== Admin build: $TYPE / Ubuntu Pro + USG ==="
  [[ "$USING_REUSED" == true ]] && echo '[reuse] Production hardened base reused; Ubuntu Pro hardening was not rerun.'
  REQUIRE_CIS_PASS=true bash scripts/platform/02-setup-ecr.sh
  echo '[OK] Admin Production images are in ECR and the central approved-image manifest is published to SSM.'
fi
