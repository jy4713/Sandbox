#!/usr/bin/env bash
# Transparent Git front-end for the AI DevContainer.
#
# Local Git operations execute with the real /usr/bin/git inside the AI
# container. Azure DevOps operations that can require credentials are relayed
# to the trusted secret broker, where the ADO PAT is fetched from SSM and used
# only through GIT_ASKPASS. The PAT is never returned to this process.
set -euo pipefail
set +x

readonly REAL_GIT="/usr/bin/git"
readonly BROKER_CLIENT="/usr/local/bin/secret-broker-client"

# The broker itself must always use the pinned real Git binary. This also
# prevents accidental recursion if the wrapper is invoked in a trusted service.
if [[ "${AI_SANDBOX_ROLE:-}" != "client" ]]; then
  exec "$REAL_GIT" "$@"
fi

# No arguments, version/help-only invocations and any command that does not
# require ADO network authentication retain native Git behaviour.
(( $# > 0 )) || exec "$REAL_GIT"

original=("$@")
workdir="$(pwd -P)"
command_name=""
command_index=-1
blocked_network_global=""

i=0
while (( i < ${#original[@]} )); do
  a="${original[$i]}"
  case "$a" in
    -C)
      (( i + 1 < ${#original[@]} )) || exec "$REAL_GIT" "${original[@]}"
      p="${original[$((i+1))]}"
      if [[ "$p" == /* ]]; then
        next="$p"
      else
        next="$workdir/$p"
      fi
      if ! workdir="$(cd "$next" 2>/dev/null && pwd -P)"; then
        # Let native Git produce its standard -C error message.
        exec "$REAL_GIT" "${original[@]}"
      fi
      i=$((i+2))
      ;;
    -C?*)
      p="${a#-C}"
      if [[ "$p" == /* ]]; then next="$p"; else next="$workdir/$p"; fi
      if ! workdir="$(cd "$next" 2>/dev/null && pwd -P)"; then
        exec "$REAL_GIT" "${original[@]}"
      fi
      i=$((i+1))
      ;;
    -c|--config-env|--git-dir|--work-tree|--namespace)
      blocked_network_global="$a"
      # Consume the associated value so we can still identify the subcommand.
      (( i + 1 < ${#original[@]} )) || exec "$REAL_GIT" "${original[@]}"
      i=$((i+2))
      ;;
    -c=*|--config-env=*|--git-dir=*|--work-tree=*|--namespace=*)
      blocked_network_global="$a"
      i=$((i+1))
      ;;
    --exec-path|--exec-path=*)
      # --exec-path is informational when used alone and an execution override
      # when combined with a command. Keep it native; it is never brokered.
      exec "$REAL_GIT" "${original[@]}"
      ;;
    -p|--paginate|-P|--no-pager|--no-replace-objects|--literal-pathspecs|--glob-pathspecs|--noglob-pathspecs|--icase-pathspecs|--no-optional-locks)
      # Harmless global presentation/pathspec switches. They are not needed by
      # the credentialed transport process, so they are intentionally omitted
      # from the broker invocation.
      i=$((i+1))
      ;;
    --version|version|--help|-h|--html-path|--man-path|--info-path)
      exec "$REAL_GIT" "${original[@]}"
      ;;
    --)
      i=$((i+1))
      if (( i < ${#original[@]} )); then
        command_name="${original[$i]}"; command_index=$i
      fi
      break
      ;;
    -*)
      # Unknown Git-global option: preserve exact native behaviour. This avoids
      # incorrectly treating an option value as a subcommand.
      exec "$REAL_GIT" "${original[@]}"
      ;;
    *)
      command_name="$a"; command_index=$i
      break
      ;;
  esac
done

[[ -n "$command_name" && $command_index -ge 0 ]] || exec "$REAL_GIT" "${original[@]}"

# Determine whether this invocation targets Azure DevOps. Public/non-ADO Git
# keeps native behaviour (and remains subject to the Sandbox proxy allowlist).
# Only ADO operations are brokered for PAT injection.
looks_like_ado_url() {
  local value="${1:-}"
  case "${value,,}" in
    https://dev.azure.com/*|https://*@dev.azure.com/*) return 0 ;;
    *) return 1 ;;
  esac
}

remote_is_ado() {
  local remote="${1:-}" url
  [[ -n "$remote" ]] || return 1
  if looks_like_ado_url "$remote"; then return 0; fi
  case "$remote" in *://*|*::*|/*|./*|../*|~/*) return 1 ;; esac
  while IFS= read -r url; do
    looks_like_ado_url "$url" && return 0
  done < <("$REAL_GIT" remote get-url --all "$remote" 2>/dev/null || true)
  while IFS= read -r url; do
    looks_like_ado_url "$url" && return 0
  done < <("$REAL_GIT" remote get-url --push --all "$remote" 2>/dev/null || true)
  return 1
}

# Find the repository/remote operand after common fetch/pull/push options.
# This is only routing logic; the broker-side policy performs authoritative
# validation before any PAT-backed Git process runs.
first_remote_operand() {
  local mode="$1"; shift
  while (( $# > 0 )); do
    case "$1" in
      --repo)
        (( $# >= 2 )) || return 1; printf '%s' "$2"; return 0 ;;
      --repo=*)
        printf '%s' "${1#--repo=}"; return 0 ;;
      --depth|--deepen|--shallow-since|--shallow-exclude|--jobs|-j|--server-option|--negotiation-tip|--refmap|--filter|--upload-pack|--receive-pack|--exec|--push-option|-o)
        (( $# >= 2 )) || return 1; shift 2 ;;
      --depth=*|--deepen=*|--shallow-since=*|--shallow-exclude=*|--jobs=*|--server-option=*|--negotiation-tip=*|--refmap=*|--filter=*|--upload-pack=*|--receive-pack=*|--exec=*|--push-option=*)
        shift ;;
      -u|--set-upstream|--porcelain|--no-verify|--follow-tags|--atomic|--no-atomic|--dry-run|-n|--progress|--quiet|-q|--verbose|-v|--prune|--no-prune|--tags|--no-tags|--force|-f|--force=*|--force-with-lease|--force-with-lease=*|--force-if-includes|--all|--mirror|--delete|--thin|--no-thin|--signed|--signed=*|--no-signed|-4|--ipv4|-6|--ipv6)
        shift ;;
      --)
        shift; (( $# > 0 )) || return 1; printf '%s' "$1"; return 0 ;;
      -*)
        # Unknown option: do not risk routing a non-ADO target through the ADO
        # broker. Native Git will handle it; if ADO auth is needed it fails
        # closed because terminal credential prompting is disabled.
        return 1 ;;
      *) printf '%s' "$1"; return 0 ;;
    esac
  done
  return 1
}

default_remote_for() {
  local mode="$1" branch remote=''
  branch="$($REAL_GIT symbolic-ref --quiet --short HEAD 2>/dev/null || true)"
  if [[ "$mode" == push && -n "$branch" ]]; then
    remote="$($REAL_GIT config --get "branch.${branch}.pushRemote" 2>/dev/null || true)"
    [[ -n "$remote" ]] || remote="$($REAL_GIT config --get remote.pushDefault 2>/dev/null || true)"
  fi
  if [[ -z "$remote" && -n "$branch" ]]; then
    remote="$($REAL_GIT config --get "branch.${branch}.remote" 2>/dev/null || true)"
  fi
  [[ -n "$remote" ]] || remote=origin
  printf '%s' "$remote"
}

needs_broker=false
case "$command_name" in
  clone|ls-remote)
    for ((j=command_index+1; j<${#original[@]}; j++)); do
      if looks_like_ado_url "${original[$j]}"; then needs_broker=true; break; fi
    done
    ;;
  fetch|pull|push)
    candidate="$(first_remote_operand "$command_name" "${original[@]:$((command_index+1))}" || true)"
    if [[ -n "$candidate" ]]; then
      remote_is_ado "$candidate" && needs_broker=true
    else
      candidate="$(default_remote_for "$command_name")"
      remote_is_ado "$candidate" && needs_broker=true
    fi
    ;;
  remote)
    sub="${original[$((command_index+1))]:-}"
    case "$sub" in
      update|prune|show|set-head)
        # These forms may contact one or more configured remotes. Broker them
        # when any configured target is Azure DevOps; the broker then validates
        # every effective URL before exposing the PAT to Git.
        while IFS= read -r r; do
          if remote_is_ado "$r"; then needs_broker=true; break; fi
        done < <("$REAL_GIT" remote 2>/dev/null || true)
        ;;
    esac
    ;;
  submodule)
    sub="${original[$((command_index+1))]:-}"
    case "$sub" in
      add)
        for ((j=command_index+2; j<${#original[@]}; j++)); do
          if looks_like_ado_url "${original[$j]}"; then needs_broker=true; break; fi
        done
        ;;
      update)
        if [[ -f .gitmodules ]] && "$REAL_GIT" config -f .gitmodules --get-regexp '^submodule\..*\.url$' 2>/dev/null | awk '{print $2}' | grep -Eqi '^https://([^/@]+@)?dev\.azure\.com/'; then
          needs_broker=true
        elif "$REAL_GIT" config --local --get-regexp '^submodule\..*\.url$' 2>/dev/null | awk '{print $2}' | grep -Eqi '^https://([^/@]+@)?dev\.azure\.com/'; then
          needs_broker=true
        fi
        ;;
    esac
    ;;
  archive)
    for ((j=command_index+1; j<${#original[@]}; j++)); do
      case "${original[$j]}" in
        --remote=*) looks_like_ado_url "${original[$j]#--remote=}" && needs_broker=true ;;
        --remote)
          if (( j + 1 < ${#original[@]} )) && looks_like_ado_url "${original[$((j+1))]}"; then needs_broker=true; fi
          ;;
      esac
    done
    ;;
esac

[[ "$needs_broker" == true ]] || exec "$REAL_GIT" "${original[@]}"

if [[ -n "$blocked_network_global" ]]; then
  echo "ERROR: Git global override '$blocked_network_global' is not permitted for credentialed Azure DevOps operations." >&2
  echo "       Run the normal Git command without -c/--config-env/--git-dir/--work-tree/--namespace overrides." >&2
  exit 2
fi

# Rebuild arguments from the actual subcommand onward. Any -C options were
# already applied to workdir above, preserving standard `git -C ...` UX while
# keeping the broker request rooted in the shared workspace.
broker_args=("${original[@]:$command_index}")

cd "$workdir"
exec "$BROKER_CLIENT" --tool ado-git "${broker_args[@]}"
