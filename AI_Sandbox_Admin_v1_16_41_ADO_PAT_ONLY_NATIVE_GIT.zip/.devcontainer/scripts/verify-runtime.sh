#!/usr/bin/env bash
# Runtime security/component verification inside the AI devcontainer.
set -uo pipefail
failures=0; warnings=0
check(){ local d="$1"; shift; if "$@" >/dev/null 2>&1; then printf '  [OK]   %s\n' "$d"; else printf '  [FAIL] %s\n' "$d" >&2; failures=$((failures+1)); fi; }
soft_check(){ local d="$1"; shift; if "$@" >/dev/null 2>&1; then printf '  [OK]   %s\n' "$d"; else printf '  [WARN] %s\n' "$d" >&2; warnings=$((warnings+1)); fi; }

echo '=== Runtime security verification ==='
echo; echo '-- Identity and privileges --'
check 'running as UID 1000' test "$(id -u)" = 1000
check 'running as GID 1000' test "$(id -g)" = 1000
check 'sudo is not installed' bash -c '! command -v sudo >/dev/null 2>&1'
check 'effective capabilities are zero' bash -c '[[ "$(awk "/^CapEff:/ {print \$2}" /proc/self/status)" == 0000000000000000 ]]'
check 'no-new-privileges is set' bash -c '[[ "$(awk "/^NoNewPrivs:/ {print \$2}" /proc/self/status)" == 1 ]]'

echo; echo '-- Filesystem --'
check 'root filesystem is read-only' bash -c 'if touch /etc/.sandbox-write-test 2>/dev/null; then rm -f /etc/.sandbox-write-test; exit 1; fi'
check 'no SUID or SGID files remain' bash -c '[[ -z "$(find / -xdev -type f -perm /6000 -print -quit 2>/dev/null)" ]]'
check 'umask is 027 (non-login bash)' bash -c 'u="$(bash -c umask)"; [[ "$u" == 0027 || "$u" == 027 ]]'
check '/tmp is noexec' bash -c 'findmnt -no OPTIONS /tmp | grep -q noexec'
check 'Snyk runtime tmpfs is exec-enabled and hardened' bash -c 'opts="$(findmnt -no OPTIONS /run/ai-sandbox-snyk)"; [[ -w /run/ai-sandbox-snyk && ",${opts}," != *,noexec,* && ",${opts}," == *,nosuid,* && ",${opts}," == *,nodev,* ]]'
check 'workspace is writable' bash -c 'touch /home/vscode/workspace/.verify-test && rm -f /home/vscode/workspace/.verify-test'
check 'protected sandbox host log mount is non-writable' bash -c '[[ -d /var/log/sandbox && ! -w /var/log/sandbox ]]'
check 'Docker socket is not mounted' bash -c '[[ ! -e /var/run/docker.sock ]]'

echo; echo '-- Credential isolation --'
check 'container role is AI client' bash -c '[[ "${AI_SANDBOX_ROLE:-}" == client ]]'
check 'IMDS is disabled' bash -c '[[ "${AWS_EC2_METADATA_DISABLED:-}" == true ]]'
check 'no AWS bootstrap credential environment variables' bash -c '! env | grep -Eq "^AWS_(ACCESS_KEY_ID|SECRET_ACCESS_KEY|SESSION_TOKEN|SECURITY_TOKEN)="'
check 'no alternate AWS credential-provider environment variables' bash -c '! env | grep -Eq "^AWS_(CONTAINER_CREDENTIALS_RELATIVE_URI|CONTAINER_CREDENTIALS_FULL_URI|CONTAINER_AUTHORIZATION_TOKEN|CONTAINER_AUTHORIZATION_TOKEN_FILE|WEB_IDENTITY_TOKEN_FILE|ROLE_ARN|ROLE_SESSION_NAME|CREDENTIAL_EXPIRATION)="'
check 'no AWS profile/config path variables in AI environment' bash -c '[[ -z "${AWS_PROFILE:-}${AWS_DEFAULT_PROFILE:-}${AWS_CONFIG_FILE:-}${AWS_SHARED_CREDENTIALS_FILE:-}${SANDBOX_AWS_HOME:-}${SANDBOX_AWS_PROFILE:-}" ]]'
check 'no AWS credential file in AI container' bash -c '[[ ! -f "$HOME/.aws/credentials" ]]'
check 'no AWS SSO token cache in AI container' bash -c '[[ ! -d "$HOME/.aws/sso/cache" ]]'
check 'no application/service secrets in parent environment' bash -c '! env | grep -Eq "^(ADO_PAT|DATABRICKS_TOKEN|DATABRICKS_SQL_MCP_TOKEN|GEMINI_API_KEY|ANTHROPIC_API_KEY|TAVILY_API_KEY|SNYK_TOKEN|HIDDENLAYER_CLIENT_ID|HIDDENLAYER_CLIENT_SECRET)="'
check 'broker-only SSM runner refuses AI invocation' bash -c '/usr/local/bin/run-with-ssm-secrets --profile tavily -- /bin/true >/dev/null 2>&1; [[ $? -eq 126 ]]'
check 'secret broker provider health endpoint is reachable' bash -c 'curl --noproxy "*" -fsS --max-time 5 "${SANDBOX_SECRET_BROKER_HTTP_URL:-http://secret-broker:8770}/healthz" >/dev/null'
check 'AI loopback provider relay is reachable' bash -c 'curl --noproxy "*" -fsS --max-time 5 "${SANDBOX_PROVIDER_LOOPBACK_URL:-http://127.0.0.1:8771}/healthz" >/dev/null'
check 'AWS SSM direct read is not credentialed' bash -c 'AWS_EC2_METADATA_DISABLED=true aws ssm get-parameter --name /__ai_sandbox_noop__ --region "${AWS_REGION:-eu-west-2}" --output text >/tmp/aws-no-cred.out 2>&1; rc=$?; rm -f /tmp/aws-no-cred.out; [[ $rc -ne 0 ]]'

echo; echo '-- Managed MCP / provider routing --'
check 'Claude managed MCP config is root-owned and non-writable' bash -c '[[ -r /etc/claude-code/managed-mcp.json && "$(stat -c %U:%G /etc/claude-code/managed-mcp.json)" == root:root && ! -w /etc/claude-code/managed-mcp.json ]]'
check 'Claude MCP uses broker bridge wrappers' bash -c 'jq -e '\''(.mcpServers.tavily.command=="/usr/local/bin/tavily-mcp-ssm") and (.mcpServers.snyk.command=="/usr/local/bin/snyk-mcp-ssm") and (.mcpServers["databricks-sql"].command=="/usr/local/bin/databricks-sql-mcp-ssm")'\'' /etc/claude-code/managed-mcp.json >/dev/null'
check 'Gemini system settings are root-owned and non-writable' bash -c '[[ -r /etc/gemini-cli/settings.json && "$(stat -c %U:%G /etc/gemini-cli/settings.json)" == root:root && ! -w /etc/gemini-cli/settings.json ]]'
check 'Gemini system MCP has Tavily/Snyk/Databricks SQL broker bridges' bash -c 'jq -e '\''(.mcpServers.tavily.command=="/usr/local/bin/tavily-mcp-ssm") and (.mcpServers.snyk.command=="/usr/local/bin/snyk-mcp-ssm") and (.mcpServers["databricks-sql"].command=="/usr/local/bin/databricks-sql-mcp-ssm") and (.mcpServers.tavily.env?==null) and (.mcpServers.snyk.env?==null) and (.mcpServers["databricks-sql"].env?==null)'\'' /etc/gemini-cli/settings.json >/dev/null' 
check 'Gemini auto-update is disabled by system policy' bash -c 'jq -e '\''(.general.enableAutoUpdate==false) and (.general.enableAutoUpdateNotification==false)'\'' /etc/gemini-cli/settings.json >/dev/null' 
check 'Gemini user MCP compatibility state has all managed bridges' bash -c 'jq -e '\''(.mcpServers.tavily.command=="/usr/local/bin/tavily-mcp-ssm") and (.mcpServers.snyk.command=="/usr/local/bin/snyk-mcp-ssm") and (.mcpServers["databricks-sql"].command=="/usr/local/bin/databricks-sql-mcp-ssm") and (.mcpServers.tavily.env?==null) and (.mcpServers.snyk.env?==null) and (.mcpServers["databricks-sql"].env?==null)'\'' "$HOME/.gemini/settings.json" >/dev/null' 
check 'Gemini public routes self-heal managed MCP state' bash -c 'grep -Fq "ensure_gemini_mcp_config" /usr/local/libexec/ai-sandbox/sandbox-command-wrapper && grep -Fq "GEMINI_CLI_SYSTEM_SETTINGS_PATH=/etc/gemini-cli/settings.json" /usr/local/libexec/ai-sandbox/sandbox-command-wrapper'
check 'ucode agent MCP commands stay local and model-free' grep -Fq 'if is_local_only_operation "$agent" "${1:-}"' /usr/local/libexec/ai-sandbox/sandbox-command-wrapper
check 'ucode preserves native Claude/Gemini argument syntax' bash -c 'f=/usr/local/libexec/ai-sandbox/sandbox-command-wrapper; ! grep -Eq "set -- --model|has_model_arg=" "$f" && grep -Fq '''export ANTHROPIC_MODEL="$model"''' "$f" && grep -Fq '''export GEMINI_MODEL="$model"''' "$f"'
check 'Tavily MCP client wrapper delegates to secret broker' grep -Fq 'secret-broker-client --tool tavily-mcp' /usr/local/bin/tavily-mcp-ssm
check 'Snyk MCP client wrapper delegates to secret broker' grep -Fq 'secret-broker-client --tool snyk-mcp' /usr/local/bin/snyk-mcp-ssm
check 'Databricks SQL MCP client wrapper delegates to secret broker' grep -Fq 'secret-broker-client --tool databricks-sql-mcp' /usr/local/bin/databricks-sql-mcp-ssm
check 'direct Claude uses internal provider broker and dummy auth only' bash -c 'grep -Fq "broker-placeholder" /usr/local/libexec/ai-sandbox/sandbox-command-wrapper && grep -Fq "/anthropic" /usr/local/libexec/ai-sandbox/sandbox-command-wrapper'
check 'direct Gemini uses internal provider broker and dummy auth only' grep -Fq '/gemini' /usr/local/libexec/ai-sandbox/sandbox-command-wrapper
check 'ucode Databricks routes use broker and never expose PAT' bash -c 'grep -Fq "/databricks/anthropic" /usr/local/libexec/ai-sandbox/sandbox-command-wrapper && grep -Fq "/databricks/gemini" /usr/local/libexec/ai-sandbox/sandbox-command-wrapper && ! grep -Eq "DATABRICKS_TOKEN=.*get_parameter|export DATABRICKS_TOKEN" /usr/local/libexec/ai-sandbox/sandbox-command-wrapper'
check 'transparent git routes credentialed ADO operations through broker' bash -c '[[ "$(command -v git)" == /usr/local/bin/git ]] && grep -Fq "secret-broker-client" /usr/local/bin/git && grep -Fq -- "--tool ado-git" /usr/local/bin/git'
check 'real git remains pinned outside the transparent wrapper' test -x /usr/bin/git
check 'legacy ado-git bridge remains available' grep -Fq 'secret-broker-client --tool ado-git' /usr/local/bin/ado-git

echo; echo '-- Policy and logging --'
check 'Tavily allowlist is root-owned and non-writable' bash -c '[[ -r /etc/ai-sandbox/tavily-allowed-domains.json && "$(stat -c %U:%G /etc/ai-sandbox/tavily-allowed-domains.json)" == root:root && ! -w /etc/ai-sandbox/tavily-allowed-domains.json ]]'
check 'Tavily fail-closed policy proxy is installed' test -x /usr/local/libexec/ai-sandbox/tavily-policy-proxy.py
check 'Claude native WebSearch/WebFetch are denied' bash -c 'jq -e '\''(.permissions.deny | index("WebSearch")) != null and (.permissions.deny | index("WebFetch")) != null'\'' /etc/claude-code/managed-settings.json >/dev/null'
check 'managed log emitter targets Docker PID1 stream' grep -Fq 'target="/proc/1/fd/1"' /usr/local/bin/sandbox-log-emit
check 'application audit required by default' bash -c '[[ "${SANDBOX_AUDIT_REQUIRED:-true}" == true ]]'

echo; echo '-- Required tools --'
for tool in node python3 git vi jq flock aws az databricks claude gemini ucode tvly tavily-mcp snyk run-with-ssm-secrets secret-broker-client provider-loopback-relay application-audit git-askpass-ado ado-git ado-pr-create ado-trigger configure-mcp sandbox-info tavily-mcp-ssm databricks-sql-mcp-ssm snyk-mcp-ssm claude-audit-hook; do
  check "$tool is available" command -v "$tool"
done
check 'in-container AWS login helpers are absent' bash -c '! command -v sandbox-aws-login >/dev/null && ! command -v configure-aws-sso >/dev/null && ! command -v aws-azure-login >/dev/null'
check 'read-only build provenance exists' test -r /etc/ai-sandbox/build-info.json
check 'stashed real application executables are available' bash -c 'for c in claude gemini ucode tvly tavily-mcp mcp-remote snyk databricks; do [[ -x "/usr/local/libexec/ai-sandbox/real/$c" ]]; done'

if [[ -n "${DATABRICKS_HOST:-}" ]]; then
  check 'DATABRICKS_HOST uses https' bash -c '[[ "$DATABRICKS_HOST" == https://* ]]'
else
  soft_check 'DATABRICKS_HOST configured when Databricks SQL MCP is required' false
fi

echo; echo '======================================'
if ((failures>0)); then printf 'FAILED: %d check(s) failed, %d warning(s).\n' "$failures" "$warnings" >&2; exit 1; fi
if ((warnings>0)); then printf 'PASSED with %d warning(s).\n' "$warnings"; else echo 'PASSED: all runtime checks succeeded.'; fi
