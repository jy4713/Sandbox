#!/usr/bin/env bash
# Root-owned Azure DevOps Git policy executed only inside the secret-broker.
# The caller keeps normal `git ...` UX; credentialed network operations arrive
# here through the transparent Git front-end. The ADO PAT exists only in this
# broker-side child and is supplied to /usr/bin/git through GIT_ASKPASS.
set -euo pipefail
set +x

readonly REAL_GIT="/usr/bin/git"
[[ "${1:-}" == "$REAL_GIT" ]] || { echo 'ERROR: ADO Git policy requires the pinned git executable' >&2; exit 2; }
shift
(( $# > 0 )) || { echo 'ERROR: ADO Git operation is required' >&2; exit 2; }

# Repository/project names are intentionally not Admin-pinned in the Sandbox.
# The ADO PAT and Azure DevOps permissions are the authorization boundary.
# This broker policy only constrains credentialed Git traffic to structurally
# valid HTTPS repositories on dev.azure.com and prevents credential redirection.

op="$1"
case "$op" in
  clone|fetch|pull|push|ls-remote|remote|submodule|archive) ;;
  *) echo 'ERROR: Git operation does not require a credentialed Azure DevOps broker path' >&2; exit 2 ;;
esac

is_ado_https_url() {
  local url="${1%/}" authority host userinfo path org project marker repo extra
  [[ "$url" == https://* ]] || return 1
  [[ "$url" != *'?'* && "$url" != *'#'* && "$url" != *\\* ]] || return 1

  authority="${url#https://}"
  authority="${authority%%/*}"
  [[ -n "$authority" ]] || return 1

  if [[ "$authority" == *@* ]]; then
    userinfo="${authority%@*}"
    host="${authority##*@}"
    # Accept the common Azure DevOps username-only URL form, but never permit
    # password/token material in URL userinfo.
    [[ -n "$userinfo" && "$userinfo" != *:* ]] || return 1
  else
    host="$authority"
  fi
  [[ "${host,,}" == "dev.azure.com" ]] || return 1

  path="${url#https://$authority/}"
  IFS='/' read -r org project marker repo extra <<< "$path"
  [[ -n "$org" && -n "$project" && "$marker" == "_git" && -n "$repo" && -z "${extra:-}" ]] || return 1
  return 0
}

reject_transport_like_value() {
  local value="${1:-}" lower
  lower="${value,,}"
  case "$lower" in
    ext::*|file://*|ssh://*|git://*) return 0 ;;
  esac
  return 1
}

# Never allow caller-controlled executable/configuration paths in the privileged
# Git child. These can turn a PAT-backed Git request into arbitrary execution or
# credential redirection. Recursive submodule traversal is also blocked because
# nested .gitmodules files have not been prevalidated.
for a in "$@"; do
  lower="${a,,}"
  case "$lower" in
    -c|-c=*|--config-env|--config-env=*|--exec-path|--exec-path=*|\
    --upload-pack|--upload-pack=*|--receive-pack|--receive-pack=*|\
    --git-dir|--git-dir=*|--work-tree|--work-tree=*|--namespace|--namespace=*|\
    --reference|--reference=*|--reference-if-able|--reference-if-able=*|\
    --separate-git-dir|--separate-git-dir=*|--template|--template=*|\
    --recurse-submodules|--recurse-submodules=*|--recursive|--exec|--exec=*)
      echo 'ERROR: Git execution/configuration override is not approved by Sandbox policy' >&2; exit 2 ;;
  esac
  if reject_transport_like_value "$a"; then
    echo 'ERROR: non-HTTPS Git transport is not approved by Sandbox policy' >&2; exit 2
  fi
done


# The workspace is Developer/agent writable. Local Git config cannot be trusted
# to define helpers, URL rewrites, hooks, filters, custom transports or proxy
# destinations while the PAT is present in the broker process.
reject_unsafe_local_config() {
  local keys
  keys="$($REAL_GIT config --local --name-only --get-regexp \
    '^(url\..*\.(insteadof|pushinsteadof)|http\.(proxy|sslverify|curloptresolve)|http\..*\.(proxy|sslverify|curloptresolve)|credential\.(helper|usehttppath)|credential\..*\.helper|core\.(hookspath|fsmonitor|sshcommand|gitproxy)|filter\..*\.(clean|smudge|process|required)|merge\..*\.driver|submodule\..*\.update|remote\..*\.(proxy|uploadpack|receivepack)|protocol\..*\.allow|fetch\.recursesubmodules|submodule\.recurse)$' \
    2>/dev/null || true)"
  if [[ -n "$keys" ]]; then
    echo 'ERROR: repository-local Git configuration contains a setting unsafe for credentialed broker execution.' >&2
    echo '       Remove URL rewrites/helpers/hooks/filters/custom transports and retry.' >&2
    return 1
  fi
}

validate_url() {
  local url="${1:-}"
  [[ "$url" == https://* ]] || { echo 'ERROR: an Azure DevOps HTTPS repository URL is required' >&2; return 1; }
  is_ado_https_url "$url" || { echo 'ERROR: only structurally valid HTTPS repositories on dev.azure.com are permitted for PAT-backed Git' >&2; return 1; }
}

validate_all_configured_remotes() {
  local found=false name url
  while IFS= read -r name; do
    [[ -n "$name" ]] || continue
    while IFS= read -r url; do
      [[ -n "$url" ]] || continue
      found=true
      validate_url "$url" || return 1
    done < <($REAL_GIT remote get-url --all "$name" 2>/dev/null || true)
    while IFS= read -r url; do
      [[ -n "$url" ]] || continue
      found=true
      validate_url "$url" || return 1
    done < <($REAL_GIT remote get-url --push --all "$name" 2>/dev/null || true)
  done < <($REAL_GIT remote 2>/dev/null || true)
  return 0
}

# Return the first repository operand for clone/ls-remote while supporting the
# common non-dangerous Git options used by normal developer workflows.
first_repository_operand() {
  local mode="$1"; shift
  while (( $# > 0 )); do
    case "$1" in
      --branch|-b|--depth|--origin|-o|--filter|--shallow-since|--shallow-exclude|--jobs|-j|--server-option|--sort)
        (( $# >= 2 )) || return 1; shift 2 ;;
      --branch=*|--depth=*|--origin=*|--filter=*|--shallow-since=*|--shallow-exclude=*|--jobs=*|--server-option=*|--sort=*|\
      --single-branch|--no-single-branch|--no-tags|--tags|--heads|--refs|--symref|--exit-code|--get-url|\
      --no-checkout|-n|--bare|--quiet|-q|--verbose|-v|--progress|--no-hardlinks|--dissociate)
        shift ;;
      --)
        shift; (( $# > 0 )) || return 1; printf '%s' "$1"; return 0 ;;
      -*) return 1 ;;
      *) printf '%s' "$1"; return 0 ;;
    esac
  done
  return 1
}

validate_explicit_https_args() {
  local a
  for a in "$@"; do
    if [[ "$a" == https://* ]]; then validate_url "$a" || return 1; fi
    case "$a" in /*|./*|../*|~/*) echo 'ERROR: local-path Git transports are not approved for credentialed operations' >&2; return 1 ;; esac
  done
}

validate_push_args() {
  local -a positional=()
  local a i=0 repo_override first
  local -a rest=("${@:1}")

  # Preserve ordinary Git push semantics. Branch/history governance belongs to
  # Azure DevOps repository permissions and branch policies, not this credential
  # isolation layer. We only parse enough to validate the effective destination
  # and to keep caller-controlled execution/configuration overrides out of the
  # PAT-bearing process. The high-risk overrides are rejected earlier as a
  # second fail-closed layer.
  while (( i < ${#rest[@]} )); do
    a="${rest[$i]}"
    case "$a" in
      -u|--set-upstream|--porcelain|--no-verify|--follow-tags|--atomic|--no-atomic|\
      --dry-run|-n|--progress|--quiet|-q|--verbose|-v|--prune|--no-prune|\
      --tags|--no-tags|--force|-f|--force=*|--force-with-lease|--force-with-lease=*|\
      --force-if-includes|--all|--mirror|--delete|--thin|--no-thin|--signed|--signed=*|\
      --no-signed|-4|--ipv4|-6|--ipv6)
        i=$((i+1)); continue ;;
      --push-option|-o)
        (( i + 1 < ${#rest[@]} )) || return 1; i=$((i+2)); continue ;;
      --push-option=*)
        i=$((i+1)); continue ;;
      --repo)
        (( i + 1 < ${#rest[@]} )) || return 1
        repo_override="${rest[$((i+1))]}"
        if [[ "$repo_override" == https://* ]]; then
          validate_url "$repo_override" || return 1
        elif [[ "$repo_override" == *://* || "$repo_override" == *::* || "$repo_override" == /* || "$repo_override" == ./* || "$repo_override" == ../* || "$repo_override" == ~/* ]]; then
          echo 'ERROR: non-HTTPS/custom --repo destination is not permitted' >&2; return 1
        fi
        i=$((i+2)); continue ;;
      --repo=*)
        repo_override="${a#--repo=}"
        if [[ "$repo_override" == https://* ]]; then
          validate_url "$repo_override" || return 1
        elif [[ "$repo_override" == *://* || "$repo_override" == *::* || "$repo_override" == /* || "$repo_override" == ./* || "$repo_override" == ../* || "$repo_override" == ~/* ]]; then
          echo 'ERROR: non-HTTPS/custom --repo destination is not permitted' >&2; return 1
        fi
        i=$((i+1)); continue ;;
      --)
        i=$((i+1)); while (( i < ${#rest[@]} )); do positional+=("${rest[$i]}"); i=$((i+1)); done; break ;;
      -*) echo 'ERROR: push option is not approved by Sandbox credential policy' >&2; return 1 ;;
      *) positional+=("$a"); i=$((i+1)) ;;
    esac
  done

  # Positional[0] is the optional remote/URL. Refspecs are intentionally left
  # to native Git/Azure DevOps semantics: main/master, force refspecs (+ref),
  # deletes (:ref), wildcard refspecs, and implicit pushes are not blocked here.
  if (( ${#positional[@]} > 0 )); then
    first="${positional[0]}"
    if [[ "$first" == https://* ]]; then
      validate_url "$first" || return 1
    elif [[ "$first" == *://* || "$first" == *::* || "$first" == /* || "$first" == ./* || "$first" == ../* || "$first" == ~/* ]]; then
      echo 'ERROR: non-HTTPS/custom Git remote is not permitted' >&2; return 1
    fi
  fi
  return 0
}

validate_submodule_urls() {
  local url
  if [[ -f .gitmodules ]]; then
    while IFS= read -r url; do
      [[ -n "$url" ]] || continue
      validate_url "$url" || return 1
    done < <($REAL_GIT config -f .gitmodules --get-regexp '^submodule\..*\.url$' 2>/dev/null | awk '{print $2}' || true)
  fi
  # `git submodule init` copies URLs into .git/config and a writable workspace
  # can override them. Validate those effective local values as well.
  while IFS= read -r url; do
    [[ -n "$url" ]] || continue
    validate_url "$url" || return 1
  done < <($REAL_GIT config --local --get-regexp '^submodule\..*\.url$' 2>/dev/null | awk '{print $2}' || true)
  return 0
}

case "$op" in
  clone|ls-remote)
    repo="$(first_repository_operand "$op" "${@:2}" || true)"
    [[ -n "$repo" ]] || { echo 'ERROR: cannot identify Git repository operand safely' >&2; exit 2; }
    validate_url "$repo" || exit 2
    ;;

  fetch|pull)
    reject_unsafe_local_config || exit 2
    validate_explicit_https_args "${@:2}" || exit 2
    validate_all_configured_remotes || exit 2
    ;;

  push)
    reject_unsafe_local_config || exit 2
    validate_all_configured_remotes || exit 2
    validate_push_args "${@:2}" || exit 2
    ;;

  remote)
    reject_unsafe_local_config || exit 2
    sub="${2:-}"
    case "$sub" in
      update|prune|show)
        validate_explicit_https_args "${@:3}" || exit 2
        validate_all_configured_remotes || exit 2
        ;;
      set-head)
        # The transparent wrapper sends set-head here only for --auto/-a.
        validate_all_configured_remotes || exit 2
        ;;
      *) echo 'ERROR: this git remote operation does not require broker credentials' >&2; exit 2 ;;
    esac
    ;;

  submodule)
    reject_unsafe_local_config || exit 2
    sub="${2:-}"
    case "$sub" in
      add)
        repo="$(first_repository_operand clone "${@:3}" || true)"
        [[ -n "$repo" ]] || { echo 'ERROR: cannot identify submodule repository operand safely' >&2; exit 2; }
        validate_url "$repo" || exit 2
        ;;
      update)
        validate_submodule_urls || exit 2
        ;;
      *) echo 'ERROR: this git submodule operation does not require broker credentials' >&2; exit 2 ;;
    esac
    ;;

  archive)
    reject_unsafe_local_config || exit 2
    remote_url=''
    prev=''
    for a in "${@:2}"; do
      if [[ "$prev" == --remote ]]; then remote_url="$a"; prev=''; continue; fi
      case "$a" in --remote=*) remote_url="${a#--remote=}" ;; --remote) prev=--remote ;; esac
    done
    [[ -n "$remote_url" ]] || { echo 'ERROR: local git archive does not require broker credentials' >&2; exit 2; }
    validate_url "$remote_url" || exit 2
    ;;
esac

# Never inherit system/global execution customizations into the credentialed
# process. Local repo config is needed for remotes/refs but dangerous keys were
# rejected above. The explicit -c values below form a second fail-closed layer.
export GIT_CONFIG_NOSYSTEM=1
export GIT_CONFIG_GLOBAL=/dev/null

exec "$REAL_GIT" \
  -c core.hooksPath=/dev/null \
  -c core.fsmonitor=false \
  -c credential.helper= \
  -c protocol.allow=never \
  -c protocol.https.allow=always \
  -c protocol.ext.allow=never \
  -c protocol.file.allow=never \
  -c protocol.git.allow=never \
  -c protocol.ssh.allow=never \
  -c fetch.recurseSubmodules=false \
  -c submodule.recurse=false \
  -c http.sslVerify=true \
  "$@"
