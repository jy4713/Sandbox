#!/usr/bin/env bash
set -euo pipefail
set +x

show_var(){ local n="$1"; printf '  %-38s %s\n' "$n" "${!n:-<not configured>}"; }
cmd_ver(){ local label="$1"; shift; local out; out="$("$@" 2>/dev/null | head -n 1 || true)"; printf '  %-38s %s\n' "$label" "${out:-<unavailable>}"; }

echo 'AI Secure Sandbox - Runtime Information'
echo '============================================================'
if [[ -r /etc/ai-sandbox/build-info.json ]]; then
  echo 'Build provenance:'
  jq . /etc/ai-sandbox/build-info.json 2>/dev/null || cat /etc/ai-sandbox/build-info.json
else
  echo 'Build provenance: <not available>'
fi

echo
echo 'Credential-isolated command routing:'
echo '  claude                                 internal broker -> Anthropic official API'
echo '  gemini                                 internal broker -> Google Gemini official API'
echo '  tavily MCP / tvly                      internal broker -> Tavily'
echo '  snyk MCP / snyk                        internal broker -> Snyk'
echo '  databricks SQL MCP / approved CLI      internal broker -> Databricks'
echo '  git clone/fetch/pull/push/...          transparent broker -> Azure DevOps'
echo '  ado-git (legacy alias) / ado-pr-create / ado-trigger  internal broker -> Azure DevOps'
echo '  ucode claude/gemini                    brokered Databricks AI Gateway; PAT hidden from AI'
show_var DATABRICKS_HOST
show_var DATABRICKS_CLAUDE_MODEL
show_var DATABRICKS_GEMINI_MODEL
show_var SANDBOX_SECRET_BROKER_HTTP_URL

echo
echo 'AWS authentication boundary:'
echo '  Browser login                          Windows host only (aws-azure-login)'
echo '  AWS profile/.aws mount                 secret-broker only'
echo '  AI container AWS credential            none'
echo '  AI container SSM access                none'
if env | grep -Eq '^AWS_(ACCESS_KEY_ID|SECRET_ACCESS_KEY|SESSION_TOKEN|SECURITY_TOKEN)='; then
  echo '  [FAIL] unexpected AWS credential environment variable is present'
else
  echo '  [OK]   no AWS credential environment variables'
fi
if [[ -f "$HOME/.aws/credentials" || -d "$HOME/.aws/sso/cache" ]]; then
  echo '  [FAIL] unexpected AWS credential/cache material exists in AI home'
else
  echo '  [OK]   no AWS credential/cache material in AI home'
fi

echo
echo 'Installed tools:'
cmd_ver 'Databricks CLI' /usr/local/libexec/ai-sandbox/real/databricks --version
cmd_ver 'ucode (installed; secure runtime route wrapped)' /usr/local/libexec/ai-sandbox/real/ucode --version
cmd_ver 'Claude Code' /usr/local/libexec/ai-sandbox/real/claude --version
cmd_ver 'Gemini CLI' /usr/local/libexec/ai-sandbox/real/gemini --version
cmd_ver 'Snyk CLI' /usr/local/libexec/ai-sandbox/real/snyk --version

echo
echo 'User configuration locations:'
printf '  %-38s %s\n' 'AWS CLI config' '<not mounted in AI container>'
printf '  %-38s %s\n' 'Claude user config' "$HOME/.claude"
printf '  %-38s %s\n' 'Claude managed config' '/etc/claude-code/managed-settings.json'
printf '  %-38s %s\n' 'Gemini user config' "$HOME/.gemini"
printf '  %-38s %s\n' 'Gemini managed system config' '/etc/gemini-cli/settings.json'
printf '  %-38s %s\n' 'Project workspace' "$HOME/workspace"

echo
echo 'Secret handling:'
echo '  SSM SecureStrings are fetched only inside the trusted broker.'
echo '  Raw PAT/API-key values are never returned to the AI container.'
echo '  Provider wrappers use broker endpoints/dummy placeholders, not real keys.'
printf 'Content logging: %s\n' "${SANDBOX_CONTENT_LOGGING:-false}"
