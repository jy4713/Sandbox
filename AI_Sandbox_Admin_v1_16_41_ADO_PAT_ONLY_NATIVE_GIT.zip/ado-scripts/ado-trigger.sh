#!/usr/bin/env bash
# =============================================================================
# PACKAGE MAINTENANCE NOTES
# Purpose: Bash workflow for triggering approved Azure DevOps pipeline operations.
# Admin maintenance: Update only for ADO API/workflow changes; keep the PowerShell peer behaviorally equivalent.
# Safety rule: preserve secret-free images/configuration, immutable version or
# digest pinning where applicable, and update the paired Bash/PowerShell path.
# After any change, run scripts/ci/lint-package.* and the applicable build/QA.
# Full change procedure: docs/ADMIN-COMPLETE-GUIDE.md
# =============================================================================
# =============================================================================
# ado-trigger — AI Sandbox ADO Pipeline Trigger Helper
#
# Triggers an Azure DevOps pipeline via REST API and optionally tails the run.
# Public/AI-side authentication is credential-free: the command is delegated to
# the trusted secret broker, which retrieves the ADO PAT from SSM and injects it
# only into the broker-side child process. Org/project are explicit CLI targets
# and are not stored in SSM.
#
# Usage:
#   ado-trigger --org ORG --project PROJECT --pipeline-id <id> [options]
#
# Options:
#   --pipeline-id  Pipeline definition ID (integer)
#   --branch       Source branch (default: main)
#   --params       JSON string of template parameters, e.g. '{"env":"staging"}'
#   --wait         Wait for the run to complete and exit with its status
#
# Example:
#   ado-trigger --pipeline-id 42 --branch feature/my-branch \
#     --params '{"deploy_env":"dev"}' --wait
#
# Internal broker note: only ADO_PAT is injected after argument validation.
# Org/project are caller-selected Azure DevOps targets and are not secrets.
# =============================================================================
set -euo pipefail

# In the AI/client container, never receive ADO_PAT. Delegate the complete
# credentialed operation to the trusted broker. The broker reruns this same
# script with AI_SANDBOX_ROLE=broker after injecting the PAT in broker memory.
if [[ "${AI_SANDBOX_ROLE:-client}" != "broker" ]]; then
  exec /usr/local/bin/secret-broker-client --tool ado-trigger "$@"
fi


# ── Defaults ─────────────────────────────────────────────────────────────────
ORG=""
PROJECT=""
PIPELINE_ID=""
BRANCH="main"
PARAMS="{}"
WAIT=false

# ── Argument parsing ──────────────────────────────────────────────────────────
while [[ $# -gt 0 ]]; do
  case "$1" in
    --org)          ORG="$2";         shift 2 ;;
    --project)      PROJECT="$2";     shift 2 ;;
    --pipeline-id)  PIPELINE_ID="$2"; shift 2 ;;
    --branch)       BRANCH="$2";      shift 2 ;;
    --params)       PARAMS="$2";      shift 2 ;;
    --wait)         WAIT=true;        shift   ;;
    -h|--help)
      sed -n '3,40p' "$0" | grep '^#' | sed 's/^# \?//'
      exit 0 ;;
    *) echo "[ERROR] Unknown argument: $1"; exit 1 ;;
  esac
done

# ── Validation ────────────────────────────────────────────────────────────────
[[ -z "$ORG" ]]         && { echo "[ERROR] --org is required"; exit 1; }
[[ -z "$PROJECT" ]]     && { echo "[ERROR] --project is required"; exit 1; }
[[ -z "$PIPELINE_ID" ]] && { echo "[ERROR] --pipeline-id is required"; exit 1; }
[[ "$PIPELINE_ID" =~ ^[0-9]+$ ]] && (( PIPELINE_ID > 0 )) || { echo "[ERROR] --pipeline-id must be a positive integer"; exit 1; }
jq -e 'type == "object"' >/dev/null 2>&1 <<<"$PARAMS" || { echo "[ERROR] --params must be a valid JSON object"; exit 1; }

# ── Auth token ────────────────────────────────────────────────────────────────
BASE_URL="https://dev.azure.com/${ORG}/${PROJECT}/_apis"
API_VERSION="api-version=7.1"

build_auth_header() {
  [[ -z "${ADO_PAT:-}" ]] && { echo "[ERROR] ADO_PAT not set" >&2; exit 1; }
  local encoded
  encoded=$(printf '%s' ":${ADO_PAT}" | base64 -w 0)
  echo "Authorization: Basic ${encoded}"
}

# ── Trigger pipeline ──────────────────────────────────────────────────────────
echo "[ado-trigger] Triggering pipeline ${PIPELINE_ID} on branch '${BRANCH}'..."
AUTH_HEADER=$(build_auth_header)

BODY=$(jq -n \
  --argjson params "$PARAMS" \
  --arg branch "refs/heads/$BRANCH" \
  '{
    resources: { repositories: { self: { refName: $branch } } },
    templateParameters: $params
  }')

RESPONSE=$(curl -s -X POST \
  "${BASE_URL}/pipelines/${PIPELINE_ID}/runs?${API_VERSION}" \
  -H "Content-Type: application/json" \
  -H "$AUTH_HEADER" \
  -d "$BODY")

RUN_ID=$(echo "$RESPONSE" | jq -r '.id // empty')
RUN_URL=$(echo "$RESPONSE" | jq -r '._links.web.href // empty')
STATE=$(echo "$RESPONSE"   | jq -r '.state // empty')

if [[ -z "$RUN_ID" ]]; then
  echo "[ERROR] Pipeline trigger failed. Response:"
  echo "$RESPONSE" | jq .
  exit 1
fi

echo "[ado-trigger] Run created:"
echo "  Run ID:  $RUN_ID"
echo "  State:   $STATE"
echo "  URL:     $RUN_URL"

# ── Wait for completion ───────────────────────────────────────────────────────
if [[ "$WAIT" == "true" ]]; then
  echo
  echo "[ado-trigger] Waiting for run ${RUN_ID} to complete..."
  POLL_INTERVAL=15
  TIMEOUT=1800   # 30 minutes
  ELAPSED=0

  while true; do
    sleep $POLL_INTERVAL
    ELAPSED=$((ELAPSED + POLL_INTERVAL))

    AUTH_HEADER=$(build_auth_header)
    STATUS=$(curl -s \
      "${BASE_URL}/pipelines/${PIPELINE_ID}/runs/${RUN_ID}?${API_VERSION}" \
      -H "$AUTH_HEADER")

    STATE=$(echo "$STATUS"  | jq -r '.state')
    RESULT=$(echo "$STATUS" | jq -r '.result // "unknown"')

    echo "  [${ELAPSED}s] state=${STATE} result=${RESULT}"

    if [[ "$STATE" == "completed" ]]; then
      echo
      echo "[ado-trigger] Run completed: $RESULT"
      echo "  URL: $RUN_URL"
      [[ "$RESULT" == "succeeded" ]] && exit 0 || exit 1
    fi

    if [[ $ELAPSED -ge $TIMEOUT ]]; then
      echo "[ERROR] Timeout after ${TIMEOUT}s — run still in state: $STATE"
      exit 1
    fi
  done
fi
