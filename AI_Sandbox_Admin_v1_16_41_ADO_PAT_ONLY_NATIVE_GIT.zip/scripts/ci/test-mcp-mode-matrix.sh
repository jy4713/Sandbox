#!/usr/bin/env bash
# Offline regression test for the four supported AI entry points:
#   claude, gemini, ucode claude, ucode gemini.
# It verifies that all modes resolve the same three Admin-managed MCP bridges
# and that Gemini MCP inspection is independent of Databricks model routing.
set -euo pipefail
root="$(cd "$(dirname "$0")/../.." && pwd)"
python3 - "$root" <<'PY'
import json
import pathlib
import sys

root = pathlib.Path(sys.argv[1])
claude = json.loads((root / '.devcontainer/policies/claude-mcp.json').read_text())
gemini = json.loads((root / '.devcontainer/policies/gemini-managed-settings.json').read_text())
wrapper = (root / '.devcontainer/scripts/sandbox-command-wrapper.sh').read_text()
config = (root / '.devcontainer/scripts/configure-mcp.sh').read_text()
dockerfile = (root / '.devcontainer/Dockerfile').read_text()
tar_compose = (root / 'tar/docker-compose.yml').read_text()
ecr_compose = (root / 'ecr/docker-compose.yml').read_text()

desired = {
    'tavily': '/usr/local/bin/tavily-mcp-ssm',
    'snyk': '/usr/local/bin/snyk-mcp-ssm',
    'databricks-sql': '/usr/local/bin/databricks-sql-mcp-ssm',
}

for label, doc in [('Claude', claude), ('Gemini system', gemini)]:
    servers = doc.get('mcpServers', {})
    missing = set(desired) - set(servers)
    if missing:
        raise SystemExit(f'{label} missing MCP servers: {sorted(missing)}')
    for name, command in desired.items():
        item = servers[name]
        if item.get('command') != command:
            raise SystemExit(f'{label} {name} command mismatch: {item.get("command")!r}')
        if item.get('env') is not None:
            raise SystemExit(f'{label} {name} unexpectedly contains env')

# Gemini's pinned vendor baseline supports a system settings layer with higher
# precedence than user/workspace server definitions. The public wrapper must
# pin that path and self-heal the persistent user settings before every Gemini
# launch (direct or Databricks-routed).
required_wrapper = [
    'ensure_gemini_mcp_config()',
    'GEMINI_CLI_SYSTEM_SETTINGS_PATH=/etc/gemini-cli/settings.json',
    'if is_local_only_operation "$agent" "${1:-}"; then',
    'if [[ "$agent" == "gemini" ]]; then ensure_gemini_mcp_config; fi',
    'ensure_gemini_mcp_config\n    if is_local_only_operation "$tool" "${1:-}"',
    'ensure_gemini_mcp_config\n      export GOOGLE_GEMINI_BASE_URL="${PROVIDER_BASE}/databricks/gemini"',
]
for needle in required_wrapper:
    if needle not in wrapper:
        raise SystemExit(f'wrapper invariant missing: {needle}')

# The local-control branch must occur before Databricks host/model validation so
# `ucode gemini mcp list` and `ucode claude mcp list` do not become model calls.
local_idx = wrapper.index('if is_local_only_operation "$agent" "${1:-}"; then')
host_idx = wrapper.index('DATABRICKS_HOST must be configured with https://')
if local_idx > host_idx:
    raise SystemExit('ucode local MCP branch occurs after Databricks validation')

# ucode's public contract is pass-through: everything after the agent name is a
# native Claude/Gemini argument. The sandbox may inject broker/gateway state via
# environment variables, but it must never splice a model flag into argv. Gemini
# exposes --model on the default chat command, not on `mcp list`, so argv mutation
# is exactly what caused the historical `Unknown argument: model` regression.
for forbidden in ('set -- --model', 'has_model_arg='):
    if forbidden in wrapper:
        raise SystemExit(f'ucode native argv contract violated by: {forbidden}')
for required in (
    'export ANTHROPIC_MODEL="$model"',
    'export GEMINI_MODEL="$model"',
    'run_audited databricks ucode-claude "$model" https "$(real_tool claude)" "$@"',
    'run_audited databricks ucode-gemini "$model" https "$(real_tool gemini)" "$@"',
):
    if required not in wrapper:
        raise SystemExit(f'ucode native argv/default-model invariant missing: {required}')

for name, command in desired.items():
    if command not in config:
        raise SystemExit(f'configure-mcp missing compatibility entry: {name}')

for token in ('"tavily", "snyk", "databricks-sql"', '.mcp.excluded'):
    if token not in config:
        raise SystemExit(f'configure-mcp stale-filter self-heal missing: {token}')

for label, text in [('Dockerfile', dockerfile), ('TAR compose', tar_compose), ('ECR compose', ecr_compose)]:
    if 'GEMINI_CLI_SYSTEM_SETTINGS_PATH' not in text or '/etc/gemini-cli/settings.json' not in text:
        raise SystemExit(f'{label} does not pin Gemini system settings path')

if gemini.get('general', {}).get('enableAutoUpdate') is not False:
    raise SystemExit('Gemini auto-update must be disabled for pinned builds')
if gemini.get('general', {}).get('enableAutoUpdateNotification') is not False:
    raise SystemExit('Gemini update notifications must be disabled for pinned builds')

print('MCP mode matrix policy test passed')
PY
