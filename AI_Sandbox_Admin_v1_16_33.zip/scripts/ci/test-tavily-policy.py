#!/usr/bin/env python3
"""Regression tests for the Admin Tavily MCP domain policy."""
from __future__ import annotations

import importlib.util
import json
import os
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
PROXY = ROOT / ".devcontainer" / "scripts" / "tavily-policy-proxy.py"


def load_proxy(policy_path: Path):
    os.environ["TAVILY_POLICY_FILE"] = str(policy_path)
    spec = importlib.util.spec_from_file_location("sandbox_tavily_policy_proxy", PROXY)
    if spec is None or spec.loader is None:
        raise RuntimeError("cannot load Tavily policy proxy")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def search_call(module, args: dict):
    msg = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "tools/call",
        "params": {"name": "tavily_search", "arguments": dict(args)},
    }
    return module.enforce_tool_call(msg)


def main() -> int:
    with tempfile.TemporaryDirectory() as tmp:
        policy = Path(tmp) / "policy.json"
        policy.write_text(json.dumps({"allowed_domains": ["docs.databricks.com", "github.com"]}))
        module = load_proxy(policy)

        allowed, denied = search_call(module, {"query": "Databricks SQL MCP"})
        assert denied is None
        assert allowed["params"]["arguments"]["include_domains"] == ["docs.databricks.com", "github.com"]

        allowed, denied = search_call(module, {"query": "search docs.databricks.com for SQL MCP"})
        assert denied is None
        assert allowed["params"]["arguments"]["include_domains"] == ["docs.databricks.com"]

        allowed, denied = search_call(module, {"query": "search espn.com for Arsenal"})
        assert allowed is None and denied["error"]["code"] == -32001

        allowed, denied = search_call(module, {"query": "Arsenal", "include_domains": ["espn.com"]})
        assert allowed is None and denied["error"]["code"] == -32001

        allowed, denied = search_call(module, {
            "query": "search docs.databricks.com for SQL MCP",
            "include_domains": ["github.com"],
        })
        assert allowed is None and denied["error"]["code"] == -32001

        extract = {
            "jsonrpc": "2.0", "id": 3, "method": "tools/call",
            "params": {"name": "tavily_extract", "arguments": {"urls": ["https://espn.com/x"]}},
        }
        allowed, denied = module.enforce_tool_call(extract)
        assert allowed is None and denied["error"]["code"] == -32001

        crawl = {
            "jsonrpc": "2.0", "id": 4, "method": "tools/call",
            "params": {"name": "tavily_crawl", "arguments": {"url": "https://docs.databricks.com/en/index.html", "allow_external": True}},
        }
        allowed, denied = module.enforce_tool_call(crawl)
        assert denied is None
        assert allowed["params"]["arguments"]["allow_external"] is False
        assert allowed["params"]["arguments"]["select_domains"] == [r"^docs\.databricks\.com$"]

        research = {
            "jsonrpc": "2.0",
            "id": 2,
            "method": "tools/call",
            "params": {"name": "tavily_research", "arguments": {"input": "x"}},
        }
        allowed, denied = module.enforce_tool_call(research)
        assert allowed is None and denied["error"]["code"] == -32001

        future_tool = {
            "jsonrpc": "2.0",
            "id": 5,
            "method": "tools/call",
            "params": {"name": "tavily_future_web_tool", "arguments": {}},
        }
        allowed, denied = module.enforce_tool_call(future_tool)
        assert allowed is None and denied["error"]["code"] == -32001

    print("Tavily policy regression tests passed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
