#Requires -Version 7.4
# =============================================================================
# PACKAGE MAINTENANCE NOTES
# Purpose: Windows static regression checks for the current two-container / tamper-resistant Docker-log package.
# =============================================================================
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop';$env:PYTHONDONTWRITEBYTECODE='1';$Root=Split-Path -Parent (Split-Path -Parent $PSScriptRoot);$script:Failures=0
function Pass($m){Write-Host "  [OK]   $m" -ForegroundColor Green};function Fail($m){Write-Host "  [FAIL] $m" -ForegroundColor Red;$script:Failures++};function Skip($m){Write-Host "  [SKIP] $m" -ForegroundColor Yellow}
Write-Host '=== AI Sandbox package lint ===' -ForegroundColor Cyan
$Required=@(
    '.build.env.example','.env.example','.devcontainer\Dockerfile','.devcontainer\post-create.sh',
    'tar\docker-compose.yml','ecr\docker-compose.yml',
    '.devcontainer\scripts\configure-aws-sso.sh','.devcontainer\scripts\sandbox-aws-login.sh',
    '.devcontainer\scripts\sandbox-info.sh','.devcontainer\scripts\claude-audit-hook.sh',
    '.devcontainer\scripts\application-audit.sh','.devcontainer\scripts\sandbox-log-emit.sh','.devcontainer\scripts\sandbox-command-wrapper.sh',
    'scripts\tar\build-and-export.ps1','scripts\tar\load-and-start.ps1',
    'scripts\platform\02-setup-ecr.ps1','scripts\ecr\pull-and-start.ps1',
    'scripts\platform\03-setup-logging.ps1',
    'scripts\monitoring\export-docker-logs-to-host.ps1','scripts\monitoring\verify-host-log-export.ps1',
    'scripts\applications\add-application.ps1','scripts\applications\remove-application.ps1',
    'scripts\applications\validate-application.ps1','scripts\applications\application-helper.py',
    'templates\developer\devcontainer-ecr.json',
    'templates\developer\DEVELOPER-GUIDE-TAR.md','templates\developer\DEVELOPER-GUIDE-ECR.md',
    'sentinel\detection-rules.kql'
)
foreach($f in $Required){if(Test-Path(Join-Path $Root $f)){Pass $f}else{Fail "$f missing"}}
if(Test-Path(Join-Path $Root 'fluent-bit')){Fail 'fluent-bit directory still exists'}else{Pass 'fluent-bit directory absent'}
$Active=@((Join-Path $Root 'scripts'),(Join-Path $Root 'tar'),(Join-Path $Root 'ecr'),(Join-Path $Root '.build.env.example'),(Join-Path $Root '.env.example'))
$refs=$Active|Get-ChildItem -Recurse -File -ErrorAction SilentlyContinue|Where-Object{$_.Name-notlike'lint-package.*'}|Select-String -Pattern 'sandbox-fluent-bit|FLUENT_BIT_BASE_IMAGE|AZURE_LAW_|azure-law-(workspace-id|shared-key)' -ErrorAction SilentlyContinue
if($refs){$refs|ForEach-Object{Write-Host $_};Fail 'active Fluent Bit/shared-key references remain'}else{Pass 'no active Fluent Bit/shared-key references'}
$tarCompose=Get-Content (Join-Path $Root 'tar\docker-compose.yml') -Raw
$ecrCompose=Get-Content (Join-Path $Root 'ecr\docker-compose.yml') -Raw
foreach($compose in @('tar\docker-compose.yml','ecr\docker-compose.yml')){
    $txt=Get-Content(Join-Path $Root $compose)-Raw
    $devMount=$txt -match '(?s)source:\s*"\$\{SANDBOX_LOG_ROOT[^\n]*?/devcontainer".*?target:\s*/var/log/sandbox.*?read_only:\s*true'
    $squidMount=$txt -match '(?s)source:\s*"\$\{SANDBOX_LOG_ROOT[^\n]*?/squid".*?target:\s*/var/log/squid.*?read_only:\s*true'
    $localDrivers=([regex]::Matches($txt,'driver:\s*local')).Count -ge 2
    if($devMount -and $squidMount -and $localDrivers){Pass "$compose protected Windows host log mounts are read-only"}else{Fail "$compose protected host logging contract missing or writable"}
}
$loggingSetup=Get-Content (Join-Path $Root 'scripts\platform\03-setup-logging.ps1') -Raw
$hostExporter=Get-Content (Join-Path $Root 'scripts\monitoring\export-docker-logs-to-host.ps1') -Raw
if($loggingSetup -match 'S-1-5-18' -and $loggingSetup -match 'ReadAndExecute' -and $loggingSetup -match 'AI-Sandbox-Protected-Log-Export' -and $hostExporter -match 'Protected host log export must run as LOCALSYSTEM'){Pass 'Windows protected-log ACL + LOCALSYSTEM exporter contract present'}else{Fail 'Windows protected-log ACL/exporter contract missing'}
$envExample=Get-Content (Join-Path $Root '.env.example') -Raw
$tarLauncher=Get-Content (Join-Path $Root 'scripts\tar\load-and-start.ps1') -Raw
$ecrLauncher=Get-Content (Join-Path $Root 'scripts\ecr\pull-and-start.ps1') -Raw
if($envExample -match '(?m)^SANDBOX_LOG_MODE=auto$' -and $loggingSetup -match "ValidateSet\('Protected','PocLocal'\)" -and $hostExporter -match "ValidateSet\('Protected','PocLocal'\)" -and $hostExporter.Contains('[switch]$Continuous') -and $tarLauncher.Contains('if ($SandboxType -eq ''poc'') { ''poc-local'' } else { ''protected'' }') -and $ecrLauncher.Contains('if ($SandboxType -eq ''poc'') { ''poc-local'' } else { ''protected'' }') -and $tarLauncher.Contains('$env:SANDBOX_LOG_ROOT=$HostLog.ComposeRoot') -and $ecrLauncher.Contains('$env:SANDBOX_LOG_ROOT=$HostLog.ComposeRoot') -and $tarLauncher.Contains('Set-RuntimeEnvValue -Path $EnvFile -Key ''SANDBOX_LOG_ROOT''') -and $ecrLauncher.Contains('Set-RuntimeEnvValue -Path $EnvFile -Key ''SANDBOX_LOG_ROOT''') -and $tarLauncher.Contains('Production manifests require protected host logging') -and $ecrLauncher.Contains('Production manifests require protected host logging')){Pass 'manifest-driven auto logging selects non-admin POC local mode, persists resolved Compose path, and fail-closes Production'}else{Fail 'auto POC/Production host-logging contract missing'}
$developerExporter=Get-Content (Join-Path $Root 'scripts\admin\export-developer-packages.ps1') -Raw
if($developerExporter -match 'scripts\\monitoring\\\$f' -and $developerExporter -match 'export-docker-logs-to-host\.ps1' -and $developerExporter -match 'export-docker-logs-to-host\.sh'){Pass 'Developer TAR/ECR export includes PowerShell and Bash POC log exporter helpers'}else{Fail 'Developer package export is missing POC log exporter helpers'}
$tarLauncherSh=Get-Content (Join-Path $Root 'scripts\tar\load-and-start.sh') -Raw
if($tarLauncher.Contains('$EnvFile = Join-Path $Root ''tar\.env''') -and $tarLauncherSh.Contains('ENV_FILE="$ROOT/tar/.env"') -and $developerExporter.Contains('Join-Path $Tar ''tar\.env.example''') -and $envExample -match '(?m)^SANDBOX_LOG_ROOT=$' -and $envExample -match '(?m)^DEVELOPER_ID=$' -and $envExample -match '(?m)^SANDBOX_ENV=$' -and $tarLauncher.Contains('Set-RuntimeEnvValue -Path $EnvFile -Key ''SANDBOX_ENV''') -and $tarLauncherSh.Contains('set_env_value SANDBOX_ENV "$SANDBOX_ENV"')){Pass 'TAR launcher and VS Code Compose share tar/.env; site-specific template values are blank'}else{Fail 'TAR deployment-local .env contract is inconsistent'}
$logEmitter=Get-Content (Join-Path $Root '.devcontainer\scripts\sandbox-log-emit.sh') -Raw
if($logEmitter -match 'target="/proc/1/fd/1"' -and $logEmitter -notmatch 'SANDBOX_LOG_FD'){Pass 'Managed log sink is hardcoded to PID1 stdout'}else{Fail 'Managed log sink can be redirected by Developer environment'}
$auditLogger=Get-Content (Join-Path $Root '.devcontainer\scripts\sandbox-audit-logger.sh') -Raw
$loopPos=$logEmitter.IndexOf('while IFS= read -r line')
$lockPos=$logEmitter.IndexOf('flock -w "$lock_timeout" -x 9')
$closePos=$logEmitter.LastIndexOf('exec 9>&-')
if($loopPos -ge 0 -and $lockPos -gt $loopPos -and $closePos -gt $lockPos){Pass 'Docker-stream serialization lock is record-scoped and released by closing the lock FD'}else{Fail 'sandbox-log-emit can hold the serialization lock across a long-lived producer'}
if($logEmitter.Contains('lock_timeout="0.2"') -and $logEmitter.Contains('source_name" == "shell') -and $logEmitter.Contains('lock_timeout="1"')){Pass 'interactive shell log lock wait is bounded below required application-audit window'}else{Fail 'interactive shell log timeout separation missing'}
if($logEmitter -notmatch '\|\s*tr\s' -and $logEmitter -notmatch '\|\s*cut\s' -and $logEmitter -match 'invalid sandbox log source identifier'){Pass 'log emitter validates source labels with Bash built-ins'}else{Fail 'log emitter still spawns source-sanitization subprocesses'}
if($auditLogger -match '_AI_SANDBOX_AUDIT_LOGGER_LOADED' -and $auditLogger -match 'case ";\$\{PROMPT_COMMAND:-\};"' -and $auditLogger -match 'Logging failure must not'){Pass 'interactive shell audit hook is idempotent and prompt-safe'}else{Fail 'interactive shell audit hook can duplicate or stall the prompt'}
if($auditLogger.Contains('hist=$(HISTTIMEFORMAT='''' history 1)') -and $auditLogger.Contains('BASH_REMATCH[1]') -and $auditLogger.Contains('read -r -a words <<< "$cmd"') -and $auditLogger.Contains('printf -v REPLY') -and $auditLogger.Contains('/usr/local/bin/sandbox-log-emit audit shell <<< "$record"') -and -not $auditLogger.Contains('_cmd_metadata()') -and -not $auditLogger.Contains('history 1 | sed') -and -not $auditLogger.Contains('$(date')){Pass 'interactive shell hot path uses Bash built-ins and direct emitter redirection'}else{Fail 'interactive shell hot path still contains avoidable subprocesses'}
if((Get-Content (Join-Path $Root '.devcontainer\Dockerfile') -Raw) -match 'sandbox-log-emit\) ;;' -and $auditLogger -match '(?s)if \[\[ \$- == \*i\* \]\]; then.*?_aw "SESSION_START".*?fi' -and ([regex]::Matches($auditLogger,'_aw "SESSION_START"')).Count -eq 1){Pass 'BASH_ENV emitter recursion is blocked and SESSION_START is interactive-only'}else{Fail 'audit logger can recursively emit SESSION_START from non-interactive helper Bash'}
if($auditLogger.Contains('run-with-ssm-secrets|claude|claude-code|gemini|gemini-cli|ucode|tavily-mcp|ado-trigger|ado-pr-create|ado-auth-setup)') -and $auditLogger.Contains('git|snyk|databricks|tvly)') -and $auditLogger.Contains('meta="tool=$first argc=$argc"')){Pass 'shell command attribution excludes arbitrary prompt/URL argv values'}else{Fail 'shell command metadata can expose free-form argv values'}
$cisHardening=Get-Content (Join-Path $Root '.devcontainer\cis-level1-harden.sh') -Raw
if($cisHardening -notmatch '/var/log/sandbox/.*\.log' -and $cisHardening -notmatch '/var/log/squid/(access|cache)\.log'){Pass 'CIS logging is container-tailored to Docker-owned streams'}else{Fail 'CIS hardening reintroduces writable runtime file-log sinks'}
$squidConf=Get-Content (Join-Path $Root 'squid\squid.conf') -Raw
if($squidConf -match 'access_log stdio:/dev/stdout' -and $squidConf -match 'cache_log\s+/dev/stderr' -and $squidConf -match 'cache_store_log none' -and $squidConf -match 'logfile_rotate 0'){Pass 'Squid access/cache logs use Docker streams without file store logs'}else{Fail 'Squid Docker stream logging missing'}
if($tarCompose -match 'SANDBOX_CONTENT_LOGGING: "\$\{SANDBOX_CONTENT_LOGGING:-false\}"' -and $tarCompose -match 'GEMINI_TELEMETRY_LOG_PROMPTS: "false"' -and $ecrCompose -match 'SANDBOX_CONTENT_LOGGING: "\$\{SANDBOX_CONTENT_LOGGING:-false\}"' -and $ecrCompose -match 'GEMINI_TELEMETRY_LOG_PROMPTS: "false"'){Pass 'Content logging defaults off'}else{Fail 'Content logging default policy missing'}
$dockerfile=Get-Content (Join-Path $Root '.devcontainer\Dockerfile') -Raw

if($dockerfile -match 'vim-tiny' -and $dockerfile -match "'set nomodeline'" -and $dockerfile -match "'set noexrc'" -and $dockerfile -match "'set noswapfile'" -and $dockerfile -match 'chmod 0444 /etc/vim/vimrc.local'){Pass 'minimal vi is installed with hardened immutable configuration'}else{Fail 'secure vi/vim-tiny configuration missing'}
if($dockerfile -match '/usr/local/bin/claude-audit-hook' -and $dockerfile -match '/etc/claude-code/managed-settings.json'){Pass 'Claude managed audit hook'}else{Fail 'Claude managed audit hook missing'}
if($dockerfile -match '/usr/local/bin/application-audit'){Pass 'application-audit helper'}else{Fail 'application-audit helper missing'}
if($dockerfile -match '/usr/local/libexec/ai-sandbox/sandbox-command-wrapper'){Pass 'SSM command wrapper baked into image'}else{Fail 'SSM command wrapper missing'}
$buildOrchestrator=Get-Content (Join-Path $Root 'scripts\admin\build-sandbox.ps1') -Raw
$baseResolver=Get-Content (Join-Path $Root 'scripts\supply-chain\resolve-base-digests.ps1') -Raw
if($buildOrchestrator -match '\[switch\]\$ReuseHardenedBase' -and $buildOrchestrator -match 'Test-ReusableHardenedBase' -and $buildOrchestrator -match 'hardening\.method' -and $buildOrchestrator -match 'hardening\.profile' -and $buildOrchestrator -match '\.build\.env\.full-build' -and $buildOrchestrator -match 'committed only after hardening succeeds' -and $baseResolver -match 'BUILD_ENV_FILE'){Pass 'validated hardened-base reuse with transactional fallback'}else{Fail 'hardened-base reuse/transaction contract missing'}
$hardeningPs=Get-Content (Join-Path $Root 'scripts\hardening\build-hardened-base.ps1') -Raw
$hardeningSh=Get-Content (Join-Path $Root 'scripts\hardening\build-hardened-base.sh') -Raw
if($hardeningPs -match 'type=bind,source=\$ResultsDir,target=/results' -and $hardeningPs -match 'COPY cleanup-toolchain\.sh /opt/hardening/cleanup-toolchain\.sh' -and $hardeningPs -notmatch 'Invoke-Docker\s+-Arguments\s+@\("cp"' -and $hardeningSh -match '--mount "type=bind,source=\$RESULTS_DIR,target=/results"' -and $hardeningSh -match 'COPY cleanup-toolchain\.sh /opt/hardening/cleanup-toolchain\.sh' -and $hardeningSh -notmatch '(?m)^\s*docker\s+cp\b'){Pass 'ECI-safe hardening builder avoids docker cp and persists evidence through a bind mount'}else{Fail 'ECI-safe hardening builder contract missing or docker cp reintroduced'}
if($buildOrchestrator -match '\[string\]\$DeploymentType' -and $buildOrchestrator -match "if \(\$ResolvedDeploymentType -eq 'tar'\)" -and $buildOrchestrator -match "'poc'\) \{ 'tar' \} else \{ 'ecr' \}" -and $buildOrchestrator -match 'scripts\\tar\\build-and-export.ps1' -and $buildOrchestrator -match '02-setup-ecr.ps1 -SandboxType'){Pass 'SandboxType hardening and DeploymentType distribution are independently selectable'}else{Fail 'SandboxType/DeploymentType separation missing'}
$buildEnvExample=Get-Content (Join-Path $Root '.build.env.example') -Raw
if($buildEnvExample -match '(?m)^HARDENED_CONFIG_ID=' -and $hardeningPs -match 'HARDENED_CONFIG_ID=\$HardenedConfigId' -and $hardeningSh -match 'HARDENED_CONFIG_ID=\$\{HARDENED_CONFIG_ID\}' -and $buildOrchestrator -match 'Labels alone are never sufficient for recovery' -and $buildOrchestrator -match '\.build\.env\.reuse\.' -and $hardeningPs -match 'Registry V2 API' -and $hardeningSh -match 'Registry V2 API'){Pass 'hardened-base reuse uses config-ID recovery, fail-closed legacy fallback, and transactional digest/tool refresh'}else{Fail 'hardened-base config-ID recovery/transaction contract missing'}
$versionMatch=[regex]::Match($buildEnvExample,'(?m)^SANDBOX_VERSION=(v[0-9]+\.[0-9]+\.[0-9]+)$')
$releaseMatch=[regex]::Match($buildEnvExample,'(?m)^RELEASE_TAG=(v[0-9]+\.[0-9]+\.[0-9]+)$')
$orchestratorVersion=[regex]::Match($buildOrchestrator,'(?m)^\$PackageVersion\s*=\s*''([^'']+)''')
if($versionMatch.Success -and $releaseMatch.Success -and $orchestratorVersion.Success -and $versionMatch.Groups[1].Value -eq $releaseMatch.Groups[1].Value -and $versionMatch.Groups[1].Value -eq $orchestratorVersion.Groups[1].Value -and $buildOrchestrator -match '\[string\]\$BuildEnvSource'){Pass "build-env migration/version metadata is dynamically consistent ($($versionMatch.Groups[1].Value))"}else{Fail 'build-env migration/version metadata is inconsistent'}
$commandWrapper=Get-Content (Join-Path $Root '.devcontainer\scripts\sandbox-command-wrapper.sh') -Raw
if($commandWrapper -match '--profile anthropic' -and $commandWrapper -match '--profile gemini' -and $commandWrapper -match 'real_tool ucode' -and $commandWrapper -match '--profile databricks'){Pass 'direct Claude/Gemini and explicit ucode/Databricks routing are separated'}else{Fail 'AI command routing contract missing'}
$mcp=Get-Content (Join-Path $Root '.devcontainer\scripts\configure-mcp.sh') -Raw
if($mcp -match '/usr/local/bin/tavily-mcp-ssm' -and $mcp -match 'REAL_GEMINI' -and $mcp -match '/etc/claude-code/managed-mcp.json' -and $mcp -notmatch 'REAL_CLAUDE.*mcp add'){Pass 'Gemini MCP credential-value-free and Claude MCP Admin-file managed'}else{Fail 'MCP registration path incorrect'}
if($dockerfile -match '"allowManagedHooksOnly": true'){Pass 'Claude hooks are restricted to the Admin-managed policy source'}else{Fail 'Admin-only Claude hook policy missing'}
$secretRunner=Get-Content (Join-Path $Root '.devcontainer\scripts\run-with-ssm-secrets.sh') -Raw
# Gemini strips inherited sensitive variables from stdio MCP children,
# so settings must carry literal runtime references but never credential values.
if($mcp -notmatch '(?m)mcp\s+add\b.*(?:\s-e\s|\s--env\s)'){Pass 'Gemini MCP does not use CLI -e credential injection'}else{Fail 'Gemini MCP still uses command-line env injection'}
if($mcp -match 'AWS_ACCESS_KEY_ID: "\$AWS_ACCESS_KEY_ID"' -and $mcp -match 'AWS_SECRET_ACCESS_KEY: "\$AWS_SECRET_ACCESS_KEY"' -and $mcp -match 'AWS_SESSION_TOKEN: "\$AWS_SESSION_TOKEN"' -and $mcp -match 'approved AWS runtime references'){Pass 'Gemini MCP stores only approved runtime AWS references, never values'}else{Fail 'Gemini MCP runtime-reference contract missing'}
if($mcp -match 'gemini_state_home="\$\{GEMINI_CLI_HOME:-\$HOME\}"' -and $secretRunner -match 'GEMINI_CLI_HOME="\$ucode_gemini_cli_home"' -and $secretRunner -match 'from ucode.agents.gemini import GEMINI_HOME_DIR'){Pass 'direct and ucode Gemini MCP settings target correct Gemini state homes'}else{Fail 'ucode Gemini GEMINI_CLI_HOME MCP contract missing'}
if($mcp -match 'mcpServers' -and $mcp -match 'AWS access-key credential material detected'){Pass 'MCP settings written deterministically with credential-value self-check'}else{Fail 'MCP settings writer or credential self-check missing'}
$appHelper=Get-Content (Join-Path $Root 'scripts\applications\application-helper.py') -Raw
if($appHelper -match 'mcp-wrapper-preamble' -and $appHelper -match 'AWS_ACCESS_KEY_ID: "\$AWS_ACCESS_KEY_ID"' -and $appHelper -match '"\$gemini_config_dir"' -and $appHelper -match '\.devcontainer/policies/claude-mcp\.json' -and $appHelper -match 'add_claude_managed_mcp' -and $appHelper -notmatch 'REAL_CLAUDE' -and $appHelper -notmatch 'mcp\s+add-json' -and $appHelper -notmatch '"\$REAL_GEMINI"\s+mcp\s+add'){Pass 'Admin application helper preserves managed Claude and Gemini MCP contracts'}else{Fail 'application helper would regress managed MCP registration'}
$tavilyWrapper=Get-Content (Join-Path $Root '.devcontainer\scripts\tavily-mcp-ssm.sh') -Raw
$snykWrapper=Get-Content (Join-Path $Root '.devcontainer\scripts\snyk-mcp-ssm.sh') -Raw
$mcpPreamble=Join-Path $Root '.devcontainer\scripts\mcp-wrapper-preamble.sh'
if((Test-Path $mcpPreamble) -and $tavilyWrapper -match 'mcp-wrapper-preamble' -and $snykWrapper -match 'mcp-wrapper-preamble'){Pass 'MCP wrappers source the deterministic environment preamble'}else{Fail 'MCP wrapper preamble missing or not sourced'}

if($mcp -match '/usr/local/bin/databricks-sql-mcp-ssm' -and $secretRunner -match 'databricks-sql-mcp-token' -and $dockerfile -match 'mcp-remote@\$\{MCP_REMOTE_VERSION\}'){Pass 'Databricks SQL MCP uses dedicated SSM token and pinned bridge'}else{Fail 'Databricks SQL MCP contract missing'}
if($secretRunner -match "databricks-sql-mcp\)\s+printf\s+'databricks'" -and $secretRunner -notmatch 'audit_safe\s+"\$profile"'){Pass 'internal Databricks SQL MCP profile maps to approved databricks audit namespace'}else{Fail 'Databricks SQL MCP profile/audit application mapping is inconsistent'}
$claudeMcpPolicy=Join-Path $Root '.devcontainer\policies\claude-mcp.json'
if((Test-Path $claudeMcpPolicy) -and $dockerfile -match '/etc/claude-code/managed-mcp.json' -and $commandWrapper -match '/etc/claude-code/managed-mcp.json' -and $secretRunner -match '/etc/claude-code/managed-mcp.json' -and $secretRunner -notmatch '--mcp-config'){Pass 'Claude and ucode Claude use the root-owned managed MCP deployment'}else{Fail 'Claude managed MCP contract missing'}
if($dockerfile -match 'command -v tavily-mcp >/dev/null 2>&1' -and $dockerfile -match 'command -v mcp-remote >/dev/null 2>&1' -and $dockerfile -notmatch 'tavily-mcp --help' -and $dockerfile -notmatch 'mcp-remote --help'){Pass 'MCP executables build-validated with command -v'}else{Fail 'MCP executable build validation regressed'}
$activeStsFiles=@(
  Get-ChildItem (Join-Path $Root '.devcontainer\scripts') -Recurse -File
  Get-ChildItem (Join-Path $Root 'scripts\ecr') -Recurse -File
  Get-Item (Join-Path $Root 'squid\whitelist.txt')
)
$activeSts=$activeStsFiles | Select-String -Pattern 'get-caller-identity|aws\s+sts|sts\.eu-west-2\.amazonaws\.com' -ErrorAction SilentlyContinue
if($activeSts){Fail 'explicit STS dependency remains in active runtime/ECR paths'}else{Pass 'active runtime/ECR paths have no explicit STS dependency'}
$geminiWebPolicy=Get-Content (Join-Path $Root '.devcontainer\policies\gemini-web-policy.toml') -Raw
if($tavilyWrapper -match 'tavily-policy-proxy.py' -and $secretRunner -match 'unset DEFAULT_PARAMETERS' -and $dockerfile -match 'tavily-allowed-domains.json'){Pass 'Tavily MCP domain allowlist is enforced by Admin-owned proxy'}else{Fail 'Tavily hard domain policy missing'}
$python = Get-Command python -ErrorAction SilentlyContinue
if($python){ & $python.Source (Join-Path $Root 'scripts\ci\test-tavily-policy.py') *> $null; if($LASTEXITCODE -eq 0){Pass 'Tavily policy blocks explicit unapproved domains and constrains generic search'}else{Fail 'Tavily policy behavioral regression test failed'} } else { Skip 'python unavailable for Tavily policy behavioral test' }
if($dockerfile -match '"WebSearch"' -and $geminiWebPolicy -match 'google_web_search'){Pass 'Claude/Gemini native web tools are disabled by Admin policy'}else{Fail 'Admin native-web deny policy missing'}
if($tarCompose -match 'SANDBOX_AUDIT_REQUIRED: "\$\{SANDBOX_AUDIT_REQUIRED:-true\}"' -and $ecrCompose -match 'SANDBOX_AUDIT_REQUIRED: "\$\{SANDBOX_AUDIT_REQUIRED:-true\}"'){Pass 'application audit required by default in TAR/ECR'}else{Fail 'application audit policy missing from TAR/ECR'}
$devcontainerJson=Get-Content (Join-Path $Root '.devcontainer\devcontainer.json') -Raw
$ecrDevcontainerJson=Get-Content (Join-Path $Root 'templates\developer\devcontainer-ecr.json') -Raw
if($devcontainerJson -match '"workspaceFolder"\s*:\s*"/home/vscode/workspace"' -and $ecrDevcontainerJson -match '"workspaceFolder"\s*:\s*"/home/vscode/workspace"' -and $tarCompose -match 'target:\s*/home/vscode/workspace' -and $ecrCompose -match 'target:\s*/home/vscode/workspace' -and $dockerfile -match 'WORKDIR /home/\$\{USERNAME\}/workspace'){Pass 'Developer workspace is mounted under /home/vscode/workspace'}else{Fail 'home-workspace contract missing'}
$legacyWorkspace=Get-ChildItem @((Join-Path $Root '.devcontainer'),(Join-Path $Root 'tar'),(Join-Path $Root 'ecr'),(Join-Path $Root 'templates\developer')) -Recurse -File -ErrorAction SilentlyContinue | Where-Object {$_.Name -notlike 'lint-package.*'} | Select-String -Pattern 'workspaceFolder"\s*:\s*"/workspace"|target:\s*/workspace(?:\s|$)|WORKDIR\s+/workspace(?:\s|$)' -ErrorAction SilentlyContinue
if($legacyWorkspace){Fail 'legacy root-level /workspace runtime path remains'}else{Pass 'legacy root-level /workspace runtime path absent'}
if($tarCompose -match 'AWS_ACCESS_KEY_ID' -and $tarCompose -match 'AWS_SECRET_ACCESS_KEY' -and $tarCompose -match 'AWS_SSO_START_URL' -and $tarCompose -match 'SANDBOX_AWS_PROFILE' -and $ecrCompose -match 'AWS_ACCESS_KEY_ID' -and $ecrCompose -match 'AWS_SECRET_ACCESS_KEY' -and $ecrCompose -match 'AWS_SSO_START_URL' -and $ecrCompose -match 'SANDBOX_AWS_PROFILE' -and $tarCompose -notmatch '(?m)^\s*AWS_PROFILE:' -and $ecrCompose -notmatch '(?m)^\s*AWS_PROFILE:'){Pass 'AWS static-key and SSO fallback Compose mapping without AWS_PROFILE injection'}else{Fail 'AWS dual-mode Compose/profile isolation missing'}
$login=Get-Content (Join-Path $Root '.devcontainer\scripts\sandbox-aws-login.sh') -Raw
$awsBootstrap=Get-Content (Join-Path $Root '.devcontainer\scripts\configure-aws-sso.sh') -Raw
if($secretRunner -match 'aws_auth_mode="static"' -and $secretRunner -match 'drop_aws_bootstrap_credentials' -and $secretRunner -match 'Tavily/Snyk MCP wrappers'){Pass 'static AWS key-first runtime flow with MCP inheritance'}else{Fail 'static AWS key-first runtime flow with MCP inheritance missing'}
if($awsBootstrap -match 'Non-secret compatibility profile for static environment credentials' -and $awsBootstrap -match '\[default\]' -and $awsBootstrap -match 'SANDBOX_AWS_PROFILE' -and $secretRunner -match 'configure-aws-sso >/dev/null'){Pass 'AWS_PROFILE is isolated from runtime while default/named AWS config is prepared'}else{Fail 'AWS profile isolation/bootstrap missing'}
if($secretRunner -match 'sandbox-aws-login' -and $login -match '--use-device-code --no-browser'){Pass 'SSO browser fallback flow'}else{Fail 'automatic SSO fallback flow missing'}
# IAM Identity Center must remain reachable from ephemeral HOME
# directories (ucode agents, Tavily/Snyk MCP), and must never prompt on stdio.
if($secretRunner -match 'SANDBOX_AWS_HOME' -and $secretRunner -match 'HOME="\$AWS_STATE_HOME" aws' -and $login -match 'SANDBOX_AWS_HOME'){Pass 'AWS CLI state pinned to a HOME-independent anchor for SSO reachability'}else{Fail 'AWS state anchor missing; SSO breaks under ephemeral HOME'}
if($secretRunner -match 'SANDBOX_NONINTERACTIVE' -and $login -match 'SANDBOX_NONINTERACTIVE'){Pass 'interactive SSO sign-in refused in MCP stdio contexts'}else{Fail 'non-interactive SSO guard missing'}
if($login -match 'flock'){Pass 'concurrent SSO sign-in attempts are serialised'}else{Fail 'SSO sign-in lock missing'}
if($dockerfile -match '/opt/snyk-cache' -and $secretRunner -match '/opt/snyk-cache'){Pass 'Snyk native runtime cache pre-warmed and seeded into the exec tmpfs'}else{Fail 'Snyk runtime cache pre-warm/seed missing'}
if($tarCompose -match 'SANDBOX_AWS_HOME' -and $ecrCompose -match 'SANDBOX_AWS_HOME'){Pass 'AWS state anchor exported by both Compose files'}else{Fail 'SANDBOX_AWS_HOME missing from Compose'}
$ssmPs1=Get-Content (Join-Path $Root 'scripts\platform\01-setup-ssm.ps1') -Raw
$ssmSh=Get-Content (Join-Path $Root 'scripts\platform\01-setup-ssm.sh') -Raw
if($ssmPs1 -match 'claude-api-key' -and $ssmPs1 -match 'gemini-api-key' -and $ssmSh -match 'claude-api-key' -and $ssmSh -match 'gemini-api-key' -and $secretRunner -match 'claude-api-key' -and $secretRunner -match 'gemini-api-key'){Pass 'direct Claude/Gemini API keys are SSM-managed'}else{Fail 'direct AI SSM parameter contract missing'}
if($secretRunner -match 'DATABRICKS_CLAUDE_MODEL is required' -and $secretRunner -match '--model "\$DATABRICKS_CLAUDE_MODEL"' -and $tarCompose -match 'DATABRICKS_CLAUDE_MODEL' -and $ecrCompose -match 'DATABRICKS_CLAUDE_MODEL'){Pass 'Claude model is explicit for ucode/Databricks'}else{Fail 'Databricks Claude model routing contract missing'}
if($secretRunner -match 'export GEMINI_MODEL="\$DATABRICKS_GEMINI_MODEL"' -and $tarCompose -match 'DATABRICKS_GEMINI_MODEL' -and $ecrCompose -match 'DATABRICKS_GEMINI_MODEL' -and $secretRunner -match 'export GEMINI_MODEL=""'){Pass 'Gemini model is explicit for ucode/Databricks while bare Gemini stays direct'}else{Fail 'Databricks Gemini model routing contract missing'}
$whitelist=Get-Content (Join-Path $Root 'squid\whitelist.txt')
if($whitelist -contains 'api.anthropic.com' -and $whitelist -contains 'generativelanguage.googleapis.com'){Pass 'direct Anthropic and Gemini API egress is allowlisted'}else{Fail 'direct AI provider egress missing'}
if($dockerfile -match 'stash_real ucode' -and $dockerfile -match '/usr/local/bin/ucode'){Pass 'ucode is stashed and wrapped as the explicit Databricks launcher'}else{Fail 'ucode wrapper installation missing'}

if($secretRunner -match 'run_logged_ephemeral_home tavily' -and $secretRunner -match 'run_logged_snyk_exec_home snyk' -and $secretRunner -match 'XDG_CACHE_HOME'){Pass 'Tavily and Snyk use ephemeral writable runtime state'}else{Fail 'Tavily/Snyk read-only HOME regression protection missing'}
if($secretRunner -match 'DATABRICKS_CLAUDE_MODEL is required' -and $secretRunner -match 'DATABRICKS_GEMINI_MODEL is required'){Pass 'ucode Claude/Gemini fail closed when approved Databricks target is missing'}else{Fail 'ucode Databricks target validation missing'}
if($secretRunner -match '--use-pat' -and $secretRunner -match 'mktemp -d /tmp/ai-sandbox-ucode' -and $secretRunner -match '--skip-validate'){Pass 'ucode uses temporary headless PAT configuration'}else{Fail 'ucode headless PAT routing contract missing'}
$verifySandboxPs1=Get-Content (Join-Path $Root 'scripts\tar\verify-sandbox.ps1') -Raw
if($verifySandboxPs1 -match 'function Dc\(\[string\[\]\]\$DockerArgs\)' -and $verifySandboxPs1 -notmatch 'function Dc\(\[string\[\]\]\$Args\)'){Pass 'PowerShell Docker Compose helper avoids automatic `$Args collision'}else{Fail 'verify-sandbox.ps1 still uses automatic `$Args parameter'}
$Obsolete=@(
    '.devcontainer\.dockerignore','scripts\ecr\devcontainer.template.json','policies\registry.json.template','WINDOWS-QUICKSTART.md','RUNTIME-POLICY.md',
    'poc','scripts\poc','templates\developer\devcontainer-production.json','templates\developer\DEVELOPER-GUIDE-POC.md','templates\developer\DEVELOPER-GUIDE-PRODUCTION.md',
    'scripts\monitoring\send-logs-ingestion.ps1','scripts\monitoring\send-logs-ingestion.sh','sentinel\dcr-logs-ingestion.example.json','templates\developer\env.example'
)
foreach($f in $Obsolete){if(Test-Path(Join-Path $Root $f)){Fail "obsolete duplicate returned: $f"}else{Pass "obsolete absent: $f"}}
$releaseHistory=@(Get-ChildItem (Join-Path $Root 'docs') -Filter 'RELEASE-NOTES-v1.16.*.md' -File -ErrorAction SilentlyContinue)
if($releaseHistory.Count -eq 0){Pass 'release-history documents are external to the active package'}else{Fail 'release-history documents were packaged despite the active-package boundary'}
$obsoleteBuildKeys=@('HARDENED_METHOD','HARDENED_PROFILE','MAX_CRITICAL_FINDINGS','MAX_HIGH_FINDINGS','REQUIRE_IMAGE_SIGNING','COSIGN_KEY_REF')
$obsoleteInTemplate=@($obsoleteBuildKeys | Where-Object { $buildEnvExample -match ('(?m)^'+[regex]::Escape($_)+'=') })
if($obsoleteInTemplate.Count -eq 0){Pass 'obsolete/unimplemented build-env parameters are absent from the public template'}else{Fail ('obsolete build-env parameters remain: '+($obsoleteInTemplate -join ', '))}
$pyCache=@(Get-ChildItem $Root -Recurse -Force -ErrorAction SilentlyContinue | Where-Object { $_.Name -eq '__pycache__' -or $_.Extension -eq '.pyc' })
if($pyCache.Count -eq 0){Pass 'Python cache artifacts are absent'}else{Fail 'Python cache artifacts are packaged'}
$dockerIgnore=Get-Content (Join-Path $Root '.dockerignore') -Raw
if($dockerIgnore -match '(?m)^tar/images/$' -and $dockerIgnore -match '(?m)^\.build\.env$' -and $dockerIgnore -match '(?m)^hardened-base-build/$' -and $dockerIgnore -match '(?m)^\*\*/\.env$' -and $dockerIgnore -match '(?m)^\*\*/\.env\.\*$'){Pass '.dockerignore excludes TAR bundles, deployment-local runtime env files, live build state, and hardening scratch data'}else{Fail '.dockerignore build-context exclusions are incomplete'}
$PsFiles = @(Get-ChildItem $Root -Recurse -Filter '*.ps1' -File)
foreach ($PsFile in $PsFiles) {
    $Head = (Get-Content $PsFile.FullName -TotalCount 12) -join "`n"
    if ($Head -match '(?im)^#Requires\s+-Version\s+7\.4(?:\s|$)') { Pass "PowerShell 7.4 requirement: $($PsFile.Name)" }
    else { Fail "PowerShell 7.4 requirement missing: $($PsFile.FullName)" }
}
# Parse every PowerShell file using the local parser.
Get-ChildItem $Root -Recurse -Filter '*.ps1' -File|ForEach-Object{$tokens=$null;$errors=$null;[System.Management.Automation.Language.Parser]::ParseFile($_.FullName,[ref]$tokens,[ref]$errors)|Out-Null;if($errors.Count){Fail "PowerShell syntax: $($_.FullName)"}else{Pass "PowerShell syntax: $($_.Name)"}}
$envTemplate=Get-Content (Join-Path $root '.env.example') -Raw
$claudeHook=Get-Content (Join-Path $root '.devcontainer/scripts/claude-audit-hook.sh') -Raw
if($envTemplate -match 'SANDBOX_CONTENT_LOGGING=false'){Pass 'Content logging defaults to false'}else{Fail 'Content logging default missing'}
$toolResolver = Get-Content -Raw (Join-Path $Root 'scripts\supply-chain\resolve-tool-artifacts.ps1')
if($dockerfile -match "ucode configure --help > /tmp/ucode-configure-help.txt 2>&1" -and $dockerfile -match "grep -Fq -- '--use-pat' /tmp/ucode-configure-help.txt" -and $buildOrchestrator -match 'resolve-tool-artifacts.ps1 -Write -UcodeOnly' -and $toolResolver -match '\[switch\]\$UcodeOnly'){Pass 'ucode headless PAT capability is refreshed and build-time validated'}else{Fail 'ucode refresh/build-time validation missing'}
if($tarCompose -match '/run/ai-sandbox-snyk:rw,exec,nosuid,nodev' -and $ecrCompose -match '/run/ai-sandbox-snyk:rw,exec,nosuid,nodev' -and $secretRunner -match 'run_logged_snyk_exec_home'){Pass 'Snyk uses isolated executable tmpfs while /tmp remains noexec'}else{Fail 'Snyk executable tmpfs contract missing'}
if($claudeHook -match 'CONTENT_SOURCE="ucode-claude"' -and $secretRunner -match 'SANDBOX_AI_ROUTE="databricks-gemini"' -and $secretRunner -match 'sandbox-log-emit gemini-telemetry' -and $secretRunner -match 'GEMINI_TELEMETRY_OUTFILE="/proc/self/fd/'){Pass 'Databricks-routed content is route-tagged and Docker-streamed'}else{Fail 'Databricks content stream routing missing'}
Write-Host '======================================'
if($script:Failures){Write-Host "LINT FAILED: $script:Failures issue(s)." -ForegroundColor Red;exit 1}
Write-Host 'LINT PASSED: package is structurally valid.' -ForegroundColor Green
