#Requires -Version 7.4
# =============================================================================
# PACKAGE MAINTENANCE NOTES
# Purpose:
#   Developer ECR launcher. Fetches the centrally approved two-image
#   manifest from AWS SSM, validates it, pulls exact ECR digests, and starts
#   DevContainer + Squid.
#
# Logging:
#   Requires the Admin-prepared SYSTEM-owned Windows log root. Runtime containers
#   mount it read-only; a SYSTEM scheduled task exports Docker streams to it.
# =============================================================================
[CmdletBinding()]
param(
    [string]$SandboxDir = (Split-Path -Parent (Split-Path -Parent $PSScriptRoot))
)

$ErrorActionPreference = 'Stop'
$ComposeFile = Join-Path $SandboxDir 'docker-compose.yml'
$EnvFile = Join-Path $SandboxDir '.env'
$EnvTemplate = Join-Path $SandboxDir '.env.example'

function Read-KeyValueFile {
    param([Parameter(Mandatory = $true)][string]$Path)
    $Map = @{}
    Get-Content $Path | ForEach-Object {
        $Line = $_.TrimEnd("`r")
        if ($Line -and -not $Line.TrimStart().StartsWith('#')) {
            $Index = $Line.IndexOf('=')
            if ($Index -gt 0) {
                $Map[$Line.Substring(0, $Index).Trim()] = $Line.Substring($Index + 1).Trim()
            }
        }
    }
    return $Map
}

function Test-ConfiguredValue {
    param([string]$Value)
    return (
        -not [string]::IsNullOrWhiteSpace($Value) -and
        $Value -notmatch '[<>]' -and
        $Value -notlike '*REPLACE_*' -and
        $Value -ne 'yourname'
    )
}

if (-not (Test-Path $ComposeFile)) { throw "Missing $ComposeFile" }
if (-not (Test-Path $EnvFile)) {
    Copy-Item $EnvTemplate $EnvFile
    Write-Host "Created $EnvFile. Configure runtime values and rerun. Protect .env if AWS static credentials are used." -ForegroundColor Yellow
    exit 2
}

function Set-RuntimeEnvValue {
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][string]$Key,
        [Parameter(Mandatory = $true)][string]$Value
    )
    $Lines = [System.Collections.Generic.List[string]]::new()
    $Found = $false
    foreach ($Line in (Get-Content -LiteralPath $Path -Encoding UTF8)) {
        if ($Line -match ('^' + [regex]::Escape($Key) + '=')) {
            $Lines.Add("$Key=$Value")
            $Found = $true
        }
        else { $Lines.Add($Line) }
    }
    if (-not $Found) { $Lines.Add("$Key=$Value") }
    $Temp = "$Path.tmp.$([guid]::NewGuid().ToString('N'))"
    try {
        [IO.File]::WriteAllLines($Temp, $Lines, [Text.UTF8Encoding]::new($false))
        Move-Item -LiteralPath $Temp -Destination $Path -Force
    }
    finally {
        if (Test-Path -LiteralPath $Temp) { Remove-Item -LiteralPath $Temp -Force -ErrorAction SilentlyContinue }
    }
}


$ProtectedLogSystemSid = 'S-1-5-18'
$ProtectedLogWriteMask = [Security.AccessControl.FileSystemRights]::WriteData `
    -bor [Security.AccessControl.FileSystemRights]::AppendData `
    -bor [Security.AccessControl.FileSystemRights]::CreateDirectories `
    -bor [Security.AccessControl.FileSystemRights]::WriteAttributes `
    -bor [Security.AccessControl.FileSystemRights]::WriteExtendedAttributes `
    -bor [Security.AccessControl.FileSystemRights]::Delete `
    -bor [Security.AccessControl.FileSystemRights]::DeleteSubdirectoriesAndFiles `
    -bor [Security.AccessControl.FileSystemRights]::ChangePermissions `
    -bor [Security.AccessControl.FileSystemRights]::TakeOwnership

function Get-ProtectedLogRuleSid([Security.Principal.IdentityReference]$IdentityReference) {
    try { return $IdentityReference.Translate([Security.Principal.SecurityIdentifier]).Value }
    catch { return $IdentityReference.Value }
}

function Assert-ProtectedLogAcl([string]$Path) {
    $Acl = Get-Acl -LiteralPath $Path
    try { $OwnerSid = ([Security.Principal.NTAccount]::new($Acl.Owner)).Translate([Security.Principal.SecurityIdentifier]).Value }
    catch { $OwnerSid = $Acl.Owner }
    if ($OwnerSid -ne $ProtectedLogSystemSid -and $Acl.Owner -notmatch 'SYSTEM') {
        throw "Security check failed: protected log path '$Path' is not owned by LOCALSYSTEM."
    }
    foreach ($Rule in $Acl.Access) {
        if ($Rule.AccessControlType -ne [Security.AccessControl.AccessControlType]::Allow) { continue }
        $RuleSid = Get-ProtectedLogRuleSid -IdentityReference $Rule.IdentityReference
        if ((([int64]$Rule.FileSystemRights -band [int64]$ProtectedLogWriteMask) -ne 0) -and $RuleSid -ne $ProtectedLogSystemSid) {
            throw "Security check failed: non-SYSTEM principal '$($Rule.IdentityReference)' has write/modify/delete rights on protected log path '$Path'."
        }
    }
}

function Initialize-HostLogRoot {
    param(
        [hashtable]$Runtime,
        [Parameter(Mandatory = $true)][ValidateSet('poc','production')][string]$SandboxType
    )
    $PersistRoot = $false
    $RequestedMode = if (Test-ConfiguredValue $Runtime['SANDBOX_LOG_MODE']) { $Runtime['SANDBOX_LOG_MODE'].Trim().ToLowerInvariant() } else { 'auto' }
    if ($RequestedMode -notin @('auto','protected','poc-local')) {
        throw "SANDBOX_LOG_MODE must be 'auto', 'protected', or 'poc-local'. Current value: $RequestedMode"
    }
    if ($SandboxType -eq 'production' -and $RequestedMode -eq 'poc-local') {
        throw 'Production manifests require protected host logging; SANDBOX_LOG_MODE=poc-local is not permitted.'
    }
    $Mode = if ($RequestedMode -eq 'auto') {
        if ($SandboxType -eq 'poc') { 'poc-local' } else { 'protected' }
    }
    else { $RequestedMode }

    if (-not (Test-ConfiguredValue $Runtime['SANDBOX_LOG_ROOT'])) {
        if ($Mode -eq 'poc-local') {
            $Runtime['SANDBOX_LOG_ROOT'] = (Join-Path $env:USERPROFILE 'AI-Sandbox\Logs') -replace '\\','/'
            $PersistRoot = $true
        }
        else {
            throw 'SANDBOX_LOG_ROOT is missing or still a placeholder in .env. Ask the Sandbox Admin to run scripts\platform\03-setup-logging.ps1 first.'
        }
    }
    $LogRoot = [IO.Path]::GetFullPath($Runtime['SANDBOX_LOG_ROOT'].Replace('/', '\'))

    # The common template intentionally carries the Production protected path.
    # For a POC that resolves to poc-local, automatically move to a user-owned
    # path so an Administrator is not required merely to run the functional POC.
    if ($Mode -eq 'poc-local' -and $LogRoot.TrimEnd('\') -ieq 'C:\ProgramData\AI-Sandbox\Logs') {
        $LogRoot = Join-Path $env:USERPROFILE 'AI-Sandbox\Logs'
        $Runtime['SANDBOX_LOG_ROOT'] = $LogRoot -replace '\\','/'
        $PersistRoot = $true
        Write-Warning "POC local mode replaced the protected default log path with user-writable path: $LogRoot"
    }

    if ($Mode -eq 'poc-local') {
        foreach ($Path in @($LogRoot, (Join-Path $LogRoot 'devcontainer'), (Join-Path $LogRoot 'squid'), (Join-Path $LogRoot '.monitoring'))) {
            New-Item -ItemType Directory -Force -Path $Path | Out-Null
        }
        Write-Warning 'POC LOCAL LOG MODE: Windows host log files are writable by the current user. This mode is for non-admin POC testing only.'
        return @{ Mode = $Mode; RequestedMode = $RequestedMode; Root = $LogRoot; ComposeRoot = ($LogRoot -replace '\\','/'); PersistRoot = $PersistRoot }
    }

    if (-not (Test-Path -LiteralPath $LogRoot -PathType Container)) {
        throw "Protected host log root is missing: $LogRoot. Ask the Sandbox Admin to run scripts\platform\03-setup-logging.ps1."
    }
    Assert-ProtectedLogAcl -Path $LogRoot
    foreach ($Subdir in @('devcontainer','squid')) {
        $Path = Join-Path $LogRoot $Subdir
        if (-not (Test-Path -LiteralPath $Path -PathType Container)) {
            throw "Protected host log directory is missing: $Path. Ask the Sandbox Admin to run scripts\platform\03-setup-logging.ps1."
        }
        Assert-ProtectedLogAcl -Path $Path
        $Probe = Join-Path $Path ('.developer-write-probe-' + [guid]::NewGuid().ToString('N'))
        $Writable = $false
        try {
            [IO.File]::WriteAllText($Probe, 'probe', [Text.UTF8Encoding]::new($false))
            $Writable = $true
        }
        catch [UnauthorizedAccessException] { }
        catch [IO.IOException] { }
        finally {
            if (Test-Path -LiteralPath $Probe) { Remove-Item -LiteralPath $Probe -Force -ErrorAction SilentlyContinue }
        }
        if ($Writable) {
            throw "Security check failed: the current Windows user can write to protected log directory $Path. Re-apply the Admin/SYSTEM ACL with scripts\platform\03-setup-logging.ps1."
        }
    }
    return @{ Mode = $Mode; RequestedMode = $RequestedMode; Root = $LogRoot; ComposeRoot = ($LogRoot -replace '\\','/'); PersistRoot = $PersistRoot }
}

function Start-PocLocalLogExporter {
    param(
        [Parameter(Mandatory = $true)][string]$PackageRoot,
        [Parameter(Mandatory = $true)][hashtable]$HostLog
    )
    $Exporter = Join-Path $PackageRoot 'scripts\monitoring\export-docker-logs-to-host.ps1'
    $MonitorRoot = Join-Path $HostLog.Root '.monitoring'
    $StateFile = Join-Path $MonitorRoot 'host-log-export-state.json'
    $PidFile = Join-Path $MonitorRoot 'poc-log-exporter.pid'
    $StdoutFile = Join-Path $MonitorRoot 'poc-log-exporter.out.log'
    $StderrFile = Join-Path $MonitorRoot 'poc-log-exporter.err.log'

    # First pass is synchronous so launcher success means the host-log path and
    # Docker log API are both working before the Developer starts work.
    & pwsh -NoProfile -File $Exporter -LogMode PocLocal -ProjectName 'ai-secure-sandbox' -LogRoot $HostLog.Root -StateFile $StateFile
    if ($LASTEXITCODE -ne 0) { throw 'Initial POC local host-log export failed.' }

    if (Test-Path -LiteralPath $PidFile -PathType Leaf) {
        $ExistingPidText = [string](Get-Content -LiteralPath $PidFile -Raw -ErrorAction SilentlyContinue)
        $ExistingPidText = $ExistingPidText.Trim()
        $ExistingPid = 0
        if ([int]::TryParse($ExistingPidText, [ref]$ExistingPid)) {
            $ExistingProcess = Get-Process -Id $ExistingPid -ErrorAction SilentlyContinue
            if ($ExistingProcess -and $ExistingProcess.ProcessName -like 'pwsh*') {
                Write-Host "[OK] POC local log exporter is already running (PID $ExistingPid)." -ForegroundColor Yellow
                return
            }
        }
        Remove-Item -LiteralPath $PidFile -Force -ErrorAction SilentlyContinue
    }

    $Pwsh = (Get-Command pwsh -ErrorAction Stop).Source
    $Arguments = @(
        '-NoProfile',
        '-File', ('"{0}"' -f $Exporter),
        '-LogMode', 'PocLocal',
        '-ProjectName', 'ai-secure-sandbox',
        '-LogRoot', ('"{0}"' -f $HostLog.Root),
        '-StateFile', ('"{0}"' -f $StateFile),
        '-Continuous',
        '-IntervalSeconds', '30'
    ) -join ' '
    $Process = Start-Process -FilePath $Pwsh -ArgumentList $Arguments -WindowStyle Hidden -PassThru `
        -RedirectStandardOutput $StdoutFile -RedirectStandardError $StderrFile
    [IO.File]::WriteAllText($PidFile, [string]$Process.Id, [Text.ASCIIEncoding]::new())
    Write-Host "[OK] POC local log exporter started in the background (PID $($Process.Id), every 30 seconds)." -ForegroundColor Yellow
}

$Runtime = Read-KeyValueFile -Path $EnvFile
foreach ($Key in @('DEVELOPER_ID', 'ECR_REGISTRY')) {
    if (-not (Test-ConfiguredValue $Runtime[$Key])) {
        throw "$Key is missing or still a placeholder in .env"
    }
}

$Region = if ($Runtime.AWS_REGION) { $Runtime.AWS_REGION } else { 'eu-west-2' }
$Profile = if ($Runtime.SANDBOX_AWS_PROFILE) { $Runtime.SANDBOX_AWS_PROFILE } else { 'sandbox' }
$Prefix = if ($Runtime.SSM_PREFIX) { $Runtime.SSM_PREFIX.TrimEnd('/') } else { '/sandbox' }
$Registry = $Runtime.ECR_REGISTRY.TrimEnd('/')
$ManifestParameter = if ($Runtime.APPROVED_IMAGES_SSM_PARAMETER) {
    $Runtime.APPROVED_IMAGES_SSM_PARAMETER
}
else {
    "$Prefix/runtime/approved-images-json"
}

$HasAccessKey = Test-ConfiguredValue $Runtime.AWS_ACCESS_KEY_ID
$HasSecretKey = Test-ConfiguredValue $Runtime.AWS_SECRET_ACCESS_KEY
$HasSessionToken = Test-ConfiguredValue $Runtime.AWS_SESSION_TOKEN
if ($HasAccessKey -xor $HasSecretKey) { throw 'AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY must be configured together. Partial static credentials do not fall back to SSO.' }
if ($HasSessionToken -and -not ($HasAccessKey -and $HasSecretKey)) { throw 'AWS_SESSION_TOKEN requires AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY.' }
$UseStaticAws = $HasAccessKey -and $HasSecretKey

function Invoke-AwsCli {
    param([Parameter(Mandatory = $true)][string[]]$Arguments)
    if ($script:UseStaticAws) { & aws @Arguments } else { & aws --profile $script:Profile @Arguments }
}

function Initialize-AwsSsoProfile {
    param([hashtable]$Runtime,[string]$Profile,[string]$Region)
    $Required=@('AWS_SSO_START_URL','AWS_SSO_REGION','AWS_SSO_ACCOUNT_ID','AWS_SSO_ROLE_NAME')
    $Missing=@($Required | Where-Object { -not (Test-ConfiguredValue $Runtime[$_]) })
    if($Missing.Count){
        throw "Admin SSO bootstrap values are missing from .env: $($Missing -join ', '). Developers should not need to run aws configure sso manually."
    }
    if($Runtime.AWS_SSO_ACCOUNT_ID -notmatch '^[0-9]{12}$'){throw 'AWS_SSO_ACCOUNT_ID must be a 12-digit account ID'}
    if($Runtime.AWS_SSO_START_URL -notmatch '^https://'){throw 'AWS_SSO_START_URL must use https://'}
    $Session=if(Test-ConfiguredValue $Runtime.AWS_SSO_SESSION){$Runtime.AWS_SSO_SESSION}else{$Profile}
    $AwsDir=Join-Path $HOME '.aws'; $Config=Join-Path $AwsDir 'config'
    New-Item -ItemType Directory -Force -Path $AwsDir | Out-Null
    $Existing=if(Test-Path $Config){Get-Content $Config -Raw}else{''}
    $Existing=[regex]::Replace($Existing,'(?ms)^# BEGIN AI-SANDBOX MANAGED SSO\r?\n.*?^# END AI-SANDBOX MANAGED SSO\r?\n?','')
    $Block=@"
# BEGIN AI-SANDBOX MANAGED SSO
# Non-secret profile generated by the AI Sandbox ECR launcher.
[sso-session $Session]
sso_start_url = $($Runtime.AWS_SSO_START_URL)
sso_region = $($Runtime.AWS_SSO_REGION)
sso_registration_scopes = sso:account:access

[default]
sso_session = $Session
sso_account_id = $($Runtime.AWS_SSO_ACCOUNT_ID)
sso_role_name = $($Runtime.AWS_SSO_ROLE_NAME)
region = $Region
output = json

[profile $Profile]
sso_session = $Session
sso_account_id = $($Runtime.AWS_SSO_ACCOUNT_ID)
sso_role_name = $($Runtime.AWS_SSO_ROLE_NAME)
region = $Region
output = json
# END AI-SANDBOX MANAGED SSO
"@
    [IO.File]::WriteAllText($Config,($Existing.TrimEnd()+"`r`n"+$Block),[Text.UTF8Encoding]::new($false))
}

# Runtime records are Docker-owned stdout/stderr first, then a SYSTEM host exporter copies them into the protected Windows log folder. Containers mount that folder read-only.

# Authentication priority: static environment credentials first; SSO fallback.
# No redundant AWS identity preflight is used. The first required
# SSM read is the real authentication/authorization check for this launcher.
if ($UseStaticAws) {
    $env:AWS_ACCESS_KEY_ID = $Runtime.AWS_ACCESS_KEY_ID
    $env:AWS_SECRET_ACCESS_KEY = $Runtime.AWS_SECRET_ACCESS_KEY
    if ($HasSessionToken) { $env:AWS_SESSION_TOKEN = $Runtime.AWS_SESSION_TOKEN } else { Remove-Item Env:AWS_SESSION_TOKEN -ErrorAction SilentlyContinue }
    Remove-Item Env:AWS_PROFILE,Env:AWS_DEFAULT_PROFILE -ErrorAction SilentlyContinue
    Write-Host 'AWS authentication mode: static environment credentials. Validation is deferred to SSM/ECR.' -ForegroundColor Cyan
}
else {
    Remove-Item Env:AWS_ACCESS_KEY_ID,Env:AWS_SECRET_ACCESS_KEY,Env:AWS_SESSION_TOKEN -ErrorAction SilentlyContinue
    Initialize-AwsSsoProfile -Runtime $Runtime -Profile $Profile -Region $Region
    Write-Host "AWS authentication mode: IAM Identity Center profile '$Profile'. Validation is deferred to SSM/ECR." -ForegroundColor Cyan
}

$script:SsoLoginAttempted = $false
function Test-AwsAuthenticationFailure {
    param([string]$Text)
    if ([string]::IsNullOrWhiteSpace($Text)) { return $false }
    return $Text -match '(?i)SSO session|Error loading SSO Token|token.*(expired|invalid|does not exist)|expired.*token|invalid_grant|login required|credentials.*(expired|invalid|not found|unable)|UnauthorizedException'
}
function Invoke-SandboxSsoLogin {
    if ($script:UseStaticAws) { return }
    if ($script:SsoLoginAttempted) { return }
    $script:SsoLoginAttempted = $true
    Write-Host "AWS SSO login required for profile '$($script:Profile)'. Opening the host browser..." -ForegroundColor Yellow
    & aws sso login --profile $script:Profile
    if ($LASTEXITCODE -ne 0) {
        Write-Host 'Automatic browser launch failed; falling back to device-code login.' -ForegroundColor Yellow
        & aws sso login --profile $script:Profile --use-device-code --no-browser
        if ($LASTEXITCODE -ne 0) { throw 'AWS SSO login failed' }
    }
}

function Get-SsmValue {
    param([Parameter(Mandatory = $true)][string]$Name)
    $Value = @(Invoke-AwsCli -Arguments @(
        'ssm','get-parameter',
        '--name',$Name,
        '--region',$Region,
        '--query','Parameter.Value',
        '--output','text'
    ) 2>&1)
    $FirstExit = $LASTEXITCODE
    $FirstText = ($Value | ForEach-Object { $_.ToString() }) -join "`n"
    if ($FirstExit -ne 0 -and -not $script:UseStaticAws -and -not $script:SsoLoginAttempted -and (Test-AwsAuthenticationFailure $FirstText)) {
        Write-Warning $FirstText
        Invoke-SandboxSsoLogin
        $Value = @(Invoke-AwsCli -Arguments @(
            'ssm','get-parameter',
            '--name',$Name,
            '--region',$Region,
            '--query','Parameter.Value',
            '--output','text'
        ) 2>&1)
    }
    if ($LASTEXITCODE -ne 0) { throw "Cannot read SSM parameter: $Name" }
    return (($Value | ForEach-Object { $_.ToString() }) -join "`n").Trim()
}

$ManifestJson = Get-SsmValue -Name $ManifestParameter
$ExpectedHash = (Get-SsmValue -Name "$ManifestParameter-sha256").ToLowerInvariant()
$Sha = [Security.Cryptography.SHA256]::Create()
try {
    $ActualHash = ([BitConverter]::ToString(
        $Sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($ManifestJson))
    )).Replace('-', '').ToLowerInvariant()
}
finally {
    $Sha.Dispose()
}
if ($ExpectedHash -ne $ActualHash) {
    throw 'Approved manifest SHA-256 validation failed'
}

$Manifest = $ManifestJson | ConvertFrom-Json
if ([string]$Manifest.registry -ne $Registry) { throw 'Manifest registry mismatch' }
$ManifestSandboxType=([string]$Manifest.sandboxType).ToLowerInvariant()
if($ManifestSandboxType -notin @('poc','production')){throw 'Approved manifest sandboxType must be poc or production.'}
if(([string]$Manifest.deploymentType).ToLowerInvariant() -ne 'ecr'){throw 'Approved manifest deploymentType must be ecr.'}
$HostLog = Initialize-HostLogRoot -Runtime $Runtime -SandboxType $ManifestSandboxType
if ($HostLog.PersistRoot) {
    Set-RuntimeEnvValue -Path $EnvFile -Key 'SANDBOX_LOG_ROOT' -Value $HostLog.ComposeRoot
    Write-Host "[OK] Persisted POC host log root in .env for future VS Code/Compose recreation: $($HostLog.ComposeRoot)" -ForegroundColor Yellow
}

function Assert-ApprovedImageReference {
    param([string]$Image, [string]$Repository)
    $Prefix = "$Registry/ai-sandbox/$Repository@sha256:"
    if (-not $Image.StartsWith($Prefix, [StringComparison]::Ordinal)) {
        throw "Invalid approved $Repository image reference"
    }
    $DigestHex = $Image.Substring($Prefix.Length)
    if ($DigestHex -notmatch '^[0-9a-f]{64}$') {
        throw "Invalid approved $Repository digest"
    }
}

$DevImage = [string]$Manifest.images.devcontainer.full
$SquidImage = [string]$Manifest.images.squid.full
Assert-ApprovedImageReference -Image $DevImage -Repository 'devcontainer'
Assert-ApprovedImageReference -Image $SquidImage -Repository 'squid'
Write-Host "Approved release: $($Manifest.releaseTag)" -ForegroundColor Green

$Password = Invoke-AwsCli -Arguments @('ecr','get-login-password','--region',$Region)
if ($LASTEXITCODE -ne 0) { throw 'Unable to obtain ECR login password' }
$Password | docker login --username AWS --password-stdin $Registry | Out-Null
if ($LASTEXITCODE -ne 0) { throw 'ECR login failed' }

$Images = @(
    @($DevImage, 'sandbox/approved-devcontainer:current'),
    @($SquidImage, 'sandbox/approved-squid:current')
)
foreach ($Pair in $Images) {
    & docker pull $Pair[0] | Out-Null
    if ($LASTEXITCODE -ne 0) { throw "Pull failed: $($Pair[0])" }
    & docker tag $Pair[0] $Pair[1]
    if ($LASTEXITCODE -ne 0) { throw "Local runtime tag failed: $($Pair[1])" }
}

$PreviousSandboxEnv=$env:SANDBOX_ENV
$PreviousLogRoot=$env:SANDBOX_LOG_ROOT
try {
    $env:SANDBOX_ENV=$ManifestSandboxType
    $env:SANDBOX_LOG_ROOT=$HostLog.ComposeRoot
    & docker compose --env-file $EnvFile -f $ComposeFile config | Out-Null
    if ($LASTEXITCODE -ne 0) { throw 'Compose validation failed' }
    & docker compose --env-file $EnvFile -f $ComposeFile up -d --force-recreate
    if ($LASTEXITCODE -ne 0) { throw 'Compose start failed' }
}
finally {
    if ($null -eq $PreviousSandboxEnv) { Remove-Item Env:SANDBOX_ENV -ErrorAction SilentlyContinue } else { $env:SANDBOX_ENV=$PreviousSandboxEnv }
    if ($null -eq $PreviousLogRoot) { Remove-Item Env:SANDBOX_LOG_ROOT -ErrorAction SilentlyContinue } else { $env:SANDBOX_LOG_ROOT=$PreviousLogRoot }
}

Write-Host "[OK] Approved $ManifestSandboxType ECR sandbox started." -ForegroundColor Green
if ($HostLog.Mode -eq 'poc-local') {
    Start-PocLocalLogExporter -PackageRoot $Root -HostLog $HostLog
    Write-Warning "POC local logs are continuously exported to $($HostLog.Root), but the current Windows user can modify/delete those host files."
}
else {
    Write-Host "[OK] Runtime logs are Docker-owned streams and are exported by SYSTEM to $($Runtime['SANDBOX_LOG_ROOT'])." -ForegroundColor Green
}
