#Requires -Version 7.4
# =============================================================================
# AI Secure Sandbox v1.16.33
# Purpose:
#   Create a protected Windows host log directory for Sentinel/AMA collection
#   and install a LOCALSYSTEM exporter that copies Docker-owned runtime streams
#   into that directory.
#
# Security boundary:
#   - Normal Developers get read-only access to the Windows log tree.
#   - Containers mount the host log folders read-only.
#   - LOCALSYSTEM is the normal writer and reads Docker logs via Docker Desktop's
#     non-privileged named pipe.
#   - A local Windows Administrator can still take ownership/reset ACLs; use
#     remote immutable retention and separation of duties for admin-proof logs.
# =============================================================================
[CmdletBinding()]
param(
    [ValidateSet('Protected','PocLocal')][string]$Mode = 'Protected',
    [string]$LogRoot = 'C:\ProgramData\AI-Sandbox\Logs',
    [string]$StateRoot = 'C:\ProgramData\AI-Sandbox\Monitoring',
    [string]$ProjectName = 'ai-secure-sandbox',
    [string]$ReadPrincipal = 'S-1-5-32-545',
    [string]$TaskName = 'AI-Sandbox-Protected-Log-Export',
    [ValidateRange(1, 60)][int]$IntervalMinutes = 1,
    [switch]$SkipScheduledTask
)

$ErrorActionPreference = 'Stop'
$PocLocal = $Mode -eq 'PocLocal'

if ($PocLocal -and -not $PSBoundParameters.ContainsKey('LogRoot')) {
    $LogRoot = Join-Path $env:USERPROFILE 'AI-Sandbox\Logs'
}
if ($PocLocal -and -not $PSBoundParameters.ContainsKey('StateRoot')) {
    $StateRoot = Join-Path $env:LOCALAPPDATA 'AI-Sandbox\Monitoring'
}

$DockerCommand = Get-Command docker.exe -ErrorAction Stop
$DockerCli = $DockerCommand.Source

$Identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$Principal = [Security.Principal.WindowsPrincipal]$Identity
if (-not $PocLocal -and -not $Principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw 'Run this script from an elevated PowerShell session for Protected mode. For a non-admin POC only, use -Mode PocLocal.'
}

$SystemSid = [Security.Principal.SecurityIdentifier]::new('S-1-5-18')
$AdministratorsSid = [Security.Principal.SecurityIdentifier]::new('S-1-5-32-544')
try {
    $ReadSid = [Security.Principal.SecurityIdentifier]::new($ReadPrincipal)
}
catch {
    $ReadSid = ([Security.Principal.NTAccount]::new($ReadPrincipal)).Translate([Security.Principal.SecurityIdentifier])
}

function Set-ProtectedAcl {
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][bool]$DeveloperReadable
    )

    $Item = Get-Item -LiteralPath $Path -Force
    $Allow = [Security.AccessControl.AccessControlType]::Allow
    $NonePropagation = [Security.AccessControl.PropagationFlags]::None

    if ($Item.PSIsContainer) {
        $Acl = [Security.AccessControl.DirectorySecurity]::new()
        $Acl.SetAccessRuleProtection($true, $false)
        $Acl.SetOwner($SystemSid)
        $Inheritance = [Security.AccessControl.InheritanceFlags]'ContainerInherit,ObjectInherit'
        $Acl.AddAccessRule([Security.AccessControl.FileSystemAccessRule]::new(
            $SystemSid,
            [Security.AccessControl.FileSystemRights]::FullControl,
            $Inheritance,
            $NonePropagation,
            $Allow
        ))
        $Acl.AddAccessRule([Security.AccessControl.FileSystemAccessRule]::new(
            $AdministratorsSid,
            [Security.AccessControl.FileSystemRights]::ReadAndExecute,
            $Inheritance,
            $NonePropagation,
            $Allow
        ))
        if ($DeveloperReadable) {
            $Acl.AddAccessRule([Security.AccessControl.FileSystemAccessRule]::new(
                $ReadSid,
                [Security.AccessControl.FileSystemRights]::ReadAndExecute,
                $Inheritance,
                $NonePropagation,
                $Allow
            ))
        }
    }
    else {
        $Acl = [Security.AccessControl.FileSecurity]::new()
        $Acl.SetAccessRuleProtection($true, $false)
        $Acl.SetOwner($SystemSid)
        $Acl.AddAccessRule([Security.AccessControl.FileSystemAccessRule]::new(
            $SystemSid,
            [Security.AccessControl.FileSystemRights]::FullControl,
            $Allow
        ))
        $Acl.AddAccessRule([Security.AccessControl.FileSystemAccessRule]::new(
            $AdministratorsSid,
            [Security.AccessControl.FileSystemRights]::ReadAndExecute,
            $Allow
        ))
        if ($DeveloperReadable) {
            $Acl.AddAccessRule([Security.AccessControl.FileSystemAccessRule]::new(
                $ReadSid,
                [Security.AccessControl.FileSystemRights]::ReadAndExecute,
                $Allow
            ))
        }
    }

    Set-Acl -LiteralPath $Path -AclObject $Acl
}

function Protect-Tree {
    param(
        [Parameter(Mandatory = $true)][string]$Root,
        [Parameter(Mandatory = $true)][bool]$DeveloperReadable
    )
    Set-ProtectedAcl -Path $Root -DeveloperReadable $DeveloperReadable
    Get-ChildItem -LiteralPath $Root -Force -Recurse -ErrorAction SilentlyContinue |
        Sort-Object { $_.FullName.Length } -Descending |
        ForEach-Object { Set-ProtectedAcl -Path $_.FullName -DeveloperReadable $DeveloperReadable }
}

$DevLogRoot = Join-Path $LogRoot 'devcontainer'
$SquidLogRoot = Join-Path $LogRoot 'squid'
foreach ($Path in @($LogRoot, $DevLogRoot, $SquidLogRoot, $StateRoot)) {
    New-Item -ItemType Directory -Force -Path $Path | Out-Null
}

$ExporterSource = Join-Path (Split-Path -Parent $PSScriptRoot) 'monitoring\export-docker-logs-to-host.ps1'
if (-not (Test-Path -LiteralPath $ExporterSource -PathType Leaf)) {
    throw "Missing exporter script: $ExporterSource"
}
$InstalledExporter = Join-Path $StateRoot 'export-docker-logs-to-host.ps1'
Copy-Item -LiteralPath $ExporterSource -Destination $InstalledExporter -Force

if ($PocLocal) {
    Write-Warning 'POC LOCAL LOG MODE: host log files are writable by the current Windows user and are NOT tamper-resistant.'
    Write-Host "[OK] POC local Windows log root: $LogRoot" -ForegroundColor Green
    Write-Host "[OK] POC local exporter state root: $StateRoot" -ForegroundColor Green
    Write-Host 'No elevated ACL change or SYSTEM scheduled task was attempted.' -ForegroundColor Yellow
    Write-Host 'Configure the runtime .env as:' -ForegroundColor Cyan
    Write-Host '  SANDBOX_LOG_MODE=poc-local' -ForegroundColor Cyan
    Write-Host ('  SANDBOX_LOG_ROOT=' + ($LogRoot -replace '\\','/')) -ForegroundColor Cyan
    Write-Host 'Containers still mount the host log folders read-only. Windows host tamper protection requires Protected mode later.' -ForegroundColor Yellow
    return
}

# Apply exact ACLs after all files/directories have been created. The log tree is
# readable but not writable by the configured Developer/read principal. The
# monitoring state tree is SYSTEM-only with Administrators read-only.
Protect-Tree -Root $LogRoot -DeveloperReadable $true
Protect-Tree -Root $StateRoot -DeveloperReadable $false

Write-Host "[OK] Protected Windows log root: $LogRoot" -ForegroundColor Green
Write-Host "[OK] Developer/read principal: $ReadSid (read-only)" -ForegroundColor Green
Write-Host "[OK] Normal writer: LOCALSYSTEM only" -ForegroundColor Green
Write-Host "[OK] Docker CLI for SYSTEM exporter: $DockerCli" -ForegroundColor Green

if (-not $SkipScheduledTask) {
    $Pwsh = (Get-Command pwsh.exe -ErrorAction Stop).Source
    $StateFile = Join-Path $StateRoot 'host-log-export-state.json'
    $Arguments = @(
        '-NoProfile',
        '-NonInteractive',
        '-ExecutionPolicy', 'Bypass',
        '-File', ('"{0}"' -f $InstalledExporter),
        '-ProjectName', ('"{0}"' -f $ProjectName),
        '-LogRoot', ('"{0}"' -f $LogRoot),
        '-StateFile', ('"{0}"' -f $StateFile),
        '-DockerCli', ('"{0}"' -f $DockerCli)
    ) -join ' '

    $Action = New-ScheduledTaskAction -Execute $Pwsh -Argument $Arguments
    $Trigger = New-ScheduledTaskTrigger `
        -Once `
        -At (Get-Date).AddMinutes(1) `
        -RepetitionInterval (New-TimeSpan -Minutes $IntervalMinutes) `
        -RepetitionDuration (New-TimeSpan -Days 3650)
    $TaskPrincipal = New-ScheduledTaskPrincipal `
        -UserId 'SYSTEM' `
        -LogonType ServiceAccount `
        -RunLevel Highest
    $Settings = New-ScheduledTaskSettingsSet `
        -StartWhenAvailable `
        -MultipleInstances IgnoreNew `
        -ExecutionTimeLimit (New-TimeSpan -Minutes 5)

    Register-ScheduledTask `
        -TaskName $TaskName `
        -Action $Action `
        -Trigger $Trigger `
        -Principal $TaskPrincipal `
        -Settings $Settings `
        -Description 'AI Secure Sandbox: export Docker runtime logs into SYSTEM-owned host files for Sentinel/AMA collection.' `
        -Force | Out-Null

    Start-ScheduledTask -TaskName $TaskName
    Write-Host "[OK] SYSTEM scheduled task installed: $TaskName (every $IntervalMinutes minute(s))" -ForegroundColor Green
}
else {
    Write-Host 'Protected host files are prepared; scheduled exporter installation was skipped.' -ForegroundColor Yellow
}

Write-Host 'Configure the runtime .env as:' -ForegroundColor Cyan
Write-Host '  SANDBOX_LOG_MODE=protected' -ForegroundColor Cyan
Write-Host ('  SANDBOX_LOG_ROOT=' + ($LogRoot -replace '\\','/')) -ForegroundColor Cyan
Write-Host 'The DevContainer and Squid mount these folders read-only. Do not grant Developer write/modify/delete rights.' -ForegroundColor Cyan
Write-Host 'Local Windows Administrators can override endpoint ACLs. Sentinel/central immutable retention is required for administrator-proof evidence.' -ForegroundColor Yellow
