#!/usr/bin/env bash
set -euo pipefail
PROJECT_NAME="${SANDBOX_PROJECT_NAME:-ai-secure-sandbox}"
LOG_ROOT="${SANDBOX_LOG_ROOT:-/var/log/ai-sandbox-host}"
STATE_FILE="${SANDBOX_MONITORING_STATE_FILE:-/var/lib/ai-sandbox-monitoring/host-log-export-state.json}"
LOOKBACK_MINUTES="${SANDBOX_LOG_INITIAL_LOOKBACK_MINUTES:-15}"

if [[ "$(id -u)" != 0 && "${AI_SANDBOX_ALLOW_NON_ROOT_LOG_EXPORT:-false}" != true ]]; then
  echo 'ERROR: host log export must run as root (or an approved host service account).' >&2
  exit 1
fi

for d in "$LOG_ROOT" "$LOG_ROOT/devcontainer" "$LOG_ROOT/squid" "$(dirname "$STATE_FILE")"; do
  [[ -d "$d" ]] || { echo "ERROR: required protected directory is missing: $d" >&2; exit 1; }
done

python3 - "$PROJECT_NAME" "$LOG_ROOT" "$STATE_FILE" "$LOOKBACK_MINUTES" <<'PY'
import datetime as dt, json, os, re, subprocess, sys
project, root, state_file, lookback = sys.argv[1], sys.argv[2], sys.argv[3], int(sys.argv[4])
now = dt.datetime.now(dt.timezone.utc)
try:
    state = json.load(open(state_file, encoding='utf-8'))
except Exception:
    state = {'services': {}}
state.setdefault('services', {})
stream_map = {
    'audit':'audit','security':'security','application':'application',
    'claude-events':'claude-events','content':'content',
    'gemini-telemetry':'gemini-telemetry','verification':'verification'
}

def cid(service):
    p = subprocess.run(['docker','ps','--filter',f'label=com.docker.compose.project={project}',
                        '--filter',f'label=com.docker.compose.service={service}','--format','{{.ID}}'],
                       text=True,capture_output=True,check=True)
    return next((x.strip() for x in p.stdout.splitlines() if x.strip()), '')

def append(path, lines):
    if not lines: return
    with open(path,'a',encoding='utf-8',newline='\n') as f:
        for line in lines: f.write(line+'\n')

def line_date(line):
    m=re.match(r'^(\d{4}-\d{2}-\d{2})T',line)
    return m.group(1) if m else now.strftime('%Y-%m-%d')

total=0
for service in ('devcontainer','squid-proxy'):
    container=cid(service)
    if not container:
        print(f'[WARN] no running container for {project}/{service}', file=sys.stderr)
        continue
    since=now-dt.timedelta(minutes=lookback)
    old=state['services'].get(service,{}).get('last_success_utc')
    if old:
        try: since=dt.datetime.fromisoformat(old.replace('Z','+00:00'))+dt.timedelta(microseconds=1)
        except Exception: pass
    cmd=['docker','logs','--timestamps','--since',since.isoformat(),'--until',now.isoformat(),container]
    p=subprocess.run(cmd,text=True,capture_output=True)
    if p.returncode: raise SystemExit(p.stderr or f'docker logs failed for {service}')
    lines=[x for x in (p.stdout+'\n'+p.stderr).splitlines() if x.strip()]
    buckets={}
    def add(path,line): buckets.setdefault(path,[]).append(line)
    for line in lines:
        date=line_date(line)
        if service=='devcontainer':
            add(os.path.join(root,'devcontainer',f'all-{date}.log'),line)
            m=re.search(r'AI_SANDBOX_LOG\|([A-Za-z0-9._-]+)\|([^|]+)\|(.*)$',line)
            if m: base=stream_map.get(m.group(1),'unclassified-stream')
            else: base='runtime'
            add(os.path.join(root,'devcontainer',f'{base}-{date}.log'),line)
        else:
            add(os.path.join(root,'squid',f'all-{date}.log'),line)
            body=re.sub(r'^[^ ]+\s+','',line,1)
            base='access' if re.match(r'^\d{10}\.\d{3}\s+',body) else 'runtime'
            add(os.path.join(root,'squid',f'{base}-{date}.log'),line)
    for path,vals in buckets.items(): append(path,vals)
    total += len(lines)
    state['services'][service]={'last_success_utc':now.isoformat(),'container_id':container}
state['updated_utc']=now.isoformat()
tmp=state_file+'.tmp'
with open(tmp,'w',encoding='utf-8') as f: json.dump(state,f,indent=2)
os.replace(tmp,state_file)
print(f'[OK] Protected host log export complete. Records observed: {total}')
PY
