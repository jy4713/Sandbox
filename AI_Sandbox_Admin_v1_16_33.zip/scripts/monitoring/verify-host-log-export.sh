#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
COMPOSE="${SANDBOX_COMPOSE_FILE:-$ROOT/tar/docker-compose.yml}"
if [[ -n "${SANDBOX_ENV_FILE:-}" ]]; then
  ENV_FILE="$SANDBOX_ENV_FILE"
elif [[ -f "$ROOT/tar/.env" ]]; then
  ENV_FILE="$ROOT/tar/.env"
else
  ENV_FILE="$ROOT/.env"
fi
LOG_ROOT="${SANDBOX_LOG_ROOT:-/var/log/ai-sandbox-host}"
for d in "$LOG_ROOT/devcontainer" "$LOG_ROOT/squid"; do
  [[ -d "$d" ]] || { echo "ERROR: protected host log directory missing: $d" >&2; exit 1; }
  [[ ! -w "$d" ]] || { echo "ERROR: current user can write protected host log directory: $d" >&2; exit 1; }
done
marker="protected_host_log_test_$(date +%s)_$$"
printf '%s\n' "$marker" | docker compose --env-file "$ENV_FILE" -f "$COMPOSE" exec -T devcontainer /usr/local/bin/sandbox-log-emit verification verify
docker compose --env-file "$ENV_FILE" -f "$COMPOSE" exec -T devcontainer sh -c 'test ! -w /var/log/sandbox && test ! -e /var/run/docker.sock'
docker compose --env-file "$ENV_FILE" -f "$COMPOSE" exec -T squid-proxy sh -c 'test ! -w /var/log/squid'
echo '[PASS] Host paths and container read-only mounts verified. Run the privileged host exporter and confirm the marker appears in verification-*.log.'
