#!/usr/bin/env bash
set -euo pipefail
set +x

show_var(){ local n="$1"; printf '  %-38s %s\n' "$n" "${!n:-<not configured>}"; }
cmd_ver(){ local label="$1"; shift; local out; out="$("$@" 2>/dev/null | head -n 1 || true)"; printf '  %-38s %s\n' "$label" "${out:-<unavailable>}"; }

echo 'AI Secure Sandbox - Runtime Information'
echo '============================================================'
if [[ -r /etc/ai-sandbox/build-info.json ]]; then
  echo 'Build provenance:'
  jq . /etc/ai-sandbox/build-info.json 2>/dev/null || cat /etc/ai-sandbox/build-info.json
else
  echo 'Build provenance: <not available>'
fi

echo
echo 'Command routing:'
echo '  claude                                 Anthropic official API'
echo '  gemini                                 Google Gemini official API'
echo '  ucode claude / ucode gemini           Databricks AI Gateway'
echo '  databricks                             Databricks workspace API'
show_var DATABRICKS_HOST
show_var DATABRICKS_CLAUDE_MODEL
show_var DATABRICKS_GEMINI_MODEL
show_var SANDBOX_AWS_PROFILE
if [[ -n "${AWS_PROFILE:-}" || -n "${AWS_DEFAULT_PROFILE:-}" ]]; then
  echo "AWS_PROFILE_ENV=UNEXPECTED_SET"
else
  echo "AWS_PROFILE_ENV=NOT_SET"
fi
show_var AWS_REGION
show_var SSM_PREFIX

echo
echo 'AWS authentication:'
if [[ -n "${AWS_ACCESS_KEY_ID:-}" || -n "${AWS_SECRET_ACCESS_KEY:-}" || -n "${AWS_SESSION_TOKEN:-}" ]]; then
  if [[ -n "${AWS_ACCESS_KEY_ID:-}" && -n "${AWS_SECRET_ACCESS_KEY:-}" ]]; then
    echo '  Authentication mode                    static environment credentials'
    echo '  Credential validation                  deferred to required SSM/ECR request'
  else
    echo '  Authentication mode                    ERROR: partial static credential configuration'
  fi
else
  echo '  Authentication mode                    IAM Identity Center (SSO) fallback'
  show_var AWS_SSO_SESSION
  show_var AWS_SSO_START_URL
  show_var AWS_SSO_REGION
  show_var AWS_SSO_ACCOUNT_ID
  show_var AWS_SSO_ROLE_NAME
  echo '  Session validation                     no STS preflight; run sandbox-aws-login if needed'
fi

echo
echo 'Installed tools:'
cmd_ver 'Databricks CLI' /usr/local/libexec/ai-sandbox/real/databricks --version
cmd_ver 'ucode' /usr/local/libexec/ai-sandbox/real/ucode --version
cmd_ver 'Claude Code' /usr/local/libexec/ai-sandbox/real/claude --version
cmd_ver 'Gemini CLI' /usr/local/libexec/ai-sandbox/real/gemini --version
cmd_ver 'Snyk CLI' /usr/local/libexec/ai-sandbox/real/snyk --version

echo
echo 'Native/user configuration locations:'
printf '  %-38s %s\n' 'AWS CLI config' "${AWS_CONFIG_FILE:-$HOME/.aws/config}"
printf '  %-38s %s\n' 'Claude user config' "$HOME/.claude"
printf '  %-38s %s\n' 'Claude managed config' '/etc/claude-code/managed-settings.json'
printf '  %-38s %s\n' 'Gemini user config' "$HOME/.gemini"
printf '  %-38s %s\n' 'ucode state (if created)' "$HOME/.ucode"
printf '  %-38s %s\n' 'Project workspace' "$HOME/workspace"

echo
echo 'Secret handling:'
echo '  Claude/Gemini/Databricks/Tavily/Snyk/ADO/HiddenLayer credentials are not shown.'
echo '  Direct Claude/Gemini keys and integration credentials are fetched from AWS SSM only when needed.'
echo '  AWS access-key values are never printed by sandbox-info.'

printf "Content logging: %s\n" "${SANDBOX_CONTENT_LOGGING:-false}"
