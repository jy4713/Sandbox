#!/usr/bin/env bash
# =============================================================================
# PACKAGE MAINTENANCE NOTES
# Purpose: Launch Snyk MCP over stdio with SNYK_TOKEN supplied only to the child
#          process and record redacted MCP lifecycle metadata.
# AWS auth: Resolved by run-with-ssm-secrets using the sandbox-wide priority
#           (static key pair first, IAM Identity Center SSO otherwise). This
#           wrapper never authenticates interactively and never persists a key.
# Safety rule: Never log MCP request/response payloads or source-code content.
#              Never write anything except JSON-RPC to stdout.
# =============================================================================
set -euo pipefail
set +x
umask 077

# shellcheck source=/usr/local/libexec/ai-sandbox/mcp-wrapper-preamble
. /usr/local/libexec/ai-sandbox/mcp-wrapper-preamble

readonly REAL_SNYK="/usr/local/libexec/ai-sandbox/real/snyk"
[[ -x "$REAL_SNYK" ]] || { echo 'ERROR: real Snyk executable is missing' >&2; exit 1; }

args=()
(( $# > 0 )) && args=("$@")
has_transport=false
if (( ${#args[@]} > 0 )); then
  for arg in "${args[@]}"; do
    case "$arg" in -t|--transport) has_transport=true ;; esac
  done
fi
if [[ "$has_transport" != true ]]; then
  if (( ${#args[@]} > 0 )); then args=(-t stdio "${args[@]}"); else args=(-t stdio); fi
fi

start_ms="$(date +%s%3N)"
application-audit --app mcp --event server_start --operation snyk --target snyk --status started --transport stdio || true

set +e
run-with-ssm-secrets --profile snyk -- "$REAL_SNYK" mcp "${args[@]}"
ec=$?
set -e

end_ms="$(date +%s%3N)"
status=success; (( ec == 0 )) || status=failure
application-audit --app mcp --event server_end --operation snyk --target snyk --status "$status" --exit-code "$ec" --duration-ms "$((end_ms-start_ms))" --transport stdio || true
exit "$ec"
