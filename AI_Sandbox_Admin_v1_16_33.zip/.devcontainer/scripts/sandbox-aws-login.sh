#!/usr/bin/env bash
# =============================================================================
# Purpose: Prepare/refresh the approved AWS authentication mode without an STS
#          preflight. Static credentials are structurally validated only; SSO is
#          established through IAM Identity Center. The first required SSM/ECR
#          operation performs the real service authorization check.
# =============================================================================
set -euo pipefail
set +x

profile="${SANDBOX_AWS_PROFILE:-sandbox}"
AWS_STATE_HOME="${SANDBOX_AWS_HOME:-/home/vscode}"
export HOME="$AWS_STATE_HOME"
export AWS_CONFIG_FILE="${AWS_CONFIG_FILE:-$AWS_STATE_HOME/.aws/config}"
export AWS_SHARED_CREDENTIALS_FILE="${AWS_SHARED_CREDENTIALS_FILE:-$AWS_STATE_HOME/.aws/credentials}"
credentials_file="$AWS_SHARED_CREDENTIALS_FILE"

# Discard unexpanded placeholders so credential-mode selection stays correct.
for _v in AWS_ACCESS_KEY_ID AWS_SECRET_ACCESS_KEY AWS_SESSION_TOKEN; do
  case "${!_v:-}" in '$'*) unset "$_v" ;; '') unset "$_v" ;; esac
done
unset _v

access_key="${AWS_ACCESS_KEY_ID:-}"
secret_key="${AWS_SECRET_ACCESS_KEY:-}"
session_token="${AWS_SESSION_TOKEN:-}"

if [[ -n "$access_key" || -n "$secret_key" || -n "$session_token" ]]; then
  if [[ -z "$access_key" || -z "$secret_key" ]]; then
    cat >&2 <<'MSG'
ERROR: Static AWS authentication is partially configured.
AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY must be supplied together.
AWS_SESSION_TOKEN is optional and may only be used with the complete key pair.
MSG
    exit 1
  fi
  if command -v configure-aws-sso >/dev/null 2>&1; then
    configure-aws-sso >/dev/null || {
      echo 'ERROR: could not prepare the non-secret AWS CLI compatibility profile for static credential mode.' >&2
      exit 1
    }
  fi
  echo '[AWS AUTH] Static AWS environment credentials are configured.'
  echo '           No STS preflight is performed; the next required SSM/ECR request validates access.'
  exit 0
fi

if [[ -f "$credentials_file" ]] && grep -Eq '^[[:space:]]*(aws_access_key_id|aws_secret_access_key)[[:space:]]*=' "$credentials_file"; then
  cat >&2 <<MSG
ERROR: Static AWS access keys were found in $credentials_file.
Credential files containing static AWS keys are not used by this Sandbox.
Provide the approved key pair through the runtime environment/.env, or use the browser SSO flow.
MSG
  exit 1
fi

if command -v configure-aws-sso >/dev/null 2>&1; then
  if ! configure-aws-sso >/dev/null; then
    cat >&2 <<MSG
ERROR: The '$profile' SSO profile cannot be generated yet.
Ask the Sandbox Admin to preconfigure these NON-SECRET runtime values in the Developer package:
  AWS_SSO_START_URL
  AWS_SSO_REGION
  AWS_SSO_ACCOUNT_ID
  AWS_SSO_ROLE_NAME
Developers should not need to run 'aws configure sso' manually.
MSG
    exit 1
  fi
fi

# MCP stdio children must never start a device-code flow because text output
# would corrupt their JSON-RPC stream.
if [[ "${SANDBOX_NONINTERACTIVE:-0}" == "1" ]] || [[ ! -t 0 ]]; then
  cat >&2 <<'MSG'
ERROR: AWS IAM Identity Center sign-in must be run from an interactive terminal.
       Run `sandbox-aws-login` in a VS Code terminal, then retry the operation.
MSG
  exit 1
fi

# Serialize concurrent sign-in attempts so several agent/MCP processes cannot
# show multiple device codes or race on ~/.aws/sso/cache.
mkdir -p "$AWS_STATE_HOME/.aws"
exec 9>"$AWS_STATE_HOME/.aws/.sso-login.lock"
if ! flock -w 300 9; then
  echo '[AWS SSO] Timed out waiting for a concurrent sign-in to finish.' >&2
  exit 1
fi

cat <<MSG
============================================================
 AWS Sandbox Browser Sign-In
============================================================
Ensuring an AWS IAM Identity Center session for profile '$profile'.

The AWS CLI may display a verification URL and a one-time code.
Open/click that URL from the VS Code terminal on the WINDOWS HOST,
then complete your normal company SSO/MFA in Edge or Chrome.

No STS identity check is used. A subsequent required SSM/ECR request is the
actual authorization test for the Sandbox operation.
============================================================
MSG

# Device authorization is intentional because the browser is on the Windows
# host while the AWS CLI runs inside the Linux DevContainer.
aws sso login --profile "$profile" --use-device-code --no-browser

echo "[AWS SSO] Login command completed for profile '$profile'."
echo '          Retry the requested SSM/MCP operation; it will validate service access directly.'
