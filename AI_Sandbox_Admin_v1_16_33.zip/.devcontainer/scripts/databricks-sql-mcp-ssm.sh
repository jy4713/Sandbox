#!/usr/bin/env bash
# =============================================================================
# Purpose: Launch Databricks managed SQL MCP through pinned mcp-remote.
# PAT source: <SSM_PREFIX>/databricks-sql-mcp-token (SecureString).
# The PAT is never written into Claude/Gemini MCP settings or command arguments.
# =============================================================================
set -euo pipefail
set +x
umask 077
. /usr/local/libexec/ai-sandbox/mcp-wrapper-preamble
readonly REAL_MCP_REMOTE="/usr/local/libexec/ai-sandbox/real/mcp-remote"
[[ -x "$REAL_MCP_REMOTE" ]] || { echo 'ERROR: real mcp-remote executable is missing' >&2; exit 1; }
# No caller arguments are accepted. The SSM runner owns the remote URL, header,
# transport and proxy mode so the Developer/agent cannot redirect the PAT.
(( $# == 0 )) || { echo 'ERROR: Databricks SQL MCP wrapper does not accept caller arguments' >&2; exit 2; }
start_ms="$(date +%s%3N)"
application-audit --app mcp --event server_start --operation databricks-sql --target databricks-sql --status started --transport stdio || true
set +e
run-with-ssm-secrets --profile databricks-sql-mcp -- "$REAL_MCP_REMOTE"
ec=$?
set -e
end_ms="$(date +%s%3N)"
status=success; (( ec == 0 )) || status=failure
application-audit --app mcp --event server_end --operation databricks-sql --target databricks-sql --status "$status" --exit-code "$ec" --duration-ms "$((end_ms-start_ms))" --transport stdio || true
exit "$ec"
