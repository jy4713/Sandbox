#!/usr/bin/env bash
# =============================================================================
# PACKAGE MAINTENANCE NOTES
# Purpose: Write shell, Git and security audit metadata to the Docker-owned
#          append-only container log stream without copying arbitrary arguments.
# Admin maintenance: Keep this metadata-only. Secret-bearing arguments, prompts,
#                    search queries, source code and response payloads must not
#                    be written to the audit/security Docker streams.
# Performance: This file may be sourced from multiple Bash startup mechanisms.
#              The per-shell guard prevents duplicate PROMPT_COMMAND hooks and
#              duplicate SESSION_START records. The hot PROMPT_COMMAND path uses
#              Bash built-ins for history parsing, timestamps and metadata so
#              normal commands only need the shared sandbox-log-emit process.
#              Non-interactive BASH_ENV helpers never emit SESSION_START.
# =============================================================================

# Do not install the same hook twice in one shell. The variable is intentionally
# not exported, so child non-login Bash processes still load their own audit
# functions through BASH_ENV.
if [[ "${_AI_SANDBOX_AUDIT_LOGGER_LOADED:-0}" == "1" ]]; then
  return 0 2>/dev/null || exit 0
fi
_AI_SANDBOX_AUDIT_LOGGER_LOADED=1

DEVELOPER_ID="${DEVELOPER_ID:-unknown}"

_utc_ts() {
  # Bash printf %(...)T avoids spawning /bin/date on every prompt.
  TZ=UTC printf -v REPLY '%(%Y-%m-%dT%H:%M:%SZ)T' -1
}

_now_ms() {
  # Bash 5 exposes EPOCHREALTIME as seconds.microseconds. Ubuntu 24.04 ships a
  # compatible Bash, so Git duration accounting also avoids external date calls.
  local now="${EPOCHREALTIME:-0.000000}" sec frac
  sec="${now%%.*}"
  frac="${now#*.}000"
  frac="${frac:0:3}"
  REPLY=$((10#${sec:-0} * 1000 + 10#${frac:-0}))
}

_aw() {
  local ts record
  _utc_ts; ts="$REPLY"
  printf -v record '%s | %-16s | user=%-10s | %-50s | %s' \
    "$ts" "$1" "$DEVELOPER_ID" "$2" "${3:-}"
  # A here-string avoids creating an extra printf side of a pipeline. The
  # managed emitter remains a separate immutable process for serialization.
  /usr/local/bin/sandbox-log-emit audit shell <<< "$record"
}

_sw() {
  # Arguments to _sw must already be metadata-only. Keep sanitization in Bash so
  # suspicious-command reporting does not need tr/cut subprocesses either.
  local detail="${3:-}" ts record host="unknown"
  detail="${detail//[^A-Za-z0-9._:@\/+ =-]/}"
  detail="${detail:0:160}"
  if [[ -r /etc/hostname ]]; then
    IFS= read -r host < /etc/hostname || host="unknown"
    host="${host//[^A-Za-z0-9._-]/}"
    host="${host:0:64}"
    [[ -n "$host" ]] || host="unknown"
  fi
  _utc_ts; ts="$REPLY"
  printf -v record '{"ts":"%s","sev":"%s","event":"%s","user":"%s","detail":"%s","host":"%s"}' \
    "$ts" "$1" "$2" "$DEVELOPER_ID" "$detail" "$host"
  /usr/local/bin/sandbox-log-emit security shell <<< "$record"
}

_sandbox_log_cmd() {
  local ec=$? hist cmd first="unknown" second="none" argc=0 meta url host
  local -a words=()

  # history is a Bash builtin. Command substitution is retained only to capture
  # its output; sed/awk/grep are intentionally absent from the hot prompt path.
  hist=$(HISTTIMEFORMAT='' history 1)
  if [[ "$hist" =~ ^[[:space:]]*[0-9]+[[:space:]]+(.*)$ ]]; then
    cmd="${BASH_REMATCH[1]}"
  else
    return 0
  fi
  [[ -z "$cmd" || "$cmd" == _sandbox_log_cmd* ]] && return 0

  # Inline metadata attribution avoids the former _cmd_metadata command
  # substitution. This deliberately does not reconstruct shell quoting because
  # the audit stream stores only command/tool attribution, never full arguments.
  read -r -a words <<< "$cmd"
  argc="${#words[@]}"
  if (( argc > 0 )); then
    first="${words[0]##*/}"
  fi
  if (( argc > 1 )); then
    second="${words[1]}"
  fi
  case "$first" in
    run-with-ssm-secrets|claude|claude-code|gemini|gemini-cli|ucode|tavily-mcp|ado-trigger|ado-pr-create|ado-auth-setup)
      # These commands can accept prompts, URLs, IDs or free-form text directly
      # after the executable. Keep only tool attribution and argument count.
      meta="tool=$first argc=$argc"
      ;;
    git|snyk|databricks|tvly)
      # The second token is a bounded command-group/subcommand for these CLIs.
      meta="tool=$first subcommand=$second argc=$argc"
      ;;
    *)
      # Generic commands may carry secrets or free-form data as argv[1].
      meta="tool=$first argc=$argc"
      ;;
  esac

  # Shell-command audit is post-execution metadata. Logging failure must not
  # freeze or corrupt the Developer's interactive prompt; required application
  # audit remains fail-closed in application-audit.
  _aw "SHELL_CMD" "$meta" "exit=$ec cwd=$PWD" >/dev/null 2>&1 || true

  # Detect high-risk patterns from the in-memory command but record only the
  # category, never the original command string. Bash regex avoids spawning grep
  # on every prompt.
  if [[ "$cmd" =~ sudo|chmod[[:space:]]+[0-7]*7|curl.*\|.*sh|wget.*\|.*sh|(^|[[:space:]])nc[[:space:]]|(^|[[:space:]])ncat[[:space:]] ]]; then
    _sw "HIGH" "suspicious_cmd" "$meta" >/dev/null 2>&1 || true
  fi

  # For direct curl/wget, record only the destination hostname, not the URL path,
  # query string, headers, body or command arguments.
  if [[ "$cmd" =~ (^|[[:space:]])(curl|wget)([[:space:]]|$) && "$cmd" =~ https?://[^[:space:]]+ ]]; then
    url="${BASH_REMATCH[0]}"
    url="${url#http://}"; url="${url#https://}"
    url="${url#*@}"
    host="${url%%[/:?#]*}"
    [[ -n "$host" ]] && _aw "EGRESS_ATTEMPT" "tool=curl-wget" "host=${host:0:120}" >/dev/null 2>&1 || true
  fi
  return 0
}

# Install the prompt hook and emit SESSION_START only for a real interactive
# shell. BASH_ENV also loads this file in non-interactive helper Bash processes;
# treating those helpers as sessions caused recursive sandbox-log-emit spawning,
# PID pressure and multi-second prompt delays in v1.16.32.
if [[ $- == *i* ]]; then
  case ";${PROMPT_COMMAND:-};" in
    *';_sandbox_log_cmd;'*) ;;
    *) PROMPT_COMMAND="_sandbox_log_cmd${PROMPT_COMMAND:+; $PROMPT_COMMAND}" ;;
  esac
  _session_tty="notty"
  [[ -t 0 ]] && _session_tty="tty"
  _aw "SESSION_START" "shell=${SHELL##*/}" "tty=$_session_tty" >/dev/null 2>&1 || true
  unset _session_tty
fi

# Interactive git wrapper. Secret-backed non-interactive ADO git operations are
# separately attributed by run-with-ssm-secrets to the ADO application stream.
git() {
  local sub="${1:-none}" start_ms end_ms duration_ms ec status
  _aw "GIT_OP" "git subcommand=${sub:0:32}" "argc=$#" >/dev/null 2>&1 || true
  if [[ "$sub" == "push" ]]; then
    _sw "INFO" "git_push" "push requested" >/dev/null 2>&1 || true
  fi
  _now_ms; start_ms="$REPLY"
  if command -v application-audit >/dev/null 2>&1; then
    application-audit --app git --event process_start --operation "$sub" --target repository --status started >/dev/null 2>&1 || true
  fi
  command git "$@"
  ec=$?
  _now_ms; end_ms="$REPLY"
  duration_ms=$((end_ms-start_ms)); status=success; (( ec == 0 )) || status=failure
  if command -v application-audit >/dev/null 2>&1; then
    application-audit --app git --event process_end --operation "$sub" --target repository --status "$status" --exit-code "$ec" --duration-ms "$duration_ms" >/dev/null 2>&1 || true
  fi
  return "$ec"
}

sudo() {
  _sw "HIGH" "sudo_attempt" "sudo requested" >/dev/null 2>&1 || true
  _aw "SECURITY" "sudo_attempt" "arguments_redacted=true" >/dev/null 2>&1 || true
  command sudo "$@"
}

# ADO helper functions retained for scripts that source this logger. Free-form PR
# titles, pipeline parameters and repository URLs are intentionally not logged.
log_ado_trigger()    { _aw "ADO_PIPELINE" "trigger" "pipeline_id=${1:-unknown}" >/dev/null 2>&1 || true; }
log_ado_pr_create()  { _aw "ADO_PR" "create_pr" "metadata_redacted=true" >/dev/null 2>&1 || true; }
log_ado_git_clone()  { _aw "ADO_GIT" "clone" "remote_redacted=true" >/dev/null 2>&1 || true; }
export -f log_ado_trigger log_ado_pr_create log_ado_git_clone 2>/dev/null || true

