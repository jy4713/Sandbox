# Developer Guide - ECR - AI Secure Sandbox v1.16.44

### Static key test mode (host only)

For temporary POC testing when SAML is unavailable, store the Access Key and Secret Access Key in the Windows host profile, not in `.env`:

```powershell
aws configure --profile sandbox
```

Set `AWS_AUTH_MODE=auto` (default) or `AWS_AUTH_MODE=static`. The host `.aws` directory is mounted read-only into `secret-broker` only; it is not mounted into the AI DevContainer.


## Purpose

Production-style image distribution uses ECR while retaining the same credential-isolation model as the TAR package. Azure/Entra browser login occurs on the Windows host. Only the trusted secret broker receives the host AWS profile directory.

## Prerequisites

- Docker Desktop / approved Docker runtime
- VS Code + Dev Containers
- AWS CLI v2
- `aws-azure-login` on Windows
- Browser access to corporate Azure/Entra authentication


## Git usage

Use normal Git commands exactly as usual. Every Git process runs locally in the Dev Container as `vscode`; for ADO operations that need authentication, only Git HTTP traffic is rewritten to the trusted credential broker:

```bash
git clone "https://dev.azure.com/ORG/PROJECT/_git/REPO"
git fetch --prune
git pull
git push -u origin feature/my-change
```

The wrapper preserves normal Git push semantics. Commands such as `git push origin main`, `git push --force origin feature/x`, `git push --force-with-lease origin feature/x`, and `git push --delete origin feature/old` still execute the local `/usr/bin/git`; only their validated `dev.azure.com` HTTP requests cross the credential broker, where the ADO PAT is injected upstream. Whether Azure DevOps accepts them is controlled by ADO repository/branch permissions and policies. The Sandbox still blocks attempts to redirect authentication through custom credential helpers, execution/config overrides, or alternate/non-ADO transports. It does not pin a specific ADO organisation/project/repository; access is decided by the PAT and Azure DevOps permissions.

Local-only operations such as `git status`, `git diff`, `git add`, `git commit`, `git branch`, `git switch`, `git checkout`, `git log`, `git merge`, `git rebase`, `git tag`, and `git stash` also execute locally. In other words, **all Git filesystem I/O is performed by the Dev Container user**, so cloned and updated source remains `vscode:vscode`. The ADO PAT is never placed in the DevContainer environment or Git credential files. `ado-git` remains a backward-compatible local-policy alias but is not required.

## Configure `.env`

Required non-secret values include:

```ini
DEVELOPER_ID=<your-id>
SANDBOX_AWS_PROFILE=sandbox
AWS_REGION=eu-north-1
AZURE_TENANT_ID=<tenant-id>
AZURE_APP_ID_URI=<app-id-uri>
AZURE_DEFAULT_USERNAME=<your-email>
AZURE_DEFAULT_ROLE_ARN=arn:aws:iam::<account>:role/<role>
AZURE_DEFAULT_DURATION_HOURS=1
AZURE_DEFAULT_REMEMBER_ME=true
ECR_REGISTRY=<approved-registry>
DATABRICKS_HOST=https://<approved-workspace>
DATABRICKS_CLAUDE_MODEL=<approved-model>
DATABRICKS_GEMINI_MODEL=<approved-model>
```

Static AWS keys and native `AWS_SSO_*` settings are rejected.

## Pull and start

```powershell
.\scripts\ecr\pull-and-start.ps1
```

If the current host AWS role session is absent/expired, the launcher opens:

```powershell
aws-azure-login --profile sandbox --mode gui
```

The host session is then used for the approved-image manifest and ECR pull. The Dev Container itself receives no AWS credentials.

## Runtime routing

```text
Claude/Gemini process    -> local DevContainer -> loopback route -> broker injects provider key -> provider
ucode Claude/Gemini      -> local DevContainer -> loopback route -> broker injects Databricks PAT -> AI Gateway
Tavily CLI/MCP process   -> local DevContainer -> loopback route -> broker injects Tavily key -> Tavily
Snyk CLI/MCP process     -> local DevContainer -> loopback route -> broker injects Snyk token -> Snyk
Databricks CLI           -> local DevContainer -> loopback route -> broker injects Databricks PAT -> workspace
Databricks SQL MCP       -> local DevContainer -> loopback route -> broker injects short-lived SP OAuth token -> workspace
Git / ADO helper process -> local DevContainer -> validated loopback route -> broker injects ADO PAT -> Azure DevOps
```

## Verify

Inside the Dev Container:

```bash
verify-runtime
```

A direct SSM read from the AI container must fail. Application and MCP processes must still run locally as `vscode`; only their approved outbound authentication crosses the broker.

## Refresh login

On Windows:

```powershell
aws-azure-login --profile sandbox --mode gui
# pull-and-start then validates the permissions it actually needs via SSM/ECR; no STS preflight is required
```

Restart/recreate the stack if an already-running broker needs the refreshed host credentials.
### v1.16.44 MCP smoke test

After the new image/container is started, verify the Admin-managed MCP set from every supported entry point:

```bash
claude mcp list
gemini mcp list
ucode claude mcp list
ucode gemini mcp list
```

All four modes must register `tavily`, `snyk`, and `databricks-sql`. Gemini also synchronizes the persistent user MCP state from the root-owned system policy at launch. No AWS/service credential is written to the Gemini or Claude configuration.

