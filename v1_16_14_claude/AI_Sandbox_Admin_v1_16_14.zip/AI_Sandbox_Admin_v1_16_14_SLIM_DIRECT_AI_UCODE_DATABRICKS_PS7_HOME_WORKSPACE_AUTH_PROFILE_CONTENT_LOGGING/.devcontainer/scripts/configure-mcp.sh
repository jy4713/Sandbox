#!/usr/bin/env bash
# =============================================================================
# PACKAGE MAINTENANCE NOTES
# Purpose: Creates secret-free user-scope MCP registrations for Claude Code and
#          Gemini CLI. Tavily and Snyk are configured as SSM-backed MCP servers.
#
# v1.16.14 CHANGE - WHY THE GEMINI REGISTRATION NO LONGER USES `mcp add -e`:
#   The previous implementation registered the Gemini MCP servers with
#     -e 'AWS_ACCESS_KEY_ID=$AWS_ACCESS_KEY_ID' ...
#   That produced two different defects depending on the calling shell:
#     1. If the shell expanded the value, REAL AWS credentials were written in
#        clear text into ~/.gemini/settings.json (secret persisted to disk).
#     2. If the shell did not expand it, the literal string '$AWS_ACCESS_KEY_ID'
#        was injected into the MCP child, which run-with-ssm-secrets then read
#        as a populated static key pair. That forced static-credential mode,
#        failed STS validation, and deliberately refused SSO fallback, so every
#        Gemini MCP start failed in SSO mode.
#   MCP registration happens in post-create, BEFORE any AWS sign-in, so no
#   credential can ever be legitimately baked into this file. AWS authentication
#   is therefore resolved at MCP launch time by run-with-ssm-secrets, exactly as
#   it already is for Claude Code (which never had an env block).
#
# Admin maintenance: When adding/removing an MCP server, update this file plus
#                    its wrapper, SSM profile, Dockerfile, Squid allowlist and
#                    runtime verification.
# Safety rule: Never place API keys, tokens or AWS credentials in MCP
#              configuration files, and never write an env block into
#              ~/.gemini/settings.json.
# =============================================================================
set -euo pipefail
umask 077

export CLAUDE_CONFIG_DIR="${CLAUDE_CONFIG_DIR:-$HOME/.claude}"
export DISABLE_AUTOUPDATER=1
export CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC=1
mkdir -p "$CLAUDE_CONFIG_DIR" "$HOME/.gemini"

readonly REAL_DIR="/usr/local/libexec/ai-sandbox/real"
readonly REAL_CLAUDE="$REAL_DIR/claude"
readonly REAL_GEMINI="$REAL_DIR/gemini"
[[ -x "$REAL_CLAUDE" ]] || { echo 'ERROR: real Claude CLI is missing' >&2; exit 1; }
[[ -x "$REAL_GEMINI" ]] || { echo 'ERROR: real Gemini CLI is missing' >&2; exit 1; }
command -v jq >/dev/null 2>&1 || { echo 'ERROR: jq is required for MCP configuration' >&2; exit 1; }

# MCP start-up budget. The wrappers must complete an STS identity check and an
# SSM get-parameter round trip through Squid before the MCP server itself
# starts. Snyk additionally materialises its versioned native executable in an
# ephemeral exec-enabled tmpfs, so it is given a larger budget.
readonly TAVILY_MCP_TIMEOUT_MS=120000
readonly SNYK_MCP_TIMEOUT_MS=180000

# -----------------------------------------------------------------------------
# Claude Code - secret-free stdio registration (unchanged contract)
# Claude Code passes the parent environment to stdio MCP servers, so the wrapper
# inherits PATH, proxy settings and whichever AWS authentication mode is active.
# -----------------------------------------------------------------------------
"$REAL_CLAUDE" mcp remove tavily --scope user >/dev/null 2>&1 || true
"$REAL_CLAUDE" mcp add-json tavily '{"type":"stdio","command":"/usr/local/bin/tavily-mcp-ssm","args":[]}' --scope user >/dev/null

"$REAL_CLAUDE" mcp remove snyk --scope user >/dev/null 2>&1 || true
"$REAL_CLAUDE" mcp add-json snyk '{"type":"stdio","command":"/usr/local/bin/snyk-mcp-ssm","args":[]}' --scope user >/dev/null

# -----------------------------------------------------------------------------
# Gemini CLI - deterministic settings.json write
# `gemini mcp add` is intentionally NOT used for registration. Its repeatable
# -e/--env option is array-typed, so it can also swallow the trailing positional
# name/command arguments depending on CLI version. Writing the object directly
# removes both the secret-injection and the argument-parsing failure modes.
# REAL_GEMINI is still used to clear any stale registration created by an
# earlier package version.
# -----------------------------------------------------------------------------
"$REAL_GEMINI" mcp remove -s user tavily >/dev/null 2>&1 || true
"$REAL_GEMINI" mcp remove -s user snyk   >/dev/null 2>&1 || true

gemini_settings="$HOME/.gemini/settings.json"
[[ -s "$gemini_settings" ]] || printf '%s\n' '{}' > "$gemini_settings"
jq -e . "$gemini_settings" >/dev/null 2>&1 || printf '%s\n' '{}' > "$gemini_settings"

gemini_tmp="$(mktemp "${TMPDIR:-/tmp}/gemini-settings.XXXXXX")"
trap 'rm -f "$gemini_tmp"' EXIT

# Any pre-existing env block on these two servers is dropped, not merged. A
# package upgrade must actively erase credentials written by v1.16.13.
jq \
  --argjson tavily_timeout "$TAVILY_MCP_TIMEOUT_MS" \
  --argjson snyk_timeout "$SNYK_MCP_TIMEOUT_MS" '
  .mcpServers = ((.mcpServers // {}) + {
    tavily: {
      command: "/usr/local/bin/tavily-mcp-ssm",
      args: [],
      timeout: $tavily_timeout
    },
    snyk: {
      command: "/usr/local/bin/snyk-mcp-ssm",
      args: [],
      timeout: $snyk_timeout
    }
  })
' "$gemini_settings" > "$gemini_tmp"

jq -e . "$gemini_tmp" >/dev/null || { echo 'ERROR: generated Gemini settings are not valid JSON' >&2; exit 1; }
mv "$gemini_tmp" "$gemini_settings"
trap - EXIT
chmod 0600 "$gemini_settings"

# Fail closed if a credential-shaped value survived anywhere in the file. This
# catches both a stale v1.16.14 env block and a hand-edited settings.json.
if jq -e '
  [ (.mcpServers // {}) | (.tavily, .snyk) | select(. != null) | select(.env != null) ] | length > 0
' "$gemini_settings" >/dev/null 2>&1; then
  echo 'ERROR: an env block is present on a managed MCP server in ~/.gemini/settings.json;' >&2
  echo '       Tavily/Snyk MCP configuration must stay secret-free.' >&2
  exit 1
fi
if grep -Eq '(AKIA|ASIA)[A-Z0-9]{16}|aws_secret_access_key' "$gemini_settings"; then
  echo 'ERROR: AWS credential material detected in ~/.gemini/settings.json' >&2
  exit 1
fi

chmod -R go-rwx "$CLAUDE_CONFIG_DIR" "$HOME/.gemini" 2>/dev/null || true
echo '[OK] Secret-free Tavily MCP and Snyk MCP definitions configured for Claude Code and Gemini CLI.'
