# AI Secure Sandbox v1.16.54 Release Notes

v1.16.54 is a minimal Snyk Code authentication correction on top of v1.16.53. No URL routing, application flow, SSM boundary, or other provider behavior is intentionally changed.

## Fix

- The broker now treats inbound `Session-Token` as a credential header and strips the DevContainer placeholder before forwarding.
- For Snyk routes, the broker now injects the same SSM-backed `snyk-token` into both `Authorization: token ...` and `Session-Token: token ...`.
- Broker error sanitization now redacts `Session-Token` values in addition to the existing credential forms.
- Regression tests verify Snyk dual-endpoint routing plus `Authorization`/`Session-Token` replacement and redaction.

This addresses the validated runtime sequence where Snyk Code successfully fetched `/filters`, then `POST /bundle` failed with `401 Unauthorized` / `Invalid auth token` because v1.16.53 replaced `Authorization` but forwarded the CLI placeholder `Session-Token` unchanged.

## Unchanged

- `api.snyk.local` -> Admin `snyk_api` and `deeproxy.snyk.local` -> Admin `snyk_code` hostname routing is unchanged.
- Native Snyk path/query forwarding is unchanged.
- The real Snyk token remains broker-only and is retrieved from SSM.
- Admin upstream endpoints remain in `policies/admin-upstream-endpoints.json`.
- Claude, Gemini, Tavily, Databricks, ADO/Git, ucode, MCP, logging, TAR/ECR, hardening, and default-deny Squid behavior are unchanged.
