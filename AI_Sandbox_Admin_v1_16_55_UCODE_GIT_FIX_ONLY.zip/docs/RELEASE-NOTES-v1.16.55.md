# AI Secure Sandbox v1.16.55 Release Notes

v1.16.55 is a minimal secret-broker startup correction on top of v1.16.54. No provider routing, SSM boundary, credential injection, application execution flow, or Developer command behavior is intentionally changed.

## Fix

- `secret-broker` now sets `working_dir: /` in both `tar/docker-compose.yml` and `ecr/docker-compose.yml`.
- This prevents the broker from inheriting the shared DevContainer image `WORKDIR /home/vscode/workspace` even though the broker intentionally has no workspace mount.
- The fix addresses Docker/OCI startup failures such as `chdir to cwd ("/home/vscode/workspace") ... permission denied`.
- Package lint now verifies the broker working directory remains `/` in both deployment Compose files.

## Unchanged

- v1.16.54 Snyk `Authorization` + `Session-Token` replacement remains unchanged.
- Snyk dual-endpoint hostname routing remains unchanged.
- The broker still has no workspace mount and cannot execute Developer/application commands.
- Claude, Gemini, Tavily, Databricks, ADO/Git, ucode, MCP, logging, SSM, Squid, TAR/ECR, and hardening behavior are unchanged.
