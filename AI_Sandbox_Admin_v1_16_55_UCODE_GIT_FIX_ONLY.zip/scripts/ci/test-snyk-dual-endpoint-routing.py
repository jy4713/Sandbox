#!/usr/bin/env python3
"""Offline regression for Snyk CLI 1.1306.2 dual endpoint credential routing."""
from __future__ import annotations
import importlib.util
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
BROKER = ROOT / ".devcontainer/scripts/secret-broker-server.py"
WRAPPER = ROOT / ".devcontainer/scripts/sandbox-command-wrapper.sh"
MCP = ROOT / ".devcontainer/scripts/snyk-mcp-ssm.sh"
os.environ["TAVILY_POLICY_FILE"] = str(ROOT / "policies/tavily-allowed-domains.json")
os.environ["ADO_POLICY_FILE"] = str(ROOT / "policies/ado-policy.json")
os.environ["ADMIN_UPSTREAM_ENDPOINTS_FILE"] = str(ROOT / "policies/admin-upstream-endpoints.json")
os.environ.pop("DATABRICKS_HOST", None)

spec = importlib.util.spec_from_file_location("broker_v1654", BROKER)
assert spec and spec.loader
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

# This mirrors code-client-go v1.27.0 SnykCodeApi(): strings.ReplaceAll(API_URL, "api", "deeproxy").
general = "http://api.snyk.local:8771"
code = "http://deeproxy.snyk.local:8771"
assert general.replace("api", "deeproxy") == code

w = WRAPPER.read_text(encoding="utf-8")
m = MCP.read_text(encoding="utf-8")
for text in (w, m):
    assert general in text
    assert code in text
    assert "SNYK_TOKEN" in text and "ai-sandbox-broker-placeholder" in text
    for retired in ("8772", "snyk-proxy-ca.pem", "SSL_CERT_FILE", "NODE_EXTRA_CA_CERTS"):
        assert retired not in text
assert 'SNYK_API="$snyk_api" DEEPROXY_API_URL="$snyk_code_api"' in w
assert 'SNYK_HTTP_PROTOCOL_UPGRADE=0' in w, 'CLI local HTTP routes must not be auto-upgraded to HTTPS'
assert 'SNYK_API="$SNYK_API_BASE" DEEPROXY_API_URL="$SNYK_CODE_BASE"' in m
assert 'SNYK_HTTP_PROTOCOL_UPGRADE=0' in m, 'MCP local HTTP routes must not be auto-upgraded to HTTPS'

# Host selects the upstream; path/query remain opaque and unchanged.
h = mod.ProviderProxyHandler.__new__(mod.ProviderProxyHandler)
h.headers = {"Host": "api.snyk.local:8771"}
h.path = "/rest/orgs/abc/issues?version=2026-01-01&foo=a%2Fb"
r = h._route()
assert r == ("/snyk", mod.SNYK_API_ORIGIN + "/rest/orgs/abc/issues?version=2026-01-01&foo=a%2Fb", "snyk-token", "snyk")

h.headers = {"Host": "deeproxy.snyk.local:8771"}
h.path = "/bundle/abc?foo=a%2Fb"
r = h._route()
assert r == ("/snyk", mod.SNYK_CODE_ORIGIN + "/bundle/abc?foo=a%2Fb", "snyk-token", "snyk")

h.headers = {"Host": "api.snyk.local:8771"}
h.path = "/../escape"
assert h._route() is None
h.headers = {"Host": "attacker.invalid:8771"}
h.path = "/filters"
assert h._route() is None

# Exact v1.16.55 regression: Snyk CLI sends placeholder credentials in both
# Authorization and Session-Token. The broker must remove both caller values
# and rebuild both headers from the broker-only SSM token before /bundle.
class _FakeResponse:
    status = 200
    headers = {}
    def read(self, _size=-1):
        return b""
    def close(self):
        pass

class _CaptureOpener:
    def __init__(self):
        self.request = None
    def open(self, request, timeout=0):
        self.request = request
        return _FakeResponse()

class _Sink:
    def write(self, _data):
        return 0
    def flush(self):
        pass

proxy = mod.ProviderProxyHandler.__new__(mod.ProviderProxyHandler)
proxy.headers = {
    "Host": "deeproxy.snyk.local:8771",
    "Authorization": "token ai-sandbox-broker-placeholder",
    "Session-Token": "token ai-sandbox-broker-placeholder",
    "Content-Type": "application/json",
}
proxy.path = "/bundle"
proxy.command = "POST"
proxy._read_body = lambda: b"{}"
proxy.send_response = lambda _status: None
proxy.send_header = lambda _key, _value: None
proxy.end_headers = lambda: None
proxy.wfile = _Sink()
proxy.close_connection = False
proxy._error = lambda status, message: (_ for _ in ()).throw(AssertionError(f"unexpected broker error {status}: {message}"))

_real_get_parameter = mod.get_parameter
_real_opener = mod.URL_OPENER
capture = _CaptureOpener()
mod.get_parameter = lambda name: "validated-real-snyk-token" if name == "snyk-token" else (_ for _ in ()).throw(AssertionError(name))
mod.URL_OPENER = capture
try:
    proxy._proxy()
finally:
    mod.get_parameter = _real_get_parameter
    mod.URL_OPENER = _real_opener

assert capture.request is not None
out_headers = {k.lower(): v for k, v in capture.request.header_items()}
assert out_headers["authorization"] == "token validated-real-snyk-token"
assert out_headers["session-token"] == "token validated-real-snyk-token"
assert "ai-sandbox-broker-placeholder" not in repr(out_headers)

source = BROKER.read_text(encoding="utf-8")
assert 'headers["Authorization"] = f"token {secret}"' in source
assert 'headers["Session-Token"] = f"token {secret}"' in source
assert '"authorization", "session-token", "x-api-key"' in source
assert 'if auth_kind == "snyk" and lk == "host":' in source
for retired in ("SnykCredentialProxyHandler", "SNYK_PROXY_PORT", "snyk-proxy-ca.pem", "cryptography"):
    assert retired not in source

for compose in (ROOT / "tar/docker-compose.yml", ROOT / "ecr/docker-compose.yml"):
    c = compose.read_text(encoding="utf-8")
    assert '"api.snyk.local:127.0.0.1"' in c
    assert '"deeproxy.snyk.local:127.0.0.1"' in c
    assert "SANDBOX_SNYK_PROXY_PORT" not in c
    assert "SANDBOX_SNYK_PROXY_LOOPBACK_PORT" not in c

print("Snyk validated dual-endpoint routing regression passed")
