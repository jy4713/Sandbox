#!/usr/bin/env python3
"""Offline regression tests for the v1.16.55 credential-only HTTP broker.

No AWS or vendor network access is used. The tests verify that the broker has no
application-command execution path, that fixed upstream validation is fail
closed, that ADO stays on fixed Admin routes without CLI/API command gating,
and that Tavily domain policy cannot be bypassed by calling the broker directly.
"""
from __future__ import annotations

import importlib.util
import json
import os
import tempfile
import urllib.parse
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
BROKER = ROOT / ".devcontainer" / "scripts" / "secret-broker-server.py"
TAVILY_POLICY = ROOT / "policies" / "tavily-allowed-domains.json"
ADO_POLICY = ROOT / "policies" / "ado-policy.json"
UPSTREAM_POLICY = ROOT / "policies" / "admin-upstream-endpoints.json"
TAVILY_PROXY = ROOT / ".devcontainer" / "scripts" / "tavily-policy-proxy.py"
os.environ["TAVILY_POLICY_FILE"] = str(TAVILY_POLICY)
os.environ["ADO_POLICY_FILE"] = str(ADO_POLICY)
os.environ["ADMIN_UPSTREAM_ENDPOINTS_FILE"] = str(UPSTREAM_POLICY)
os.environ.pop("DATABRICKS_HOST", None)
os.environ.pop("SNYK_API", None)

spec = importlib.util.spec_from_file_location("ai_sandbox_secret_broker", BROKER)
assert spec and spec.loader
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)


def expect_denied(fn, *args):
    try:
        fn(*args)
    except (PermissionError, ValueError, RuntimeError):
        return
    raise AssertionError(f"expected denial: {fn.__name__}{args!r}")


# Broker architecture: AWS SSM retrieval is the only subprocess use.
source = BROKER.read_text(encoding="utf-8")
for forbidden in ("subprocess.Popen", "subprocess.call", "subprocess.check_call", "subprocess.check_output", "os.system(", "os.exec"):
    assert forbidden not in source
assert source.count("subprocess.run(") == 1
assert "run-with-ssm-secrets" not in source
assert "secret-broker-client" not in source
assert "/home/vscode/workspace" not in source
assert '["aws", "--profile", AWS_PROFILE, "ssm", "get-parameter"' in source
assert "command_execution=disabled" in source
assert "def do_OPTIONS(self) -> None: self._proxy()" in source
assert 'self.send_header("Location", rewritten or v)' in source

# Dependency errors keep useful vendor/proxy diagnostics but redact credentials.
raw_error = (
    'aws: [ERROR]: Failed to connect to proxy URL: "http://squid-proxy:3128"\n'
    'Authorization: Bearer super-secret-token\n'
    'Session-Token: token super-secret-session\n'
    'aws_secret_access_key=example-secret\n'
    'access=AKIA1234567890ABCDEF'
)
san = mod.sanitize_error_text(raw_error)
assert 'Failed to connect to proxy URL: "http://squid-proxy:3128"' in san
assert 'super-secret-token' not in san
assert 'super-secret-session' not in san
assert 'example-secret' not in san
assert 'AKIA1234567890ABCDEF' not in san
assert '[REDACTED]' in san

# AWS SSM stderr is returned to the caller after sanitization instead of being
# replaced with a generic "refresh profile" message. No network access occurs.
class _FakeCompleted:
    returncode = 255
    stdout = ''
    stderr = 'aws: [ERROR]: An error occurred (ParameterNotFound) when calling the GetParameter operation'

_real_run = mod.subprocess.run
mod.subprocess.run = lambda *args, **kwargs: _FakeCompleted()
try:
    try:
        mod.get_parameter('__lint_missing_parameter__')
    except RuntimeError as exc:
        text = str(exc)
        assert text.startswith('[broker:aws-ssm] ')
        assert 'ParameterNotFound' in text
        assert 'refresh the host AWS profile' not in text
    else:
        raise AssertionError('expected sanitized AWS SSM error')
finally:
    mod.subprocess.run = _real_run

# Databricks remains environment-specific and vendor-suffix validated.
assert mod._validate_https_origin("https://dbc.example.databricks.com", (".databricks.com",), "x") == "https://dbc.example.databricks.com"
for bad in (
    "http://dbc.example.databricks.com",
    "https://user:pass@dbc.example.databricks.com",
    "https://dbc.example.databricks.com/evil",
    "https://dbc.example.databricks.com:8443",
    "https://example.invalid",
):
    expect_denied(mod._validate_https_origin, bad, (".databricks.com",), "x")

# Fixed vendor upstreams are loaded from one root-owned Admin policy. The Admin
# can change a vendor hostname/path before rebuilding, while runtime callers
# cannot choose an arbitrary destination.
upstream_doc = json.loads(UPSTREAM_POLICY.read_text(encoding="utf-8"))
assert mod.ADMIN_UPSTREAMS == upstream_doc["upstreams"]
for bad in (
    "http://api.example.com",
    "https://user:pass@api.example.com",
    "https://api.example.com:8443",
    "https://127.0.0.1",
    "https://api.example.com/a/../b",
    "https://api.example.com/x?y=1",
):
    expect_denied(mod._validate_admin_endpoint, bad, "x")
assert mod._validate_admin_endpoint("https://new.vendor.example/api/v2", "x") == "https://new.vendor.example/api/v2"

# Every configured fixed upstream must also be covered by the Admin Squid ACL.
# This keeps endpoint maintenance to policy + egress allowlist, not Python code.
whitelist = []
for line in (ROOT / "squid/whitelist.txt").read_text(encoding="utf-8").splitlines():
    item = line.split("#", 1)[0].strip().lower().rstrip(".")
    if item:
        whitelist.append(item)

def squid_allows(host: str) -> bool:
    host = host.lower().rstrip(".")
    for item in whitelist:
        if item.startswith("."):
            base = item[1:]
            if host == base or host.endswith(item):
                return True
        elif host == item:
            return True
    return False

for name, endpoint in mod.ADMIN_UPSTREAMS.items():
    host = urllib.parse.urlsplit(endpoint).hostname
    assert host and squid_allows(host), f"Admin upstream is not covered by squid/whitelist.txt: {name} -> {host}"

# Fixed provider route identities resolve only to the Admin-configured targets.
_route_h = mod.ProviderProxyHandler.__new__(mod.ProviderProxyHandler)
_route_h.headers = {"Host": "127.0.0.1:8771"}
for path, expected, secret, auth in (
    ("/anthropic/v1/messages?x=1", mod.ANTHROPIC_ORIGIN + "/v1/messages?x=1", "claude-api-key", "anthropic"),
    ("/gemini/v1beta/models?x=1", mod.GEMINI_ORIGIN + "/v1beta/models?x=1", "gemini-api-key", "gemini"),
    ("/tavily-api/search", mod.TAVILY_API_ORIGIN + "/search", "tavily-api-key", "tavily"),
    ("/tavily-mcp", mod.TAVILY_MCP_ORIGIN, "tavily-api-key", "tavily-mcp"),
):
    _route_h.path = path
    route = _route_h._route()
    assert route and route[1:] == (expected, secret, auth)

# Snyk dual-endpoint routing is driven by the native Snyk CLI split, not by
# broker path classification. CLI 1.1306.2 (code-client-go v1.27.0) derives
# Code API from API_URL by replacing "api" with "deeproxy". The local alias
# pair preserves that behavior, while the broker fixes each alias to one Snyk
# upstream and injects only the SSM token.
assert mod.SNYK_LOCAL_API_HOST == "api.snyk.local"
assert mod.SNYK_LOCAL_CODE_HOST == "deeproxy.snyk.local"
local_api = "http://api.snyk.local:8771"
assert local_api.replace("api", "deeproxy") == "http://deeproxy.snyk.local:8771"

_h = mod.ProviderProxyHandler.__new__(mod.ProviderProxyHandler)
_h.headers = {"Host": "api.snyk.local:8771"}
_h.path = "/v1/track-sast-usage/cli?org=a%2Fb&x=1+2"
_r = _h._route()
assert _r == (
    "/snyk",
    mod.SNYK_API_ORIGIN + "/v1/track-sast-usage/cli?org=a%2Fb&x=1+2",
    "snyk-token",
    "snyk",
)
_h.headers = {"Host": "deeproxy.snyk.local:8771"}
_h.path = "/filters?x=a%2Fb&y=1+2"
_r = _h._route()
assert _r == (
    "/snyk",
    mod.SNYK_CODE_ORIGIN + "/filters?x=a%2Fb&y=1+2",
    "snyk-token",
    "snyk",
)
_h.headers = {"Host": "example.invalid:8771"}
assert _h._route() is None
assert 'headers["Authorization"] = f"token {secret}"' in source
assert 'headers["Session-Token"] = f"token {secret}"' in source
assert '"authorization", "session-token", "x-api-key"' in source
for retired in (
    "SNYK_PROXY_PORT", "SnykCredentialProxyHandler", "snyk-proxy-ca.pem",
    "ensure_snyk_proxy_material", "_inject_snyk_auth_header",
):
    assert retired not in source

# Traversal must be denied before privileged forwarding.
assert mod.safe_suffix("/ado/dev/org/proj", "/ado/dev") == "/org/proj"
for bad in (
    "/ado/dev/../x",
    "/ado/dev/%2e%2e/x",
    "/ado/dev/%252e%252e/x",
    "/ado/dev/a\\..\\b",
):
    expect_denied(mod.safe_suffix, bad, "/ado/dev")

# ADO policy is loaded from the same single source used by the local Git policy.
ado_doc = json.loads(ADO_POLICY.read_text(encoding="utf-8"))
assert mod.ADO_POLICY["policy_version"] == ado_doc["policy_version"]
assert set(mod.ADO_ROUTES) == {r["prefix"] for r in ado_doc["broker_routes"]}
assert mod.ADO_POLICY["git"]["repository_host"] == "dev.azure.com"
assert "allowed_operations" not in mod.ADO_POLICY["git"]
assert "repository_path_regex" not in mod.ADO_POLICY["git"]
assert all("rules" not in route for route in ado_doc["broker_routes"])
assert "allowed_operations" not in source
assert "repository_path_regex" not in source
assert "query_requirements" not in source

# ADO remains fixed to the shared Admin route metadata, but the broker is not a
# Git/REST subcommand allowlist. Azure DevOps permissions on the PAT are the
# authorization boundary; only Tavily retains an application-level allowlist.
assert "_ado_request_allowed" not in source
assert "approved Git/PR/pipeline policy" not in source
assert mod.ADO_ROUTES["/ado/dev"]["upstream_origin"] == "https://dev.azure.com"
assert mod.ADO_ROUTES["/ado/vssps"]["upstream_origin"] == "https://vssps.dev.azure.com"
assert all(route["credential_parameter"] == "ado-pat" for route in mod.ADO_ROUTES.values())

# Tavily policy is enforced again at the broker, so direct HTTP use cannot
# bypass the Admin allowlist even if a Developer ignores the CLI/MCP wrapper.
allowed = json.loads(mod._enforce_tavily_http(
    "/search", json.dumps({"query": "python docs from docs.python.org"}).encode()
).decode())
assert allowed["include_domains"] == ["docs.python.org"]

normalized = json.loads(mod._enforce_tavily_http(
    "/search", json.dumps({"query": "secure coding"}).encode()
).decode())
assert set(normalized["include_domains"]) == set(mod.TAVILY_ALLOWED)

expect_denied(
    mod._enforce_tavily_http,
    "/search",
    json.dumps({"query": "arsenal news from espn.com"}).encode(),
)
expect_denied(
    mod._enforce_tavily_http,
    "/search",
    json.dumps({"query": "test", "include_domains": ["espn.com"]}).encode(),
)
expect_denied(
    mod._enforce_tavily_http,
    "/extract",
    json.dumps({"urls": ["https://espn.com/news"]}).encode(),
)
expect_denied(mod._enforce_tavily_http, "/research", json.dumps({"input": "x"}).encode())
expect_denied(mod._enforce_tavily_http, "/unknown", json.dumps({"x": 1}).encode())

mcp = {
    "jsonrpc": "2.0",
    "id": 1,
    "method": "tools/call",
    "params": {"name": "tavily_search", "arguments": {"query": "docs.python.org asyncio"}},
}
out = json.loads(mod._enforce_tavily_mcp(json.dumps(mcp).encode()).decode())
assert out["params"]["arguments"]["include_domains"] == ["docs.python.org"]
mcp["params"]["arguments"] = {"query": "scores from espn.com"}
expect_denied(mod._enforce_tavily_mcp, json.dumps(mcp).encode())

# Local Tavily MCP policy proxy is tested here as part of the same policy suite,
# so a second standalone regression script is unnecessary.
def _load_tavily_proxy(policy_path: Path):
    os.environ["TAVILY_POLICY_FILE"] = str(policy_path)
    proxy_spec = importlib.util.spec_from_file_location("ai_sandbox_tavily_policy_proxy", TAVILY_PROXY)
    assert proxy_spec and proxy_spec.loader
    proxy = importlib.util.module_from_spec(proxy_spec)
    proxy_spec.loader.exec_module(proxy)
    return proxy


def _proxy_search_call(proxy, args: dict):
    message = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "tools/call",
        "params": {"name": "tavily_search", "arguments": dict(args)},
    }
    return proxy.enforce_tool_call(message)


with tempfile.TemporaryDirectory() as tmp:
    proxy_policy = Path(tmp) / "tavily-policy.json"
    proxy_policy.write_text(json.dumps({"allowed_domains": ["docs.databricks.com", "github.com"]}), encoding="utf-8")
    proxy = _load_tavily_proxy(proxy_policy)

    allowed_msg, denied_msg = _proxy_search_call(proxy, {"query": "Databricks SQL MCP"})
    assert denied_msg is None
    assert allowed_msg["params"]["arguments"]["include_domains"] == ["docs.databricks.com", "github.com"]

    allowed_msg, denied_msg = _proxy_search_call(proxy, {"query": "search docs.databricks.com for SQL MCP"})
    assert denied_msg is None
    assert allowed_msg["params"]["arguments"]["include_domains"] == ["docs.databricks.com"]

    allowed_msg, denied_msg = _proxy_search_call(proxy, {"query": "search espn.com for Arsenal"})
    assert allowed_msg is None and denied_msg["error"]["code"] == -32001

    allowed_msg, denied_msg = _proxy_search_call(proxy, {"query": "Arsenal", "include_domains": ["espn.com"]})
    assert allowed_msg is None and denied_msg["error"]["code"] == -32001

    allowed_msg, denied_msg = _proxy_search_call(proxy, {
        "query": "search docs.databricks.com for SQL MCP",
        "include_domains": ["github.com"],
    })
    assert allowed_msg is None and denied_msg["error"]["code"] == -32001

    extract = {
        "jsonrpc": "2.0",
        "id": 3,
        "method": "tools/call",
        "params": {"name": "tavily_extract", "arguments": {"urls": ["https://espn.com/x"]}},
    }
    allowed_msg, denied_msg = proxy.enforce_tool_call(extract)
    assert allowed_msg is None and denied_msg["error"]["code"] == -32001

    crawl = {
        "jsonrpc": "2.0",
        "id": 4,
        "method": "tools/call",
        "params": {"name": "tavily_crawl", "arguments": {"url": "https://docs.databricks.com/en/index.html", "allow_external": True}},
    }
    allowed_msg, denied_msg = proxy.enforce_tool_call(crawl)
    assert denied_msg is None
    assert allowed_msg["params"]["arguments"]["allow_external"] is False
    assert allowed_msg["params"]["arguments"]["select_domains"] == [r"^docs\.databricks\.com$"]

    research = {
        "jsonrpc": "2.0",
        "id": 2,
        "method": "tools/call",
        "params": {"name": "tavily_research", "arguments": {"input": "x"}},
    }
    allowed_msg, denied_msg = proxy.enforce_tool_call(research)
    assert allowed_msg is None and denied_msg["error"]["code"] == -32001

    future_tool = {
        "jsonrpc": "2.0",
        "id": 5,
        "method": "tools/call",
        "params": {"name": "tavily_future_web_tool", "arguments": {}},
    }
    allowed_msg, denied_msg = proxy.enforce_tool_call(future_tool)
    assert allowed_msg is None and denied_msg["error"]["code"] == -32001

# Restore the package policy path for any future additions to this module.
os.environ["TAVILY_POLICY_FILE"] = str(TAVILY_POLICY)

print("Credential-only broker policy regression tests passed")
