#!/usr/bin/env python3
"""Legacy guard: v1.16.55 never executes application commands in the broker."""
import sys
print("ERROR: broker-side command execution is disabled. Use the normal devcontainer command; credentials are injected by the broker HTTP route.", file=sys.stderr)
raise SystemExit(126)
