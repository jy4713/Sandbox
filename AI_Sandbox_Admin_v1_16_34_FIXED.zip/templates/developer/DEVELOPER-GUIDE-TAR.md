# Developer Guide - TAR - AI Secure Sandbox v1.16.34

## Purpose

The TAR package starts a credential-isolated AI Dev Container. AWS authentication is performed on the Windows 365 host using `aws-azure-login` and the corporate Azure/Entra browser/MFA flow. The AI container never receives the host `.aws` directory or raw application secrets.

## Prerequisites

- Docker Desktop / approved Docker runtime
- VS Code + Dev Containers
- AWS CLI v2
- `aws-azure-login` on the Windows host
- Browser access to Azure/Entra

If approved and not already installed:

```powershell
npm install -g aws-azure-login
```

## Configure `.env`

The launcher creates `.env` from `.env.example` when required. Fill only non-secret settings, especially:

```ini
DEVELOPER_ID=<your-id>
SANDBOX_AWS_PROFILE=sandbox
AWS_REGION=eu-west-2
AZURE_TENANT_ID=<tenant-id>
AZURE_APP_ID_URI=<app-id-uri>
AZURE_DEFAULT_USERNAME=<your-email>
AZURE_DEFAULT_ROLE_ARN=arn:aws:iam::<account>:role/<role>
AZURE_DEFAULT_DURATION_HOURS=1
AZURE_DEFAULT_REMEMBER_ME=true
DATABRICKS_HOST=https://<approved-workspace>
DATABRICKS_CLAUDE_MODEL=<approved-model>
DATABRICKS_GEMINI_MODEL=<approved-model>
```

Never add AWS access keys, SSM secret values, PATs, or provider API keys to `.env`.

## Start

```powershell
.\scripts\tar\load-and-start.ps1
```

The launcher:

1. validates package/image hashes;
2. writes the non-secret Azure SAML settings into the host named AWS profile;
3. validates the current temporary AWS session;
4. opens `aws-azure-login --profile sandbox --mode gui` when login is required;
5. mounts host `~/.aws` read-only into `secret-broker` only;
6. starts the proxy, broker, and AI Dev Container.

## Use

```bash
claude
 gemini
ucode claude
ucode gemini
snyk code test
snyk test
tvly search "example query"
databricks current-user me
```

Tavily/Snyk/Databricks/ADO secrets are fetched inside the broker. `ucode claude/gemini` use a brokered Databricks AI Gateway route so the PAT is not placed into the AI process.

## Verify credential isolation

```bash
verify-runtime
```

Expected security properties:

- no `~/.aws/credentials` or AWS SSO/SAML cache in the AI container;
- no AWS access-key environment variables;
- no Tavily/Snyk/Databricks/ADO raw secret environment variables;
- direct `aws ssm get-parameter ... --with-decryption` fails;
- MCP and provider broker health checks succeed.

## Refresh AWS login

If the broker reports that the host AWS session expired, return to Windows PowerShell and run:

```powershell
aws-azure-login --profile sandbox --mode gui
# load-and-start then relies on the broker's first SSM call as the required-permission check; no STS preflight is required
```

Then restart/recreate the sandbox so the broker reopens the current host credential files.

## Notes

`aws-azure-login` can store temporary AWS role credentials on the Windows host. The Developer can inspect their own host session. Those files are intentionally not mounted into the AI Dev Container.
