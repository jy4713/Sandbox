# AI Secure Sandbox v1.16.34

v1.16.34 hardens v1.16.33 around a strict credential boundary: the Developer authenticates to AWS on the Windows 365 host through Azure/Entra SAML and a browser, while AI processes inside the Dev Container receive no AWS credential material and cannot call SSM directly.

## 1. Security model

```text
Windows 365 host
  Developer
    -> aws-azure-login --profile sandbox --mode gui
    -> Azure/Entra browser + MFA
    -> temporary AWS role credentials in host ~/.aws
                    |
                    | read-only bind mount, broker only
                    v
              secret-broker
                -> AWS SSM GetParameter
                -> Tavily / Snyk / ADO / Databricks credentials
                -> provider and MCP calls
                    |
                    | approved broker protocol / results only
                    v
              AI Dev Container
                Claude / Gemini / ucode route / MCP clients
                no ~/.aws
                no AWS_ACCESS_KEY_ID / AWS_SECRET_ACCESS_KEY
                no AWS SSO/SAML cache
                no ssm:GetParameter-capable credential
                no raw PAT/API key
```

The broker and Dev Container use the same hardened runtime image but have different runtime roles and mounts. Only `secret-broker` receives the host `.aws` directory. The Dev Container has no Docker socket, no privileged capabilities, a read-only root filesystem, and no AWS credential mount.

## 2. AWS login information required from the federation administrator

The Developer package requires the following non-secret values in its deployment-local `.env`:

```ini
SANDBOX_AWS_PROFILE=sandbox
AWS_REGION=eu-west-2

AZURE_TENANT_ID=<tenant-id>
AZURE_APP_ID_URI=<enterprise-application-id-uri>
AZURE_DEFAULT_USERNAME=<developer-email>
AZURE_DEFAULT_ROLE_ARN=arn:aws:iam::<12-digit-account-id>:role/<role-name>
AZURE_DEFAULT_DURATION_HOURS=1
AZURE_DEFAULT_REMEMBER_ME=true
```

These correspond to the `aws-azure-login` profile fields:

```ini
azure_tenant_id=...
azure_app_id_uri=...
azure_default_username=...
azure_default_role_arn=...
azure_default_duration_hours=1
azure_default_remember_me=true
```

Do not put `AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY`, `AWS_SESSION_TOKEN`, or native `AWS_SSO_*` values in `.env`. v1.16.34 rejects them.

The Windows launchers create/update the named profile in the host `~/.aws/config` and invoke the Azure/Entra browser authentication flow directly. No separate STS preflight is required; the first SSM/ECR operation validates the AWS permissions actually needed by the package:

```powershell
aws-azure-login --profile sandbox --mode gui
```

If the normal GUI path fails once on Windows 365, the launcher retries with `--disable-gpu`.

## 3. Windows 365 prerequisites

Developer host prerequisites:

- Docker Desktop / approved Docker runtime
- VS Code with Dev Containers extension
- AWS CLI v2
- Node.js/npm only if required to install the approved `aws-azure-login` client
- `aws-azure-login` available on `PATH`
- Browser access to the corporate Azure/Entra authentication flow

Example installation of `aws-azure-login` when permitted by the client software policy:

```powershell
npm install -g aws-azure-login
aws-azure-login --version
```

The AI CLIs remain inside the container; installing Claude Code or Gemini CLI on the Windows host is not required.

## 4. SSM secrets

Runtime secrets remain in AWS SSM Parameter Store. The Admin bootstrap creates the approved parameter names, including:

| Parameter | Type | Consumer |
|---|---|---|
| `/sandbox/claude-api-key` | SecureString | provider broker only |
| `/sandbox/gemini-api-key` | SecureString | provider broker only |
| `/sandbox/databricks-token` | SecureString | Databricks broker route / approved CLI |
| `/sandbox/databricks-sql-mcp-token` | SecureString | Databricks SQL MCP broker |
| `/sandbox/ado-pat` | SecureString | ADO broker |
| `/sandbox/tavily-api-key` | SecureString | Tavily broker |
| `/sandbox/snyk-token` | SecureString | Snyk broker |
| `/sandbox/hiddenlayer-client-id` | SecureString | approved HiddenLayer adapter |
| `/sandbox/hiddenlayer-client-secret` | SecureString | approved HiddenLayer adapter |

The AI Dev Container cannot run the broker-side secret runner. `run-with-ssm-secrets` returns exit code 126 unless `AI_SANDBOX_ROLE=broker`.

## 5. AI and tool routing

### Direct Claude

```text
claude -> 127.0.0.1 loopback relay -> secret-broker -> SSM claude-api-key -> api.anthropic.com
```

Claude sees only a fixed non-secret placeholder credential. The broker discards client authentication and inserts the real key for the upstream request.

### Direct Gemini

```text
gemini -> 127.0.0.1 loopback relay -> secret-broker -> SSM gemini-api-key -> Google Gemini API
```

Gemini also receives only a fixed placeholder. The real key exists only in broker memory while the request is made.

### Databricks coding-agent route

The existing Developer command contract is preserved:

```bash
ucode claude
ucode gemini
```

For credential isolation, v1.16.34 does **not** use upstream ucode's PAT-injection runtime path. The public `ucode` wrapper launches the approved Claude/Gemini binary against a brokered Databricks AI Gateway route:

```text
ucode claude -> local relay -> broker -> SSM databricks-token -> <workspace>/ai-gateway/anthropic
ucode gemini -> local relay -> broker -> SSM databricks-token -> <workspace>/ai-gateway/gemini
```

The Databricks PAT is never placed in the AI agent environment or user configuration. `DATABRICKS_CLAUDE_MODEL` and `DATABRICKS_GEMINI_MODEL` select the approved models.

### MCP and CLI integrations

- Tavily MCP/CLI -> broker -> SSM Tavily key -> Admin domain policy -> Tavily
- Snyk MCP/approved scan CLI -> broker -> SSM Snyk token -> Snyk
- Databricks SQL MCP -> broker -> dedicated SSM token -> Databricks MCP endpoint
- Approved Databricks CLI read operations -> broker -> SSM Databricks PAT
- ADO Git/PR/pipeline commands -> broker -> SSM ADO PAT

The broker exposes fixed operations only. There is no generic "execute arbitrary command with a secret" operation.

## 6. Developer TAR flow

1. Extract the Developer TAR package.
2. If Windows marks downloaded PowerShell files as blocked, use the documented Process-scope execution-policy/unblock commands.
3. Copy `.env.example` to `.env` if the launcher has not already done so.
4. Fill the Azure/Entra SAML fields and other non-secret runtime values.
5. Run:

```powershell
.\scripts\tar\load-and-start.ps1
```

The launcher validates package hashes, configures the host AWS profile, opens browser login if needed, and starts `squid-proxy`, `secret-broker`, and `devcontainer`.

## 7. Developer ECR flow

Fill the same host authentication fields plus the approved ECR registry value, then run:

```powershell
.\scripts\ecr\pull-and-start.ps1
```

The host session is used to read the centrally approved image manifest and pull immutable image digests. The AWS profile is not copied into the AI container.

## 8. Verification inside the Dev Container

Run:

```bash
verify-runtime
```

Important expected results:

```text
[OK] container role is AI client
[OK] no AWS bootstrap credential environment variables
[OK] no AWS profile/config path variables in AI environment
[OK] no AWS credential file in AI container
[OK] no AWS SSO token cache in AI container
[OK] no application/service secrets in parent environment
[OK] broker-only SSM runner refuses AI invocation
[OK] AWS SSM direct read is not credentialed
[OK] AI loopback provider relay is reachable
```

Additional safe checks:

```bash
env | grep -E 'AWS_(ACCESS_KEY|SECRET|SESSION)|TAVILY_API_KEY|SNYK_TOKEN|DATABRICKS_TOKEN|ADO_PAT'
ls -la ~/.aws 2>/dev/null || true
aws ssm get-parameter --name /sandbox/tavily-api-key --with-decryption --region eu-west-2
```

The first two must not reveal credentials. The direct SSM command must fail because the AI container has no AWS credential source.

## 9. What the Developer can and cannot see

The Developer controls the Windows host login and therefore can inspect the temporary host-side AWS session material produced by `aws-azure-login`. This POC does not claim to hide the Developer's own AWS session from the Developer.

However, application PATs/API keys are not written to `.env`, workspace files, or AI-agent configuration. They stay in SSM and are fetched by the trusted broker. To prevent the Developer from directly reading those SSM values as well, use a separate production broker IAM identity and remove `ssm:GetParameter`/KMS decrypt from the Developer SSO role.

## 10. Important production boundary

The v1.16.34 broker prevents AI processes in the Dev Container from obtaining AWS/SSM credentials or raw service secrets. If the Developer is also considered hostile and retains full Docker Desktop administrator control on the same Windows host, a local sibling container is not a complete security boundary against the host administrator. Production should move the broker to an Admin-controlled service/host or otherwise enforce the Docker runtime outside Developer control.

## 11. Main Admin validation

```bash
scripts/ci/lint-package.sh
```

The lint checks architecture invariants rather than a version-specific file list: no static AWS runtime mappings, broker-only `.aws` mount, browser federation launcher path, broker-only secret execution, credential-free MCP definitions, and syntax/compile checks.
