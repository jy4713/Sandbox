#Requires -Version 7.4
# =============================================================================
# PACKAGE MAINTENANCE NOTES
# Purpose:
#   Developer ECR launcher. Fetches the centrally approved two-image
#   manifest from AWS SSM, validates it, pulls exact ECR digests, and starts
#   DevContainer + Squid.
#
# Logging:
#   Requires the Admin-prepared SYSTEM-owned Windows log root. Runtime containers
#   mount it read-only; a SYSTEM scheduled task exports Docker streams to it.
# =============================================================================
[CmdletBinding()]
param(
    [string]$SandboxDir = (Split-Path -Parent (Split-Path -Parent $PSScriptRoot))
)

$ErrorActionPreference = 'Stop'
$ComposeFile = Join-Path $SandboxDir 'docker-compose.yml'
$EnvFile = Join-Path $SandboxDir '.env'
$EnvTemplate = Join-Path $SandboxDir '.env.example'

function Read-KeyValueFile {
    param([Parameter(Mandatory = $true)][string]$Path)
    $Map = @{}
    Get-Content $Path | ForEach-Object {
        $Line = $_.TrimEnd("`r")
        if ($Line -and -not $Line.TrimStart().StartsWith('#')) {
            $Index = $Line.IndexOf('=')
            if ($Index -gt 0) {
                $Map[$Line.Substring(0, $Index).Trim()] = $Line.Substring($Index + 1).Trim()
            }
        }
    }
    return $Map
}

function Test-ConfiguredValue {
    param([string]$Value)
    return (
        -not [string]::IsNullOrWhiteSpace($Value) -and
        $Value -notmatch '[<>]' -and
        $Value -notlike '*REPLACE_*' -and
        $Value -ne 'yourname'
    )
}

if (-not (Test-Path $ComposeFile)) { throw "Missing $ComposeFile" }
if (-not (Test-Path $EnvFile)) {
    Copy-Item $EnvTemplate $EnvFile
    Write-Host "Created $EnvFile. Configure runtime values and rerun. AWS authentication is host-only via aws-azure-login; no static AWS keys are supported." -ForegroundColor Yellow
    exit 2
}

function Set-RuntimeEnvValue {
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][string]$Key,
        [Parameter(Mandatory = $true)][string]$Value
    )
    $Lines = [System.Collections.Generic.List[string]]::new()
    $Found = $false
    foreach ($Line in (Get-Content -LiteralPath $Path -Encoding UTF8)) {
        if ($Line -match ('^' + [regex]::Escape($Key) + '=')) {
            $Lines.Add("$Key=$Value")
            $Found = $true
        }
        else { $Lines.Add($Line) }
    }
    if (-not $Found) { $Lines.Add("$Key=$Value") }
    $Temp = "$Path.tmp.$([guid]::NewGuid().ToString('N'))"
    try {
        [IO.File]::WriteAllLines($Temp, $Lines, [Text.UTF8Encoding]::new($false))
        Move-Item -LiteralPath $Temp -Destination $Path -Force
    }
    finally {
        if (Test-Path -LiteralPath $Temp) { Remove-Item -LiteralPath $Temp -Force -ErrorAction SilentlyContinue }
    }
}


$ProtectedLogSystemSid = 'S-1-5-18'
$ProtectedLogWriteMask = [Security.AccessControl.FileSystemRights]::WriteData `
    -bor [Security.AccessControl.FileSystemRights]::AppendData `
    -bor [Security.AccessControl.FileSystemRights]::CreateDirectories `
    -bor [Security.AccessControl.FileSystemRights]::WriteAttributes `
    -bor [Security.AccessControl.FileSystemRights]::WriteExtendedAttributes `
    -bor [Security.AccessControl.FileSystemRights]::Delete `
    -bor [Security.AccessControl.FileSystemRights]::DeleteSubdirectoriesAndFiles `
    -bor [Security.AccessControl.FileSystemRights]::ChangePermissions `
    -bor [Security.AccessControl.FileSystemRights]::TakeOwnership

function Get-ProtectedLogRuleSid([Security.Principal.IdentityReference]$IdentityReference) {
    try { return $IdentityReference.Translate([Security.Principal.SecurityIdentifier]).Value }
    catch { return $IdentityReference.Value }
}

function Assert-ProtectedLogAcl([string]$Path) {
    $Acl = Get-Acl -LiteralPath $Path
    try { $OwnerSid = ([Security.Principal.NTAccount]::new($Acl.Owner)).Translate([Security.Principal.SecurityIdentifier]).Value }
    catch { $OwnerSid = $Acl.Owner }
    if ($OwnerSid -ne $ProtectedLogSystemSid -and $Acl.Owner -notmatch 'SYSTEM') {
        throw "Security check failed: protected log path '$Path' is not owned by LOCALSYSTEM."
    }
    foreach ($Rule in $Acl.Access) {
        if ($Rule.AccessControlType -ne [Security.AccessControl.AccessControlType]::Allow) { continue }
        $RuleSid = Get-ProtectedLogRuleSid -IdentityReference $Rule.IdentityReference
        if ((([int64]$Rule.FileSystemRights -band [int64]$ProtectedLogWriteMask) -ne 0) -and $RuleSid -ne $ProtectedLogSystemSid) {
            throw "Security check failed: non-SYSTEM principal '$($Rule.IdentityReference)' has write/modify/delete rights on protected log path '$Path'."
        }
    }
}

function Initialize-HostLogRoot {
    param(
        [hashtable]$Runtime,
        [Parameter(Mandatory = $true)][ValidateSet('poc','production')][string]$SandboxType
    )
    $PersistRoot = $false
    $RequestedMode = if (Test-ConfiguredValue $Runtime['SANDBOX_LOG_MODE']) { $Runtime['SANDBOX_LOG_MODE'].Trim().ToLowerInvariant() } else { 'auto' }
    if ($RequestedMode -notin @('auto','protected','poc-local')) {
        throw "SANDBOX_LOG_MODE must be 'auto', 'protected', or 'poc-local'. Current value: $RequestedMode"
    }
    if ($SandboxType -eq 'production' -and $RequestedMode -eq 'poc-local') {
        throw 'Production manifests require protected host logging; SANDBOX_LOG_MODE=poc-local is not permitted.'
    }
    $Mode = if ($RequestedMode -eq 'auto') {
        if ($SandboxType -eq 'poc') { 'poc-local' } else { 'protected' }
    }
    else { $RequestedMode }

    if (-not (Test-ConfiguredValue $Runtime['SANDBOX_LOG_ROOT'])) {
        if ($Mode -eq 'poc-local') {
            $Runtime['SANDBOX_LOG_ROOT'] = (Join-Path $env:USERPROFILE 'AI-Sandbox\Logs') -replace '\\','/'
            $PersistRoot = $true
        }
        else {
            throw 'SANDBOX_LOG_ROOT is missing or still a placeholder in .env. Ask the Sandbox Admin to run scripts\platform\03-setup-logging.ps1 first.'
        }
    }
    $LogRoot = [IO.Path]::GetFullPath($Runtime['SANDBOX_LOG_ROOT'].Replace('/', '\'))

    # The common template intentionally carries the Production protected path.
    # For a POC that resolves to poc-local, automatically move to a user-owned
    # path so an Administrator is not required merely to run the functional POC.
    if ($Mode -eq 'poc-local' -and $LogRoot.TrimEnd('\') -ieq 'C:\ProgramData\AI-Sandbox\Logs') {
        $LogRoot = Join-Path $env:USERPROFILE 'AI-Sandbox\Logs'
        $Runtime['SANDBOX_LOG_ROOT'] = $LogRoot -replace '\\','/'
        $PersistRoot = $true
        Write-Warning "POC local mode replaced the protected default log path with user-writable path: $LogRoot"
    }

    if ($Mode -eq 'poc-local') {
        foreach ($Path in @($LogRoot, (Join-Path $LogRoot 'devcontainer'), (Join-Path $LogRoot 'squid'), (Join-Path $LogRoot '.monitoring'))) {
            New-Item -ItemType Directory -Force -Path $Path | Out-Null
        }
        Write-Warning 'POC LOCAL LOG MODE: Windows host log files are writable by the current user. This mode is for non-admin POC testing only.'
        return @{ Mode = $Mode; RequestedMode = $RequestedMode; Root = $LogRoot; ComposeRoot = ($LogRoot -replace '\\','/'); PersistRoot = $PersistRoot }
    }

    if (-not (Test-Path -LiteralPath $LogRoot -PathType Container)) {
        throw "Protected host log root is missing: $LogRoot. Ask the Sandbox Admin to run scripts\platform\03-setup-logging.ps1."
    }
    Assert-ProtectedLogAcl -Path $LogRoot
    foreach ($Subdir in @('devcontainer','squid')) {
        $Path = Join-Path $LogRoot $Subdir
        if (-not (Test-Path -LiteralPath $Path -PathType Container)) {
            throw "Protected host log directory is missing: $Path. Ask the Sandbox Admin to run scripts\platform\03-setup-logging.ps1."
        }
        Assert-ProtectedLogAcl -Path $Path
        $Probe = Join-Path $Path ('.developer-write-probe-' + [guid]::NewGuid().ToString('N'))
        $Writable = $false
        try {
            [IO.File]::WriteAllText($Probe, 'probe', [Text.UTF8Encoding]::new($false))
            $Writable = $true
        }
        catch [UnauthorizedAccessException] { }
        catch [IO.IOException] { }
        finally {
            if (Test-Path -LiteralPath $Probe) { Remove-Item -LiteralPath $Probe -Force -ErrorAction SilentlyContinue }
        }
        if ($Writable) {
            throw "Security check failed: the current Windows user can write to protected log directory $Path. Re-apply the Admin/SYSTEM ACL with scripts\platform\03-setup-logging.ps1."
        }
    }
    return @{ Mode = $Mode; RequestedMode = $RequestedMode; Root = $LogRoot; ComposeRoot = ($LogRoot -replace '\\','/'); PersistRoot = $PersistRoot }
}

function Start-PocLocalLogExporter {
    param(
        [Parameter(Mandatory = $true)][string]$PackageRoot,
        [Parameter(Mandatory = $true)][hashtable]$HostLog
    )
    $Exporter = Join-Path $PackageRoot 'scripts\monitoring\export-docker-logs-to-host.ps1'
    $MonitorRoot = Join-Path $HostLog.Root '.monitoring'
    $StateFile = Join-Path $MonitorRoot 'host-log-export-state.json'
    $PidFile = Join-Path $MonitorRoot 'poc-log-exporter.pid'
    $StdoutFile = Join-Path $MonitorRoot 'poc-log-exporter.out.log'
    $StderrFile = Join-Path $MonitorRoot 'poc-log-exporter.err.log'

    # First pass is synchronous so launcher success means the host-log path and
    # Docker log API are both working before the Developer starts work.
    & pwsh -NoProfile -File $Exporter -LogMode PocLocal -ProjectName 'ai-secure-sandbox' -LogRoot $HostLog.Root -StateFile $StateFile
    if ($LASTEXITCODE -ne 0) { throw 'Initial POC local host-log export failed.' }

    if (Test-Path -LiteralPath $PidFile -PathType Leaf) {
        $ExistingPidText = [string](Get-Content -LiteralPath $PidFile -Raw -ErrorAction SilentlyContinue)
        $ExistingPidText = $ExistingPidText.Trim()
        $ExistingPid = 0
        if ([int]::TryParse($ExistingPidText, [ref]$ExistingPid)) {
            $ExistingProcess = Get-Process -Id $ExistingPid -ErrorAction SilentlyContinue
            if ($ExistingProcess -and $ExistingProcess.ProcessName -like 'pwsh*') {
                Write-Host "[OK] POC local log exporter is already running (PID $ExistingPid)." -ForegroundColor Yellow
                return
            }
        }
        Remove-Item -LiteralPath $PidFile -Force -ErrorAction SilentlyContinue
    }

    $Pwsh = (Get-Command pwsh -ErrorAction Stop).Source
    $Arguments = @(
        '-NoProfile',
        '-File', ('"{0}"' -f $Exporter),
        '-LogMode', 'PocLocal',
        '-ProjectName', 'ai-secure-sandbox',
        '-LogRoot', ('"{0}"' -f $HostLog.Root),
        '-StateFile', ('"{0}"' -f $StateFile),
        '-Continuous',
        '-IntervalSeconds', '30'
    ) -join ' '
    $Process = Start-Process -FilePath $Pwsh -ArgumentList $Arguments -WindowStyle Hidden -PassThru `
        -RedirectStandardOutput $StdoutFile -RedirectStandardError $StderrFile
    [IO.File]::WriteAllText($PidFile, [string]$Process.Id, [Text.ASCIIEncoding]::new())
    Write-Host "[OK] POC local log exporter started in the background (PID $($Process.Id), every 30 seconds)." -ForegroundColor Yellow
}

$Runtime = Read-KeyValueFile -Path $EnvFile
foreach ($Key in @('DEVELOPER_ID', 'ECR_REGISTRY')) {
    if (-not (Test-ConfiguredValue $Runtime[$Key])) {
        throw "$Key is missing or still a placeholder in .env"
    }
}

$Region = if ($Runtime.AWS_REGION) { $Runtime.AWS_REGION } else { 'eu-west-2' }
$Profile = if ($Runtime.SANDBOX_AWS_PROFILE) { $Runtime.SANDBOX_AWS_PROFILE } else { 'sandbox' }
$Prefix = if ($Runtime.SSM_PREFIX) { $Runtime.SSM_PREFIX.TrimEnd('/') } else { '/sandbox' }
$Registry = $Runtime.ECR_REGISTRY.TrimEnd('/')
$ManifestParameter = if ($Runtime.APPROVED_IMAGES_SSM_PARAMETER) {
    $Runtime.APPROVED_IMAGES_SSM_PARAMETER
}
else {
    "$Prefix/runtime/approved-images-json"
}

function Initialize-AwsAzureSamlProfile {
    param(
        [Parameter(Mandatory = $true)][hashtable]$Runtime,
        [Parameter(Mandatory = $true)][string]$Profile,
        [Parameter(Mandatory = $true)][string]$Region,
        [Parameter(Mandatory = $true)][string]$EnvFile
    )

    foreach ($LegacyKey in @('AWS_ACCESS_KEY_ID','AWS_SECRET_ACCESS_KEY','AWS_SESSION_TOKEN','AWS_SSO_SESSION','AWS_SSO_START_URL','AWS_SSO_REGION','AWS_SSO_ACCOUNT_ID','AWS_SSO_ROLE_NAME')) {
        if (Test-ConfiguredValue $Runtime[$LegacyKey]) {
            throw "Legacy/static AWS setting '$LegacyKey' is not supported in v1.16.34. Remove it from .env and use the Azure/Entra browser SAML settings."
        }
    }

    $Required = @(
        'AZURE_TENANT_ID',
        'AZURE_APP_ID_URI',
        'AZURE_DEFAULT_USERNAME',
        'AZURE_DEFAULT_ROLE_ARN',
        'AZURE_DEFAULT_DURATION_HOURS',
        'AZURE_DEFAULT_REMEMBER_ME'
    )
    $Missing = @($Required | Where-Object { -not (Test-ConfiguredValue $Runtime[$_]) })
    if ($Missing.Count) {
        throw "Azure/Entra AWS SAML settings are missing from .env: $($Missing -join ', ')"
    }
    if ($Runtime['AZURE_DEFAULT_ROLE_ARN'] -notmatch '^arn:[a-z0-9-]+:iam::[0-9]{12}:role/.+') {
        throw 'AZURE_DEFAULT_ROLE_ARN must be a complete AWS IAM role ARN.'
    }
    $Duration = 0
    if (-not [int]::TryParse($Runtime['AZURE_DEFAULT_DURATION_HOURS'], [ref]$Duration) -or $Duration -lt 1 -or $Duration -gt 12) {
        throw 'AZURE_DEFAULT_DURATION_HOURS must be an integer from 1 to 12.'
    }
    $Remember = $Runtime['AZURE_DEFAULT_REMEMBER_ME'].Trim().ToLowerInvariant()
    if ($Remember -notin @('true','false')) {
        throw 'AZURE_DEFAULT_REMEMBER_ME must be true or false.'
    }

    if (-not (Get-Command aws -ErrorAction SilentlyContinue)) {
        throw 'AWS CLI is not installed on the host.'
    }
    if (-not (Get-Command aws-azure-login -ErrorAction SilentlyContinue)) {
        throw 'aws-azure-login is not installed on the Windows host. Install the Admin-approved aws-azure-login package, then rerun this launcher.'
    }

    # v1.16.34 never accepts static AWS environment credentials. Explicitly
    # remove AWS provider overrides so host authentication is profile-only.
    foreach ($Name in @('AWS_ACCESS_KEY_ID','AWS_SECRET_ACCESS_KEY','AWS_SESSION_TOKEN','AWS_SECURITY_TOKEN','AWS_PROFILE','AWS_DEFAULT_PROFILE','AWS_CONFIG_FILE','AWS_SHARED_CREDENTIALS_FILE')) {
        Remove-Item "Env:$Name" -ErrorAction SilentlyContinue
    }

    $AwsDir = Join-Path $HOME '.aws'
    $Config = Join-Path $AwsDir 'config'
    New-Item -ItemType Directory -Force -Path $AwsDir | Out-Null

    # Replace only the managed target profile section. This also removes stale
    # native IAM Identity Center keys from a profile reused from v1.16.33.
    $SectionName = if ($Profile -eq 'default') { 'default' } else { "profile $Profile" }
    $ExistingLines = if (Test-Path -LiteralPath $Config) { @(Get-Content -LiteralPath $Config -Encoding UTF8) } else { @() }
    $Output = [System.Collections.Generic.List[string]]::new()
    $Skipping = $false
    foreach ($Line in $ExistingLines) {
        if ($Line -match '^\s*\[([^\]]+)\]\s*$') {
            $Skipping = ($matches[1].Trim() -eq $SectionName)
            if (-not $Skipping) { $Output.Add($Line) }
            continue
        }
        if (-not $Skipping) { $Output.Add($Line) }
    }
    while ($Output.Count -gt 0 -and [string]::IsNullOrWhiteSpace($Output[$Output.Count - 1])) { $Output.RemoveAt($Output.Count - 1) }
    if ($Output.Count -gt 0) { $Output.Add('') }
    $Output.Add("[$SectionName]")
    $Output.Add("azure_tenant_id=$($Runtime['AZURE_TENANT_ID'])")
    $Output.Add("azure_app_id_uri=$($Runtime['AZURE_APP_ID_URI'])")
    $Output.Add("azure_default_username=$($Runtime['AZURE_DEFAULT_USERNAME'])")
    $Output.Add("azure_default_role_arn=$($Runtime['AZURE_DEFAULT_ROLE_ARN'])")
    $Output.Add("azure_default_duration_hours=$Duration")
    $Output.Add("azure_default_remember_me=$Remember")
    $Output.Add("region=$Region")
    $Output.Add('output=json')
    [IO.File]::WriteAllLines($Config, $Output, [Text.UTF8Encoding]::new($false))

    # Only this non-secret host path is persisted. Compose mounts it read-only
    # into secret-broker; the AI devcontainer has no .aws mount.
    $ComposeAwsDir = ([IO.Path]::GetFullPath($AwsDir) -replace '\\','/')
    Set-RuntimeEnvValue -Path $EnvFile -Key 'SANDBOX_HOST_AWS_DIR' -Value $ComposeAwsDir
    $Runtime['SANDBOX_HOST_AWS_DIR'] = $ComposeAwsDir
    $env:SANDBOX_HOST_AWS_DIR = $ComposeAwsDir

    Write-Host "AWS authentication: Azure/Entra SAML profile '$Profile' on the Windows host." -ForegroundColor Cyan
    Write-Host "Host AWS directory will be mounted read-only into secret-broker only: $ComposeAwsDir" -ForegroundColor DarkGray
}

function Invoke-AwsAzureBrowserLogin {
    param([Parameter(Mandatory = $true)][string]$Profile)
    Write-Host "Opening Azure/Entra browser login for AWS profile '$Profile'..." -ForegroundColor Yellow
    & aws-azure-login --profile $Profile --mode gui
    if ($LASTEXITCODE -ne 0) {
        Write-Host 'GUI login failed once; retrying with GPU acceleration disabled for Windows 365 compatibility...' -ForegroundColor Yellow
        & aws-azure-login --profile $Profile --mode gui --disable-gpu
        if ($LASTEXITCODE -ne 0) { throw 'aws-azure-login browser authentication failed.' }
    }
}

function Ensure-AwsAzureSession {
    param([Parameter(Mandatory = $true)][string]$Profile)
    # Browser login is the single host authentication path. Do not add an STS
    # preflight: ECR/SSM operations below are the least-privilege authorization
    # checks for the capabilities this launcher actually requires.
    Invoke-AwsAzureBrowserLogin -Profile $Profile
    Write-Host "[OK] Azure/Entra browser authentication completed for host profile '$Profile'." -ForegroundColor Green
}

function Invoke-AwsCli {
    param([Parameter(Mandatory = $true)][string[]]$Arguments)
    & aws --profile $script:Profile @Arguments
}

# Runtime records are Docker-owned stdout/stderr first, then a SYSTEM host exporter copies them into the protected Windows log folder. Containers mount that folder read-only.

Initialize-AwsAzureSamlProfile -Runtime $Runtime -Profile $Profile -Region $Region -EnvFile $EnvFile
Ensure-AwsAzureSession -Profile $Profile

function Get-SsmValue {
    param([Parameter(Mandatory = $true)][string]$Name)
    $Value = @(Invoke-AwsCli -Arguments @(
        'ssm','get-parameter',
        '--name',$Name,
        '--region',$Region,
        '--query','Parameter.Value',
        '--output','text'
    ) 2>&1)
    if ($LASTEXITCODE -ne 0) {
        throw "Cannot read SSM parameter '$Name' with the host Azure/Entra AWS session. Re-run aws-azure-login --profile $Profile --mode gui if the session expired."
    }
    return (($Value | ForEach-Object { $_.ToString() }) -join "`n").Trim()
}

$ManifestJson = Get-SsmValue -Name $ManifestParameter
$ExpectedHash = (Get-SsmValue -Name "$ManifestParameter-sha256").ToLowerInvariant()
$Sha = [Security.Cryptography.SHA256]::Create()
try {
    $ActualHash = ([BitConverter]::ToString(
        $Sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($ManifestJson))
    )).Replace('-', '').ToLowerInvariant()
}
finally {
    $Sha.Dispose()
}
if ($ExpectedHash -ne $ActualHash) {
    throw 'Approved manifest SHA-256 validation failed'
}

$Manifest = $ManifestJson | ConvertFrom-Json
if ([string]$Manifest.registry -ne $Registry) { throw 'Manifest registry mismatch' }
$ManifestSandboxType=([string]$Manifest.sandboxType).ToLowerInvariant()
if($ManifestSandboxType -notin @('poc','production')){throw 'Approved manifest sandboxType must be poc or production.'}
if(([string]$Manifest.deploymentType).ToLowerInvariant() -ne 'ecr'){throw 'Approved manifest deploymentType must be ecr.'}
$HostLog = Initialize-HostLogRoot -Runtime $Runtime -SandboxType $ManifestSandboxType
if ($HostLog.PersistRoot) {
    Set-RuntimeEnvValue -Path $EnvFile -Key 'SANDBOX_LOG_ROOT' -Value $HostLog.ComposeRoot
    Write-Host "[OK] Persisted POC host log root in .env for future VS Code/Compose recreation: $($HostLog.ComposeRoot)" -ForegroundColor Yellow
}

function Assert-ApprovedImageReference {
    param([string]$Image, [string]$Repository)
    $Prefix = "$Registry/ai-sandbox/$Repository@sha256:"
    if (-not $Image.StartsWith($Prefix, [StringComparison]::Ordinal)) {
        throw "Invalid approved $Repository image reference"
    }
    $DigestHex = $Image.Substring($Prefix.Length)
    if ($DigestHex -notmatch '^[0-9a-f]{64}$') {
        throw "Invalid approved $Repository digest"
    }
}

$DevImage = [string]$Manifest.images.devcontainer.full
$SquidImage = [string]$Manifest.images.squid.full
Assert-ApprovedImageReference -Image $DevImage -Repository 'devcontainer'
Assert-ApprovedImageReference -Image $SquidImage -Repository 'squid'
Write-Host "Approved release: $($Manifest.releaseTag)" -ForegroundColor Green

$Password = Invoke-AwsCli -Arguments @('ecr','get-login-password','--region',$Region)
if ($LASTEXITCODE -ne 0) { throw 'Unable to obtain ECR login password' }
$Password | docker login --username AWS --password-stdin $Registry | Out-Null
if ($LASTEXITCODE -ne 0) { throw 'ECR login failed' }

$Images = @(
    @($DevImage, 'sandbox/approved-devcontainer:current'),
    @($SquidImage, 'sandbox/approved-squid:current')
)
foreach ($Pair in $Images) {
    & docker pull $Pair[0] | Out-Null
    if ($LASTEXITCODE -ne 0) { throw "Pull failed: $($Pair[0])" }
    & docker tag $Pair[0] $Pair[1]
    if ($LASTEXITCODE -ne 0) { throw "Local runtime tag failed: $($Pair[1])" }
}

$PreviousSandboxEnv=$env:SANDBOX_ENV
$PreviousLogRoot=$env:SANDBOX_LOG_ROOT
$PreviousHostAwsDir=$env:SANDBOX_HOST_AWS_DIR
try {
    $env:SANDBOX_ENV=$ManifestSandboxType
    $env:SANDBOX_LOG_ROOT=$HostLog.ComposeRoot
    $env:SANDBOX_HOST_AWS_DIR=$Runtime['SANDBOX_HOST_AWS_DIR']
    & docker compose --env-file $EnvFile -f $ComposeFile config | Out-Null
    if ($LASTEXITCODE -ne 0) { throw 'Compose validation failed' }
    & docker compose --env-file $EnvFile -f $ComposeFile up -d --force-recreate
    if ($LASTEXITCODE -ne 0) { throw 'Compose start failed' }
}
finally {
    if ($null -eq $PreviousSandboxEnv) { Remove-Item Env:SANDBOX_ENV -ErrorAction SilentlyContinue } else { $env:SANDBOX_ENV=$PreviousSandboxEnv }
    if ($null -eq $PreviousLogRoot) { Remove-Item Env:SANDBOX_LOG_ROOT -ErrorAction SilentlyContinue } else { $env:SANDBOX_LOG_ROOT=$PreviousLogRoot }
    if ($null -eq $PreviousHostAwsDir) { Remove-Item Env:SANDBOX_HOST_AWS_DIR -ErrorAction SilentlyContinue } else { $env:SANDBOX_HOST_AWS_DIR=$PreviousHostAwsDir }
}

Write-Host "[OK] Approved $ManifestSandboxType ECR sandbox started." -ForegroundColor Green
if ($HostLog.Mode -eq 'poc-local') {
    Start-PocLocalLogExporter -PackageRoot $Root -HostLog $HostLog
    Write-Warning "POC local logs are continuously exported to $($HostLog.Root), but the current Windows user can modify/delete those host files."
}
else {
    Write-Host "[OK] Runtime logs are Docker-owned streams and are exported by SYSTEM to $($Runtime['SANDBOX_LOG_ROOT'])." -ForegroundColor Green
}
