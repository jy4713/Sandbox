#Requires -Version 7.4
[CmdletBinding()] param([string]$Root = (Split-Path -Parent (Split-Path -Parent $PSScriptRoot)))
$ErrorActionPreference='Stop'; $failures=0
function Pass([string]$m){Write-Host "[OK]   $m" -ForegroundColor Green}
function Fail([string]$m){$script:failures++;Write-Host "[FAIL] $m" -ForegroundColor Red}
function Text([string]$p){Get-Content (Join-Path $Root $p) -Raw -Encoding UTF8}
function Has([string]$p,[string]$needle){(Text $p).Contains($needle)}
function NoMatch([string]$p,[string]$rx){(Text $p) -notmatch $rx}

$required=@('.env.example','.build.env.example','.devcontainer\Dockerfile','.devcontainer\scripts\secret-broker-client.py','.devcontainer\scripts\secret-broker-server.py','.devcontainer\scripts\provider-loopback-relay.py','.devcontainer\scripts\run-with-ssm-secrets.sh','.devcontainer\scripts\sandbox-command-wrapper.sh','tar\docker-compose.yml','ecr\docker-compose.yml','scripts\tar\load-and-start.ps1','scripts\ecr\pull-and-start.ps1')
foreach($f in $required){if(Test-Path(Join-Path $Root $f)){ }else{Fail "required file exists: $f"}}
foreach($k in 'AZURE_TENANT_ID','AZURE_APP_ID_URI','AZURE_DEFAULT_USERNAME','AZURE_DEFAULT_ROLE_ARN','AZURE_DEFAULT_DURATION_HOURS','AZURE_DEFAULT_REMEMBER_ME','SANDBOX_HOST_AWS_DIR'){if(-not(Has '.env.example' "$k=")){Fail ".env.example exposes required host Azure SAML field: $k"}}
if(NoMatch '.env.example' '(?m)^(AWS_ACCESS_KEY_ID|AWS_SECRET_ACCESS_KEY|AWS_SESSION_TOKEN|AWS_SSO_)='){Pass 'runtime template has no static/native-IAM-SSO credential fields'}else{Fail 'legacy AWS credential/Identity Center fields remain in runtime template'}
foreach($f in 'tar\docker-compose.yml','ecr\docker-compose.yml'){
 $t=Text $f
 if($t -match 'AWS_ACCESS_KEY_ID:|AWS_SECRET_ACCESS_KEY:|AWS_SESSION_TOKEN:|AWS_SSO_'){Fail "legacy AWS runtime mapping in $f"}
 if($t -notmatch 'AI_SANDBOX_ROLE: "client"'){Fail "AI client role missing in $f"}
 if($t -notmatch 'AI_SANDBOX_ROLE: "broker"'){Fail "broker role missing in $f"}
 if(([regex]::Matches($t,'target: /home/vscode/\.aws')).Count -ne 1){Fail "exactly one .aws mount required in $f"}
}
foreach($f in 'scripts\tar\load-and-start.ps1','scripts\ecr\pull-and-start.ps1'){
 if(-not(Has $f 'aws-azure-login --profile $Profile --mode gui')){Fail "browser aws-azure-login flow missing: $f"}
 if(-not(NoMatch $f 'aws sso login|UseStaticAws|sts get-caller-identity')){Fail "legacy AWS auth or STS preflight path remains: $f"}
}
if(-not(Has '.devcontainer\scripts\run-with-ssm-secrets.sh' 'AI_SANDBOX_ROLE:-}" == "broker"')){Fail 'SSM runner is not broker-only'}
if(-not(Has '.devcontainer\scripts\sandbox-command-wrapper.sh' 'ai-sandbox-broker-placeholder')){Fail 'AI provider wrapper dummy auth missing'}
if(-not(Has '.devcontainer\scripts\sandbox-command-wrapper.sh' '/databricks/anthropic')){Fail 'ucode Claude broker route missing'}
if(-not(Has '.devcontainer\scripts\sandbox-command-wrapper.sh' '/databricks/gemini')){Fail 'ucode Gemini broker route missing'}
if(-not(Has '.devcontainer\scripts\secret-broker-server.py' 'approved Databricks hostname')){Fail 'Databricks PAT route does not restrict upstream hostnames'}
if(-not(Has '.devcontainer\scripts\secret-broker-server.py' 'safe_route_suffix')){Fail 'provider broker path-traversal guard missing'}
if(-not(NoMatch '.devcontainer\scripts\sandbox-command-wrapper.sh' 'DATABRICKS_TOKEN=.*get_parameter|export DATABRICKS_TOKEN')){Fail 'ucode AI wrapper can receive Databricks PAT'}
if(-not(Has '.devcontainer\scripts\ado-git.sh' 'secret-broker-client --tool ado-git')){Fail 'ADO Git broker bridge missing'}
if(-not(NoMatch 'scripts\applications\application-helper.py' 'AWS_ACCESS_KEY_ID:|AWS_SECRET_ACCESS_KEY:|AWS_SESSION_TOKEN:')){Fail 'application helper can emit AWS credential env references'}

# Parse all PowerShell sources without executing them and report exact locations.
$parseErrors = @()
Get-ChildItem $Root -Recurse -File -Filter *.ps1 | ForEach-Object {
    $psFile = $_
    $tokens = $null
    $errors = $null
    [System.Management.Automation.Language.Parser]::ParseFile(
        $psFile.FullName,
        [ref]$tokens,
        [ref]$errors
    ) | Out-Null

    foreach ($parseError in @($errors)) {
        $parseErrors += [pscustomobject]@{
            File    = $psFile.FullName
            Line    = $parseError.Extent.StartLineNumber
            Column  = $parseError.Extent.StartColumnNumber
            Text    = $parseError.Extent.Text
            Message = $parseError.Message
        }
    }
}
if ($parseErrors.Count) {
    foreach ($parseError in $parseErrors) {
        Write-Host ("[PS PARSE] {0}:{1}:{2}" -f $parseError.File, $parseError.Line, $parseError.Column) -ForegroundColor Red
        Write-Host ("  {0}" -f $parseError.Message) -ForegroundColor Red
        if ($parseError.Text) { Write-Host ("  {0}" -f $parseError.Text) -ForegroundColor DarkRed }
    }
    Fail 'one or more PowerShell sources have parse errors'
}
else {
    Pass 'all PowerShell sources parse'
}

if($failures){throw "$failures lint check(s) failed"}
Pass 'package security/integration invariants hold'
