# =============================================================================
# PACKAGE MAINTENANCE NOTES (sourced fragment - not directly executable)
# Purpose: Establish the minimum deterministic environment every MCP stdio
#          wrapper needs, so an MCP client that passes a reduced or replaced
#          environment to its child cannot break credential resolution.
# Safety rule: This fragment must never contain, fetch or print a secret. It
#              sets non-secret locations and flags only.
# =============================================================================

# MCP servers speak JSON-RPC on stdout. Nothing here may write to stdout.
export SANDBOX_NONINTERACTIVE=1

# A stripped PATH would make application-audit / run-with-ssm-secrets / aws
# unresolvable and the server would exit before the handshake.
export PATH="/usr/local/bin:/usr/bin:/bin:/usr/local/sbin:/usr/sbin:/sbin${PATH:+:$PATH}"

# Broker-only AWS profile locations. The Windows host obtains a temporary AWS
# role session through Azure/Entra SAML using aws-azure-login. Only the trusted
# broker receives the host .aws directory; AI-side wrappers return before this
# fragment is sourced. No native IAM Identity Center cache is used here.
export SANDBOX_AWS_HOME="${SANDBOX_AWS_HOME:-/home/vscode}"
export AWS_CONFIG_FILE="${AWS_CONFIG_FILE:-$SANDBOX_AWS_HOME/.aws/config}"
export AWS_SHARED_CREDENTIALS_FILE="${AWS_SHARED_CREDENTIALS_FILE:-$SANDBOX_AWS_HOME/.aws/credentials}"
export AWS_REGION="${AWS_REGION:-eu-west-2}"
export SANDBOX_AWS_PROFILE="${SANDBOX_AWS_PROFILE:-sandbox}"
export SSM_PREFIX="${SSM_PREFIX:-/sandbox}"
export AWS_EC2_METADATA_DISABLED="true"

# Discard unexpanded placeholders inherited from a malformed MCP env block.
for _mcp_aws_var in AWS_ACCESS_KEY_ID AWS_SECRET_ACCESS_KEY AWS_SESSION_TOKEN AWS_SECURITY_TOKEN; do
  case "${!_mcp_aws_var:-}" in
    '$'*) unset "$_mcp_aws_var" ;;
    '')   unset "$_mcp_aws_var" ;;
  esac
done
unset _mcp_aws_var

# Egress is default-deny through Squid; a lost proxy variable looks like a hang.
if [[ -z "${HTTPS_PROXY:-}" && -n "${SANDBOX_HTTPS_PROXY:-}" ]]; then
  export HTTPS_PROXY="$SANDBOX_HTTPS_PROXY" HTTP_PROXY="$SANDBOX_HTTPS_PROXY"
  export https_proxy="$SANDBOX_HTTPS_PROXY" http_proxy="$SANDBOX_HTTPS_PROXY"
fi
if [[ -n "${HTTPS_PROXY:-}" ]]; then
  export NO_PROXY="${NO_PROXY:-localhost,127.0.0.1,squid-proxy}"
  export no_proxy="${no_proxy:-$NO_PROXY}"
fi
