#!/usr/bin/env bash
# Root-owned policy wrapper executed only inside the secret-broker container.
# It validates every credentialed Azure DevOps Git destination before the PAT is
# made available to git via GIT_ASKPASS.
set -euo pipefail
set +x

readonly REAL_GIT="/usr/bin/git"
[[ "${1:-}" == "$REAL_GIT" ]] || { echo 'ERROR: ADO Git policy requires the pinned git executable' >&2; exit 2; }
shift
(( $# > 0 )) || { echo 'ERROR: ADO Git operation is required' >&2; exit 2; }

: "${ADO_ORG:?ADO_ORG is required}"
: "${ADO_PROJECT:?ADO_PROJECT is required}"
: "${ADO_REPO:?ADO_REPO is required}"

op="$1"
case "$op" in clone|fetch|pull|push|ls-remote) ;;
  *) echo 'ERROR: ADO Git policy permits only clone/fetch/pull/push/ls-remote' >&2; exit 2 ;;
esac

approved_prefix="https://dev.azure.com/${ADO_ORG}/${ADO_PROJECT}/_git/${ADO_REPO}"

is_approved_url() {
  local url="${1%/}"
  [[ "$url" == "$approved_prefix" || "$url" == "$approved_prefix/"* ]]
}

# Reject dangerous process/config override options.  The caller cannot replace
# credential helpers, upload/receive-pack programs or the executable path.
for a in "$@"; do
  case "$a" in
    -c|--config-env|--exec-path|--upload-pack|--receive-pack|\
    -c=*|--config-env=*|--exec-path=*|--upload-pack=*|--receive-pack=*)
      echo 'ERROR: Git option is not approved by Sandbox policy' >&2; exit 2 ;;
  esac
done

case "$op" in
  clone|ls-remote)
    # Locate the first HTTPS argument and require the single configured repo.
    found=false
    for a in "${@:2}"; do
      if [[ "$a" == https://* ]]; then
        found=true
        is_approved_url "$a" || { echo 'ERROR: Azure DevOps URL is outside the Admin-approved repository' >&2; exit 2; }
      fi
    done
    [[ "$found" == true ]] || { echo 'ERROR: an explicit approved Azure DevOps HTTPS URL is required' >&2; exit 2; }
    ;;
  fetch|pull|push)
    # The workspace is writable by the Developer/agent, so .git/config is not a
    # trust boundary. Resolve the selected remote now and fail closed if it was
    # modified to another host/repository.
    remote="origin"
    if [[ "$op" == "push" || "$op" == "fetch" ]]; then
      candidate="${2:-}"
      if [[ -n "$candidate" && "$candidate" != -* && "$candidate" != */* && "$candidate" != *:* ]]; then
        remote="$candidate"
      fi
    fi
    url="$($REAL_GIT remote get-url "$remote" 2>/dev/null || true)"
    [[ -n "$url" ]] || { echo 'ERROR: cannot resolve the selected Git remote' >&2; exit 2; }
    is_approved_url "$url" || { echo 'ERROR: Git remote is outside the Admin-approved Azure DevOps repository' >&2; exit 2; }
    ;;
esac

exec "$REAL_GIT" -c core.hooksPath=/dev/null -c credential.helper= "$@"
