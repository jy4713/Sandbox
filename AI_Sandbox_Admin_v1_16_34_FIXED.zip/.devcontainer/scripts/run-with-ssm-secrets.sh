#!/usr/bin/env bash
# =============================================================================
# Broker-only SSM secret runner - AI Secure Sandbox v1.16.34
#
# This executable is present in the common runtime image, but it refuses to run
# unless AI_SANDBOX_ROLE=broker. The AI/devcontainer has no AWS profile mount,
# no AWS bootstrap environment variables and no supported path to invoke SSM.
#
# Secrets are injected only into pinned Admin-approved broker child processes.
# There is intentionally no generic "run any command with a secret" mode.
# =============================================================================
set -euo pipefail
set +x
umask 077

usage() {
  cat >&2 <<'USAGE'
Internal broker usage only:
  run-with-ssm-secrets --profile <ado|databricks-cli|databricks-sql-mcp|tavily|snyk|hiddenlayer> -- <approved command> [args...]
USAGE
  exit 2
}

[[ "${AI_SANDBOX_ROLE:-}" == "broker" ]] || {
  echo 'ERROR: SSM secret runner is broker-only; the AI container has no SSM credential path.' >&2
  exit 126
}
[[ "${1:-}" == "--profile" ]] || usage
profile="${2:-}"; [[ -n "$profile" ]] || usage
case "$profile" in ado|databricks-cli|databricks-sql-mcp|tavily|snyk|hiddenlayer) ;; *) usage ;; esac
shift 2; [[ "${1:-}" == "--" ]] || usage; shift
(( $# > 0 )) || usage

prefix="${SSM_PREFIX:-/sandbox}"
region="${AWS_REGION:-eu-west-2}"
aws_profile="${SANDBOX_AWS_PROFILE:-sandbox}"
AWS_STATE_HOME="${SANDBOX_AWS_HOME:-/home/vscode}"
export AWS_CONFIG_FILE="${AWS_CONFIG_FILE:-$AWS_STATE_HOME/.aws/config}"
export AWS_SHARED_CREDENTIALS_FILE="${AWS_SHARED_CREDENTIALS_FILE:-$AWS_STATE_HOME/.aws/credentials}"

# Static bootstrap credentials are forbidden in this release. Browser login on
# the host writes a temporary named profile; only the broker receives that
# profile directory as a read-only mount.
for v in AWS_ACCESS_KEY_ID AWS_SECRET_ACCESS_KEY AWS_SESSION_TOKEN AWS_SECURITY_TOKEN; do
  if [[ -n "${!v:-}" ]]; then
    echo "ERROR: static AWS environment credential '$v' is not supported in v1.16.34" >&2
    exit 1
  fi
done

command -v aws >/dev/null 2>&1 || { echo 'ERROR: aws CLI not found' >&2; exit 1; }
command -v application-audit >/dev/null 2>&1 || { echo 'ERROR: application-audit not found' >&2; exit 1; }

configured() { local v="${1:-}"; [[ -n "$v" && "$v" != *'<'* && "$v" != *'>'* && "$v" != *REPLACE_* ]]; }

audit_safe() {
  local app="$1" event="$2" operation="${3:-}" target="${4:-}" status="${5:-info}" exit_code="${6:-}" duration_ms="${7:-}" transport="${8:-}"
  local args=(--app "$app" --event "$event" --status "$status")
  [[ -n "$operation" ]] && args+=(--operation "$operation")
  [[ -n "$target" ]] && args+=(--target "$target")
  [[ -n "$exit_code" ]] && args+=(--exit-code "$exit_code")
  [[ -n "$duration_ms" ]] && args+=(--duration-ms "$duration_ms")
  [[ -n "$transport" ]] && args+=(--transport "$transport")
  application-audit "${args[@]}" || [[ "${SANDBOX_AUDIT_REQUIRED:-true}" != "true" ]]
}

aws_cli() {
  env -u AWS_ACCESS_KEY_ID -u AWS_SECRET_ACCESS_KEY -u AWS_SESSION_TOKEN -u AWS_SECURITY_TOKEN \
      -u AWS_PROFILE -u AWS_DEFAULT_PROFILE \
      HOME="$AWS_STATE_HOME" aws --profile "$aws_profile" "$@"
}

get_parameter() {
  local name="$1" value err
  err="$(mktemp "${TMPDIR:-/tmp}/ai-sandbox-ssm.XXXXXX")"
  if ! value="$(aws_cli ssm get-parameter --name "${prefix}/${name}" --with-decryption \
      --region "$region" --query 'Parameter.Value' --output text 2>"$err")"; then
    rm -f "$err"
    echo "ERROR: broker cannot read required SSM parameter for profile '$profile'." >&2
    echo "       Refresh the Windows host browser session with aws-azure-login --profile $aws_profile --mode gui, then recreate/restart the sandbox." >&2
    return 1
  fi
  rm -f "$err"
  [[ -n "$value" && "$value" != "None" ]] || { echo "ERROR: required SSM parameter is empty for profile '$profile'" >&2; return 1; }
  printf '%s' "$value"
}

run_logged() {
  local app="$1" operation="$2" target="$3" transport="$4"; shift 4
  local start_ms end_ms ec status
  start_ms="$(date +%s%3N)"
  audit_safe "$app" process_start "$operation" "$target" started "" "" "$transport"
  set +e; "$@"; ec=$?; set -e
  end_ms="$(date +%s%3N)"; status=success; (( ec == 0 )) || status=failure
  audit_safe "$app" process_end "$operation" "$target" "$status" "$ec" "$((end_ms-start_ms))" "$transport" || true
  return "$ec"
}

run_ephemeral_home() {
  local state="$1" app="$2" operation="$3" target="$4" transport="$5"; shift 5
  local h ec
  h="$(mktemp -d "/tmp/ai-sandbox-${state}.XXXXXX")"; chmod 0700 "$h"; mkdir -p "$h/.cache" "$h/.config"
  set +e
  run_logged "$app" "$operation" "$target" "$transport" env HOME="$h" XDG_CACHE_HOME="$h/.cache" XDG_CONFIG_HOME="$h/.config" "$@"
  ec=$?
  set -e
  rm -rf "$h"
  return "$ec"
}

run_snyk_home() {
  local app="$1" operation="$2" target="$3" transport="$4"; shift 4
  local root="/run/ai-sandbox-snyk" h ec
  [[ -d "$root" && -w "$root" ]] || { echo 'ERROR: Snyk runtime tmpfs unavailable' >&2; return 1; }
  h="$(mktemp -d "$root/home.XXXXXX")"; chmod 0700 "$h"; mkdir -p "$h/.cache" "$h/.config"
  if [[ -d /opt/snyk-cache ]]; then cp -a /opt/snyk-cache "$h/.cache/snyk" 2>/dev/null || true; chmod -R u+rwX "$h/.cache/snyk" 2>/dev/null || true; fi
  set +e
  run_logged "$app" "$operation" "$target" "$transport" env HOME="$h" XDG_CACHE_HOME="$h/.cache" XDG_CONFIG_HOME="$h/.config" "$@"
  ec=$?
  set -e
  rm -rf "$h"
  return "$ec"
}

# Remove AWS resolution hints from every secret-bearing child. The child is a
# pinned trusted integration process, never the AI agent itself.
strip_aws_child_env() {
  unset AWS_ACCESS_KEY_ID AWS_SECRET_ACCESS_KEY AWS_SESSION_TOKEN AWS_SECURITY_TOKEN AWS_PROFILE AWS_DEFAULT_PROFILE
  unset AWS_CONFIG_FILE AWS_SHARED_CREDENTIALS_FILE SANDBOX_AWS_HOME SANDBOX_AWS_PROFILE
}

case "$profile" in
  ado)
    readonly ado_git_policy="/usr/local/libexec/ai-sandbox/ado-git-policy"
    readonly real_git="/usr/bin/git"
    if [[ "$1" == "$ado_git_policy" ]]; then
      [[ $# -ge 3 && "$2" == "$real_git" ]] || { echo 'ERROR: invalid ADO Git broker path' >&2; exit 2; }
      operation="git-${3:-unknown}"
    elif [[ "$1" == "/usr/local/bin/ado-pr-create" ]]; then
      operation="pr-create"
    elif [[ "$1" == "/usr/local/bin/ado-trigger" ]]; then
      operation="pipeline-trigger"
    else
      echo 'ERROR: ADO SSM profile accepts only pinned broker operations' >&2; exit 2
    fi
    ADO_ORG="$(get_parameter ado-org)"; ADO_PROJECT="$(get_parameter ado-project)"; ADO_REPO="$(get_parameter ado-repo)"; ADO_PAT="$(get_parameter ado-pat)"
    export ADO_ORG ADO_PROJECT ADO_REPO ADO_PAT GIT_ASKPASS=/usr/local/bin/git-askpass-ado GIT_TERMINAL_PROMPT=0
    strip_aws_child_env
    audit_safe ado credential_fetch ssm_get_parameter aws-ssm success
    run_logged ado "$operation" azure-devops https "$@"
    ;;

  databricks-cli)
    readonly real_databricks="/usr/local/libexec/ai-sandbox/real/databricks"
    [[ "$1" == "$real_databricks" && $# -ge 3 ]] || { echo 'ERROR: Databricks CLI profile accepts only the pinned CLI' >&2; exit 2; }
    case "${2:-} ${3:-}" in
      'current-user me'|'warehouses list'|'clusters list') ;;
      *) echo 'ERROR: Databricks CLI command is not approved by Sandbox policy' >&2; exit 2 ;;
    esac
    configured "${DATABRICKS_HOST:-}" || { echo 'ERROR: DATABRICKS_HOST is not configured' >&2; exit 1; }
    [[ "$DATABRICKS_HOST" == https://* ]] || { echo 'ERROR: DATABRICKS_HOST must use https://' >&2; exit 1; }
    DATABRICKS_TOKEN="$(get_parameter databricks-token)"; export DATABRICKS_HOST DATABRICKS_TOKEN
    strip_aws_child_env
    audit_safe databricks credential_fetch ssm_get_parameter aws-ssm success
    run_ephemeral_home databricks-cli databricks cli workspace https "$@"
    ;;

  databricks-sql-mcp)
    readonly real_mcp_remote="/usr/local/libexec/ai-sandbox/real/mcp-remote"
    [[ "$1" == "$real_mcp_remote" && $# -eq 1 ]] || { echo 'ERROR: Databricks SQL MCP accepts only pinned mcp-remote' >&2; exit 2; }
    configured "${DATABRICKS_HOST:-}" || { echo 'ERROR: DATABRICKS_HOST is not configured' >&2; exit 1; }
    [[ "$DATABRICKS_HOST" == https://* ]] || { echo 'ERROR: DATABRICKS_HOST must use https://' >&2; exit 1; }
    DATABRICKS_SQL_MCP_TOKEN="$(get_parameter databricks-sql-mcp-token)"; export DATABRICKS_SQL_MCP_TOKEN
    strip_aws_child_env
    audit_safe databricks credential_fetch sql_mcp_ssm_get_parameter aws-ssm success
    url="${DATABRICKS_HOST%/}/api/2.0/mcp/sql"
    run_ephemeral_home databricks-sql-mcp databricks sql-mcp workspace stdio \
      "$real_mcp_remote" "$url" --header 'Authorization: Bearer ${DATABRICKS_SQL_MCP_TOKEN}' --silent --enable-proxy --transport http-only
    ;;

  tavily)
    readonly mcp_policy="/usr/local/libexec/ai-sandbox/tavily-policy-proxy.py"
    readonly cli_policy="/usr/local/libexec/ai-sandbox/tavily-cli-policy.py"
    readonly real_mcp="/usr/local/libexec/ai-sandbox/real/tavily-mcp"
    readonly real_tvly="/usr/local/libexec/ai-sandbox/real/tvly"
    if [[ "$1" == "$mcp_policy" ]]; then
      [[ $# -eq 2 && "$2" == "$real_mcp" ]] || { echo 'ERROR: invalid Tavily MCP broker path' >&2; exit 2; }
      operation=mcp; transport=stdio
    elif [[ "$1" == "$cli_policy" ]]; then
      [[ $# -ge 3 && "$2" == "$real_tvly" ]] || { echo 'ERROR: invalid Tavily CLI broker path' >&2; exit 2; }
      operation="${3:-cli}"; transport=https
    else
      echo 'ERROR: Tavily SSM profile accepts only Admin policy wrappers' >&2; exit 2
    fi
    unset DEFAULT_PARAMETERS
    TAVILY_API_KEY="$(get_parameter tavily-api-key)"; export TAVILY_API_KEY
    strip_aws_child_env
    audit_safe tavily credential_fetch ssm_get_parameter aws-ssm success
    run_ephemeral_home tavily tavily "$operation" tavily "$transport" "$@"
    ;;

  snyk)
    readonly real_snyk="/usr/local/libexec/ai-sandbox/real/snyk"
    [[ "$1" == "$real_snyk" ]] || { echo 'ERROR: Snyk profile accepts only the pinned Snyk CLI' >&2; exit 2; }
    first="${2:-}"; second="${3:-}"
    case "$first" in
      mcp) [[ "$second" == '-t' || "$second" == '--transport' ]] || { echo 'ERROR: invalid Snyk MCP broker arguments' >&2; exit 2; }; operation=mcp; transport=stdio ;;
      test|monitor) operation="$first"; transport=https ;;
      code|iac|container) [[ "$second" == test || "$second" == monitor ]] || { echo 'ERROR: Snyk command not approved' >&2; exit 2; }; operation="$first-$second"; transport=https ;;
      *) echo 'ERROR: Snyk command not approved by Sandbox policy' >&2; exit 2 ;;
    esac
    for a in "$@"; do [[ "$a" != '--debug' && "$a" != '-d' && "$a" != --debug=* ]] || { echo 'ERROR: Snyk debug output is disabled' >&2; exit 2; }; done
    SNYK_TOKEN="$(get_parameter snyk-token)"; export SNYK_TOKEN
    configured "${SNYK_API:-}" && export SNYK_API || true
    strip_aws_child_env
    audit_safe snyk credential_fetch ssm_get_parameter aws-ssm success
    run_snyk_home snyk "$operation" snyk "$transport" "$@"
    ;;

  hiddenlayer)
    readonly hl="/opt/company/bin/hiddenlayer-client"
    [[ "$1" == "$hl" ]] || { echo 'ERROR: HiddenLayer profile accepts only the pinned client' >&2; exit 2; }
    configured "${HIDDENLAYER_API_URL:-}" || { echo 'ERROR: HIDDENLAYER_API_URL is not configured' >&2; exit 1; }
    HIDDENLAYER_CLIENT_ID="$(get_parameter hiddenlayer-client-id)"; HIDDENLAYER_CLIENT_SECRET="$(get_parameter hiddenlayer-client-secret)"
    export HIDDENLAYER_API_URL HIDDENLAYER_CLIENT_ID HIDDENLAYER_CLIENT_SECRET
    strip_aws_child_env
    audit_safe hiddenlayer credential_fetch ssm_get_parameter aws-ssm success
    run_logged hiddenlayer client hiddenlayer https "$@"
    ;;
esac
