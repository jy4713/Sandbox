#!/usr/bin/env bash
set -euo pipefail
set +x

profile="${SANDBOX_AWS_PROFILE:-sandbox}"
region="${AWS_REGION:-eu-west-2}"

# AWS CLI v2 stores the IAM Identity Center token cache under ~/.aws/sso/cache,
# resolved from HOME. Pin HOME to the persistent sandbox AWS state directory so
# a sign-in performed from any context (including a short-lived ucode HOME) is
# written where every later process will look for it.
AWS_STATE_HOME="${SANDBOX_AWS_HOME:-/home/vscode}"
export HOME="$AWS_STATE_HOME"
export AWS_CONFIG_FILE="${AWS_CONFIG_FILE:-$AWS_STATE_HOME/.aws/config}"
export AWS_SHARED_CREDENTIALS_FILE="${AWS_SHARED_CREDENTIALS_FILE:-$AWS_STATE_HOME/.aws/credentials}"
credentials_file="$AWS_SHARED_CREDENTIALS_FILE"

# Discard unexpanded placeholders so credential-mode selection stays correct.
for _v in AWS_ACCESS_KEY_ID AWS_SECRET_ACCESS_KEY AWS_SESSION_TOKEN; do
  case "${!_v:-}" in '$'*) unset "$_v" ;; '') unset "$_v" ;; esac
done
unset _v

access_key="${AWS_ACCESS_KEY_ID:-}"
secret_key="${AWS_SECRET_ACCESS_KEY:-}"
session_token="${AWS_SESSION_TOKEN:-}"

if [[ -n "$access_key" || -n "$secret_key" || -n "$session_token" ]]; then
  if [[ -z "$access_key" || -z "$secret_key" ]]; then
    cat >&2 <<MSG
ERROR: Static AWS authentication is partially configured.
AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY must be supplied together.
AWS_SESSION_TOKEN is optional and may only be used with the complete key pair.
MSG
    exit 1
  fi
  if command -v configure-aws-sso >/dev/null 2>&1; then
    configure-aws-sso >/dev/null || {
      echo 'ERROR: could not prepare the non-secret AWS CLI compatibility profile for static credential mode.' >&2
      exit 1
    }
  fi
  if env -u AWS_PROFILE -u AWS_DEFAULT_PROFILE aws sts get-caller-identity --region "$region" >/dev/null 2>&1; then
    echo '[AWS AUTH] Static AWS environment credentials are valid. SSO login is not required.'
    exit 0
  fi
  cat >&2 <<MSG
ERROR: AWS_ACCESS_KEY_ID/AWS_SECRET_ACCESS_KEY are configured but STS validation failed.
Static credentials have priority, so the Sandbox will not silently fall back to SSO.
Correct/remove the static credentials and try again.
MSG
  exit 1
fi

if [[ -f "$credentials_file" ]] && grep -Eq '^[[:space:]]*(aws_access_key_id|aws_secret_access_key)[[:space:]]*=' "$credentials_file"; then
  cat >&2 <<MSG
ERROR: Static AWS access keys were found in $credentials_file.
Credential files containing static AWS keys are not used by this Sandbox.
Provide the approved key pair through the runtime environment/.env, or use the browser SSO flow.
MSG
  exit 1
fi

if command -v configure-aws-sso >/dev/null 2>&1; then
  if ! configure-aws-sso >/dev/null; then
    cat >&2 <<MSG
ERROR: The '$profile' SSO profile cannot be generated yet.
Ask the Sandbox Admin to preconfigure these NON-SECRET runtime values in the Developer package:
  AWS_SSO_START_URL
  AWS_SSO_REGION
  AWS_SSO_ACCOUNT_ID
  AWS_SSO_ROLE_NAME
Developers should not need to run 'aws configure sso' manually.
MSG
    exit 1
  fi
fi

if aws sts get-caller-identity --profile "$profile" --region "$region" >/dev/null 2>&1; then
  echo "[AWS SSO] Existing session for profile '$profile' is valid."
  exit 0
fi

# Refuse device-code sign-in where there is no terminal to display it. An MCP
# stdio server would otherwise corrupt its JSON-RPC channel and hang.
if [[ "${SANDBOX_NONINTERACTIVE:-0}" == "1" ]] || [[ ! -t 0 ]]; then
  cat >&2 <<'MSG'
ERROR: An AWS IAM Identity Center sign-in is required, but this process has no
       interactive terminal (non-interactive / MCP stdio context).
       Run `sandbox-aws-login` from a VS Code terminal instead.
MSG
  exit 1
fi

# Serialise concurrent sign-in attempts. An agent and its Tavily/Snyk MCP
# servers can detect expiry at the same moment; without a lock they would race
# on ~/.aws/sso/cache and show the developer several device codes at once.
mkdir -p "$AWS_STATE_HOME/.aws"
exec 9>"$AWS_STATE_HOME/.aws/.sso-login.lock"
if ! flock -w 300 9; then
  echo '[AWS SSO] Timed out waiting for a concurrent sign-in to finish.' >&2
  exit 1
fi
# Re-check under the lock: another process may have completed sign-in already.
if aws sts get-caller-identity --profile "$profile" --region "$region" >/dev/null 2>&1; then
  echo "[AWS SSO] Session for profile '$profile' was refreshed by a concurrent process."
  exit 0
fi

cat <<MSG
============================================================
 AWS Sandbox Browser Sign-In
============================================================
No valid AWS SSO session is available for profile '$profile'.

The AWS CLI will display a verification URL and a one-time code.
Open/click that URL from the VS Code terminal on the WINDOWS HOST,
then complete your normal company SSO/MFA in Edge or Chrome.

No static AWS key pair was supplied, so IAM Identity Center is being used.
============================================================
MSG

# Device authorization is intentionally used because the browser is on the
# Windows host while the AWS CLI runs inside the Linux DevContainer.
aws sso login --profile "$profile" --use-device-code --no-browser

if ! aws sts get-caller-identity --profile "$profile" --region "$region" >/dev/null 2>&1; then
  echo '[AWS SSO] Login completed but AWS identity validation failed.' >&2
  exit 1
fi

echo "[AWS SSO] Login successful for profile '$profile'."
