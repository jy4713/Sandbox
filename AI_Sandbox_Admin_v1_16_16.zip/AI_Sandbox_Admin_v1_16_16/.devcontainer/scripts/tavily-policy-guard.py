#!/usr/bin/env python3
"""Claude PreToolUse defense-in-depth guard for Tavily MCP calls.

The hard enforcement point is the root-owned Tavily MCP policy proxy. This hook
provides an earlier, clearer denial in Claude Code and uses the same policy file.
"""

import json
import re
import sys
from pathlib import Path
from urllib.parse import urlparse

POLICY = Path("/etc/ai-sandbox/tavily-allowed-domains.json")

try:
    allowed = tuple(json.loads(POLICY.read_text(encoding="utf-8"))["allowed_domains"])
except Exception:
    allowed = tuple()


def host(value):
    if not isinstance(value, str):
        return ""
    v = value.strip().lower()
    if v.startswith("*."):
        v = v[2:]
    if "://" in v:
        return (urlparse(v).hostname or "").lower().rstrip(".")
    return v.split("/", 1)[0].split(":", 1)[0].rstrip(".")


def ok(h):
    return bool(allowed) and any(h == a or h.endswith("." + a) for a in allowed)


def deny(reason):
    print(json.dumps({"hookSpecificOutput": {
        "hookEventName": "PreToolUse",
        "permissionDecision": "deny",
        "permissionDecisionReason": reason,
    }}))
    raise SystemExit(0)


data = json.load(sys.stdin)
tool = data.get("tool_name", "")
args = data.get("tool_input", {}) or {}

if tool.endswith("tavily_search"):
    requested = args.get("include_domains")
    if requested:
        if not isinstance(requested, list) or any(not ok(host(d)) for d in requested):
            deny("Admin Tavily policy: include_domains contains a non-approved domain.")
elif tool.endswith("tavily_extract"):
    urls = args.get("urls") or []
    if not isinstance(urls, list) or any(urlparse(u).scheme != "https" or not ok(host(u)) for u in urls if isinstance(u, str)):
        deny("Admin Tavily policy: extract is limited to approved HTTPS domains.")
elif tool.endswith("tavily_crawl") or tool.endswith("tavily_map"):
    u = args.get("url", "")
    if urlparse(u).scheme != "https" or not ok(host(u)):
        deny("Admin Tavily policy: crawl/map is limited to approved HTTPS domains.")
elif tool.endswith("tavily_research"):
    deny("Admin Tavily policy: unconstrained Tavily research is disabled because it cannot be domain-restricted.")

print(json.dumps({}))
