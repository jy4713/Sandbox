#!/usr/bin/env bash
set -euo pipefail
umask 077

profile="${SANDBOX_AWS_PROFILE:-sandbox}"
session="${AWS_SSO_SESSION:-$profile}"
start_url="${AWS_SSO_START_URL:-}"
sso_region="${AWS_SSO_REGION:-}"
account_id="${AWS_SSO_ACCOUNT_ID:-}"
role_name="${AWS_SSO_ROLE_NAME:-}"
client_region="${AWS_REGION:-eu-west-2}"
# Pin AWS CLI state to the persistent sandbox anchor rather than $HOME. ucode,
# Tavily and Snyk all execute under short-lived HOME directories, and the
# generated profile must remain the one every later process reads.
aws_state_home="${SANDBOX_AWS_HOME:-/home/vscode}"
config_file="${AWS_CONFIG_FILE:-$aws_state_home/.aws/config}"
for _v in AWS_ACCESS_KEY_ID AWS_SECRET_ACCESS_KEY AWS_SESSION_TOKEN; do
  case "${!_v:-}" in '$'*) unset "$_v" ;; esac
done
unset _v
access_key="${AWS_ACCESS_KEY_ID:-}"
secret_key="${AWS_SECRET_ACCESS_KEY:-}"
session_token="${AWS_SESSION_TOKEN:-}"

[[ "$profile" =~ ^[A-Za-z0-9._-]+$ ]] || { echo '[AWS AUTH] SANDBOX_AWS_PROFILE contains unsupported characters.' >&2; exit 2; }
[[ "$session" =~ ^[A-Za-z0-9._-]+$ ]] || { echo '[AWS AUTH] AWS_SSO_SESSION contains unsupported characters.' >&2; exit 2; }

profile_header() {
  if [[ "$profile" == "default" ]]; then
    printf '[default]'
  else
    printf '[profile %s]' "$profile"
  fi
}

default_profile_header() {
  printf '[default]'
}

prepare_config() {
  mkdir -p "$(dirname "$config_file")"
  touch "$config_file"
  chmod 600 "$config_file"
}

strip_managed_blocks() {
  local source="$1" target="$2"
  awk '
    /^# BEGIN AI-SANDBOX MANAGED SSO$/ {skip=1; next}
    /^# END AI-SANDBOX MANAGED SSO$/   {skip=0; next}
    /^# BEGIN AI-SANDBOX MANAGED AWS PROFILE$/ {skip=1; next}
    /^# END AI-SANDBOX MANAGED AWS PROFILE$/   {skip=0; next}
    !skip {print}
  ' "$source" > "$target"
}

write_static_profile_stub() {
  local tmp
  prepare_config
  tmp="$(mktemp)"
  trap 'rm -f "$tmp"' EXIT
  strip_managed_blocks "$config_file" "$tmp"
  cat >> "$tmp" <<CFG
# BEGIN AI-SANDBOX MANAGED AWS PROFILE
# Non-secret compatibility profile for static environment credentials.
# AWS_ACCESS_KEY_ID/AWS_SECRET_ACCESS_KEY remain environment credentials and
# take precedence; no static credential value is persisted in this file.
$(default_profile_header)
region = $client_region
output = json
$(if [[ "$profile" != "default" ]]; then printf '
[profile %s]
region = %s
output = json
' "$profile" "$client_region"; fi)
# END AI-SANDBOX MANAGED AWS PROFILE
CFG
  mv "$tmp" "$config_file"
  chmod 600 "$config_file"
  trap - EXIT
}

write_sso_profile() {
  local tmp
  prepare_config
  tmp="$(mktemp)"
  trap 'rm -f "$tmp"' EXIT
  strip_managed_blocks "$config_file" "$tmp"
  cat >> "$tmp" <<CFG
# BEGIN AI-SANDBOX MANAGED AWS PROFILE
# Non-secret IAM Identity Center fallback profile generated from Admin-approved runtime settings.
[sso-session $session]
sso_start_url = $start_url
sso_region = $sso_region
sso_registration_scopes = sso:account:access

$(default_profile_header)
sso_session = $session
sso_account_id = $account_id
sso_role_name = $role_name
region = $client_region
output = json
$(if [[ "$profile" != "default" ]]; then printf '
[profile %s]
sso_session = %s
sso_account_id = %s
sso_role_name = %s
region = %s
output = json
' "$profile" "$session" "$account_id" "$role_name" "$client_region"; fi)
# END AI-SANDBOX MANAGED AWS PROFILE
CFG
  mv "$tmp" "$config_file"
  chmod 600 "$config_file"
  trap - EXIT
}

if [[ -n "$access_key" || -n "$secret_key" || -n "$session_token" ]]; then
  if [[ -z "$access_key" || -z "$secret_key" ]]; then
    echo '[AWS AUTH] AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY must be configured together.' >&2
    exit 2
  fi
  write_static_profile_stub
  echo "[AWS AUTH] Static AWS environment credentials selected. Created non-secret default/profile configuration for AWS CLI compatibility; no key value was persisted."
  exit 0
fi

configured() {
  local v="${1:-}"
  [[ -n "$v" && "$v" != *'<'* && "$v" != *'>'* && "$v" != *REPLACE_* ]]
}

missing=()
configured "$start_url" || missing+=(AWS_SSO_START_URL)
configured "$sso_region" || missing+=(AWS_SSO_REGION)
configured "$account_id" || missing+=(AWS_SSO_ACCOUNT_ID)
configured "$role_name" || missing+=(AWS_SSO_ROLE_NAME)

if ((${#missing[@]})); then
  echo "[AWS SSO] Profile '$profile' was not generated because Admin SSO bootstrap values are incomplete." >&2
  printf '[AWS SSO] Missing: %s\n' "${missing[*]}" >&2
  exit 2
fi

[[ "$start_url" == https://* ]] || { echo '[AWS SSO] AWS_SSO_START_URL must use https://' >&2; exit 2; }
[[ "$account_id" =~ ^[0-9]{12}$ ]] || { echo '[AWS SSO] AWS_SSO_ACCOUNT_ID must be a 12-digit AWS account ID.' >&2; exit 2; }

write_sso_profile
echo "[AWS SSO] Configured non-secret AWS CLI profile '$profile' in $config_file"
