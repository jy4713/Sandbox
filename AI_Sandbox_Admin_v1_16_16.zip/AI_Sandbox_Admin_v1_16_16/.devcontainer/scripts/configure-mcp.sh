#!/usr/bin/env bash
# =============================================================================
# Purpose: Credential-value-free MCP registration for Claude Code and Gemini CLI.
#          Tavily, Snyk, and Databricks SQL credentials are fetched from SSM only
#          when their Admin-managed MCP child process starts.
# =============================================================================
set -euo pipefail
umask 077

export CLAUDE_CONFIG_DIR="${CLAUDE_CONFIG_DIR:-$HOME/.claude}"
export DISABLE_AUTOUPDATER=1
export CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC=1

readonly REAL_DIR="/usr/local/libexec/ai-sandbox/real"
readonly REAL_CLAUDE="$REAL_DIR/claude"
readonly REAL_GEMINI="$REAL_DIR/gemini"
[[ -x "$REAL_CLAUDE" ]] || { echo 'ERROR: real Claude CLI is missing' >&2; exit 1; }
[[ -x "$REAL_GEMINI" ]] || { echo 'ERROR: real Gemini CLI is missing' >&2; exit 1; }
command -v jq >/dev/null 2>&1 || { echo 'ERROR: jq is required for MCP configuration' >&2; exit 1; }

gemini_state_home="${GEMINI_CLI_HOME:-$HOME}"
gemini_config_dir="$gemini_state_home/.gemini"
gemini_settings="$gemini_config_dir/settings.json"
mkdir -p "$CLAUDE_CONFIG_DIR" "$gemini_config_dir"

readonly TAVILY_MCP_TIMEOUT_MS=120000
readonly SNYK_MCP_TIMEOUT_MS=180000
readonly DATABRICKS_SQL_MCP_TIMEOUT_MS=180000

# Claude Code passes runtime AWS bootstrap state to stdio children. No service
# credential is stored in the MCP registration.
"$REAL_CLAUDE" mcp remove tavily --scope user >/dev/null 2>&1 || true
"$REAL_CLAUDE" mcp add-json tavily '{"type":"stdio","command":"/usr/local/bin/tavily-mcp-ssm","args":[]}' --scope user >/dev/null

"$REAL_CLAUDE" mcp remove snyk --scope user >/dev/null 2>&1 || true
"$REAL_CLAUDE" mcp add-json snyk '{"type":"stdio","command":"/usr/local/bin/snyk-mcp-ssm","args":[]}' --scope user >/dev/null

"$REAL_CLAUDE" mcp remove databricks-sql --scope user >/dev/null 2>&1 || true
"$REAL_CLAUDE" mcp add-json databricks-sql '{"type":"stdio","command":"/usr/local/bin/databricks-sql-mcp-ssm","args":[]}' --scope user >/dev/null

# Gemini CLI may sanitize inherited sensitive variables for MCP children. Keep
# only literal runtime references to the AWS bootstrap variables in settings;
# these are references, never credential values.
if [[ ! -s "$gemini_settings" ]]; then
  printf '%s\n' '{}' > "$gemini_settings"
elif ! jq -e . "$gemini_settings" >/dev/null 2>&1; then
  invalid_backup="${gemini_settings}.invalid.$(date +%Y%m%d%H%M%S)"
  cp -p "$gemini_settings" "$invalid_backup" 2>/dev/null || true
  printf '%s\n' '{}' > "$gemini_settings"
  echo "WARN: invalid Gemini settings were backed up to $invalid_backup and reset" >&2
fi

gemini_tmp="$(mktemp "${TMPDIR:-/tmp}/gemini-settings.XXXXXX")"
trap 'rm -f "$gemini_tmp"' EXIT
jq \
  --argjson tavily_timeout "$TAVILY_MCP_TIMEOUT_MS" \
  --argjson snyk_timeout "$SNYK_MCP_TIMEOUT_MS" \
  --argjson databricks_sql_timeout "$DATABRICKS_SQL_MCP_TIMEOUT_MS" '
  def aws_runtime_refs: {
    AWS_ACCESS_KEY_ID: "$AWS_ACCESS_KEY_ID",
    AWS_SECRET_ACCESS_KEY: "$AWS_SECRET_ACCESS_KEY",
    AWS_SESSION_TOKEN: "$AWS_SESSION_TOKEN"
  };
  .mcpServers = ((.mcpServers // {}) + {
    tavily: {
      command: "/usr/local/bin/tavily-mcp-ssm",
      args: [],
      timeout: $tavily_timeout,
      env: aws_runtime_refs
    },
    snyk: {
      command: "/usr/local/bin/snyk-mcp-ssm",
      args: [],
      timeout: $snyk_timeout,
      env: aws_runtime_refs
    },
    "databricks-sql": {
      command: "/usr/local/bin/databricks-sql-mcp-ssm",
      args: [],
      timeout: $databricks_sql_timeout,
      env: aws_runtime_refs
    }
  })
' "$gemini_settings" > "$gemini_tmp"

jq -e . "$gemini_tmp" >/dev/null || { echo 'ERROR: generated Gemini settings are not valid JSON' >&2; exit 1; }
mv "$gemini_tmp" "$gemini_settings"
trap - EXIT
chmod 0600 "$gemini_settings"

if ! jq -e '
  def refs: {
    AWS_ACCESS_KEY_ID: "$AWS_ACCESS_KEY_ID",
    AWS_SECRET_ACCESS_KEY: "$AWS_SECRET_ACCESS_KEY",
    AWS_SESSION_TOKEN: "$AWS_SESSION_TOKEN"
  };
  (.mcpServers.tavily.env == refs) and
  (.mcpServers.snyk.env == refs) and
  (.mcpServers["databricks-sql"].env == refs)
' "$gemini_settings" >/dev/null; then
  echo 'ERROR: managed Gemini MCP env must contain only approved AWS runtime references' >&2
  exit 1
fi

if grep -Eq '(AKIA|ASIA)[A-Z0-9]{16}' "$gemini_settings"; then
  echo 'ERROR: AWS access-key credential material detected in Gemini MCP settings' >&2
  exit 1
fi

chmod -R go-rwx "$CLAUDE_CONFIG_DIR" "$gemini_config_dir" 2>/dev/null || true
printf '[OK] Tavily/Snyk/Databricks SQL MCP configured for Claude and Gemini (state root: %s; credential values not persisted).\n' "$gemini_state_home"
