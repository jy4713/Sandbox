#!/usr/bin/env python3
"""Fail-closed MCP stdio proxy enforcing the Admin Tavily domain policy.

The proxy sits between Claude/Gemini and the real Tavily MCP process. It parses
client -> server JSON-RPC messages and applies the root-owned allowlist before a
tool call reaches Tavily. No prompt/query/result content is logged.
"""

from __future__ import annotations

import json
import os
import re
import subprocess
import sys
from pathlib import Path
from urllib.parse import urlparse

POLICY_PATH = Path(os.environ.get("TAVILY_POLICY_FILE", "/etc/ai-sandbox/tavily-allowed-domains.json"))


def fail(message: str) -> None:
    print(f"ERROR: {message}", file=sys.stderr)
    raise SystemExit(1)


def load_allowed_domains() -> tuple[str, ...]:
    try:
        data = json.loads(POLICY_PATH.read_text(encoding="utf-8"))
    except Exception as exc:  # fail closed
        fail(f"cannot load Tavily policy: {exc}")
    raw = data.get("allowed_domains")
    if not isinstance(raw, list) or not raw:
        fail("Tavily policy contains no allowed_domains")
    out: list[str] = []
    for item in raw:
        if not isinstance(item, str):
            fail("Tavily policy contains a non-string domain")
        d = item.strip().lower().rstrip(".")
        if not re.fullmatch(r"[a-z0-9.-]+", d) or ".." in d or d.startswith("-"):
            fail("Tavily policy contains an invalid domain")
        out.append(d)
    return tuple(dict.fromkeys(out))


ALLOWED = load_allowed_domains()


def hostname_from_domain(value: str) -> str:
    value = value.strip().lower()
    if value.startswith("*."):
        value = value[2:]
    if "://" in value:
        parsed = urlparse(value)
        return (parsed.hostname or "").lower().rstrip(".")
    value = value.split("/", 1)[0]
    value = value.split(":", 1)[0]
    return value.rstrip(".")


def is_allowed_host(host: str) -> bool:
    host = host.lower().rstrip(".")
    return any(host == allowed or host.endswith("." + allowed) for allowed in ALLOWED)


def validate_domain_list(values: object) -> tuple[list[str], list[str]]:
    if not isinstance(values, list):
        return [], ["<invalid include_domains type>"]
    good: list[str] = []
    bad: list[str] = []
    for item in values:
        if not isinstance(item, str):
            bad.append("<non-string domain>")
            continue
        host = hostname_from_domain(item)
        if host and is_allowed_host(host):
            good.append(host)
        else:
            bad.append(item)
    return list(dict.fromkeys(good)), bad


def validate_url(value: object) -> tuple[bool, str]:
    if not isinstance(value, str):
        return False, "<non-string URL>"
    parsed = urlparse(value)
    host = (parsed.hostname or "").lower().rstrip(".")
    if parsed.scheme != "https" or not host or not is_allowed_host(host):
        return False, value
    return True, host


def denial(request_id: object, reason: str) -> dict:
    return {
        "jsonrpc": "2.0",
        "id": request_id,
        "error": {
            "code": -32001,
            "message": "Tavily request denied by Admin domain policy",
            "data": {
                "reason": reason,
                "allowed_domains": list(ALLOWED),
            },
        },
    }


def enforce_tool_call(message: dict) -> tuple[dict | None, dict | None]:
    if message.get("method") != "tools/call":
        return message, None
    params = message.get("params")
    if not isinstance(params, dict):
        return message, None
    name = params.get("name")
    arguments = params.get("arguments")
    if not isinstance(arguments, dict):
        arguments = {}
        params["arguments"] = arguments

    if name == "tavily_search":
        requested = arguments.get("include_domains")
        if requested in (None, []):
            # Safe default: a search without a site constraint is restricted to
            # the full Admin allowlist, never the public web.
            arguments["include_domains"] = list(ALLOWED)
            return message, None
        approved, rejected = validate_domain_list(requested)
        if rejected or not approved:
            return None, denial(message.get("id"), "include_domains contains a domain outside the Admin allowlist")
        arguments["include_domains"] = approved
        return message, None

    if name == "tavily_extract":
        urls = arguments.get("urls")
        if not isinstance(urls, list) or not urls:
            return None, denial(message.get("id"), "extract requires one or more approved HTTPS URLs")
        rejected = [u for u in urls if not validate_url(u)[0]]
        if rejected:
            return None, denial(message.get("id"), "extract URL is outside the Admin allowlist")
        return message, None

    if name in {"tavily_crawl", "tavily_map"}:
        ok, host_or_value = validate_url(arguments.get("url"))
        if not ok:
            return None, denial(message.get("id"), "crawl/map root URL is outside the Admin allowlist")
        # Prevent following external destinations even when the model asks for it.
        arguments["allow_external"] = False
        arguments["select_domains"] = [rf"^{re.escape(host_or_value)}$"]
        return message, None

    if name == "tavily_research":
        # This tool has no domain constraint, so it cannot satisfy an allowlist
        # guarantee. Fail closed rather than allowing an unconstrained search.
        return None, denial(message.get("id"), "tavily_research has no domain constraint and is disabled by policy")

    return message, None


def main() -> int:
    if len(sys.argv) < 2:
        fail("usage: tavily-policy-proxy.py <real-tavily-mcp> [args...]")
    real = sys.argv[1:]
    child = subprocess.Popen(
        real,
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=None,
        env=os.environ.copy(),
        bufsize=0,
    )
    assert child.stdin is not None
    assert child.stdout is not None

    import threading

    def server_to_client() -> None:
        try:
            for raw in iter(child.stdout.readline, b""):
                sys.stdout.buffer.write(raw)
                sys.stdout.buffer.flush()
        finally:
            try:
                sys.stdout.buffer.flush()
            except Exception:
                pass

    relay = threading.Thread(target=server_to_client, name="tavily-mcp-relay", daemon=True)
    relay.start()

    try:
        for raw in iter(sys.stdin.buffer.readline, b""):
            outbound = raw
            try:
                msg = json.loads(raw.decode("utf-8"))
                if isinstance(msg, dict):
                    allowed_msg, denied_msg = enforce_tool_call(msg)
                    if denied_msg is not None:
                        # MCP requests normally carry an id. For a notification,
                        # fail closed by dropping it without emitting an invalid
                        # response frame.
                        if denied_msg.get("id") is not None:
                            sys.stdout.write(json.dumps(denied_msg, separators=(",", ":")) + "\n")
                            sys.stdout.flush()
                        continue
                    if allowed_msg is not None:
                        outbound = (json.dumps(allowed_msg, separators=(",", ":")) + "\n").encode("utf-8")
            except Exception:
                # Non-JSON lines are passed through unchanged so protocol-version
                # changes fail at the real MCP server instead of being corrupted.
                outbound = raw
            try:
                child.stdin.write(outbound)
                child.stdin.flush()
            except BrokenPipeError:
                break
    finally:
        try:
            child.stdin.close()
        except Exception:
            pass
    return child.wait()


if __name__ == "__main__":
    raise SystemExit(main())
