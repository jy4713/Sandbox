# Microsoft Sentinel integration - v1.16.35

The Windows 365 host keeps protected log files specifically so the approved Windows monitoring agent can collect them for Microsoft Sentinel.

Runtime flow:

```text
DevContainer/Squid stdout+stderr
  -> Docker local logging
  -> LOCALSYSTEM scheduled exporter
  -> C:\ProgramData\AI-Sandbox\Logs\devcontainer\*.log
     C:\ProgramData\AI-Sandbox\Logs\squid\*.log
  -> Windows monitoring agent / DCR
  -> Log Analytics / Microsoft Sentinel
```

Run `scripts\platform\03-setup-logging.ps1` elevated before a Developer starts the Sandbox. It creates the SYSTEM-owned protected log tree and installs `AI-Sandbox-Protected-Log-Export` as a LOCALSYSTEM scheduled task.

Normal Developers receive read-only Windows ACL access. The same folders are mounted into the runtime containers read-only, so a Developer cannot manually edit or delete the host audit, application, content, or Squid access logs from Linux or Windows through the supported runtime path.

Configure collection for:

```text
C:\ProgramData\AI-Sandbox\Logs\devcontainer\*.log
C:\ProgramData\AI-Sandbox\Logs\squid\*.log
```

`detection-rules.kql` is a reference detection/query starting point. The Windows file-collection DCR/AMA configuration is intentionally client-specific and is not shipped as a generic Direct Logs Ingestion API template.

A local Windows Administrator can ultimately take ownership/reset local ACLs or stop local components. Therefore endpoint-local files are not an administrator-proof archive. If audit evidence must survive endpoint/platform administrator actions, treat the Sentinel copy as authoritative and use immutable/WORM retention with separation of duties where required.
