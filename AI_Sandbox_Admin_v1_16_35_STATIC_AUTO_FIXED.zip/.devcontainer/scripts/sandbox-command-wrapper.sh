#!/usr/bin/env bash
# =============================================================================
# AI Secure Sandbox credential-isolated command shim.
# v1.16.35 security model:
#   * The AI/devcontainer never receives AWS credentials or an AWS profile.
#   * Direct Claude/Gemini calls use the internal provider proxy. Only a fixed,
#     non-secret placeholder is visible to the AI process; the real API key is
#     injected by the secret-broker from SSM.
#   * Tavily, Snyk, Databricks CLI and MCP operations are executed by the
#     secret-broker and only their I/O is relayed.
#   * `ucode claude` / `ucode gemini` retain the Developer command contract,
#     but do NOT use upstream ucode PAT injection at runtime. They launch the
#     approved agent through a brokered Databricks AI Gateway route; the PAT
#     exists only in the secret-broker.
# =============================================================================
set -euo pipefail
set +x
umask 027

readonly REAL_DIR="/usr/local/libexec/ai-sandbox/real"
readonly BROKER_CLIENT="/usr/local/bin/secret-broker-client"
readonly PROVIDER_BASE="${SANDBOX_PROVIDER_LOOPBACK_URL:-http://127.0.0.1:8771}"
tool="$(basename -- "$0")"

fail() { echo "ERROR: $*" >&2; exit 1; }
real_tool() { printf '%s/%s' "$REAL_DIR" "$1"; }

is_local_only_operation() {
  local t="$1" first="${2:-}"
  case "$first" in --help|-h|help|--version|-v|version) return 0 ;; esac
  case "$t:$first" in claude:mcp|gemini:mcp|ucode:status) return 0 ;; esac
  return 1
}

strip_aws() {
  unset AWS_ACCESS_KEY_ID AWS_SECRET_ACCESS_KEY AWS_SESSION_TOKEN AWS_SECURITY_TOKEN
  unset AWS_PROFILE AWS_DEFAULT_PROFILE AWS_CONFIG_FILE AWS_SHARED_CREDENTIALS_FILE SANDBOX_AWS_HOME SANDBOX_AWS_PROFILE
  unset AWS_CONTAINER_CREDENTIALS_RELATIVE_URI AWS_CONTAINER_CREDENTIALS_FULL_URI
  unset AWS_CONTAINER_AUTHORIZATION_TOKEN AWS_CONTAINER_AUTHORIZATION_TOKEN_FILE
  unset AWS_WEB_IDENTITY_TOKEN_FILE AWS_ROLE_ARN AWS_ROLE_SESSION_NAME AWS_CREDENTIAL_EXPIRATION
}

run_audited() {
  local app="$1" operation="$2" target="$3" transport="$4"; shift 4
  local start_ms end_ms ec status
  start_ms="$(date +%s%3N)"
  application-audit --app "$app" --event process_start --operation "$operation" --target "$target" --status started --transport "$transport" || true
  set +e
  "$@"
  ec=$?
  set -e
  end_ms="$(date +%s%3N)"
  status=success; (( ec == 0 )) || status=failure
  application-audit --app "$app" --event process_end --operation "$operation" --target "$target" --status "$status" --exit-code "$ec" --duration-ms "$((end_ms-start_ms))" --transport "$transport" || true
  return "$ec"
}

strip_aws

case "$tool" in
  claude)
    [[ -x "$(real_tool claude)" ]] || fail "real claude executable is missing"
    if is_local_only_operation "$tool" "${1:-}"; then exec "$(real_tool claude)" "$@"; fi
    [[ -r /etc/claude-code/managed-mcp.json ]] || fail "Admin Claude managed MCP config is missing"
    export ANTHROPIC_BASE_URL="${PROVIDER_BASE}/anthropic"
    export ENABLE_TOOL_SEARCH="true"
    export ANTHROPIC_API_KEY="ai-sandbox-broker-placeholder"
    export ANTHROPIC_AUTH_TOKEN=""
    export ANTHROPIC_CUSTOM_HEADERS=""
    export CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC=1 DISABLE_AUTOUPDATER=1
    unset CLAUDE_CODE_USE_BEDROCK CLAUDE_CODE_USE_VERTEX CLAUDE_CODE_USE_FOUNDRY
    export SANDBOX_AI_ROUTE="brokered-anthropic"
    run_audited anthropic claude-direct api.anthropic.com https "$(real_tool claude)" "$@"
    ;;

  gemini)
    [[ -x "$(real_tool gemini)" ]] || fail "real gemini executable is missing"
    if is_local_only_operation "$tool" "${1:-}"; then exec "$(real_tool gemini)" "$@"; fi
    export GOOGLE_GEMINI_BASE_URL="${PROVIDER_BASE}/gemini"
    export GEMINI_API_KEY="ai-sandbox-broker-placeholder"
    export GOOGLE_API_KEY=""
    export GOOGLE_GENAI_USE_VERTEXAI="false" GOOGLE_GENAI_USE_GCA="false"
    export GOOGLE_CLOUD_PROJECT="" GOOGLE_CLOUD_PROJECT_ID="" GOOGLE_CLOUD_LOCATION=""
    export SANDBOX_AI_ROUTE="brokered-gemini"
    run_audited gemini gemini-direct generativelanguage.googleapis.com https "$(real_tool gemini)" "$@"
    ;;

  ucode)
    [[ -x "$(real_tool ucode)" ]] || fail "real ucode executable is missing"
    case "${1:-}" in
      --help|-h|help|--version|-v|version) exec "$(real_tool ucode)" "$@" ;;
      status)
        cat <<EOF
AI Secure Sandbox Databricks route (credential-isolated)
  Workspace: ${DATABRICKS_HOST:-not-configured}
  Claude model: ${DATABRICKS_CLAUDE_MODEL:-not-configured}
  Gemini model: ${DATABRICKS_GEMINI_MODEL:-not-configured}
  Authentication: SSM PAT in secret-broker only (not exposed to AI process)
  Runtime: brokered Databricks AI Gateway compatibility route
EOF
        exit 0
        ;;
    esac
    agent="${1:-}"
    [[ "$agent" == "claude" || "$agent" == "gemini" ]] || fail "credential-isolated ucode supports only 'ucode claude' and 'ucode gemini'"
    shift
    [[ -n "${DATABRICKS_HOST:-}" && "${DATABRICKS_HOST}" == https://* ]] || fail "DATABRICKS_HOST must be configured with https://"

    has_model_arg=false
    for a in "$@"; do [[ "$a" == "--model" || "$a" == "-m" || "$a" == --model=* ]] && has_model_arg=true; done

    if [[ "$agent" == "claude" ]]; then
      model="${DATABRICKS_CLAUDE_MODEL:-}"
      [[ -n "$model" ]] || fail "DATABRICKS_CLAUDE_MODEL is required for 'ucode claude'"
      [[ -r /etc/claude-code/managed-mcp.json ]] || fail "Admin Claude managed MCP config is missing"
      export ANTHROPIC_BASE_URL="${PROVIDER_BASE}/databricks/anthropic"
      export ANTHROPIC_AUTH_TOKEN="ai-sandbox-broker-placeholder"
      export ANTHROPIC_API_KEY="" OAUTH_TOKEN=""
      export ANTHROPIC_MODEL="$model" CLAUDE_CODE_USE_GATEWAY="1" ENABLE_TOOL_SEARCH="true"
      export ANTHROPIC_CUSTOM_HEADERS=""
      export CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC=1 DISABLE_AUTOUPDATER=1
      unset CLAUDE_CODE_USE_BEDROCK CLAUDE_CODE_USE_VERTEX CLAUDE_CODE_USE_FOUNDRY
      export SANDBOX_AI_ROUTE="brokered-databricks-claude"
      if [[ "$has_model_arg" == false ]]; then set -- --model "$model" "$@"; fi
      run_audited databricks ucode-claude "$model" https "$(real_tool claude)" "$@"
    else
      model="${DATABRICKS_GEMINI_MODEL:-}"
      [[ -n "$model" ]] || fail "DATABRICKS_GEMINI_MODEL is required for 'ucode gemini'"
      export GOOGLE_GEMINI_BASE_URL="${PROVIDER_BASE}/databricks/gemini"
      export GEMINI_API_KEY="ai-sandbox-broker-placeholder" GEMINI_API_KEY_AUTH_MECHANISM="bearer"
      export GEMINI_MODEL="$model" GEMINI_CLI_TRUST_WORKSPACE="true"
      export GOOGLE_API_KEY="" OAUTH_TOKEN=""
      export GOOGLE_GENAI_USE_VERTEXAI="false" GOOGLE_GENAI_USE_GCA="false"
      export GOOGLE_CLOUD_PROJECT="" GOOGLE_CLOUD_PROJECT_ID="" GOOGLE_CLOUD_LOCATION=""
      export SANDBOX_AI_ROUTE="brokered-databricks-gemini"
      if [[ "$has_model_arg" == false ]]; then set -- --model "$model" "$@"; fi
      run_audited databricks ucode-gemini "$model" https "$(real_tool gemini)" "$@"
    fi
    ;;

  databricks)
    [[ -x "$(real_tool databricks)" ]] || fail "real databricks executable is missing"
    if is_local_only_operation "$tool" "${1:-}"; then exec "$(real_tool databricks)" "$@"; fi
    exec "$BROKER_CLIENT" --tool databricks-cli "$@"
    ;;

  tvly)
    [[ -x "$(real_tool tvly)" ]] || fail "real tvly executable is missing"
    if is_local_only_operation "$tool" "${1:-}"; then exec "$(real_tool tvly)" "$@"; fi
    exec "$BROKER_CLIENT" --tool tavily-cli "$@"
    ;;

  tavily-mcp)
    exec /usr/local/bin/tavily-mcp-ssm "$@"
    ;;

  snyk)
    [[ -x "$(real_tool snyk)" ]] || fail "real snyk executable is missing"
    if is_local_only_operation "$tool" "${1:-}"; then exec "$(real_tool snyk)" "$@"; fi
    if [[ "${1:-}" == "mcp" ]]; then shift; exec /usr/local/bin/snyk-mcp-ssm "$@"; fi
    exec "$BROKER_CLIENT" --tool snyk-cli "$@"
    ;;

  *) fail "unsupported sandbox command wrapper name: $tool" ;;
esac
