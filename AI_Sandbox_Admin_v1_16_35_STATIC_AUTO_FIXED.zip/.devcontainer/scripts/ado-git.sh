#!/usr/bin/env bash
# AI-facing Azure DevOps Git bridge. No ADO PAT exists in this container.
set -euo pipefail
set +x
exec /usr/local/bin/secret-broker-client --tool ado-git "$@"
