#!/usr/bin/env python3
"""Secret-isolating broker for the AI Secure Sandbox.

Security boundary:
* The broker container is the only runtime container that receives the host
  AWS host profile containing either an approved static test key pair or browser-based SAML credentials.
* The AI/devcontainer receives no .aws mount, AWS access key environment
  variables, SSO token cache, or ssm:GetParameter-capable credential.
* The TCP control protocol exposes only fixed Admin-approved operations.  It
  never has an operation that returns a secret value.
* Provider HTTP proxy routes replace client-supplied/dummy authentication with
  SSM-backed credentials inside this process and stream only provider results.

No prompts, source, queries, results or secret values are logged by this file.
"""
from __future__ import annotations

import argparse
import http.server
import json
import os
import selectors
import signal
import socket
import socketserver
import struct
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Iterable

MAX_CONTROL = 64 * 1024
BROKER_HOST = os.environ.get("SANDBOX_SECRET_BROKER_LISTEN", "0.0.0.0")
BROKER_PORT = int(os.environ.get("SANDBOX_SECRET_BROKER_PORT", "8765"))
HTTP_PORT = int(os.environ.get("SANDBOX_SECRET_BROKER_HTTP_PORT", "8770"))
WORKSPACE = Path(os.environ.get("SANDBOX_BROKER_WORKSPACE", "/home/vscode/workspace")).resolve()
AWS_HOME = os.environ.get("SANDBOX_AWS_HOME", "/home/vscode")
AWS_PROFILE = os.environ.get("SANDBOX_AWS_PROFILE", "sandbox")
AWS_REGION = os.environ.get("AWS_REGION", "eu-west-2")
SSM_PREFIX = os.environ.get("SSM_PREFIX", "/sandbox").rstrip("/")
def validate_databricks_host(raw: str) -> str:
    """Return a canonical Admin-configured Databricks HTTPS origin.

    The broker injects a real Databricks PAT on this route, so a Developer-
    editable environment value must never be able to redirect that credential
    to an arbitrary Internet host.  Standard AWS/Azure Databricks hostnames,
    including PrivateLink subdomains, are accepted.
    """
    raw = raw.strip().rstrip("/")
    if not raw:
        return ""
    parsed = urllib.parse.urlsplit(raw)
    if parsed.scheme.lower() != "https" or not parsed.hostname:
        raise RuntimeError("DATABRICKS_HOST must be an https:// Databricks origin")
    if parsed.username or parsed.password or parsed.query or parsed.fragment:
        raise RuntimeError("DATABRICKS_HOST must not contain userinfo, query or fragment")
    if parsed.path not in {"", "/"}:
        raise RuntimeError("DATABRICKS_HOST must not contain a path")
    try:
        port = parsed.port
    except ValueError as exc:
        raise RuntimeError("DATABRICKS_HOST contains an invalid port") from exc
    if port not in {None, 443}:
        raise RuntimeError("DATABRICKS_HOST must use HTTPS port 443")
    host = parsed.hostname.rstrip(".").lower()
    allowed_suffixes = (".databricks.com", ".azuredatabricks.net", ".databricks.net")
    if not any(host == suffix[1:] or host.endswith(suffix) for suffix in allowed_suffixes):
        raise RuntimeError("DATABRICKS_HOST is not an approved Databricks hostname")
    return f"https://{host}"


def safe_route_suffix(path: str, prefix: str) -> str:
    """Reject path traversal before joining a caller path to a privileged origin."""
    suffix = path[len(prefix):] or "/"
    probe = suffix
    for _ in range(3):
        decoded = urllib.parse.unquote(probe)
        normalized = decoded.replace("\\", "/")
        if any(seg in {".", ".."} for seg in normalized.split("/")):
            raise ValueError("provider route path traversal is not allowed")
        if any(ch in decoded for ch in ("\x00", "\r", "\n")):
            raise ValueError("provider route contains invalid control characters")
        if decoded == probe:
            break
        probe = decoded
    return suffix


DATABRICKS_HOST = validate_databricks_host(os.environ.get("DATABRICKS_HOST", ""))

REAL = "/usr/local/libexec/ai-sandbox/real"
RUNNER = "/usr/local/bin/run-with-ssm-secrets"
POLICY_TAVILY = "/usr/local/libexec/ai-sandbox/tavily-cli-policy.py"
ADO_GIT_POLICY = "/usr/local/libexec/ai-sandbox/ado-git-policy"


def log_event(message: str) -> None:
    # Metadata only; never include request args or secret material.
    print(f"[secret-broker] {message}", file=sys.stderr, flush=True)


def recv_exact(sock: socket.socket, n: int) -> bytes:
    chunks: list[bytes] = []
    left = n
    while left:
        b = sock.recv(left)
        if not b:
            raise RuntimeError("connection closed during control header")
        chunks.append(b)
        left -= len(b)
    return b"".join(chunks)


def control_reply(sock: socket.socket, ok: bool, message: str = "") -> None:
    raw = message.encode("utf-8", "replace")[:MAX_CONTROL]
    sock.sendall((b"\x00" if ok else b"\x01") + struct.pack("!I", len(raw)) + raw)


def map_cwd(value: object) -> str:
    # Both containers mount the same workspace at the same canonical path.
    # Anything outside the workspace is intentionally collapsed to the root.
    if not isinstance(value, str):
        return str(WORKSPACE)
    try:
        p = Path(value).resolve()
        p.relative_to(WORKSPACE)
        return str(p)
    except Exception:
        return str(WORKSPACE)


def reject_bad_args(args: object) -> list[str]:
    if not isinstance(args, list) or any(not isinstance(x, str) for x in args):
        raise ValueError("arguments must be a string array")
    if len(args) > 128 or sum(len(x) for x in args) > 32768:
        raise ValueError("argument list exceeds broker limits")
    if any("\x00" in x or "\r" in x or "\n" in x for x in args):
        raise ValueError("arguments contain invalid control characters")
    return list(args)


def validate_snyk_cli(args: list[str]) -> None:
    if not args:
        raise ValueError("Snyk broker requires an approved scan command")
    forbidden_network = ("--api", "--endpoint", "--proxy", "--token", "--auth")
    for a in args:
        low = a.lower()
        if low in {"--debug", "-d"} or low.startswith("--debug="):
            raise ValueError("Snyk debug output is disabled by Sandbox policy")
        if any(low == p or low.startswith(p + "=") for p in forbidden_network):
            raise ValueError("Snyk network/authentication override is disabled by Sandbox policy")
        # The broker has privileged runtime state outside the shared workspace.
        # Absolute scan paths are allowed only when they resolve inside the
        # shared workspace; parent traversal is always rejected.
        value = a.split("=", 1)[1] if "=" in a and a.startswith("--") else a
        if value.startswith(("~/", "../")) or "/../" in value or value.endswith("/.."):
            raise ValueError("Snyk paths must remain inside the shared workspace")
        if value.startswith("/"):
            try:
                Path(value).resolve().relative_to(WORKSPACE)
            except Exception as exc:
                raise ValueError("Snyk absolute paths must remain inside the shared workspace") from exc
    first = args[0]
    if first == "test":
        return
    if first == "monitor":
        return
    if first in {"code", "iac", "container"} and len(args) >= 2 and args[1] in {"test", "monitor"}:
        return
    raise ValueError("Snyk command is not approved by Sandbox policy")


def validate_tavily_cli(args: list[str]) -> None:
    if not args:
        raise ValueError("Tavily CLI requires a command")
    if args[0] not in {"search", "extract", "crawl", "map"}:
        raise ValueError("Tavily CLI command is not approved by Sandbox policy")


def validate_databricks_cli(args: list[str]) -> None:
    if not args:
        raise ValueError("Databricks CLI command is required")
    allowed = {
        ("current-user", "me"),
        ("warehouses", "list"),
        ("clusters", "list"),
    }
    pair = tuple(args[:2])
    if pair not in allowed:
        raise ValueError("Databricks CLI command is not approved by Sandbox policy")
    if any(a in {"--debug", "--log-level", "--profile", "--token"} or a.startswith(("--profile=", "--token=", "--log-level=")) for a in args):
        raise ValueError("Databricks CLI option is not approved by Sandbox policy")


def validate_ado_git(args: list[str]) -> None:
    if not args or args[0] not in {"clone", "fetch", "pull", "push", "ls-remote"}:
        raise ValueError("ADO Git broker permits only clone/fetch/pull/push/ls-remote")
    # Caller-controlled Git execution/configuration overrides and recursive
    # submodule network operations are forbidden. Exact repo URL validation is
    # repeated by the broker-side ado-git-policy after SSM metadata is loaded.
    forbidden_prefixes = (
        "-c", "--config-env", "--exec-path", "--upload-pack", "--receive-pack",
        "--git-dir", "--work-tree", "--namespace", "--recurse-submodules",
        "--force", "-f", "--force-with-lease", "--force-if-includes", "--mirror",
        "--all", "--delete", "--prune",
    )
    for a in args:
        low = a.lower()
        if any(low == p or low.startswith(p + "=") for p in forbidden_prefixes):
            raise ValueError("Git option is not approved by Sandbox policy")
        if "ext::" in low or low.startswith(("file://", "ssh://", "git://")):
            raise ValueError("Non-HTTPS Git transport is not approved by Sandbox policy")




def validate_ado_pr(args: list[str]) -> None:
    forbidden = {"--org", "--project", "--repo", "--auth"}
    for i, a in enumerate(args):
        if a in forbidden or any(a.startswith(x + "=") for x in forbidden):
            raise ValueError("ADO PR org/project/repo/auth are Admin-managed and cannot be overridden")


def validate_ado_trigger(args: list[str]) -> None:
    pipeline_id: str | None = None
    i = 0
    while i < len(args):
        a = args[i]
        if a in {"--org", "--project", "--auth"} or any(a.startswith(x + "=") for x in {"--org", "--project", "--auth"}):
            raise ValueError("ADO pipeline org/project/auth are Admin-managed and cannot be overridden")
        if a == "--wait":
            i += 1
            continue
        if a in {"--pipeline-id", "--branch", "--params"}:
            if i + 1 >= len(args):
                raise ValueError(f"{a} requires a value")
            value = args[i + 1]
            if a == "--pipeline-id":
                pipeline_id = value
                if not value.isdigit() or int(value) <= 0:
                    raise ValueError("ADO pipeline id must be a positive integer")
            elif a == "--params":
                try:
                    decoded = json.loads(value)
                except json.JSONDecodeError as exc:
                    raise ValueError("ADO pipeline params must be valid JSON") from exc
                if not isinstance(decoded, dict):
                    raise ValueError("ADO pipeline params must be a JSON object")
            elif not value.strip():
                raise ValueError("ADO branch cannot be empty")
            i += 2
            continue
        raise ValueError("ADO pipeline argument is not approved by Sandbox policy")
    if pipeline_id is None:
        raise ValueError("ADO pipeline id is required")

def command_for(tool: str, args: list[str]) -> list[str]:
    if tool == "tavily-mcp":
        if args:
            raise ValueError("Tavily MCP accepts no caller arguments")
        return ["/usr/local/bin/tavily-mcp-ssm"]
    if tool == "snyk-mcp":
        if args:
            raise ValueError("Snyk MCP accepts no caller arguments")
        return ["/usr/local/bin/snyk-mcp-ssm"]
    if tool == "databricks-sql-mcp":
        if args:
            raise ValueError("Databricks SQL MCP accepts no caller arguments")
        return ["/usr/local/bin/databricks-sql-mcp-ssm"]
    if tool == "tavily-cli":
        validate_tavily_cli(args)
        return [RUNNER, "--profile", "tavily", "--", POLICY_TAVILY, f"{REAL}/tvly", *args]
    if tool == "snyk-cli":
        validate_snyk_cli(args)
        return [RUNNER, "--profile", "snyk", "--", f"{REAL}/snyk", *args]
    if tool == "databricks-cli":
        validate_databricks_cli(args)
        return [RUNNER, "--profile", "databricks-cli", "--", f"{REAL}/databricks", *args]
    if tool == "ado-git":
        validate_ado_git(args)
        return [RUNNER, "--profile", "ado", "--", ADO_GIT_POLICY, "/usr/bin/git", *args]
    if tool == "ado-pr-create":
        validate_ado_pr(args)
        return [RUNNER, "--profile", "ado", "--", "/usr/local/bin/ado-pr-create", *args]
    if tool == "ado-trigger":
        validate_ado_trigger(args)
        return [RUNNER, "--profile", "ado", "--", "/usr/local/bin/ado-trigger", *args]
    raise ValueError("tool is not approved by the secret broker")


def send_stream_frame(conn: socket.socket, kind: bytes, payload: bytes = b"") -> None:
    conn.sendall(kind + struct.pack("!I", len(payload)) + payload)


def pump_socket_and_process(conn: socket.socket, proc: subprocess.Popen[bytes]) -> int:
    assert proc.stdin is not None and proc.stdout is not None and proc.stderr is not None
    sel = selectors.DefaultSelector()
    sel.register(conn, selectors.EVENT_READ, "socket")
    sel.register(proc.stdout, selectors.EVENT_READ, "stdout")
    sel.register(proc.stderr, selectors.EVENT_READ, "stderr")
    socket_open = True
    try:
        while True:
            if proc.poll() is not None:
                # Drain both output pipes after process termination.
                for stream, kind in ((proc.stdout, b"O"), (proc.stderr, b"E")):
                    try:
                        tail = stream.read()
                        if tail:
                            send_stream_frame(conn, kind, tail)
                    except Exception:
                        pass
                code = int(proc.returncode or 0)
                send_stream_frame(conn, b"X", struct.pack("!i", code))
                return code
            events = sel.select(timeout=0.5)
            for key, _ in events:
                if key.data == "socket":
                    if not socket_open:
                        continue
                    try:
                        data = conn.recv(65536)
                    except OSError:
                        data = b""
                    if not data:
                        socket_open = False
                        try:
                            proc.stdin.close()
                        except Exception:
                            pass
                        try:
                            sel.unregister(conn)
                        except Exception:
                            pass
                        continue
                    try:
                        proc.stdin.write(data)
                        proc.stdin.flush()
                    except (BrokenPipeError, OSError):
                        socket_open = False
                elif key.data == "stdout":
                    try:
                        data = os.read(proc.stdout.fileno(), 65536)
                    except OSError:
                        data = b""
                    if data:
                        send_stream_frame(conn, b"O", data)
                    else:
                        try: sel.unregister(proc.stdout)
                        except Exception: pass
                elif key.data == "stderr":
                    try:
                        data = os.read(proc.stderr.fileno(), 65536)
                    except OSError:
                        data = b""
                    if data:
                        send_stream_frame(conn, b"E", data)
                    else:
                        try: sel.unregister(proc.stderr)
                        except Exception: pass
    finally:
        try:
            sel.close()
        except Exception:
            pass
        if proc.poll() is None:
            proc.terminate()
            try:
                proc.wait(timeout=3)
            except subprocess.TimeoutExpired:
                proc.kill()


class ToolHandler(socketserver.BaseRequestHandler):
    def handle(self) -> None:
        conn: socket.socket = self.request
        try:
            raw_len = recv_exact(conn, 4)
            header_len = struct.unpack("!I", raw_len)[0]
            if header_len < 2 or header_len > MAX_CONTROL:
                raise ValueError("invalid broker request size")
            header = json.loads(recv_exact(conn, header_len).decode("utf-8"))
            if not isinstance(header, dict) or header.get("version") != 1:
                raise ValueError("unsupported broker protocol version")
            tool = header.get("tool")
            if not isinstance(tool, str):
                raise ValueError("missing tool name")
            args = reject_bad_args(header.get("args", []))
            cwd = map_cwd(header.get("cwd"))
            cmd = command_for(tool, args)

            env = os.environ.copy()
            env["AI_SANDBOX_ROLE"] = "broker"
            env["SANDBOX_NONINTERACTIVE"] = "1"
            env["SANDBOX_AWS_HOME"] = AWS_HOME
            env["AWS_CONFIG_FILE"] = f"{AWS_HOME}/.aws/config"
            env["AWS_SHARED_CREDENTIALS_FILE"] = f"{AWS_HOME}/.aws/credentials"
            env["SANDBOX_AWS_PROFILE"] = AWS_PROFILE
            for key in (
                "AWS_ACCESS_KEY_ID", "AWS_SECRET_ACCESS_KEY", "AWS_SESSION_TOKEN", "AWS_SECURITY_TOKEN",
                "AWS_CONTAINER_CREDENTIALS_RELATIVE_URI", "AWS_CONTAINER_CREDENTIALS_FULL_URI",
                "AWS_CONTAINER_AUTHORIZATION_TOKEN", "AWS_CONTAINER_AUTHORIZATION_TOKEN_FILE",
                "AWS_WEB_IDENTITY_TOKEN_FILE", "AWS_ROLE_ARN", "AWS_ROLE_SESSION_NAME", "AWS_CREDENTIAL_EXPIRATION",
            ):
                env.pop(key, None)

            # stdout/stderr are framed separately on the broker transport. The
            # client restores them to local stdout/stderr, preserving clean MCP
            # stdio while also returning the real child exit status.
            proc = subprocess.Popen(
                cmd,
                cwd=cwd,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                env=env,
                bufsize=0,
            )
            control_reply(conn, True)
            log_event(f"started approved tool={tool}")
            pump_socket_and_process(conn, proc)
        except Exception as exc:
            try:
                control_reply(conn, False, str(exc))
            except Exception:
                pass
            log_event("rejected or failed tool request")


class ThreadingToolServer(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True


_secret_cache: dict[str, tuple[float, str]] = {}
_secret_lock = threading.Lock()


def aws_env() -> dict[str, str]:
    env = os.environ.copy()
    env["HOME"] = AWS_HOME
    env["AWS_CONFIG_FILE"] = f"{AWS_HOME}/.aws/config"
    env["AWS_SHARED_CREDENTIALS_FILE"] = f"{AWS_HOME}/.aws/credentials"
    for key in (
        "AWS_ACCESS_KEY_ID", "AWS_SECRET_ACCESS_KEY", "AWS_SESSION_TOKEN", "AWS_SECURITY_TOKEN",
        "AWS_PROFILE", "AWS_DEFAULT_PROFILE",
        "AWS_CONTAINER_CREDENTIALS_RELATIVE_URI", "AWS_CONTAINER_CREDENTIALS_FULL_URI",
        "AWS_CONTAINER_AUTHORIZATION_TOKEN", "AWS_CONTAINER_AUTHORIZATION_TOKEN_FILE",
        "AWS_WEB_IDENTITY_TOKEN_FILE", "AWS_ROLE_ARN", "AWS_ROLE_SESSION_NAME", "AWS_CREDENTIAL_EXPIRATION",
    ):
        env.pop(key, None)
    return env


def get_parameter(name: str) -> str:
    now = time.time()
    with _secret_lock:
        cached = _secret_cache.get(name)
        if cached and cached[0] > now:
            return cached[1]
    full = f"{SSM_PREFIX}/{name}"
    cp = subprocess.run(
        ["aws", "--profile", AWS_PROFILE, "ssm", "get-parameter", "--name", full, "--with-decryption",
         "--region", AWS_REGION, "--query", "Parameter.Value", "--output", "text"],
        env=aws_env(), stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=30,
    )
    if cp.returncode != 0:
        raise RuntimeError("SSM credential retrieval failed; check/refresh the host AWS profile and restart the broker")
    value = cp.stdout.rstrip("\r\n")
    if not value or value == "None":
        raise RuntimeError("required SSM parameter is empty")
    with _secret_lock:
        _secret_cache[name] = (now + 300, value)
    return value


HOP_BY_HOP = {
    "connection", "keep-alive", "proxy-authenticate", "proxy-authorization",
    "te", "trailers", "transfer-encoding", "upgrade", "host", "content-length",
}


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):  # noqa: ANN001
        return None


URL_OPENER = urllib.request.build_opener(urllib.request.ProxyHandler(), NoRedirect())


class ProviderProxyHandler(http.server.BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server_version = "AI-Sandbox-SecretBroker/1"
    sys_version = ""

    def log_message(self, fmt: str, *args: object) -> None:
        # Never log URL/query/body because prompts can appear there.
        return

    def do_GET(self) -> None: self._proxy()
    def do_POST(self) -> None: self._proxy()
    def do_PUT(self) -> None: self._proxy()
    def do_PATCH(self) -> None: self._proxy()
    def do_DELETE(self) -> None: self._proxy()

    def _error(self, status: int, message: str) -> None:
        body = (message + "\n").encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Connection", "close")
        self.end_headers()
        self.wfile.write(body)

    def _route(self) -> tuple[str, str, str] | None:
        parsed = urllib.parse.urlsplit(self.path)
        path = parsed.path
        if path == "/healthz":
            return ("health", "", "")
        routes = (
            ("/anthropic", "https://api.anthropic.com", "claude-api-key"),
            ("/gemini", "https://generativelanguage.googleapis.com", "gemini-api-key"),
            ("/databricks/anthropic", (DATABRICKS_HOST + "/ai-gateway/anthropic") if DATABRICKS_HOST else "", "databricks-token"),
            ("/databricks/gemini", (DATABRICKS_HOST + "/ai-gateway/gemini") if DATABRICKS_HOST else "", "databricks-token"),
        )
        # Longest prefixes first so /databricks/* can never be confused with
        # a direct-provider route. Targets are Admin-configured constants; the
        # caller cannot supply or override an upstream URL.
        for prefix, target, secret in sorted(routes, key=lambda r: len(r[0]), reverse=True):
            if path == prefix or path.startswith(prefix + "/"):
                if not target:
                    return None
                try:
                    suffix = safe_route_suffix(path, prefix)
                except ValueError:
                    return None
                query = urllib.parse.parse_qsl(parsed.query, keep_blank_values=True)
                if prefix in {"/gemini", "/databricks/gemini"}:
                    query = [(k, v) for (k, v) in query if k.lower() != "key"]
                out_query = urllib.parse.urlencode(query, doseq=True)
                url = target + suffix + (("?" + out_query) if out_query else "")
                return (prefix[1:], url, secret)
        return None

    def _proxy(self) -> None:
        route = self._route()
        if route is None:
            self._error(404, "route not available")
            return
        name, target_url, secret_name = route
        if name == "health":
            body = b"ok\n"
            self.send_response(200)
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return
        try:
            secret = get_parameter(secret_name)
        except Exception as exc:
            self._error(503, str(exc))
            return

        length = int(self.headers.get("Content-Length", "0") or "0")
        if length > 32 * 1024 * 1024:
            self._error(413, "request body too large")
            return
        body = self.rfile.read(length) if length else None
        headers: dict[str, str] = {}
        for k, v in self.headers.items():
            lk = k.lower()
            if lk in HOP_BY_HOP or lk in {"authorization", "x-api-key", "x-goog-api-key"}:
                continue
            headers[k] = v
        if name == "anthropic":
            headers["x-api-key"] = secret
        elif name == "gemini":
            headers["x-goog-api-key"] = secret
        elif name in {"databricks/anthropic", "databricks/gemini"}:
            headers["Authorization"] = f"Bearer {secret}"

        req = urllib.request.Request(target_url, data=body, headers=headers, method=self.command)
        try:
            resp = URL_OPENER.open(req, timeout=300)
        except urllib.error.HTTPError as exc:
            resp = exc
        except Exception:
            self._error(502, "upstream request failed")
            return

        try:
            self.send_response(resp.status)
            for k, v in resp.headers.items():
                if k.lower() in HOP_BY_HOP or k.lower() == "location":
                    continue
                self.send_header(k, v)
            self.send_header("Connection", "close")
            self.end_headers()
            while True:
                chunk = resp.read(65536)
                if not chunk:
                    break
                self.wfile.write(chunk)
                self.wfile.flush()
        except (BrokenPipeError, ConnectionResetError):
            pass
        finally:
            try:
                resp.close()
            except Exception:
                pass
            self.close_connection = True


class ThreadingHTTPServer(http.server.ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True


def healthcheck() -> int:
    try:
        with socket.create_connection(("127.0.0.1", BROKER_PORT), timeout=2) as sock:
            # A connection proves listener readiness; no tool request is sent.
            return 0
    except OSError:
        return 1


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--healthcheck", action="store_true")
    ns = parser.parse_args()
    if ns.healthcheck:
        return healthcheck()

    if os.environ.get("AI_SANDBOX_ROLE") != "broker":
        print("ERROR: secret broker must run with AI_SANDBOX_ROLE=broker", file=sys.stderr)
        return 1
    if not (Path(AWS_HOME) / ".aws" / "config").exists() and not (Path(AWS_HOME) / ".aws" / "credentials").exists():
        print("ERROR: host AWS profile is not mounted into the secret broker", file=sys.stderr)
        return 1

    tool_server = ThreadingToolServer((BROKER_HOST, BROKER_PORT), ToolHandler)
    http_server = ThreadingHTTPServer((BROKER_HOST, HTTP_PORT), ProviderProxyHandler)
    t = threading.Thread(target=http_server.serve_forever, name="provider-proxy", daemon=True)
    t.start()
    log_event(f"ready tool_port={BROKER_PORT} provider_port={HTTP_PORT}")
    try:
        tool_server.serve_forever(poll_interval=0.5)
    except KeyboardInterrupt:
        pass
    finally:
        tool_server.shutdown()
        http_server.shutdown()
        tool_server.server_close()
        http_server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
