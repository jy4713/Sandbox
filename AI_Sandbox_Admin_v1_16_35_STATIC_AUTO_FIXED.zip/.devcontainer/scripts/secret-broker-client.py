#!/usr/bin/env python3
"""Client-side bridge to the Admin-managed secret broker.

No AWS credential or SSM secret is returned to this process.  The broker starts
an approved command/MCP server in a separate container and this client only
relays stdin/stdout/stderr-equivalent bytes.
"""
from __future__ import annotations

import argparse
import json
import os
import socket
import struct
import sys
import threading

MAX_CONTROL = 64 * 1024


def recv_exact(sock: socket.socket, n: int) -> bytes:
    chunks: list[bytes] = []
    left = n
    while left:
        b = sock.recv(left)
        if not b:
            raise RuntimeError("secret broker closed the connection during control handshake")
        chunks.append(b)
        left -= len(b)
    return b"".join(chunks)


def copy_fd_to_socket(sock: socket.socket) -> None:
    try:
        while True:
            data = os.read(sys.stdin.fileno(), 65536)
            if not data:
                try:
                    sock.shutdown(socket.SHUT_WR)
                except OSError:
                    pass
                return
            sock.sendall(data)
    except (BrokenPipeError, ConnectionResetError, OSError):
        return


def copy_socket_to_fd(sock: socket.socket, exit_status: list[int]) -> None:
    try:
        while True:
            kind = recv_exact(sock, 1)
            size = struct.unpack("!I", recv_exact(sock, 4))[0]
            if size > 64 * 1024 * 1024:
                raise RuntimeError("invalid broker stream frame")
            payload = recv_exact(sock, size) if size else b""
            if kind == b"O":
                if payload:
                    os.write(sys.stdout.fileno(), payload)
            elif kind == b"E":
                if payload:
                    os.write(sys.stderr.fileno(), payload)
            elif kind == b"X":
                if size != 4:
                    raise RuntimeError("invalid broker exit frame")
                exit_status[:] = [struct.unpack("!i", payload)[0]]
                return
            else:
                raise RuntimeError("unknown broker stream frame")
    except (BrokenPipeError, ConnectionResetError, OSError, RuntimeError) as exc:
        print(f"ERROR: secret broker stream failed: {exc}", file=sys.stderr)
        exit_status[:] = [1]
        return


def main() -> int:
    parser = argparse.ArgumentParser(add_help=True)
    parser.add_argument("--tool", required=True)
    parser.add_argument("args", nargs=argparse.REMAINDER)
    ns = parser.parse_args()

    host = os.environ.get("SANDBOX_SECRET_BROKER_HOST", "secret-broker")
    port = int(os.environ.get("SANDBOX_SECRET_BROKER_PORT", "8765"))
    timeout = float(os.environ.get("SANDBOX_SECRET_BROKER_CONNECT_TIMEOUT", "10"))
    cwd = os.getcwd()
    header = {
        "version": 1,
        "tool": ns.tool,
        "args": ns.args,
        "cwd": cwd,
    }
    raw = json.dumps(header, separators=(",", ":")).encode("utf-8")
    if len(raw) > MAX_CONTROL:
        print("ERROR: secret broker request is too large", file=sys.stderr)
        return 2

    try:
        sock = socket.create_connection((host, port), timeout=timeout)
    except OSError as exc:
        print(f"ERROR: cannot connect to secret broker {host}:{port}: {exc}", file=sys.stderr)
        return 1

    with sock:
        sock.settimeout(None)
        sock.sendall(struct.pack("!I", len(raw)) + raw)
        status = recv_exact(sock, 1)
        msg_len = struct.unpack("!I", recv_exact(sock, 4))[0]
        if msg_len > MAX_CONTROL:
            print("ERROR: invalid secret broker control response", file=sys.stderr)
            return 1
        msg = recv_exact(sock, msg_len).decode("utf-8", "replace") if msg_len else ""
        if status != b"\x00":
            print(f"ERROR: secret broker rejected request: {msg or 'unknown error'}", file=sys.stderr)
            return 1

        exit_status: list[int] = []
        t_in = threading.Thread(target=copy_fd_to_socket, args=(sock,), daemon=True)
        t_out = threading.Thread(target=copy_socket_to_fd, args=(sock, exit_status), daemon=True)
        t_in.start()
        t_out.start()
        t_out.join()
        return exit_status[0] if exit_status else 1


if __name__ == "__main__":
    raise SystemExit(main())
