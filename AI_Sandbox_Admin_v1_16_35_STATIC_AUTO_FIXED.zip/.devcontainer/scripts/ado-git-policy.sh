#!/usr/bin/env bash
# Root-owned policy wrapper executed only inside the secret-broker container.
# It validates every credentialed Azure DevOps Git destination before the PAT is
# made available to git via GIT_ASKPASS.
set -euo pipefail
set +x

readonly REAL_GIT="/usr/bin/git"
[[ "${1:-}" == "$REAL_GIT" ]] || { echo 'ERROR: ADO Git policy requires the pinned git executable' >&2; exit 2; }
shift
(( $# > 0 )) || { echo 'ERROR: ADO Git operation is required' >&2; exit 2; }

: "${ADO_ORG:?ADO_ORG is required}"
: "${ADO_PROJECT:?ADO_PROJECT is required}"
: "${ADO_REPO:?ADO_REPO is required}"

op="$1"
case "$op" in clone|fetch|pull|push|ls-remote) ;;
  *) echo 'ERROR: ADO Git policy permits only clone/fetch/pull/push/ls-remote' >&2; exit 2 ;;
esac

approved_prefix="https://dev.azure.com/${ADO_ORG}/${ADO_PROJECT}/_git/${ADO_REPO}"

is_approved_url() {
  local url="${1%/}"
  [[ "$url" == "$approved_prefix" || "$url" == "$approved_prefix/"* ]]
}

reject_transport_like_value() {
  local value="${1:-}" lower
  lower="${value,,}"
  case "$lower" in
    ext::*|file://*|ssh://*|git://*) return 0 ;;
  esac
  return 1
}

# Reject process/config override options and recursive submodule network access.
# Submodules can carry independently controlled URLs and must be handled by a
# separate reviewed workflow if ever required.
for a in "$@"; do
  lower="${a,,}"
  case "$lower" in
    -c|-c=*|--config-env|--config-env=*|--exec-path|--exec-path=*|\
    --upload-pack|--upload-pack=*|--receive-pack|--receive-pack=*|\
    --git-dir|--git-dir=*|--work-tree|--work-tree=*|--namespace|--namespace=*|\
    --recurse-submodules|--recurse-submodules=*|--force|--force=*|-f|\
    --force-with-lease|--force-with-lease=*|--force-if-includes|--mirror|--all|\
    --delete|--prune)
      echo 'ERROR: Git option is not approved by Sandbox policy' >&2; exit 2 ;;
  esac
  if reject_transport_like_value "$a"; then
    echo 'ERROR: non-HTTPS Git transport is not approved by Sandbox policy' >&2; exit 2
  fi
done

# The workspace is Developer/agent writable. Local Git config therefore cannot
# be trusted to define helpers, URL rewrites, filters, merge drivers, alternate
# proxies or executable hooks. Fail closed if any such key exists. Command-line
# overrides below provide a second layer of protection.
reject_unsafe_local_config() {
  local keys
  keys="$($REAL_GIT config --local --name-only --get-regexp \
    '^(url\..*\.(insteadof|pushinsteadof)|http\.(proxy|sslverify|curloptresolve)|http\..*\.(proxy|sslverify|curloptresolve)|credential\.(helper|usehttppath)|credential\..*\.helper|core\.(hookspath|fsmonitor|sshcommand|gitproxy)|filter\..*\.(clean|smudge|process|required)|merge\..*\.driver|submodule\..*\.update|remote\..*\.(proxy|uploadpack|receivepack)|protocol\..*\.allow|fetch\.recursesubmodules|submodule\.recurse)$' \
    2>/dev/null || true)"
  if [[ -n "$keys" ]]; then
    echo 'ERROR: repository-local Git configuration contains a setting that is unsafe for credentialed broker execution.' >&2
    echo '       Remove URL rewrites/helpers/hooks/filters/custom transports and retry.' >&2
    return 1
  fi
}

validate_all_urls() {
  local url found=false
  while IFS= read -r url; do
    [[ -n "$url" ]] || continue
    found=true
    is_approved_url "$url" || {
      echo 'ERROR: Git remote is outside the Admin-approved Azure DevOps repository' >&2
      return 1
    }
  done
  [[ "$found" == true ]] || {
    echo 'ERROR: cannot resolve the selected Git remote' >&2
    return 1
  }
}

# Return the first non-option repository operand for clone/ls-remote. We support
# the small option set needed by the sandbox workflow and fail closed on unknown
# pre-repository options rather than trying to emulate the full Git parser.
first_repository_operand() {
  local mode="$1"; shift
  while (( $# > 0 )); do
    case "$1" in
      --branch|-b|--depth|--origin|-o)
        (( $# >= 2 )) || return 1
        shift 2
        ;;
      --branch=*|--depth=*|--origin=*|--single-branch|--no-single-branch|--no-tags|--tags|--heads|--refs|--symref|--exit-code)
        shift
        ;;
      --)
        shift
        (( $# > 0 )) || return 1
        printf '%s' "$1"; return 0
        ;;
      -*)
        # Unknown option before the repository could consume another argument,
        # so parsing it permissively would risk validating the wrong operand.
        return 1
        ;;
      *)
        printf '%s' "$1"; return 0
        ;;
    esac
  done
  return 1
}

validate_push_refspec() {
  local ref="${1#+}" src dst
  [[ -n "$ref" && "$ref" != *'*'* ]] || {
    echo 'ERROR: wildcard/empty push refspec is not approved by Sandbox policy' >&2
    return 1
  }
  if [[ "$ref" == *:* ]]; then
    src="${ref%%:*}"; dst="${ref#*:}"
    [[ -n "$src" && -n "$dst" ]] || {
      echo 'ERROR: ref deletion or empty push destination is not approved by Sandbox policy' >&2
      return 1
    }
  else
    src="$ref"; dst="$ref"
  fi
  case "${dst,,}" in
    main|master|refs/heads/main|refs/heads/master)
      echo 'ERROR: direct push to main/master is forbidden; create a feature branch and PR instead' >&2
      return 1 ;;
  esac
  return 0
}

parse_push_remote_and_refs() {
  local -a rest=("${@:1}") refs=()
  local remote='' a
  local i=0
  while (( i < ${#rest[@]} )); do
    a="${rest[$i]}"
    case "$a" in
      -u|--set-upstream|--porcelain|--no-verify)
        i=$((i+1)); continue ;;
      --)
        i=$((i+1)); break ;;
      -*)
        echo 'ERROR: push option is not approved by Sandbox policy' >&2; return 1 ;;
      *)
        remote="$a"; i=$((i+1)); break ;;
    esac
  done
  [[ -n "$remote" ]] || { echo 'ERROR: push requires an explicit approved remote' >&2; return 1; }
  while (( i < ${#rest[@]} )); do
    a="${rest[$i]}"
    [[ "$a" != -* ]] || { echo 'ERROR: push options after the remote are not approved' >&2; return 1; }
    refs+=("$a"); i=$((i+1))
  done
  [[ ${#refs[@]} -gt 0 ]] || {
    echo 'ERROR: push requires an explicit feature-branch refspec; implicit current/default pushes are disabled' >&2
    return 1
  }
  printf '%s\n' "$remote"
  printf '%s\n' "${refs[@]}"
}

case "$op" in
  clone|ls-remote)
    repo="$(first_repository_operand "$op" "${@:2}" || true)"
    [[ -n "$repo" && "$repo" == https://* ]] || {
      echo 'ERROR: an explicit approved Azure DevOps HTTPS repository URL is required' >&2; exit 2;
    }
    is_approved_url "$repo" || { echo 'ERROR: Azure DevOps URL is outside the Admin-approved repository' >&2; exit 2; }
    ;;

  fetch|pull)
    reject_unsafe_local_config || exit 2
    candidate="${2:-}"
    if [[ -n "$candidate" && "$candidate" == https://* ]]; then
      is_approved_url "$candidate" || { echo 'ERROR: explicit Git URL is outside the Admin-approved repository' >&2; exit 2; }
    elif [[ -n "$candidate" && ( "$candidate" == *://* || "$candidate" == *::* || "$candidate" == /* || "$candidate" == ./* || "$candidate" == ../* || "$candidate" == ~/* ) ]]; then
      echo 'ERROR: explicit non-approved Git transport/path is not permitted' >&2; exit 2
    else
      remote="${candidate:-origin}"
      $REAL_GIT remote get-url --all "$remote" 2>/dev/null | validate_all_urls || exit 2
    fi
    ;;

  push)
    reject_unsafe_local_config || exit 2
    mapfile -t push_parts < <(parse_push_remote_and_refs "${@:2}") || exit 2
    remote="${push_parts[0]:-}"
    [[ -n "$remote" ]] || exit 2
    if [[ "$remote" == https://* ]]; then
      is_approved_url "$remote" || { echo 'ERROR: explicit Git URL is outside the Admin-approved repository' >&2; exit 2; }
    elif [[ "$remote" == *://* || "$remote" == *::* || "$remote" == /* || "$remote" == ./* || "$remote" == ../* || "$remote" == ~/* ]]; then
      echo 'ERROR: explicit non-approved Git transport/path is not permitted' >&2; exit 2
    else
      $REAL_GIT remote get-url --push --all "$remote" 2>/dev/null | validate_all_urls || exit 2
    fi
    for ref in "${push_parts[@]:1}"; do validate_push_refspec "$ref" || exit 2; done
    ;;
esac

# Do not inherit host/global Git execution customizations. Local repo config is
# still needed for remotes/refs, but dangerous keys were rejected above.
export GIT_CONFIG_NOSYSTEM=1
export GIT_CONFIG_GLOBAL=/dev/null

exec "$REAL_GIT" \
  -c core.hooksPath=/dev/null \
  -c core.fsmonitor=false \
  -c credential.helper= \
  -c protocol.allow=never \
  -c protocol.https.allow=always \
  -c protocol.ext.allow=never \
  -c protocol.file.allow=never \
  -c protocol.git.allow=never \
  -c protocol.ssh.allow=never \
  -c fetch.recurseSubmodules=false \
  -c submodule.recurse=false \
  -c http.sslVerify=true \
  "$@"
