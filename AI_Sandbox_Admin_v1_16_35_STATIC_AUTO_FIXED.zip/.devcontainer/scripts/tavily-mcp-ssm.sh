#!/usr/bin/env bash
# Tavily MCP launcher. In the AI container this is a credential-free stdio
# bridge to the secret broker. In the broker container it launches the pinned
# Tavily MCP with SSM-backed credential injection and Admin domain policy.
set -euo pipefail
set +x
umask 077

if [[ "${AI_SANDBOX_ROLE:-client}" != "broker" ]]; then
  exec /usr/local/bin/secret-broker-client --tool tavily-mcp
fi

. /usr/local/libexec/ai-sandbox/mcp-wrapper-preamble
readonly REAL_TAVILY_MCP="/usr/local/libexec/ai-sandbox/real/tavily-mcp"
readonly TAVILY_POLICY_PROXY="/usr/local/libexec/ai-sandbox/tavily-policy-proxy.py"
[[ -x "$REAL_TAVILY_MCP" ]] || { echo 'ERROR: real Tavily MCP executable is missing' >&2; exit 1; }
[[ -x "$TAVILY_POLICY_PROXY" ]] || { echo 'ERROR: Tavily policy proxy is missing' >&2; exit 1; }
(( $# == 0 )) || { echo 'ERROR: Tavily MCP wrapper does not accept caller arguments' >&2; exit 2; }
start_ms="$(date +%s%3N)"
application-audit --app mcp --event server_start --operation tavily --target tavily --status started --transport stdio || true
set +e
run-with-ssm-secrets --profile tavily -- "$TAVILY_POLICY_PROXY" "$REAL_TAVILY_MCP"
ec=$?
set -e
end_ms="$(date +%s%3N)"
status=success; (( ec == 0 )) || status=failure
application-audit --app mcp --event server_end --operation tavily --target tavily --status "$status" --exit-code "$ec" --duration-ms "$((end_ms-start_ms))" --transport stdio || true
exit "$ec"
