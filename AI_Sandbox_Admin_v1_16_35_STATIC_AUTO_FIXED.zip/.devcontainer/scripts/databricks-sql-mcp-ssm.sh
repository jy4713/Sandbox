#!/usr/bin/env bash
# Databricks SQL MCP launcher. AI-side process receives no PAT; the broker-side
# child retrieves /databricks-sql-mcp-token and owns the Authorization header.
set -euo pipefail
set +x
umask 077

if [[ "${AI_SANDBOX_ROLE:-client}" != "broker" ]]; then
  (( $# == 0 )) || { echo 'ERROR: Databricks SQL MCP wrapper does not accept caller arguments' >&2; exit 2; }
  exec /usr/local/bin/secret-broker-client --tool databricks-sql-mcp
fi

. /usr/local/libexec/ai-sandbox/mcp-wrapper-preamble
readonly REAL_MCP_REMOTE="/usr/local/libexec/ai-sandbox/real/mcp-remote"
[[ -x "$REAL_MCP_REMOTE" ]] || { echo 'ERROR: real mcp-remote executable is missing' >&2; exit 1; }
(( $# == 0 )) || { echo 'ERROR: Databricks SQL MCP wrapper does not accept caller arguments' >&2; exit 2; }
start_ms="$(date +%s%3N)"
application-audit --app mcp --event server_start --operation databricks-sql --target databricks-sql --status started --transport stdio || true
set +e
run-with-ssm-secrets --profile databricks-sql-mcp -- "$REAL_MCP_REMOTE"
ec=$?
set -e
end_ms="$(date +%s%3N)"
status=success; (( ec == 0 )) || status=failure
application-audit --app mcp --event server_end --operation databricks-sql --target databricks-sql --status "$status" --exit-code "$ec" --duration-ms "$((end_ms-start_ms))" --transport stdio || true
exit "$ec"
