#!/usr/bin/env bash
# Credential-free MCP registration. All managed MCP commands are local stdio
# bridges to the secret-broker; no AWS or service secret values/references are
# written into Claude/Gemini state.
set -euo pipefail
umask 077

export CLAUDE_CONFIG_DIR="${CLAUDE_CONFIG_DIR:-$HOME/.claude}"
export DISABLE_AUTOUPDATER=1
export CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC=1

readonly REAL_DIR="/usr/local/libexec/ai-sandbox/real"
readonly REAL_GEMINI="$REAL_DIR/gemini"
[[ -x "$REAL_GEMINI" ]] || { echo 'ERROR: real Gemini CLI is missing' >&2; exit 1; }
[[ -r /etc/claude-code/managed-mcp.json ]] || { echo 'ERROR: Admin Claude MCP config is missing' >&2; exit 1; }
command -v jq >/dev/null 2>&1 || { echo 'ERROR: jq is required for MCP configuration' >&2; exit 1; }

gemini_state_home="${GEMINI_CLI_HOME:-$HOME}"
gemini_config_dir="$gemini_state_home/.gemini"
gemini_settings="$gemini_config_dir/settings.json"
mkdir -p "$CLAUDE_CONFIG_DIR" "$gemini_config_dir"

readonly TAVILY_MCP_TIMEOUT_MS=120000
readonly SNYK_MCP_TIMEOUT_MS=180000
readonly DATABRICKS_SQL_MCP_TIMEOUT_MS=180000

if [[ ! -s "$gemini_settings" ]]; then
  printf '%s\n' '{}' > "$gemini_settings"
elif ! jq -e . "$gemini_settings" >/dev/null 2>&1; then
  invalid_backup="${gemini_settings}.invalid.$(date +%Y%m%d%H%M%S)"
  cp -p "$gemini_settings" "$invalid_backup" 2>/dev/null || true
  printf '%s\n' '{}' > "$gemini_settings"
  echo "WARN: invalid Gemini settings backed up to $invalid_backup and reset" >&2
fi

tmp="$(mktemp "${TMPDIR:-/tmp}/gemini-settings.XXXXXX")"
trap 'rm -f "$tmp"' EXIT
jq \
  --argjson tavily_timeout "$TAVILY_MCP_TIMEOUT_MS" \
  --argjson snyk_timeout "$SNYK_MCP_TIMEOUT_MS" \
  --argjson databricks_sql_timeout "$DATABRICKS_SQL_MCP_TIMEOUT_MS" '
  .mcpServers = ((.mcpServers // {}) + {
    tavily: {
      command: "/usr/local/bin/tavily-mcp-ssm",
      args: [],
      timeout: $tavily_timeout
    },
    snyk: {
      command: "/usr/local/bin/snyk-mcp-ssm",
      args: [],
      timeout: $snyk_timeout
    },
    "databricks-sql": {
      command: "/usr/local/bin/databricks-sql-mcp-ssm",
      args: [],
      timeout: $databricks_sql_timeout
    }
  }) |
  del(.mcpServers.tavily.env) |
  del(.mcpServers.snyk.env) |
  del(.mcpServers["databricks-sql"].env)
' "$gemini_settings" > "$tmp"

jq -e . "$tmp" >/dev/null || { echo 'ERROR: generated Gemini settings are invalid JSON' >&2; exit 1; }
mv "$tmp" "$gemini_settings"
trap - EXIT
chmod 0600 "$gemini_settings"

if jq -e '
  (.mcpServers.tavily.env? != null) or
  (.mcpServers.snyk.env? != null) or
  (.mcpServers["databricks-sql"].env? != null)
' "$gemini_settings" >/dev/null; then
  echo 'ERROR: managed MCP settings must not contain credential environment blocks' >&2
  exit 1
fi

if grep -Eq '(AKIA|ASIA)[A-Z0-9]{16}|AWS_(ACCESS_KEY_ID|SECRET_ACCESS_KEY|SESSION_TOKEN)' "$gemini_settings"; then
  echo 'ERROR: AWS credential material/reference detected in Gemini MCP settings' >&2
  exit 1
fi

chmod -R go-rwx "$CLAUDE_CONFIG_DIR" "$gemini_config_dir" 2>/dev/null || true
printf '[OK] Gemini Tavily/Snyk/Databricks SQL MCP configured as credential-free broker bridges; Claude uses root-owned Admin MCP config.\n'
