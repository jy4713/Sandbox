#!/usr/bin/env bash
# Snyk MCP launcher. The AI container only bridges stdio to the secret broker;
# the SNYK_TOKEN exists only in the broker-side child process.
set -euo pipefail
set +x
umask 077

if [[ "${AI_SANDBOX_ROLE:-client}" != "broker" ]]; then
  (( $# == 0 )) || { echo 'ERROR: Snyk MCP wrapper does not accept caller arguments' >&2; exit 2; }
  exec /usr/local/bin/secret-broker-client --tool snyk-mcp
fi

. /usr/local/libexec/ai-sandbox/mcp-wrapper-preamble
readonly REAL_SNYK="/usr/local/libexec/ai-sandbox/real/snyk"
[[ -x "$REAL_SNYK" ]] || { echo 'ERROR: real Snyk executable is missing' >&2; exit 1; }
(( $# == 0 )) || { echo 'ERROR: Snyk MCP wrapper does not accept caller arguments' >&2; exit 2; }
start_ms="$(date +%s%3N)"
application-audit --app mcp --event server_start --operation snyk --target snyk --status started --transport stdio || true
set +e
run-with-ssm-secrets --profile snyk -- "$REAL_SNYK" mcp -t stdio
ec=$?
set -e
end_ms="$(date +%s%3N)"
status=success; (( ec == 0 )) || status=failure
application-audit --app mcp --event server_end --operation snyk --target snyk --status "$status" --exit-code "$ec" --duration-ms "$((end_ms-start_ms))" --transport stdio || true
exit "$ec"
