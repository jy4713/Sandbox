#!/usr/bin/env bash
# Initialize the credential-isolated AI client container.
set -uo pipefail
umask 027

echo '=============================================='
echo '  AI Secure Sandbox v1.16.35 - Container Init'
echo '=============================================='

git config --global safe.directory /home/vscode/workspace 2>/dev/null && echo '[1/4] Git safe.directory set' || echo '[1/4] WARN: could not set git safe.directory'

echo; echo '[2/4] Configuring credential-free MCP definitions'
if configure-mcp; then
  echo '  [OK] Tavily/Snyk/Databricks SQL MCP use secret-broker stdio bridges.'
else
  echo '  [FAIL] MCP configuration failed'
fi

echo; echo '[3/4] Secret-broker boundary check'
if env | grep -Eq '^AWS_(ACCESS_KEY_ID|SECRET_ACCESS_KEY|SESSION_TOKEN|SECURITY_TOKEN)='; then
  echo '  [FAIL] AWS credential environment variable is present in the AI container.'
  broker_status=FAILED
elif [[ -e /home/vscode/.aws/credentials || -e /home/vscode/.aws/sso/cache ]]; then
  echo '  [FAIL] AWS credential/cache material is present in the AI container.'
  broker_status=FAILED
elif curl --noproxy '*' -fsS --max-time 5 "${SANDBOX_SECRET_BROKER_HTTP_URL:-http://secret-broker:8770}/healthz" >/dev/null 2>&1; then
  echo '  [OK] AI container has no AWS credential material; secret-broker is reachable.'
  broker_status=PASSED
else
  echo '  [FAIL] secret-broker health endpoint is not reachable.'
  broker_status=FAILED
fi

echo; echo '[4/4] Runtime security verification'
if verify-runtime; then verify_status=PASSED; else verify_status=FAILED; fi

echo
echo "Broker boundary: $broker_status"
echo "Runtime verification: $verify_status"
echo 'Developer workflow:'
echo '  1. On the WINDOWS HOST, the launcher configures the sandbox AWS profile and opens'
echo '     aws-azure-login in GUI/browser mode. The resulting temporary AWS profile stays on the host.'
echo '  2. Only the secret-broker receives the host .aws directory as a read-only mount.'
echo '     Claude/Gemini/ucode shell tools cannot read AWS credentials or call SSM directly.'
echo '  3. Claude/Gemini direct provider keys, Tavily, Snyk, ADO PAT and Databricks SQL PAT'
echo '     are fetched by the broker and are never written into AI-container env/config/files.'
echo '  4. ucode claude/gemini keep the Databricks route through the provider broker; the real'
echo '     Databricks PAT remains broker-only and is never injected into the AI process.'

[[ "$verify_status" == FAILED || "$broker_status" == FAILED ]] && exit 1
