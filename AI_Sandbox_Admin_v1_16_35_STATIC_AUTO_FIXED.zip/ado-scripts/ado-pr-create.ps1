#Requires -Version 7.4
# =============================================================================
# ado-pr-create.ps1 — Host convenience launcher for the brokered ADO PR helper.
#
# Security contract (v1.16.35+):
#   * The Windows host script never accepts, prompts for, or stores ADO_PAT.
#   * ADO org/project/repo and PAT remain Admin-managed SSM values.
#   * The AI-side command delegates to secret-broker; only the broker-side
#     child receives ADO_PAT in memory for the duration of the operation.
# =============================================================================
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$Title,
    [Parameter(Mandatory = $true)][string]$Source,
    [string]$Target = 'main',
    [string]$Description = '',
    [string]$Reviewers = '',
    [switch]$Draft,
    [switch]$AutoComplete
)
$ErrorActionPreference = 'Stop'

if ($Source -in @('main','master')) {
    throw 'Cannot create PR from main/master as source. Create a feature branch first.'
}

$Root = Split-Path -Parent $PSScriptRoot
$SvcDir = if (Test-Path (Join-Path $Root 'tar\docker-compose.yml')) { 'tar' } elseif (Test-Path (Join-Path $Root 'ecr\docker-compose.yml')) { 'ecr' } else { throw 'Cannot locate sandbox docker-compose.yml' }
$ComposeDir = Join-Path $Root $SvcDir

$ToolArgs = @('--title', $Title, '--source', $Source, '--target', $Target)
if ($Description) { $ToolArgs += @('--description', $Description) }
if ($Reviewers) { $ToolArgs += @('--reviewers', $Reviewers) }
if ($Draft) { $ToolArgs += '--draft' }
if ($AutoComplete) { $ToolArgs += '--auto-complete' }

Push-Location $ComposeDir
try {
    & docker compose exec -T devcontainer /usr/local/bin/ado-pr-create @ToolArgs
    if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
}
finally { Pop-Location }
