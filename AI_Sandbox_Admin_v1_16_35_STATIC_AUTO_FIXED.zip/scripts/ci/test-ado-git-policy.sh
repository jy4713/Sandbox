#!/usr/bin/env bash
set -euo pipefail
root="$(cd "$(dirname "$0")/../.." && pwd)"
policy="$root/.devcontainer/scripts/ado-git-policy.sh"
[[ -x "$policy" ]] || { echo 'ERROR: ADO Git policy is not executable' >&2; exit 1; }
command -v git >/dev/null 2>&1 || { echo 'SKIP: git unavailable'; exit 0; }

tmp="$(mktemp -d)"; trap 'rm -rf "$tmp"' EXIT
cd "$tmp"
git init -q
git config user.name lint
git config user.email lint@example.invalid
export ADO_ORG='approved-org' ADO_PROJECT='approved-project' ADO_REPO='approved-repo'
approved='https://dev.azure.com/approved-org/approved-project/_git/approved-repo'
git remote add origin "$approved"

expect_reject() {
  if "$policy" /usr/bin/git "$@" >/dev/null 2>&1; then
    echo "ERROR: policy unexpectedly accepted: git $*" >&2
    exit 1
  fi
}

# These all fail before any network request is attempted.
expect_reject push 'ext::sh -c id'
expect_reject clone 'file:///tmp/other'
expect_reject fetch --upload-pack=/tmp/helper origin
expect_reject push --force origin feature/x
expect_reject push origin main
expect_reject push origin refs/heads/main
expect_reject push origin

git remote set-url --push origin 'https://example.invalid/steal'
expect_reject push origin
# Restore push URL and verify local rewrite/helper policy cannot change the target.
git remote set-url --delete --push origin 'https://example.invalid/steal' 2>/dev/null || true
git config 'url.https://example.invalid/.insteadOf' 'https://dev.azure.com/'
expect_reject fetch origin

echo 'ADO Git policy regression tests passed'
