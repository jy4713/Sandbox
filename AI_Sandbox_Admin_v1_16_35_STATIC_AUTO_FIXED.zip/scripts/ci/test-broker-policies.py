#!/usr/bin/env python3
"""Offline regression checks for secret-broker caller policy.

No network or AWS access is used. These tests assert that caller-controlled
arguments cannot select authentication, alternate transports, or paths outside
the shared workspace before a broker child receives a secret.
"""
from __future__ import annotations

import importlib.util
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
BROKER = ROOT / ".devcontainer" / "scripts" / "secret-broker-server.py"
os.environ.pop("DATABRICKS_HOST", None)
spec = importlib.util.spec_from_file_location("ai_sandbox_secret_broker", BROKER)
assert spec and spec.loader
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)


def must_pass(fn, args):
    fn(args)


def must_fail(fn, args):
    try:
        fn(args)
    except ValueError:
        return
    raise AssertionError(f"expected rejection: {fn.__name__}({args!r})")


# Tavily raw auth/configuration commands must never run in the credentialed child.
must_pass(mod.validate_tavily_cli, ["search", "security guidance"])
must_fail(mod.validate_tavily_cli, ["auth", "status"])
must_fail(mod.validate_tavily_cli, ["research", "topic"])

# Snyk scans may refer to workspace content but not broker/AWS state or auth endpoints.
must_pass(mod.validate_snyk_cli, ["code", "test", "--file=/home/vscode/workspace/app/pom.xml"])
must_fail(mod.validate_snyk_cli, ["code", "test", "/home/vscode/.aws/credentials"])
must_fail(mod.validate_snyk_cli, ["code", "test", "../.aws/credentials"])
must_fail(mod.validate_snyk_cli, ["test", "--proxy=https://example.invalid"])
must_fail(mod.validate_snyk_cli, ["test", "--api=https://example.invalid"])
must_fail(mod.validate_snyk_cli, ["test", "--debug"])

# ADO Git cannot switch protocol or execute caller-supplied helpers/configuration.
must_pass(mod.validate_ado_git, ["fetch", "origin"])
must_fail(mod.validate_ado_git, ["push", "ext::sh -c id"])
must_fail(mod.validate_ado_git, ["clone", "file:///tmp/repo"])
must_fail(mod.validate_ado_git, ["fetch", "--upload-pack=/tmp/helper", "origin"])
must_fail(mod.validate_ado_git, ["push", "-c", "protocol.ext.allow=always", "origin"])
must_fail(mod.validate_ado_git, ["push", "--force", "origin", "feature/x"])

must_pass(mod.validate_ado_trigger, ["--pipeline-id", "42", "--branch", "feature/x", "--params", "{\"env\":\"dev\"}"])
must_fail(mod.validate_ado_trigger, ["--pipeline-id", "../git/repositories"])
must_fail(mod.validate_ado_trigger, ["--pipeline-id", "42/../43"])
must_fail(mod.validate_ado_trigger, ["--auth", "az", "--pipeline-id", "42"])

print("Secret broker policy regression tests passed")
