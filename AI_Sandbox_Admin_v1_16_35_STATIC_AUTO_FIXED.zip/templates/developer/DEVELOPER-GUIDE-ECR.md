# Developer Guide - ECR - AI Secure Sandbox v1.16.35

### Static key test mode (host only)

For temporary POC testing when SAML is unavailable, store the Access Key and Secret Access Key in the Windows host profile, not in `.env`:

```powershell
aws configure --profile sandbox
```

Set `AWS_AUTH_MODE=auto` (default) or `AWS_AUTH_MODE=static`. The host `.aws` directory is mounted read-only into `secret-broker` only; it is not mounted into the AI DevContainer.


## Purpose

Production-style image distribution uses ECR while retaining the same credential-isolation model as the TAR package. Azure/Entra browser login occurs on the Windows host. Only the trusted secret broker receives the host AWS profile directory.

## Prerequisites

- Docker Desktop / approved Docker runtime
- VS Code + Dev Containers
- AWS CLI v2
- `aws-azure-login` on Windows
- Browser access to corporate Azure/Entra authentication

## Configure `.env`

Required non-secret values include:

```ini
DEVELOPER_ID=<your-id>
SANDBOX_AWS_PROFILE=sandbox
AWS_REGION=eu-west-2
AZURE_TENANT_ID=<tenant-id>
AZURE_APP_ID_URI=<app-id-uri>
AZURE_DEFAULT_USERNAME=<your-email>
AZURE_DEFAULT_ROLE_ARN=arn:aws:iam::<account>:role/<role>
AZURE_DEFAULT_DURATION_HOURS=1
AZURE_DEFAULT_REMEMBER_ME=true
ECR_REGISTRY=<approved-registry>
DATABRICKS_HOST=https://<approved-workspace>
DATABRICKS_CLAUDE_MODEL=<approved-model>
DATABRICKS_GEMINI_MODEL=<approved-model>
```

Static AWS keys and native `AWS_SSO_*` settings are rejected.

## Pull and start

```powershell
.\scripts\ecr\pull-and-start.ps1
```

If the current host AWS role session is absent/expired, the launcher opens:

```powershell
aws-azure-login --profile sandbox --mode gui
```

The host session is then used for the approved-image manifest and ECR pull. The Dev Container itself receives no AWS credentials.

## Runtime routing

```text
Claude/Gemini direct -> loopback relay -> secret broker -> provider key from SSM
ucode claude/gemini -> loopback relay -> secret broker -> Databricks PAT from SSM -> AI Gateway
Tavily/Snyk MCP     -> secret broker -> SSM -> approved service
Databricks SQL MCP  -> secret broker -> dedicated SSM token
ADO operations      -> secret broker -> ADO PAT from SSM
```

## Verify

Inside the Dev Container:

```bash
verify-runtime
```

A direct SSM read from the AI container must fail. Application functionality should continue through the broker.

## Refresh login

On Windows:

```powershell
aws-azure-login --profile sandbox --mode gui
# pull-and-start then validates the permissions it actually needs via SSM/ECR; no STS preflight is required
```

Restart/recreate the stack if an already-running broker needs the refreshed host credentials.
