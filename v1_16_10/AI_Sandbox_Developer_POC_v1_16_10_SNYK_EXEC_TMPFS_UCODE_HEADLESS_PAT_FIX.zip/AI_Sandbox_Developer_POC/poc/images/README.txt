Admin supplies the complete generated poc/images bundle here. Do not modify bundle files.
