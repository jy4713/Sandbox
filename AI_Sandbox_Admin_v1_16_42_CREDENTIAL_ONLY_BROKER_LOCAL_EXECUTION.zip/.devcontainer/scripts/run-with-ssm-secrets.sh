#!/usr/bin/env bash
# =============================================================================
# Retired broker command runner - AI Secure Sandbox v1.16.42
#
# v1.16.42 removes broker-side application execution. The credential broker is
# allowed to read approved SSM parameters and inject credentials only into fixed
# outbound HTTP routes. Git/Snyk/Tavily/Databricks/Claude/Gemini/ucode/MCP and
# every other developer command must execute in the devcontainer.
#
# This compatibility guard is retained so an old script cannot silently restore
# the former execution model. It returns 126 for every invocation.
# =============================================================================
set -euo pipefail
set +x

echo 'ERROR: broker-side command execution is disabled in v1.16.42.' >&2
echo '       Run the normal command in the devcontainer; the credential broker only injects approved SSM credentials into fixed HTTP routes.' >&2
exit 126
