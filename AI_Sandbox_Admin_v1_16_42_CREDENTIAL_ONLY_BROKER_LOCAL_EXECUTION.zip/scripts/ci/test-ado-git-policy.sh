#!/usr/bin/env bash
set -euo pipefail
root="$(cd "$(dirname "$0")/../.." && pwd)"
policy="$root/.devcontainer/scripts/ado-git-policy.sh"
[[ -x "$policy" ]] || { echo 'ERROR: ADO Git policy is not executable' >&2; exit 1; }
command -v git >/dev/null 2>&1 || { echo 'SKIP: git unavailable'; exit 0; }

tmp="$(mktemp -d)"; trap 'rm -rf "$tmp"' EXIT
cd "$tmp"
git init -q
git config user.name lint
git config user.email lint@example.invalid
approved='https://dev.azure.com/approved-org/approved-project/_git/approved-repo'
git remote add origin "$approved"

expect_reject() {
  if "$policy" /usr/bin/git "$@" >/dev/null 2>&1; then
    echo "ERROR: policy unexpectedly accepted: git $*" >&2
    exit 1
  fi
}


# Repository identity is deliberately not pinned in Sandbox metadata. The PAT
# and Azure DevOps permissions decide which dev.azure.com repositories are
# authorized.
if grep -Eq 'ADO_ORG|ADO_PROJECT|ADO_REPO|Admin-approved repository|outside the Admin-approved repository' "$policy"; then
  echo 'ERROR: ADO Git policy still pins repository identity in Sandbox metadata' >&2
  exit 1
fi
grep -Fq 'dev.azure.com' "$policy" || { echo 'ERROR: ADO HTTPS host validation missing' >&2; exit 1; }
grep -Fq 'LOCAL_ADO_BASE="http://127.0.0.1:8771/ado/dev/"' "$policy" || { echo 'ERROR: ADO Git localhost credential route missing' >&2; exit 1; }
grep -Fq 'insteadOf=https://dev.azure.com/' "$policy" || { echo 'ERROR: ADO Git HTTPS-to-local rewrite missing' >&2; exit 1; }
if grep -Eq 'ADO_PAT|GIT_ASKPASS|secret-broker-client|run-with-ssm-secrets' "$policy"; then
  echo 'ERROR: local ADO Git policy still receives/delegates a raw credential' >&2
  exit 1
fi
if grep -Eq 'secret-broker-client|run-with-ssm-secrets' "$root/.devcontainer/scripts/git-transparent.sh"; then
  echo 'ERROR: transparent Git still delegates the Git process to the broker' >&2
  exit 1
fi

# These all fail before any network request is attempted.
expect_reject push 'ext::sh -c id'
expect_reject clone 'file:///tmp/other'
expect_reject fetch --upload-pack=/tmp/helper origin

git remote set-url --push origin 'https://example.invalid/steal'
expect_reject push origin
# Restore push URL and verify local rewrite/helper policy cannot change the target.
git remote set-url --delete --push origin 'https://example.invalid/steal' 2>/dev/null || true
git config 'url.https://example.invalid/.insteadOf' 'https://dev.azure.com/'
expect_reject fetch origin

# Repository/branch governance is intentionally delegated to Azure DevOps.
# The broker policy must not reintroduce local bans on main/master, force,
# force-with-lease, deletion, mirror/all/prune or force refspecs.
if grep -Eqi 'direct push to main/master|force-push refspecs are not approved|destructive Git push option is not approved' "$policy"; then
  echo 'ERROR: sandbox Git policy still contains branch/history governance restrictions' >&2
  exit 1
fi
grep -Fq -- '--force-with-lease=*' "$policy" || { echo 'ERROR: force-with-lease parser support missing' >&2; exit 1; }
grep -Fq -- '--mirror' "$policy" || { echo 'ERROR: mirror push parser support missing' >&2; exit 1; }
grep -Fq -- '--delete' "$policy" || { echo 'ERROR: delete push parser support missing' >&2; exit 1; }

echo 'ADO Git policy regression tests passed' 
