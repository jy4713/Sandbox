#!/usr/bin/env bash
# Architecture-invariant package lint. Checks capabilities/security contracts,
# not a particular release number.
set -uo pipefail
root="$(cd "$(dirname "$0")/../.." && pwd)"
failures=0
pass(){ printf '[OK]   %s\n' "$1"; }
fail(){ printf '[FAIL] %s\n' "$1" >&2; failures=$((failures+1)); }
contains(){ grep -Fq -- "$2" "$1"; }
not_contains_re(){ ! grep -Eq -- "$2" "$1"; }

required=(
  .env.example .build.env.example
  .devcontainer/Dockerfile .devcontainer/devcontainer.json
  .devcontainer/scripts/secret-broker-client.py
  .devcontainer/scripts/secret-broker-server.py
  .devcontainer/scripts/provider-loopback-relay.py
  .devcontainer/scripts/run-with-ssm-secrets.sh
  .devcontainer/scripts/sandbox-command-wrapper.sh
  .devcontainer/scripts/mcp-wrapper-preamble.sh
  .devcontainer/scripts/tavily-mcp-ssm.sh
  .devcontainer/scripts/snyk-mcp-ssm.sh
  .devcontainer/scripts/databricks-sql-mcp-ssm.sh
  .devcontainer/scripts/configure-mcp.sh
  .devcontainer/policies/gemini-managed-settings.json
  .devcontainer/policies/claude-mcp.json
  .devcontainer/policies/tavily-allowed-domains.json
  .devcontainer/scripts/verify-runtime.sh
  .devcontainer/scripts/ado-git.sh
  .devcontainer/scripts/ado-git-policy.sh
  .devcontainer/scripts/git-transparent.sh
  tar/docker-compose.yml ecr/docker-compose.yml
  scripts/tar/load-and-start.sh scripts/tar/load-and-start.ps1
  scripts/ecr/pull-and-start.sh scripts/ecr/pull-and-start.ps1
  scripts/ci/test-broker-policies.py scripts/ci/test-mcp-mode-matrix.sh scripts/ci/test-ado-git-policy.sh
)
for f in "${required[@]}"; do [[ -f "$root/$f" ]] || fail "required file exists: $f"; done

# Host AWS authentication contract.
for k in AWS_AUTH_MODE AZURE_TENANT_ID AZURE_APP_ID_URI AZURE_DEFAULT_USERNAME AZURE_DEFAULT_ROLE_ARN AZURE_DEFAULT_DURATION_HOURS AZURE_DEFAULT_REMEMBER_ME SANDBOX_HOST_AWS_DIR; do
  contains "$root/.env.example" "$k=" || fail ".env.example exposes required host auth field: $k"
done
if not_contains_re "$root/.env.example" '^(AWS_ACCESS_KEY_ID|AWS_SECRET_ACCESS_KEY|AWS_SESSION_TOKEN|AWS_SSO_)='; then
  pass 'runtime template has no static/native-IAM-SSO credential fields'
else
  fail 'legacy AWS credential/Identity Center fields remain in runtime template'
fi
for f in "$root/scripts/tar/load-and-start.sh" "$root/scripts/ecr/pull-and-start.sh"; do
  contains "$f" 'aws-azure-login --profile "$PROFILE" --mode gui' || fail "host browser aws-azure-login flow: ${f#$root/}"
  contains "$f" 'AWS_AUTH_MODE' || fail "host auth mode selection present: ${f#$root/}"
  contains "$f" 'aws configure --profile' || fail "static host-profile guidance present: ${f#$root/}"
  not_contains_re "$f" 'aws sso login|sts get-caller-identity' || fail "no native SSO/STS preflight flow: ${f#$root/}"
done
for f in "$root/scripts/tar/load-and-start.ps1" "$root/scripts/ecr/pull-and-start.ps1"; do
  contains "$f" 'aws-azure-login --profile $Profile --mode gui' || fail "host browser aws-azure-login flow: ${f#$root/}"
  contains "$f" 'AWS_AUTH_MODE' || fail "host auth mode selection present: ${f#$root/}"
  contains "$f" 'aws configure --profile' || fail "static host-profile guidance present: ${f#$root/}"
  not_contains_re "$f" 'aws sso login|sts get-caller-identity' || fail "no native SSO/STS preflight flow: ${f#$root/}"
done
pass 'host authentication flow inspected'

# Compose trust boundary: only the broker gets host AWS state; only the
# devcontainer gets the workspace. This prevents cross-container UID ownership.
for f in "$root/tar/docker-compose.yml" "$root/ecr/docker-compose.yml"; do
  not_contains_re "$f" 'AWS_ACCESS_KEY_ID:|AWS_SECRET_ACCESS_KEY:|AWS_SESSION_TOKEN:|AWS_SSO_' || fail "Compose has no static/native-IAM-SSO credential mapping: ${f#$root/}"
  contains "$f" 'AI_SANDBOX_ROLE: "client"' || fail "AI client role exists: ${f#$root/}"
  contains "$f" 'AI_SANDBOX_ROLE: "broker"' || fail "credential broker role exists: ${f#$root/}"
  contains "$f" 'SANDBOX_HOST_AWS_DIR' || fail "host .aws is broker-mounted: ${f#$root/}"
  [[ "$(grep -c 'target: /home/vscode/.aws' "$f" || true)" == 1 ]] || fail "exactly one .aws bind target exists (broker only): ${f#$root/}"
  broker_block="$(awk '/^  secret-broker:/{p=1} /^  devcontainer:/{p=0} p{print}' "$f")"
  dev_block="$(awk '/^  devcontainer:/{p=1} p{print}' "$f")"
  if grep -Fq 'target: /home/vscode/workspace' <<<"$broker_block"; then fail "broker must not mount workspace: ${f#$root/}"; fi
  if ! grep -Fq 'target: /home/vscode/workspace' <<<"$dev_block"; then fail "devcontainer must mount workspace: ${f#$root/}"; fi
  if grep -Fq '/run/ai-sandbox-snyk' <<<"$broker_block"; then fail "broker must not own Snyk executable tmpfs: ${f#$root/}"; fi
  grep -Fq '/run/ai-sandbox-snyk' <<<"$dev_block" || fail "Snyk executable tmpfs belongs to devcontainer: ${f#$root/}"
  contains "$f" 'cap_drop: [ALL]' || fail "capabilities dropped: ${f#$root/}"
  contains "$f" 'no-new-privileges:true' || fail "no-new-privileges enabled: ${f#$root/}"
done
pass 'Compose credential/workspace boundary inspected'

runner="$root/.devcontainer/scripts/run-with-ssm-secrets.sh"
client="$root/.devcontainer/scripts/secret-broker-client.py"
broker="$root/.devcontainer/scripts/secret-broker-server.py"
wrapper="$root/.devcontainer/scripts/sandbox-command-wrapper.sh"
preamble="$root/.devcontainer/scripts/mcp-wrapper-preamble.sh"

# Broker never executes developer/application commands.
contains "$runner" 'broker-side command execution is disabled' || fail 'retired SSM runner is an explicit fail-closed guard'
contains "$runner" 'exit 126' || fail 'retired SSM runner returns 126'
not_contains_re "$runner" 'aws[[:space:]]+ssm|get_parameter|exec[[:space:]].*\$@' || fail 'retired SSM runner contains no credential fetch/command execution path'
contains "$client" 'broker-side command execution is disabled' || fail 'legacy broker command client is fail closed'
contains "$client" 'SystemExit(126)' || fail 'legacy broker command client returns 126'
contains "$broker" 'command_execution=disabled' || fail 'broker advertises command execution disabled'
contains "$broker" '"ssm", "get-parameter"' || fail 'broker owns SSM get-parameter retrieval'
not_contains_re "$broker" 'subprocess\.(Popen|call|check_call|check_output)|os\.(system|exec)|run-with-ssm-secrets|secret-broker-client|/home/vscode/workspace' || fail 'broker contains no application process/workspace execution path'
[[ "$(grep -Fc 'subprocess.run(' "$broker")" -eq 1 ]] || fail 'broker has exactly one subprocess use (internal AWS SSM read)'
contains "$broker" '["aws", "--profile", AWS_PROFILE, "ssm", "get-parameter"' || fail 'broker subprocess is pinned to AWS SSM get-parameter'
contains "$broker" 'safe_suffix' || fail 'broker rejects route traversal'
contains "$broker" '_enforce_tavily_http' || fail 'broker independently enforces Tavily REST domain policy'
contains "$broker" '_enforce_tavily_mcp' || fail 'broker independently enforces Tavily MCP domain policy'
contains "$broker" '_ado_request_allowed' || fail 'broker restricts ADO PAT use to reviewed Git/PR/pipeline routes'
for needle in 'claude-api-key' 'gemini-api-key' 'snyk-token' 'tavily-api-key' 'ado-pat' '/databricks/anthropic' '/databricks/gemini' '/databricks/sql-mcp'; do
  contains "$broker" "$needle" || fail "credential broker route/parameter exists: $needle"
done
contains "$broker" 'Authorization' || fail 'broker injects service authentication headers'
contains "$root/.devcontainer/scripts/provider-loopback-relay.py" 'LISTEN_HOST = "127.0.0.1"' || fail 'provider relay is loopback-only'
pass 'credential-only broker architecture inspected'

# Every real application command remains in the devcontainer.
contains "$wrapper" 'readonly PROVIDER_BASE="http://127.0.0.1:8771"' || fail 'application wrapper pins credential route to localhost'
contains "$wrapper" 'ai-sandbox-broker-placeholder' || fail 'application processes receive non-secret placeholder auth only'
contains "$wrapper" 'strip_service_secrets' || fail 'application wrapper strips caller-injected service credentials'
contains "$wrapper" 'unset ADO_PAT DATABRICKS_TOKEN DATABRICKS_SQL_MCP_TOKEN' || fail 'application wrapper strips PAT/token variables'
contains "$wrapper" 'export NO_PROXY="localhost,127.0.0.1,squid-proxy' || fail 'application wrapper pins localhost broker bypass'
not_contains_re "$wrapper" 'secret-broker-client|run-with-ssm-secrets' || fail 'application wrapper never delegates process execution to broker'
for cmd in claude gemini databricks tvly snyk; do contains "$wrapper" "real_tool $cmd" || fail "local real executable path is used: $cmd"; done
contains "$wrapper" 'exec "$(real_tool "$agent")" "$@"' || fail 'ucode local MCP/help control delegates to real Claude/Gemini locally'
contains "$wrapper" 'run_audited databricks ucode-claude' || fail 'ucode Claude model process runs locally'
contains "$wrapper" 'run_audited databricks ucode-gemini' || fail 'ucode Gemini model process runs locally'
not_contains_re "$wrapper" 'DATABRICKS_TOKEN=.*get_parameter|export DATABRICKS_TOKEN' || fail 'ucode process never receives real Databricks PAT'
contains "$wrapper" '/run/ai-sandbox-snyk' || fail 'Snyk runtime home is local devcontainer tmpfs'
contains "$wrapper" 'SNYK_API="${PROVIDER_BASE}/snyk"' || fail 'Snyk local CLI uses credential-only localhost API route'
contains "$wrapper" 'tavily-cli-policy.py' || fail 'Tavily local CLI remains behind Admin domain policy'
contains "$root/.devcontainer/scripts/tavily-sitecustomize.py" 'BROKER_BASE = "http://127.0.0.1:8771/tavily-api"' || fail 'Tavily SDK is pinned to localhost credential route'
pass 'local application execution inspected'

# MCP processes are also local and credential-free.
not_contains_re "$preamble" 'export AWS_CONFIG_FILE|export AWS_SHARED_CREDENTIALS_FILE|aws[[:space:]]+ssm' || fail 'MCP preamble does not configure/fetch broker AWS state'
contains "$preamble" 'unset AWS_PROFILE AWS_DEFAULT_PROFILE AWS_CONFIG_FILE AWS_SHARED_CREDENTIALS_FILE' || fail 'MCP preamble strips AWS profile paths'
contains "$preamble" 'unset ADO_PAT DATABRICKS_TOKEN DATABRICKS_SQL_MCP_TOKEN' || fail 'MCP preamble strips caller-injected service credentials'
for f in tavily-mcp-ssm.sh snyk-mcp-ssm.sh databricks-sql-mcp-ssm.sh; do
  path="$root/.devcontainer/scripts/$f"
  not_contains_re "$path" 'secret-broker-client|run-with-ssm-secrets' || fail "MCP process does not execute in broker: $f"
  contains "$path" 'mcp-wrapper-preamble' || fail "MCP wrapper uses credential-free preamble: $f"
done
contains "$root/.devcontainer/scripts/tavily-mcp-ssm.sh" '/usr/local/libexec/ai-sandbox/real/mcp-remote' || fail 'Tavily MCP mcp-remote runs locally'
contains "$root/.devcontainer/scripts/tavily-mcp-ssm.sh" 'tavily-policy-proxy.py' || fail 'Tavily MCP local policy enforcement retained'
contains "$root/.devcontainer/scripts/snyk-mcp-ssm.sh" '/usr/local/libexec/ai-sandbox/real/snyk' || fail 'Snyk MCP process runs locally'
contains "$root/.devcontainer/scripts/snyk-mcp-ssm.sh" 'SNYK_API="$BASE"' || fail 'Snyk MCP uses localhost credential route'
contains "$root/.devcontainer/scripts/databricks-sql-mcp-ssm.sh" '/usr/local/libexec/ai-sandbox/real/mcp-remote' || fail 'Databricks SQL MCP mcp-remote runs locally'
contains "$root/.devcontainer/scripts/databricks-sql-mcp-ssm.sh" '/databricks/sql-mcp' || fail 'Databricks SQL MCP uses broker auth route'
pass 'local MCP execution inspected'

# Git is local. Only validated HTTP is rewritten through the credential route.
git_wrap="$root/.devcontainer/scripts/git-transparent.sh"
git_policy="$root/.devcontainer/scripts/ado-git-policy.sh"
contains "$git_wrap" 'readonly REAL_GIT="/usr/bin/git"' || fail 'transparent Git pins native local Git'
contains "$git_wrap" 'ado-git-policy' || fail 'ADO Git uses local root-owned policy'
not_contains_re "$git_wrap" 'secret-broker-client|run-with-ssm-secrets' || fail 'Git process is never delegated to broker'
contains "$git_policy" 'LOCAL_ADO_BASE="http://127.0.0.1:8771/ado/dev/"' || fail 'ADO Git policy rewrites credentialed HTTP to localhost'
contains "$git_policy" 'insteadOf=https://dev.azure.com/' || fail 'ADO Git preserves native HTTPS remote while routing transport locally'
contains "$git_policy" 'protocol.ext.allow=never' || fail 'ADO Git disables external/custom transports'
not_contains_re "$git_policy" 'ADO_PAT|GIT_ASKPASS|secret-broker-client|run-with-ssm-secrets' || fail 'local Git process never receives PAT/askpass secret path'
not_contains_re "$git_policy" 'ADO_ORG|ADO_PROJECT|ADO_REPO|Admin-approved repository' || fail 'ADO Git policy does not pin repository identity in Sandbox metadata'
contains "$git_wrap" '--force-with-lease=*' || fail 'transparent Git recognizes force-with-lease without breaking ADO routing'
not_contains_re "$git_policy" 'direct push to main/master|force-push refspecs are not approved|destructive Git push option is not approved' || fail 'branch/history governance remains delegated to Azure DevOps'
contains "$root/.devcontainer/scripts/ado-git.sh" '/usr/local/libexec/ai-sandbox/ado-git-policy' || fail 'legacy ado-git alias uses local policy'
not_contains_re "$root/.devcontainer/scripts/ado-git.sh" 'secret-broker-client|run-with-ssm-secrets' || fail 'legacy ado-git alias cannot restore broker process execution'
for f in "$root/ado-scripts/ado-pr-create.sh" "$root/ado-scripts/ado-trigger.sh"; do
  contains "$f" 'http://127.0.0.1:8771' || fail "ADO REST helper uses localhost credential route: ${f#$root/}"
  not_contains_re "$f" 'secret-broker-client|run-with-ssm-secrets|ADO_PAT=' || fail "ADO REST helper is credential-free and local: ${f#$root/}"
done
pass 'local Git/ADO execution inspected'

# MCP set consistency and native ucode argument semantics.
mcp="$root/.devcontainer/scripts/configure-mcp.sh"
gemini_policy="$root/.devcontainer/policies/gemini-managed-settings.json"
for cmd in /usr/local/bin/tavily-mcp-ssm /usr/local/bin/snyk-mcp-ssm /usr/local/bin/databricks-sql-mcp-ssm; do contains "$mcp" "$cmd" || fail "Gemini compatibility MCP includes $cmd"; done
contains "$mcp" 'SYSTEM_GEMINI_SETTINGS="/etc/gemini-cli/settings.json"' || fail 'Gemini synchronizer validates immutable system settings'
contains "$wrapper" 'ensure_gemini_mcp_config' || fail 'Gemini routes self-heal managed MCP registration'
contains "$wrapper" 'if is_local_only_operation "$agent" "${1:-}"; then' || fail 'ucode MCP/help/version commands remain local control operations'
not_contains_re "$wrapper" 'set -- --model|has_model_arg=' || fail 'ucode preserves native Claude/Gemini argv without model-flag injection'
contains "$root/.devcontainer/Dockerfile" 'gemini-managed-settings.json /etc/gemini-cli/settings.json' || fail 'Gemini managed settings are baked into image'
if jq -e '
  (.mcpServers.tavily.command == "/usr/local/bin/tavily-mcp-ssm") and
  (.mcpServers.snyk.command == "/usr/local/bin/snyk-mcp-ssm") and
  (.mcpServers["databricks-sql"].command == "/usr/local/bin/databricks-sql-mcp-ssm") and
  (.mcpServers.tavily.env? == null) and
  (.mcpServers.snyk.env? == null) and
  (.mcpServers["databricks-sql"].env? == null) and
  (.general.enableAutoUpdate == false) and
  (.general.enableAutoUpdateNotification == false)
' "$gemini_policy" >/dev/null 2>&1; then
  pass 'Gemini system MCP policy has all three credential-free local wrappers'
else
  fail 'Gemini system MCP policy is incomplete or unsafe'
fi
not_contains_re "$gemini_policy" '(AKIA|ASIA)[A-Z0-9]{16}|AWS_ACCESS_KEY_ID|AWS_SECRET_ACCESS_KEY|AWS_SESSION_TOKEN|TAVILY_API_KEY|SNYK_TOKEN|DATABRICKS_SQL_MCP_TOKEN' || fail 'Gemini system MCP policy contains no credential material/references'

# New application helper must fail closed for unknown secret-backed apps rather
# than teaching admins to inject secrets into local process environments.
not_contains_re "$root/scripts/applications/application-helper.py" 'AWS_ACCESS_KEY_ID:|AWS_SECRET_ACCESS_KEY:|AWS_SESSION_TOKEN:|SECRET_RUNNER|run-with-ssm-secrets' || fail 'application helper cannot generate legacy credential/process runner paths'
contains "$root/scripts/applications/application-helper.py" 'forbids generic secret_env onboarding' || fail 'generic secret-backed onboarding fails closed pending reviewed HTTP adapter'

# ADO metadata remains caller-selected; SSM stores PAT only.
not_contains_re "$root/.env.example" '/sandbox/ado-(org|project|repo)' || fail 'runtime env documentation still requires ADO org/project/repo SSM metadata'
not_contains_re "$root/ecr/.env.example" '/sandbox/ado-(org|project|repo)' || fail 'ECR env documentation still requires ADO org/project/repo SSM metadata'
not_contains_re "$root/tar/.env.example" '/sandbox/ado-(org|project|repo)' || fail 'TAR env documentation still requires ADO org/project/repo SSM metadata'
not_contains_re "$root/scripts/platform/01-setup-ssm.sh" 'ado-(org|project|repo)' || fail 'Bash SSM bootstrap still creates ADO org/project/repo metadata'
not_contains_re "$root/scripts/platform/01-setup-ssm.ps1" 'ado-(org|project|repo)' || fail 'PowerShell SSM bootstrap still creates ADO org/project/repo metadata'

# Tavily policy remains fail-closed at CLI, MCP and broker layers.
contains "$root/.devcontainer/scripts/tavily-cli-policy.py" 'Tavily auth is disabled in credential-isolated mode' || fail 'Tavily CLI auth command is blocked'
contains "$root/.devcontainer/scripts/tavily-cli-policy.py" 'Tavily research is disabled' || fail 'unconstrained Tavily research is blocked'
contains "$root/.devcontainer/scripts/tavily-policy-proxy.py" 'include_domains' || fail 'Tavily MCP policy constrains search domains'
contains "$broker" 'TAVILY_ALLOWED' || fail 'Tavily broker policy uses root-owned allowlist'

# Host logging invariants.
ps_exporter="$root/scripts/monitoring/export-docker-logs-to-host.ps1"
contains "$ps_exporter" 'StandardOutputEncoding = $DockerUtf8' || fail 'Windows log exporter pins Docker stdout to UTF-8'
contains "$ps_exporter" 'StandardErrorEncoding = $DockerUtf8' || fail 'Windows log exporter pins Docker stderr to UTF-8'
contains "$ps_exporter" '$DevContentLogRoot' || fail 'Windows log exporter has dedicated content log subtree'
contains "$ps_exporter" "if (\$Stream -eq 'content')" || fail 'Windows log exporter routes content separately'
contains "$root/scripts/monitoring/export-docker-logs-to-host.sh" "'devcontainer','content'" || fail 'Linux log exporter routes content separately'
contains "$root/docs/SECURITY-LOGGING-AND-SENTINEL.md" 'devcontainer\content\*.log' || fail 'Sentinel logging guide includes dedicated content collection path'
pass 'UTF-8 and content-log separation invariants inspected'

# Squid/default-deny regression test includes SSRF and whitelist overlap checks.
python3 "$root/scripts/ci/test-squid-policy.py" >/dev/null 2>&1 \
  && pass 'Squid SSRF/default-deny regressions pass' || fail 'Squid policy regression failed'

# Source syntax checks.
syntax_failed=0
while IFS= read -r -d '' f; do bash -n "$f" || syntax_failed=1; done < <(find "$root" -type f -name '*.sh' -print0)
(( syntax_failed == 0 )) && pass 'all Bash sources parse' || fail 'one or more Bash sources have syntax errors'
py_failed=0
while IFS= read -r -d '' f; do PYTHONDONTWRITEBYTECODE=1 python3 -m py_compile "$f" || py_failed=1; done < <(find "$root" -type f -name '*.py' -print0)
(( py_failed == 0 )) && pass 'all Python sources compile' || fail 'one or more Python sources have syntax errors'

# Offline policy/integration regression tests.
TAVILY_POLICY_FILE="$root/.devcontainer/policies/tavily-allowed-domains.json" python3 "$root/scripts/ci/test-broker-policies.py" >/dev/null 2>&1 \
  && pass 'credential-only broker policy regressions pass' || fail 'credential-only broker policy regression failed'
bash "$root/scripts/ci/test-mcp-mode-matrix.sh" >/dev/null 2>&1 \
  && pass 'Claude/Gemini/ucode MCP local-execution regressions pass' || fail 'MCP mode-matrix regression failed'
bash "$root/scripts/ci/test-ado-git-policy.sh" >/dev/null 2>&1 \
  && pass 'ADO Git credential-boundary regressions pass' || fail 'ADO Git credential-boundary regression failed'

# Compose parser is optional in CI, but YAML parse should still happen when
# PyYAML is available.
if python3 -c 'import yaml' >/dev/null 2>&1; then
  python3 - "$root/tar/docker-compose.yml" "$root/ecr/docker-compose.yml" <<'PY' >/dev/null 2>&1
import sys, yaml
for p in sys.argv[1:]:
    with open(p, encoding='utf-8') as f:
        doc=yaml.safe_load(f)
    assert isinstance(doc, dict) and 'services' in doc
PY
  [[ $? -eq 0 ]] && pass 'Compose YAML parses with PyYAML' || fail 'Compose YAML parse failed'
elif command -v docker >/dev/null 2>&1 && docker compose version >/dev/null 2>&1; then
  for f in "$root/tar/docker-compose.yml" "$root/ecr/docker-compose.yml"; do
    SANDBOX_LOG_ROOT=/tmp/ai-sandbox-lint-logs SANDBOX_HOST_AWS_DIR=/tmp/ai-sandbox-lint-aws DEVELOPER_ID=lint \
      docker compose --env-file "$root/.env.example" -f "$f" config >/dev/null 2>&1 \
      && pass "Compose parses: ${f#$root/}" || fail "Compose parse failed: ${f#$root/}"
  done
else
  printf '[WARN] No YAML/Compose parser available; skipped Compose parser check.\n'
fi

if (( failures > 0 )); then printf 'FAILED: %d lint check(s) failed.\n' "$failures" >&2; exit 1; fi
echo 'PASSED: package security/integration invariants hold.'
