#Requires -Version 7.4
# =============================================================================
# ado-trigger.ps1 — Host convenience launcher for the brokered ADO pipeline helper.
#
# Security contract (v1.16.42+):
#   * The Windows host script never accepts, prompts for, or stores ADO_PAT.
#   * Only ADO PAT is stored in SSM. Org/project are explicit target args.
#   * The local helper validates arguments; the broker independently restricts the
#     allowed ADO REST route before injecting ADO_PAT upstream.
# =============================================================================
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$Org,
    [Parameter(Mandatory = $true)][string]$Project,
    [Parameter(Mandatory = $true)][ValidateRange(1,2147483647)][int]$PipelineId,
    [string]$Branch = 'main',
    [string]$Params = '{}',
    [switch]$Wait
)
$ErrorActionPreference = 'Stop'

try {
    $Decoded = $Params | ConvertFrom-Json -AsHashtable
    if ($Decoded -isnot [System.Collections.IDictionary]) { throw 'not an object' }
}
catch { throw 'Params must be a JSON object.' }

$Root = Split-Path -Parent $PSScriptRoot
$SvcDir = if (Test-Path (Join-Path $Root 'tar\docker-compose.yml')) { 'tar' } elseif (Test-Path (Join-Path $Root 'ecr\docker-compose.yml')) { 'ecr' } else { throw 'Cannot locate sandbox docker-compose.yml' }
$ComposeDir = Join-Path $Root $SvcDir

$ToolArgs = @('--org', $Org, '--project', $Project, '--pipeline-id', [string]$PipelineId, '--branch', $Branch, '--params', $Params)
if ($Wait) { $ToolArgs += '--wait' }

Push-Location $ComposeDir
try {
    & docker compose exec -T devcontainer /usr/local/bin/ado-trigger @ToolArgs
    if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
}
finally { Pop-Location }
