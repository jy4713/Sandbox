#!/usr/bin/env bash
# =============================================================================
# PACKAGE MAINTENANCE NOTES
# Purpose: Creates secret-free user-scope MCP registrations for Claude Code and
#          Gemini CLI. Tavily is configured as an SSM-backed MCP server.
# Admin maintenance: When adding/removing an MCP server, update this file plus
#                    its wrapper, SSM profile, Dockerfile, Squid allowlist and
#                    runtime verification.
# Safety rule: Never place API keys or tokens in MCP configuration files.
# =============================================================================
set -euo pipefail
umask 077

export CLAUDE_CONFIG_DIR="${CLAUDE_CONFIG_DIR:-$HOME/.claude}"
export DISABLE_AUTOUPDATER=1
export CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC=1
mkdir -p "$CLAUDE_CONFIG_DIR" "$HOME/.gemini"

readonly REAL_DIR="/usr/local/libexec/ai-sandbox/real"
readonly REAL_CLAUDE="$REAL_DIR/claude"
readonly REAL_GEMINI="$REAL_DIR/gemini"
[[ -x "$REAL_CLAUDE" ]] || { echo 'ERROR: real Claude CLI is missing' >&2; exit 1; }
[[ -x "$REAL_GEMINI" ]] || { echo 'ERROR: real Gemini CLI is missing' >&2; exit 1; }

# Use the real configuration CLIs here. The public `claude` and `gemini`
# commands are SSM-aware execution wrappers and intentionally require runtime
# credentials for model access. MCP configuration itself must remain secret-free
# and must not require an AWS login.

# Tavily is the default web/retrieval integration and is exposed to both AI CLIs
# through an audited stdio MCP wrapper. No Tavily key is written to settings.
"$REAL_CLAUDE" mcp remove tavily --scope user >/dev/null 2>&1 || true
"$REAL_CLAUDE" mcp add-json tavily '{"type":"stdio","command":"/usr/local/bin/tavily-mcp-ssm","args":[]}' --scope user >/dev/null

"$REAL_GEMINI" mcp remove -s user tavily >/dev/null 2>&1 || true
"$REAL_GEMINI" mcp add -s user \
  --timeout 10000 \
  -e 'AWS_ACCESS_KEY_ID=$AWS_ACCESS_KEY_ID' \
  -e 'AWS_SECRET_ACCESS_KEY=$AWS_SECRET_ACCESS_KEY' \
  -e 'AWS_SESSION_TOKEN=$AWS_SESSION_TOKEN' \
  -e 'SANDBOX_AWS_PROFILE=$SANDBOX_AWS_PROFILE' \
  -e 'AWS_REGION=$AWS_REGION' \
  tavily /usr/local/bin/tavily-mcp-ssm >/dev/null

# Snyk MCP remains available for AI-assisted security analysis. Direct `snyk`
# CLI usage is also SSM-aware through the public command wrapper.
"$REAL_CLAUDE" mcp remove snyk --scope user >/dev/null 2>&1 || true
"$REAL_CLAUDE" mcp add-json snyk '{"type":"stdio","command":"/usr/local/bin/snyk-mcp-ssm","args":[]}' --scope user >/dev/null

"$REAL_GEMINI" mcp remove -s user snyk >/dev/null 2>&1 || true
"$REAL_GEMINI" mcp add -s user \
  --timeout 10000 \
  -e 'AWS_ACCESS_KEY_ID=$AWS_ACCESS_KEY_ID' \
  -e 'AWS_SECRET_ACCESS_KEY=$AWS_SECRET_ACCESS_KEY' \
  -e 'AWS_SESSION_TOKEN=$AWS_SESSION_TOKEN' \
  -e 'SANDBOX_AWS_PROFILE=$SANDBOX_AWS_PROFILE' \
  -e 'AWS_REGION=$AWS_REGION' \
  snyk /usr/local/bin/snyk-mcp-ssm >/dev/null

chmod -R go-rwx "$CLAUDE_CONFIG_DIR" "$HOME/.gemini" 2>/dev/null || true
echo '[OK] Secret-free Tavily MCP and Snyk MCP definitions configured for Claude Code and Gemini CLI.'
