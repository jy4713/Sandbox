#!/usr/bin/env bash
# Architecture-invariant package lint. Keep checks capability/security based,
# not tied to a particular release number.
set -uo pipefail
root="$(cd "$(dirname "$0")/../.." && pwd)"
failures=0
pass(){ printf '[OK]   %s\n' "$1"; }
fail(){ printf '[FAIL] %s\n' "$1" >&2; failures=$((failures+1)); }
contains(){ grep -Fq -- "$2" "$1"; }
not_contains_re(){ ! grep -Eq -- "$2" "$1"; }

required=(
  .env.example .build.env.example
  .devcontainer/Dockerfile .devcontainer/devcontainer.json
  .devcontainer/scripts/secret-broker-client.py
  .devcontainer/scripts/secret-broker-server.py
  .devcontainer/scripts/provider-loopback-relay.py
  .devcontainer/scripts/run-with-ssm-secrets.sh
  .devcontainer/scripts/sandbox-command-wrapper.sh
  .devcontainer/scripts/configure-mcp.sh
  .devcontainer/policies/gemini-managed-settings.json
  .devcontainer/scripts/verify-runtime.sh
  .devcontainer/scripts/ado-git.sh
  .devcontainer/scripts/git-transparent.sh
  tar/docker-compose.yml ecr/docker-compose.yml
  scripts/tar/load-and-start.sh scripts/tar/load-and-start.ps1
  scripts/ecr/pull-and-start.sh scripts/ecr/pull-and-start.ps1
)
for f in "${required[@]}"; do [[ -f "$root/$f" ]] || fail "required file exists: $f"; done

# Runtime authentication contract.
for k in AWS_AUTH_MODE AZURE_TENANT_ID AZURE_APP_ID_URI AZURE_DEFAULT_USERNAME AZURE_DEFAULT_ROLE_ARN AZURE_DEFAULT_DURATION_HOURS AZURE_DEFAULT_REMEMBER_ME SANDBOX_HOST_AWS_DIR; do
  contains "$root/.env.example" "$k=" || fail ".env.example exposes required host Azure SAML field: $k"
done
if not_contains_re "$root/.env.example" '^(AWS_ACCESS_KEY_ID|AWS_SECRET_ACCESS_KEY|AWS_SESSION_TOKEN|AWS_SSO_)='; then pass 'runtime template has no static/native-IAM-SSO credential fields'; else fail 'legacy AWS credential/Identity Center fields remain in runtime template'; fi
for f in "$root/tar/docker-compose.yml" "$root/ecr/docker-compose.yml"; do
  not_contains_re "$f" 'AWS_ACCESS_KEY_ID:|AWS_SECRET_ACCESS_KEY:|AWS_SESSION_TOKEN:|AWS_SSO_' || fail "Compose has no static/native-IAM-SSO credential mapping: ${f#$root/}"
  contains "$f" 'AI_SANDBOX_ROLE: "client"' || fail "AI client role exists: ${f#$root/}"
  contains "$f" 'AI_SANDBOX_ROLE: "broker"' || fail "trusted broker role exists: ${f#$root/}"
  contains "$f" 'SANDBOX_HOST_AWS_DIR' || fail "host .aws is broker-mounted: ${f#$root/}"
  # Exactly one runtime .aws bind target is allowed and it must belong to secret-broker.
  count="$(grep -c 'target: /home/vscode/.aws' "$f" || true)"
  [[ "$count" == 1 ]] || fail "exactly one .aws bind target exists (broker only): ${f#$root/}"
  contains "$f" 'read_only: true' || fail "read-only hardening present: ${f#$root/}"
  contains "$f" 'cap_drop: [ALL]' || fail "capabilities dropped: ${f#$root/}"
  contains "$f" 'no-new-privileges:true' || fail "no-new-privileges enabled: ${f#$root/}"
done
pass 'Compose credential boundary inspected'

for f in "$root/scripts/tar/load-and-start.sh" "$root/scripts/ecr/pull-and-start.sh"; do
  contains "$f" 'aws-azure-login --profile "$PROFILE" --mode gui' || fail "host browser aws-azure-login flow: ${f#$root/}"
  not_contains_re "$f" 'aws sso login|sts get-caller-identity' || fail "no native SSO/STS-preflight runtime flow: ${f#$root/}"
  contains "$f" 'AWS_AUTH_MODE' || fail "host auth mode selection present: ${f#$root/}"
  contains "$f" 'aws configure --profile' || fail "static host-profile guidance present: ${f#$root/}"
done
for f in "$root/scripts/tar/load-and-start.ps1" "$root/scripts/ecr/pull-and-start.ps1"; do
  contains "$f" 'aws-azure-login --profile $Profile --mode gui' || fail "host browser aws-azure-login flow: ${f#$root/}"
  not_contains_re "$f" 'aws sso login|sts get-caller-identity' || fail "no native SSO/STS-preflight runtime flow: ${f#$root/}"
  contains "$f" 'AWS_AUTH_MODE' || fail "host auth mode selection present: ${f#$root/}"
  contains "$f" 'aws configure --profile' || fail "static host-profile guidance present: ${f#$root/}"
done
pass 'host browser login flow inspected'

runner="$root/.devcontainer/scripts/run-with-ssm-secrets.sh"
contains "$runner" 'AI_SANDBOX_ROLE:-}" == "broker"' || fail 'SSM secret runner is broker-only'
contains "$runner" 'AWS credential-provider environment source' || fail 'SSM runner refuses AWS credential-provider environment variables'
wrapper="$root/.devcontainer/scripts/sandbox-command-wrapper.sh"
contains "$wrapper" 'SANDBOX_PROVIDER_LOOPBACK_URL' || fail 'provider calls route through loopback broker relay'
contains "$wrapper" 'ai-sandbox-broker-placeholder' || fail 'AI provider process receives dummy auth only'
contains "$wrapper" '/databricks/anthropic' || fail 'ucode Claude route uses Databricks broker'
contains "$wrapper" '/databricks/gemini' || fail 'ucode Gemini route uses Databricks broker'
not_contains_re "$wrapper" 'DATABRICKS_TOKEN=.*get_parameter|export DATABRICKS_TOKEN' || fail 'ucode AI wrapper does not receive Databricks PAT'
contains "$root/.devcontainer/scripts/secret-broker-server.py" 'get_parameter' || fail 'broker owns SSM retrieval'
contains "$root/.devcontainer/scripts/secret-broker-server.py" 'claude-api-key' || fail 'Anthropic credential is broker-side'
contains "$root/.devcontainer/scripts/secret-broker-server.py" 'gemini-api-key' || fail 'Gemini credential is broker-side'
contains "$root/.devcontainer/scripts/secret-broker-server.py" '/databricks/anthropic' || fail 'Databricks Claude provider route is broker-side'
contains "$root/.devcontainer/scripts/secret-broker-server.py" '/databricks/gemini' || fail 'Databricks Gemini provider route is broker-side'
contains "$root/.devcontainer/scripts/secret-broker-server.py" 'approved Databricks hostname' || fail 'Databricks PAT route restricts upstream hostnames'
contains "$root/.devcontainer/scripts/secret-broker-server.py" 'safe_route_suffix' || fail 'provider broker rejects path traversal before privileged routing'
contains "$root/.devcontainer/scripts/provider-loopback-relay.py" '127.0.0.1' || fail 'provider relay is loopback-only'
contains "$runner" 'AWS_CONTAINER_CREDENTIALS_FULL_URI' || fail 'SSM runner strips alternate AWS container/web-identity providers'
contains "$root/.devcontainer/scripts/verify-runtime.sh" 'no alternate AWS credential-provider environment variables' || fail 'runtime verification checks alternate AWS credential providers'
contains "$root/.devcontainer/scripts/tavily-cli-policy.py" 'Tavily auth is disabled in credential-isolated mode' || fail 'Tavily credentialed CLI cannot execute auth commands'
contains "$root/.devcontainer/scripts/ado-git-policy.sh" 'protocol.ext.allow=never' || fail 'ADO Git broker disables external/custom Git transports'
contains "$root/.devcontainer/scripts/secret-broker-server.py" 'Snyk network/authentication override is disabled' || fail 'Snyk broker rejects caller-controlled auth/network overrides'
contains "$runner" 'for a in "${@:2}"; do' || fail 'Snyk runner validates arguments without rejecting its pinned executable path'
contains "$runner" "mode == 'hiddenlayer'" || fail 'HiddenLayer credentialed endpoint is hostname-restricted'
contains "$runner" '--silent --enable-proxy --transport http-only' || fail 'Databricks SQL mcp-remote suppresses header-bearing diagnostic output'
contains "$runner" 'Authorization: Bearer ${DATABRICKS_SQL_MCP_TOKEN}' || fail 'Databricks SQL mcp-remote expands its token internally rather than shell-rendering it into argv'

mcp="$root/.devcontainer/scripts/configure-mcp.sh"
gemini_policy="$root/.devcontainer/policies/gemini-managed-settings.json"
contains "$mcp" '/usr/local/bin/tavily-mcp-ssm' || fail 'Tavily MCP uses broker bridge'
contains "$mcp" '/usr/local/bin/snyk-mcp-ssm' || fail 'Snyk MCP uses broker bridge'
contains "$mcp" '/usr/local/bin/databricks-sql-mcp-ssm' || fail 'Databricks SQL MCP uses broker bridge'
contains "$mcp" 'SYSTEM_GEMINI_SETTINGS="/etc/gemini-cli/settings.json"' || fail 'Gemini MCP synchronizer validates immutable system settings'
contains "$wrapper" 'ensure_gemini_mcp_config' || fail 'Gemini public routes self-heal MCP registration before launch'
contains "$wrapper" 'GEMINI_CLI_SYSTEM_SETTINGS_PATH=/etc/gemini-cli/settings.json' || fail 'Gemini public routes pin the Admin system settings path'
contains "$wrapper" 'if is_local_only_operation "$agent" "${1:-}"' || fail 'ucode agent local MCP/help/version commands bypass Databricks model injection'
not_contains_re "$wrapper" 'set -- --model|has_model_arg=' || fail 'ucode wrapper preserves native Claude/Gemini argv without model-flag injection'
contains "$wrapper" 'export ANTHROPIC_MODEL="$model"' || fail 'ucode Claude default model is environment-routed'
contains "$wrapper" 'export GEMINI_MODEL="$model"' || fail 'ucode Gemini default model is environment-routed'
contains "$root/.devcontainer/Dockerfile" 'gemini-managed-settings.json /etc/gemini-cli/settings.json' || fail 'Gemini managed settings are baked into the image'
if jq -e '''
  (.mcpServers.tavily.command == "/usr/local/bin/tavily-mcp-ssm") and
  (.mcpServers.snyk.command == "/usr/local/bin/snyk-mcp-ssm") and
  (.mcpServers["databricks-sql"].command == "/usr/local/bin/databricks-sql-mcp-ssm") and
  (.mcpServers.tavily.env? == null) and
  (.mcpServers.snyk.env? == null) and
  (.mcpServers["databricks-sql"].env? == null) and
  (.general.enableAutoUpdate == false) and
  (.general.enableAutoUpdateNotification == false)
''' "$gemini_policy" >/dev/null 2>&1; then
  pass 'Gemini system MCP policy has all three credential-free bridges and pinned update policy'
else
  fail 'Gemini system MCP policy is incomplete or unsafe'
fi
not_contains_re "$gemini_policy" '(AKIA|ASIA)[A-Z0-9]{16}|AWS_ACCESS_KEY_ID|AWS_SECRET_ACCESS_KEY|AWS_SESSION_TOKEN|TAVILY_API_KEY|SNYK_TOKEN|DATABRICKS_SQL_MCP_TOKEN' || fail 'Gemini system MCP policy contains no credential material/references'

contains "$root/.devcontainer/scripts/git-transparent.sh" 'exec "$REAL_GIT"' || fail 'transparent Git preserves native local commands'
contains "$root/.devcontainer/scripts/git-transparent.sh" 'secret-broker-client' || fail 'transparent Git routes credentialed ADO operations to broker'
contains "$root/.devcontainer/Dockerfile" '/usr/local/bin/git' || fail 'transparent Git is installed ahead of /usr/bin/git'
contains "$root/.devcontainer/scripts/ado-git.sh" 'secret-broker-client --tool ado-git' || fail 'legacy ADO Git alias remains brokered'
contains "$root/ado-scripts/ado-pr-create.sh" 'secret-broker-client --tool ado-pr-create' || fail 'ADO PR creation is brokered'
contains "$root/ado-scripts/ado-trigger.sh" 'secret-broker-client --tool ado-trigger' || fail 'ADO pipeline trigger is brokered'
not_contains_re "$root/scripts/applications/application-helper.py" 'AWS_ACCESS_KEY_ID:|AWS_SECRET_ACCESS_KEY:|AWS_SESSION_TOKEN:' || fail 'application helper cannot generate AWS credential env blocks'
contains "$root/scripts/applications/application-helper.py" 'forbids generic secret_env onboarding' || fail 'generic new secret integrations fail closed pending broker adapter'

# Host logging invariants: Windows native Docker output must be decoded as
# UTF-8 before it becomes a PowerShell string, and content-bearing records must
# stay in a dedicated subtree rather than leaking into the aggregate file.
ps_exporter="$root/scripts/monitoring/export-docker-logs-to-host.ps1"
contains "$ps_exporter" 'StandardOutputEncoding = $DockerUtf8' || fail 'Windows log exporter pins Docker stdout to UTF-8'
contains "$ps_exporter" 'StandardErrorEncoding = $DockerUtf8' || fail 'Windows log exporter pins Docker stderr to UTF-8'
contains "$ps_exporter" '$DevContentLogRoot' || fail 'Windows log exporter has dedicated content log subtree'
contains "$ps_exporter" "if (\$Stream -eq 'content')" || fail 'Windows log exporter routes content separately'
contains "$root/scripts/monitoring/export-docker-logs-to-host.sh" "'devcontainer','content'" || fail 'Linux log exporter routes content separately'
contains "$root/docs/SECURITY-LOGGING-AND-SENTINEL.md" 'devcontainer\content\*.log' || fail 'Sentinel logging guide includes dedicated content collection path'
pass 'UTF-8 and content-log separation invariants inspected'

# Source syntax checks.
syntax_failed=0
while IFS= read -r -d '' f; do bash -n "$f" || syntax_failed=1; done < <(find "$root" -type f -name '*.sh' -print0)
(( syntax_failed == 0 )) && pass 'all Bash sources parse' || fail 'one or more Bash sources have syntax errors'
py_failed=0
while IFS= read -r -d '' f; do PYTHONDONTWRITEBYTECODE=1 python3 -m py_compile "$f" || py_failed=1; done < <(find "$root" -type f -name '*.py' -print0)
(( py_failed == 0 )) && pass 'all Python sources compile' || fail 'one or more Python sources have syntax errors'

# Offline broker-policy regression tests.
python3 "$root/scripts/ci/test-broker-policies.py" >/dev/null 2>&1 \
  && pass 'secret broker caller-policy regressions pass' || fail 'secret broker caller-policy regression failed'
bash "$root/scripts/ci/test-mcp-mode-matrix.sh" >/dev/null 2>&1 \
  && pass 'Claude/Gemini/ucode MCP mode-matrix regressions pass' || fail 'MCP mode-matrix regression failed'
bash "$root/scripts/ci/test-ado-git-policy.sh" >/dev/null 2>&1 \
  && pass 'ADO Git credential-boundary regressions pass' || fail 'ADO Git credential-boundary regression failed'
python3 "$root/scripts/ci/test-squid-policy.py" >/dev/null 2>&1 \
  && pass 'Squid SSRF/default-deny regressions pass' || fail 'Squid policy regression failed'

# Docker Compose parse is optional when Docker Compose is unavailable in CI.
if command -v docker >/dev/null 2>&1 && docker compose version >/dev/null 2>&1; then
  for f in "$root/tar/docker-compose.yml" "$root/ecr/docker-compose.yml"; do
    SANDBOX_LOG_ROOT=/tmp/ai-sandbox-lint-logs SANDBOX_HOST_AWS_DIR=/tmp/ai-sandbox-lint-aws DEVELOPER_ID=lint \
      docker compose --env-file "$root/.env.example" -f "$f" config >/dev/null 2>&1 \
      && pass "Compose parses: ${f#$root/}" || fail "Compose parse failed: ${f#$root/}"
  done
else
  printf '[WARN] Docker Compose unavailable; skipped Compose parser check.\n'
fi

if (( failures > 0 )); then printf 'FAILED: %d lint check(s) failed.\n' "$failures" >&2; exit 1; fi
echo 'PASSED: package security/integration invariants hold.'
