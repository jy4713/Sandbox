#!/usr/bin/env bash
# Azure DevOps credential-isolated usage/status helper.
set -euo pipefail
mode="${1:-check}"
show_help(){ cat <<'HELP'
ADO authentication - v1.16.39 credential-isolated model

The AI container never receives ADO_PAT. Credentialed operations go through the
trusted secret broker, which fetches ADO values from SSM in broker memory only.

Use normal Git commands:
  git clone https://dev.azure.com/ORG/PROJECT/_git/REPO
  git fetch --prune
  git pull
  git push -u origin feature/ai-123
  ado-pr-create --title "..." --source feature/ai-123
  ado-trigger --pipeline-id 42 --wait

The transparent /usr/local/bin/git front-end executes local Git commands with
/usr/bin/git and relays only credentialed ADO network operations to the broker.
The legacy ado-git command remains available but is not required.

Do NOT use run-with-ssm-secrets from the AI container; it is broker-only.
HELP
}
show_check(){
  echo '=== ADO authentication status ==='
  echo '  PAT source       : AWS SSM, trusted broker only'
  echo '  AI ADO_PAT env   : absent (required)'
  echo '  Disk PAT storage : none'
  if [[ -n "${ADO_PAT:-}" ]]; then
    echo '  [FAIL] ADO_PAT unexpectedly exists in AI process environment'
  else
    echo '  [OK]   ADO_PAT is absent'
  fi
  [[ ! -f "$HOME/.git-credentials" && ! -f "$HOME/.git-credentials-ado" ]] \
    && echo '  [OK]   no Git credential files on disk' \
    || echo '  [FAIL] stale Git credential file found'
  [[ "$(command -v git 2>/dev/null || true)" == /usr/local/bin/git ]] && echo '  [OK]   transparent git broker front-end is installed' || echo '  [FAIL] transparent git front-end missing'
  command -v ado-git >/dev/null 2>&1 && echo '  [OK]   legacy ado-git bridge is installed' || echo '  [WARN] legacy ado-git bridge missing'
  if curl --noproxy '*' -fsS --max-time 5 "${SANDBOX_SECRET_BROKER_HTTP_URL:-http://secret-broker:8770}/healthz" >/dev/null 2>&1; then
    echo '  [OK]   secret broker is reachable'
  else
    echo '  [FAIL] secret broker is not reachable'
  fi
}
case "$mode" in check) show_check ;; help|-h|--help) show_help ;; *) echo "ERROR: unknown mode '$mode'" >&2; exit 2 ;; esac
