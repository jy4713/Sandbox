#!/usr/bin/env bash
# Offline regression: non-Tavily public CLI wrappers must not reject native
# subcommands/options. SSM-backed credentials remain broker-only; this test uses
# stubs and no network.
set -euo pipefail
root="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd -P)"
tmp="$(mktemp -d)"; trap 'rm -rf "$tmp"' EXIT
mkdir -p "$tmp/real" "$tmp/bin" "$tmp/snyk-root"

cat > "$tmp/bin/application-audit" <<'SH'
#!/usr/bin/env bash
exit 0
SH
chmod +x "$tmp/bin/application-audit"

make_stub() {
  local name="$1"
  cat > "$tmp/real/$name" <<'SH'
#!/usr/bin/env bash
printf '%s\n' "$0" > "${NATIVE_CAPTURE:?}"
printf '%s\n' "$@" >> "${NATIVE_CAPTURE:?}"
SH
  chmod +x "$tmp/real/$name"
}
for c in claude gemini ucode snyk databricks tvly; do make_stub "$c"; done

wrapper="$tmp/bin/sandbox-command-wrapper"
sed \
  -e "s|readonly REAL_DIR=\"/usr/local/libexec/ai-sandbox/real\"|readonly REAL_DIR=\"$tmp/real\"|" \
  -e "s|local root=/run/ai-sandbox-snyk h ec|local root=$tmp/snyk-root h ec|" \
  "$root/.devcontainer/scripts/sandbox-command-wrapper.sh" > "$wrapper"
chmod +x "$wrapper"
for c in claude gemini snyk databricks ucode; do ln -s "$wrapper" "$tmp/bin/$c"; done
export PATH="$tmp/bin:/usr/bin:/bin"

capture="$tmp/capture"
export NATIVE_CAPTURE="$capture"

"$tmp/bin/claude" --help --native-test=value
mapfile -t got < "$capture"
[[ "${got[1]:-}" == --help && "${got[2]:-}" == --native-test=value ]] || { echo 'ERROR: claude native help/options changed/rejected' >&2; exit 1; }

"$tmp/bin/gemini" --help --native-test=value
mapfile -t got < "$capture"
[[ "${got[1]:-}" == --help && "${got[2]:-}" == --native-test=value ]] || { echo 'ERROR: gemini native help/options changed/rejected' >&2; exit 1; }

"$tmp/bin/ucode" claude --help --native-agent-flag=value
mapfile -t got < "$capture"
[[ "${got[0]:-}" == "$tmp/real/claude" && "${got[1]:-}" == --help && "${got[2]:-}" == --native-agent-flag=value ]] || { echo 'ERROR: ucode claude agent argv changed/rejected' >&2; exit 1; }

"$tmp/bin/ucode" gemini --help --native-agent-flag=value
mapfile -t got < "$capture"
[[ "${got[0]:-}" == "$tmp/real/gemini" && "${got[1]:-}" == --help && "${got[2]:-}" == --native-agent-flag=value ]] || { echo 'ERROR: ucode gemini agent argv changed/rejected' >&2; exit 1; }

printf 'diagnostic-input\n' | "$tmp/bin/snyk" doctor --stdin
mapfile -t got < "$capture"
[[ "${got[1]:-}" == doctor && "${got[2]:-}" == --stdin ]] || { echo 'ERROR: snyk doctor argv changed/rejected' >&2; exit 1; }

"$tmp/bin/snyk" code test -d --severity-threshold=high
mapfile -t got < "$capture"
[[ "${got[1]:-}" == code && "${got[2]:-}" == test && "${got[3]:-}" == -d && "${got[4]:-}" == --severity-threshold=high ]] || { echo 'ERROR: snyk native options changed/rejected' >&2; exit 1; }

"$tmp/bin/databricks" workspace list /
mapfile -t got < "$capture"
[[ "${got[1]:-}" == workspace && "${got[2]:-}" == list && "${got[3]:-}" == / ]] || { echo 'ERROR: databricks native command changed/rejected' >&2; exit 1; }

"$tmp/bin/ucode" arbitrary-native-subcommand --flag value
mapfile -t got < "$capture"
[[ "${got[1]:-}" == arbitrary-native-subcommand && "${got[2]:-}" == --flag && "${got[3]:-}" == value ]] || { echo 'ERROR: native ucode fallback changed/rejected' >&2; exit 1; }

"$tmp/bin/ucode" status --json
mapfile -t got < "$capture"
[[ "${got[1]:-}" == status && "${got[2]:-}" == --json ]] || { echo 'ERROR: ucode status was intercepted instead of preserving native argv' >&2; exit 1; }

"$tmp/bin/snyk" mcp --help
mapfile -t got < "$capture"
[[ "${got[1]:-}" == mcp && "${got[2]:-}" == --help ]] || { echo 'ERROR: snyk mcp argv changed/rejected' >&2; exit 1; }

echo 'Native command contract regression tests passed'
