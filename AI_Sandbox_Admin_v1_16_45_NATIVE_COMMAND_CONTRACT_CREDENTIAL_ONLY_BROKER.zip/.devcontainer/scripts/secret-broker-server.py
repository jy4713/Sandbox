#!/usr/bin/env python3
"""Credential-only HTTP broker for the AI Secure Sandbox.

v1.16.45 invariant:
* The broker may retrieve SSM credentials and inject them only on fixed provider
  HTTP routes. Tavily domain allowlisting is the sole application-policy exception.
* The broker NEVER executes Git, Snyk, Tavily, Databricks, Claude, Gemini,
  ucode, MCP servers, or any other developer/application command.
* The broker has no workspace mount and therefore cannot create or modify source
  files. All application processes run in the devcontainer as uid/gid 1000.

The AI/devcontainer receives no AWS profile, SSM credential, or real service
secret. Client tools use fixed loopback proxy routes with non-secret placeholder
credentials where a vendor CLI requires an authentication value.
"""
from __future__ import annotations

import argparse
import base64
import http.server
import json
import os
import re
import socket
import subprocess
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

BROKER_HOST = os.environ.get("SANDBOX_SECRET_BROKER_LISTEN", "0.0.0.0")
HTTP_PORT = int(os.environ.get("SANDBOX_SECRET_BROKER_HTTP_PORT", "8770"))
AWS_HOME = os.environ.get("SANDBOX_AWS_HOME", "/home/vscode")
AWS_PROFILE = os.environ.get("SANDBOX_AWS_PROFILE", "sandbox")
AWS_REGION = os.environ.get("AWS_REGION", "eu-west-2")
SSM_PREFIX = os.environ.get("SSM_PREFIX", "/sandbox").rstrip("/")
MAX_BODY = int(os.environ.get("SANDBOX_BROKER_MAX_BODY_BYTES", str(256 * 1024 * 1024)))



POLICY_DIR = Path("/etc/ai-sandbox/policies")
TAVILY_POLICY_PATH = Path(os.environ.get("TAVILY_POLICY_FILE", str(POLICY_DIR / "tavily-allowed-domains.json")))
ADO_POLICY_PATH = Path(os.environ.get("ADO_POLICY_FILE", str(POLICY_DIR / "ado-policy.json")))
DOMAIN_TOKEN_RE = re.compile(
    r"(?i)(?<![@a-z0-9_.-])(?:https?://)?(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}(?::\d+)?(?:/[^\s\"'<>]*)?"
)


def _load_tavily_allowed() -> tuple[str, ...]:
    try:
        raw = json.loads(TAVILY_POLICY_PATH.read_text(encoding="utf-8")).get("allowed_domains")
    except Exception as exc:
        raise RuntimeError("cannot load Admin Tavily domain policy") from exc
    if not isinstance(raw, list) or not raw:
        raise RuntimeError("Admin Tavily domain policy is empty")
    out: list[str] = []
    for item in raw:
        if not isinstance(item, str):
            raise RuntimeError("Admin Tavily domain policy contains an invalid value")
        domain = item.strip().lower().rstrip(".")
        if not re.fullmatch(r"[a-z0-9.-]+", domain) or ".." in domain or domain.startswith("-"):
            raise RuntimeError("Admin Tavily domain policy contains an invalid domain")
        out.append(domain)
    return tuple(dict.fromkeys(out))


TAVILY_ALLOWED = _load_tavily_allowed()


def _load_ado_policy() -> tuple[dict, dict[str, dict]]:
    """Load ADO credential-route metadata only.

    This is intentionally not a Git/REST command policy. The broker keeps the
    PAT on fixed Azure DevOps upstream origins and injects it into whatever
    native ADO HTTP request the DevContainer command generates.
    """
    try:
        data = json.loads(ADO_POLICY_PATH.read_text(encoding="utf-8"))
    except Exception as exc:
        raise RuntimeError("cannot load Admin Azure DevOps route configuration") from exc
    if not isinstance(data, dict) or data.get("policy_version") != 1:
        raise RuntimeError("Admin Azure DevOps route configuration version is unsupported")

    git = data.get("git")
    routes = data.get("broker_routes")
    if not isinstance(git, dict) or not isinstance(routes, list) or not routes:
        raise RuntimeError("Admin Azure DevOps route configuration is incomplete")

    repo_host = git.get("repository_host")
    broker_base = git.get("broker_base")
    rewrite_origin = git.get("rewrite_origin")
    if not isinstance(repo_host, str) or not re.fullmatch(r"[a-z0-9.-]+", repo_host.lower()):
        raise RuntimeError("Admin Azure DevOps repository host is invalid")
    if rewrite_origin != f"https://{repo_host.lower()}/":
        raise RuntimeError("Admin Azure DevOps rewrite origin and repository host are inconsistent")
    if not isinstance(broker_base, str) or not re.fullmatch(r"http://127\.0\.0\.1:8771/ado/[a-z0-9-]+/", broker_base):
        raise RuntimeError("Admin Azure DevOps broker route must remain on the fixed loopback broker")
    expected_prefix = "/" + broker_base.removeprefix("http://127.0.0.1:8771/").rstrip("/")

    route_map: dict[str, dict] = {}
    approved_origins = {"https://dev.azure.com", "https://vssps.dev.azure.com"}
    for route in routes:
        if not isinstance(route, dict):
            raise RuntimeError("Admin Azure DevOps broker route is invalid")
        prefix = route.get("prefix")
        origin = route.get("upstream_origin")
        secret = route.get("credential_parameter")
        auth_kind = route.get("auth_kind")
        if not isinstance(prefix, str) or not re.fullmatch(r"/ado/[a-z0-9-]+", prefix) or prefix in route_map:
            raise RuntimeError("Admin Azure DevOps broker route prefix is invalid")
        if origin not in approved_origins or secret != "ado-pat" or auth_kind != "ado":
            raise RuntimeError("Admin Azure DevOps broker route target/credential configuration is invalid")
        route_map[prefix] = {
            "prefix": prefix,
            "upstream_origin": origin,
            "credential_parameter": secret,
            "auth_kind": auth_kind,
        }

    expected = route_map.get(expected_prefix)
    if expected is None or expected["upstream_origin"] != rewrite_origin.rstrip("/"):
        raise RuntimeError("Admin Azure DevOps Git and broker route configuration are inconsistent")
    return data, route_map


ADO_POLICY, ADO_ROUTES = _load_ado_policy()


def _domain_host(value: str) -> str:
    value = value.strip().lower()
    if value.startswith("*."):
        value = value[2:]
    if "://" in value:
        return (urllib.parse.urlsplit(value).hostname or "").lower().rstrip(".")
    return value.split("/", 1)[0].split(":", 1)[0].rstrip(".")


def _allowed_tavily_host(host: str) -> bool:
    host = host.lower().rstrip(".")
    return bool(host) and any(host == allowed or host.endswith("." + allowed) for allowed in TAVILY_ALLOWED)


def _query_domains(value: object) -> list[str]:
    if not isinstance(value, str):
        return []
    out: list[str] = []
    for match in DOMAIN_TOKEN_RE.finditer(value):
        host = _domain_host(match.group(0))
        if host:
            out.append(host)
    return list(dict.fromkeys(out))


def _approved_domain_list(value: object) -> list[str]:
    if not isinstance(value, list) or not value:
        raise PermissionError("Tavily include_domains must be a non-empty list")
    out: list[str] = []
    for item in value:
        if not isinstance(item, str):
            raise PermissionError("Tavily include_domains contains an invalid value")
        host = _domain_host(item)
        if not _allowed_tavily_host(host):
            raise PermissionError("Tavily domain is outside the Admin allowlist")
        out.append(host)
    return list(dict.fromkeys(out))


def _approved_https_url(value: object) -> str:
    if not isinstance(value, str):
        raise PermissionError("Tavily URL must be a string")
    parsed = urllib.parse.urlsplit(value)
    host = (parsed.hostname or "").lower().rstrip(".")
    if parsed.scheme.lower() != "https" or not _allowed_tavily_host(host):
        raise PermissionError("Tavily URL is outside the Admin allowlist")
    return host


def _enforce_tavily_args(name: str, arguments: dict) -> dict:
    args = dict(arguments)
    if name == "tavily_search":
        explicit = _query_domains(args.get("query"))
        if any(not _allowed_tavily_host(host) for host in explicit):
            raise PermissionError("Tavily query explicitly names a domain outside the Admin allowlist")
        requested = args.get("include_domains")
        approved = list(TAVILY_ALLOWED) if requested in (None, []) else _approved_domain_list(requested)
        if explicit:
            if any(not any(host == inc or host.endswith("." + inc) for inc in approved) for host in explicit):
                raise PermissionError("Tavily include_domains does not cover the explicitly requested domain")
            approved = explicit
        args["include_domains"] = approved
        return args
    if name == "tavily_extract":
        urls = args.get("urls")
        if isinstance(urls, str):
            urls = [urls]
        if not isinstance(urls, list) or not urls:
            raise PermissionError("Tavily extract requires approved HTTPS URLs")
        for url in urls:
            _approved_https_url(url)
        args["urls"] = urls
        return args
    if name in {"tavily_crawl", "tavily_map"}:
        host = _approved_https_url(args.get("url"))
        args["allow_external"] = False
        args["select_domains"] = [rf"^{re.escape(host)}$"]
        return args
    if name == "tavily_research":
        raise PermissionError("Tavily research is disabled because it cannot be domain constrained")
    if name.startswith("tavily_"):
        raise PermissionError("Tavily tool is not approved by Admin policy")
    return args


def _enforce_tavily_http(path: str, body: bytes | None) -> bytes | None:
    if not body:
        raise PermissionError("Tavily API request body is required")
    try:
        payload = json.loads(body.decode("utf-8"))
    except Exception as exc:
        raise PermissionError("Tavily API request must be JSON") from exc
    if not isinstance(payload, dict):
        raise PermissionError("Tavily API request must be a JSON object")
    endpoint = path.rstrip("/")
    mapping = {"/search": "tavily_search", "/extract": "tavily_extract", "/crawl": "tavily_crawl", "/map": "tavily_map", "/research": "tavily_research"}
    name = mapping.get(endpoint)
    if not name:
        raise PermissionError("Tavily API endpoint is not approved by Admin policy")
    payload = _enforce_tavily_args(name, payload)
    return json.dumps(payload, separators=(",", ":")).encode("utf-8")


def _enforce_tavily_mcp(body: bytes | None) -> bytes | None:
    if not body:
        return body
    try:
        payload = json.loads(body.decode("utf-8"))
    except Exception as exc:
        raise PermissionError("Tavily MCP request must be JSON") from exc

    def enforce(message: object) -> object:
        if not isinstance(message, dict) or message.get("method") != "tools/call":
            return message
        params = message.get("params")
        if not isinstance(params, dict):
            raise PermissionError("Tavily MCP tools/call is malformed")
        name = params.get("name")
        args = params.get("arguments")
        if not isinstance(name, str) or not isinstance(args, dict):
            raise PermissionError("Tavily MCP tools/call is malformed")
        params = dict(params)
        params["arguments"] = _enforce_tavily_args(name, args)
        updated = dict(message)
        updated["params"] = params
        return updated

    if isinstance(payload, list):
        payload = [enforce(item) for item in payload]
    else:
        payload = enforce(payload)
    return json.dumps(payload, separators=(",", ":")).encode("utf-8")


def _validate_https_origin(raw: str, suffixes: tuple[str, ...], label: str, *, default: str = "") -> str:
    raw = (raw or default).strip().rstrip("/")
    if not raw:
        return ""
    parsed = urllib.parse.urlsplit(raw)
    if parsed.scheme.lower() != "https" or not parsed.hostname:
        raise RuntimeError(f"{label} must be an https:// origin")
    if parsed.username or parsed.password or parsed.query or parsed.fragment:
        raise RuntimeError(f"{label} must not contain userinfo, query or fragment")
    if parsed.path not in {"", "/"}:
        raise RuntimeError(f"{label} must not contain a path")
    try:
        port = parsed.port
    except ValueError as exc:
        raise RuntimeError(f"{label} contains an invalid port") from exc
    if port not in {None, 443}:
        raise RuntimeError(f"{label} must use HTTPS port 443")
    host = parsed.hostname.rstrip(".").lower()
    if not any(host == s.lstrip(".") or host.endswith(s) for s in suffixes):
        raise RuntimeError(f"{label} is not an approved service hostname")
    return f"https://{host}"


DATABRICKS_HOST = _validate_https_origin(
    os.environ.get("DATABRICKS_HOST", ""),
    (".databricks.com", ".azuredatabricks.net", ".databricks.net"),
    "DATABRICKS_HOST",
)
SNYK_ORIGIN = _validate_https_origin(
    os.environ.get("SNYK_API", ""),
    (".snyk.io", ".snykgov.io"),
    "SNYK_API",
    default="https://api.snyk.io",
)


def log_event(message: str) -> None:
    # Metadata only. Never log path/query/body/header values.
    print(f"[secret-broker] {message}", file=os.sys.stderr, flush=True)


def aws_env() -> dict[str, str]:
    env = os.environ.copy()
    env["HOME"] = AWS_HOME
    env["AWS_CONFIG_FILE"] = f"{AWS_HOME}/.aws/config"
    env["AWS_SHARED_CREDENTIALS_FILE"] = f"{AWS_HOME}/.aws/credentials"
    for key in (
        "AWS_ACCESS_KEY_ID", "AWS_SECRET_ACCESS_KEY", "AWS_SESSION_TOKEN", "AWS_SECURITY_TOKEN",
        "AWS_PROFILE", "AWS_DEFAULT_PROFILE", "AWS_CONTAINER_CREDENTIALS_RELATIVE_URI",
        "AWS_CONTAINER_CREDENTIALS_FULL_URI", "AWS_CONTAINER_AUTHORIZATION_TOKEN",
        "AWS_CONTAINER_AUTHORIZATION_TOKEN_FILE", "AWS_WEB_IDENTITY_TOKEN_FILE", "AWS_ROLE_ARN",
        "AWS_ROLE_SESSION_NAME", "AWS_CREDENTIAL_EXPIRATION",
    ):
        env.pop(key, None)
    return env


_secret_cache: dict[str, tuple[float, str]] = {}
_secret_lock = threading.Lock()


def get_parameter(name: str) -> str:
    now = time.time()
    with _secret_lock:
        cached = _secret_cache.get(name)
        if cached and cached[0] > now:
            return cached[1]
    full = f"{SSM_PREFIX}/{name}"
    cp = subprocess.run(
        ["aws", "--profile", AWS_PROFILE, "ssm", "get-parameter", "--name", full,
         "--with-decryption", "--region", AWS_REGION, "--query", "Parameter.Value", "--output", "text"],
        env=aws_env(), stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=30,
    )
    if cp.returncode != 0:
        raise RuntimeError("SSM credential retrieval failed; refresh the host AWS profile and restart the broker")
    value = cp.stdout.rstrip("\r\n")
    if not value or value == "None":
        raise RuntimeError("required SSM parameter is empty")
    with _secret_lock:
        _secret_cache[name] = (now + 300, value)
    return value


HOP_BY_HOP = {
    "connection", "keep-alive", "proxy-authenticate", "proxy-authorization", "te", "trailers",
    "transfer-encoding", "upgrade", "host", "content-length",
}


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):  # noqa: ANN001
        return None


URL_OPENER = urllib.request.build_opener(urllib.request.ProxyHandler(), NoRedirect())


def safe_suffix(path: str, prefix: str) -> str:
    suffix = path[len(prefix):] or "/"
    probe = suffix
    for _ in range(3):
        decoded = urllib.parse.unquote(probe)
        normalized = decoded.replace("\\", "/")
        if any(seg in {".", ".."} for seg in normalized.split("/")):
            raise ValueError("route traversal is not allowed")
        if any(ch in decoded for ch in ("\x00", "\r", "\n")):
            raise ValueError("route contains invalid control characters")
        if decoded == probe:
            break
        probe = decoded
    return suffix


def _join_target(origin: str, suffix: str, query: str) -> str:
    return origin.rstrip("/") + suffix + (("?" + query) if query else "")


class ProviderProxyHandler(http.server.BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server_version = "AI-Sandbox-CredentialBroker/2"
    sys_version = ""

    def log_message(self, fmt: str, *args: object) -> None:
        return

    def do_GET(self) -> None: self._proxy()
    def do_POST(self) -> None: self._proxy()
    def do_PUT(self) -> None: self._proxy()
    def do_PATCH(self) -> None: self._proxy()
    def do_DELETE(self) -> None: self._proxy()
    def do_HEAD(self) -> None: self._proxy()

    def _error(self, status: int, message: str) -> None:
        body = (message + "\n").encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Connection", "close")
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def _read_body(self) -> bytes | None:
        te = (self.headers.get("Transfer-Encoding") or "").lower()
        if te:
            if te != "chunked":
                raise ValueError("unsupported request transfer encoding")
            chunks: list[bytes] = []
            total = 0
            while True:
                line = self.rfile.readline(128)
                if not line:
                    raise ValueError("unexpected end of chunked request")
                size_token = line.split(b";", 1)[0].strip()
                size = int(size_token, 16)
                if size == 0:
                    while True:
                        trailer = self.rfile.readline(8192)
                        if trailer in (b"\r\n", b"\n", b""):
                            break
                    break
                total += size
                if total > MAX_BODY:
                    raise OverflowError("request body too large")
                chunks.append(self.rfile.read(size))
                if self.rfile.read(2) != b"\r\n":
                    raise ValueError("invalid chunk framing")
            return b"".join(chunks)
        length = int(self.headers.get("Content-Length", "0") or "0")
        if length < 0 or length > MAX_BODY:
            raise OverflowError("request body too large")
        return self.rfile.read(length) if length else None

    def _route(self) -> tuple[str, str, str, str] | None:
        parsed = urllib.parse.urlsplit(self.path)
        path = parsed.path
        if path == "/healthz":
            return ("health", "", "", "")

        # Fixed Admin routes. The caller cannot select an arbitrary upstream.
        routes: list[tuple[str, str, str, str]] = [
            ("/anthropic", "https://api.anthropic.com", "claude-api-key", "anthropic"),
            ("/gemini", "https://generativelanguage.googleapis.com", "gemini-api-key", "gemini"),
            ("/snyk", SNYK_ORIGIN, "snyk-token", "snyk"),
            ("/tavily-api", "https://api.tavily.com", "tavily-api-key", "tavily"),
            ("/tavily-mcp", "https://mcp.tavily.com/mcp", "tavily-api-key", "tavily-mcp"),
        ]
        routes.extend(
            (route["prefix"], route["upstream_origin"], route["credential_parameter"], route["auth_kind"])
            for route in ADO_ROUTES.values()
        )
        if DATABRICKS_HOST:
            routes.extend([
                ("/databricks/anthropic", DATABRICKS_HOST + "/ai-gateway/anthropic", "databricks-token", "databricks"),
                ("/databricks/gemini", DATABRICKS_HOST + "/ai-gateway/gemini", "databricks-token", "databricks"),
                ("/databricks/api", DATABRICKS_HOST, "databricks-token", "databricks"),
                ("/databricks/sql-mcp", DATABRICKS_HOST + "/api/2.0/mcp/sql", "databricks-sql-mcp-token", "databricks"),
            ])

        for prefix, target, secret, auth_kind in sorted(routes, key=lambda r: len(r[0]), reverse=True):
            if path != prefix and not path.startswith(prefix + "/"):
                continue
            try:
                suffix = safe_suffix(path, prefix)
            except ValueError:
                return None
            query_pairs = urllib.parse.parse_qsl(parsed.query, keep_blank_values=True)
            if auth_kind == "gemini" or prefix == "/databricks/gemini":
                query_pairs = [(k, v) for k, v in query_pairs if k.lower() != "key"]
            query = urllib.parse.urlencode(query_pairs, doseq=True)
            # Fixed endpoint routes should not gain an extra slash for their root request.
            if prefix in {"/tavily-mcp", "/databricks/sql-mcp"} and suffix == "/":
                suffix = ""
            return (prefix, _join_target(target, suffix, query), secret, auth_kind)
        return None

    def _rewrite_location(self, location: str) -> str | None:
        try:
            p = urllib.parse.urlsplit(location)
        except Exception:
            return None
        if p.scheme != "https" or p.username or p.password:
            return None
        try:
            port = p.port
        except ValueError:
            return None
        if port not in {None, 443}:
            return None
        origin = f"https://{(p.hostname or '').lower().rstrip('.')}"
        local = "http://127.0.0.1:8771"
        for route in ADO_ROUTES.values():
            if origin == route["upstream_origin"]:
                return local + route["prefix"] + (p.path or "/") + (("?" + p.query) if p.query else "")
        return None

    def _proxy(self) -> None:
        route = self._route()
        if route is None:
            self._error(404, "route not available")
            return
        prefix, target_url, secret_name, auth_kind = route
        if prefix == "health":
            body = b"ok\n"
            self.send_response(200)
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            if self.command != "HEAD": self.wfile.write(body)
            return
        try:
            body = self._read_body()
            parsed_client = urllib.parse.urlsplit(self.path)
            # ADO is a fixed-origin credential route, not a CLI/API command
            # allowlist. Native Git/ADO command semantics are preserved; Azure
            # DevOps permissions on the PAT remain the authorization boundary.
            if prefix == "/tavily-api":
                body = _enforce_tavily_http(parsed_client.path[len(prefix):] or "/", body)
            elif prefix == "/tavily-mcp" and self.command in {"POST", "PUT", "PATCH"}:
                body = _enforce_tavily_mcp(body)
            secret = get_parameter(secret_name)
        except OverflowError as exc:
            self._error(413, str(exc)); return
        except PermissionError as exc:
            self._error(403, str(exc)); return
        except Exception as exc:
            self._error(503, str(exc)); return

        headers: dict[str, str] = {}
        for k, v in self.headers.items():
            lk = k.lower()
            if lk in HOP_BY_HOP or lk in {
                "authorization", "x-api-key", "x-goog-api-key", "x-snyk-token", "private-token",
            }:
                continue
            headers[k] = v

        if auth_kind == "anthropic":
            headers["x-api-key"] = secret
        elif auth_kind == "gemini":
            headers["x-goog-api-key"] = secret
        elif auth_kind == "snyk":
            headers["Authorization"] = f"token {secret}"
        elif auth_kind in {"tavily", "tavily-mcp", "databricks"}:
            headers["Authorization"] = f"Bearer {secret}"
        elif auth_kind == "ado":
            encoded = base64.b64encode((":" + secret).encode("utf-8")).decode("ascii")
            headers["Authorization"] = f"Basic {encoded}"

        req = urllib.request.Request(target_url, data=body, headers=headers, method=self.command)
        try:
            resp = URL_OPENER.open(req, timeout=300)
        except urllib.error.HTTPError as exc:
            resp = exc
        except Exception:
            self._error(502, "upstream request failed")
            return

        try:
            self.send_response(resp.status)
            for k, v in resp.headers.items():
                lk = k.lower()
                if lk in HOP_BY_HOP:
                    continue
                if lk == "location":
                    rewritten = self._rewrite_location(v)
                    if rewritten:
                        self.send_header("Location", rewritten)
                    continue
                self.send_header(k, v)
            self.send_header("Connection", "close")
            self.end_headers()
            if self.command != "HEAD":
                while True:
                    chunk = resp.read(65536)
                    if not chunk:
                        break
                    self.wfile.write(chunk)
                    self.wfile.flush()
        except (BrokenPipeError, ConnectionResetError):
            pass
        finally:
            try: resp.close()
            except Exception: pass
            self.close_connection = True


class ThreadingHTTPServer(http.server.ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True


def healthcheck() -> int:
    try:
        with socket.create_connection(("127.0.0.1", HTTP_PORT), timeout=2):
            return 0
    except OSError:
        return 1


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--healthcheck", action="store_true")
    ns = parser.parse_args()
    if ns.healthcheck:
        return healthcheck()
    if os.environ.get("AI_SANDBOX_ROLE") != "broker":
        print("ERROR: secret broker must run with AI_SANDBOX_ROLE=broker", file=os.sys.stderr)
        return 1
    if not (Path(AWS_HOME) / ".aws" / "config").exists() and not (Path(AWS_HOME) / ".aws" / "credentials").exists():
        print("ERROR: host AWS profile is not mounted into the secret broker", file=os.sys.stderr)
        return 1
    server = ThreadingHTTPServer((BROKER_HOST, HTTP_PORT), ProviderProxyHandler)
    log_event(f"ready credential_proxy_port={HTTP_PORT}; command_execution=disabled")
    try:
        server.serve_forever(poll_interval=0.5)
    except KeyboardInterrupt:
        pass
    finally:
        server.shutdown(); server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
