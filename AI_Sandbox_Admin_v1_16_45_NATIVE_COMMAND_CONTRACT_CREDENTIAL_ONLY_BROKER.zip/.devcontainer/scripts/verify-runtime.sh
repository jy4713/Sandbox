#!/usr/bin/env bash
# Runtime security/component verification inside the AI devcontainer - v1.16.45.
set -uo pipefail
failures=0; warnings=0
check(){ local d="$1"; shift; if "$@" >/dev/null 2>&1; then printf '  [OK]   %s\n' "$d"; else printf '  [FAIL] %s\n' "$d" >&2; failures=$((failures+1)); fi; }
soft_check(){ local d="$1"; shift; if "$@" >/dev/null 2>&1; then printf '  [OK]   %s\n' "$d"; else printf '  [WARN] %s\n' "$d" >&2; warnings=$((warnings+1)); fi; }

echo '=== Runtime security verification v1.16.45 ==='
echo; echo '-- Identity and privileges --'
check 'running as UID 1000' test "$(id -u)" = 1000
check 'running as GID 1000' test "$(id -g)" = 1000
check 'sudo is not installed' bash -c '! command -v sudo >/dev/null 2>&1'
check 'effective capabilities are zero' bash -c '[[ "$(awk "/^CapEff:/ {print \$2}" /proc/self/status)" == 0000000000000000 ]]'
check 'no-new-privileges is set' bash -c '[[ "$(awk "/^NoNewPrivs:/ {print \$2}" /proc/self/status)" == 1 ]]'

echo; echo '-- Filesystem and local execution identity --'
check 'root filesystem is read-only' bash -c 'if touch /etc/.sandbox-write-test 2>/dev/null; then rm -f /etc/.sandbox-write-test; exit 1; fi'
check 'no SUID or SGID files remain' bash -c '[[ -z "$(find / -xdev -type f -perm /6000 -print -quit 2>/dev/null)" ]]'
check 'umask is 027 (non-login bash)' bash -c 'u="$(bash -c umask)"; [[ "$u" == 0027 || "$u" == 027 ]]'
check '/tmp is noexec' bash -c 'findmnt -no OPTIONS /tmp | grep -q noexec'
check 'Snyk runtime tmpfs is exec-enabled and hardened' bash -c 'opts="$(findmnt -no OPTIONS /run/ai-sandbox-snyk)"; [[ -w /run/ai-sandbox-snyk && ",${opts}," != *,noexec,* && ",${opts}," == *,nosuid,* && ",${opts}," == *,nodev,* ]]'
check 'workspace is writable' bash -c 'touch /home/vscode/workspace/.verify-test && rm -f /home/vscode/workspace/.verify-test'
check 'devcontainer writes remain vscode-owned, including local Git directories' bash -c '
  base="$(mktemp -d /home/vscode/workspace/.owner-verify.XXXXXX)" || exit 1
  trap '\''rm -rf "$base"'\'' EXIT
  [[ "$(stat -c %u:%g "$base")" == 1000:1000 ]] || exit 1
  /usr/bin/git init -q "$base/repo" || exit 1
  [[ "$(stat -c %u:%g "$base/repo")" == 1000:1000 ]] || exit 1
  printf x > "$base/repo/source.py" || exit 1
  [[ "$(stat -c %u:%g "$base/repo/source.py")" == 1000:1000 ]]
'
check 'protected sandbox host log mount is non-writable' bash -c '[[ -d /var/log/sandbox && ! -w /var/log/sandbox ]]'
check 'Docker socket is not mounted' bash -c '[[ ! -e /var/run/docker.sock ]]'

echo; echo '-- Credential isolation --'
check 'container role is AI client' bash -c '[[ "${AI_SANDBOX_ROLE:-}" == client ]]'
check 'IMDS is disabled' bash -c '[[ "${AWS_EC2_METADATA_DISABLED:-}" == true ]]'
check 'no AWS bootstrap credential environment variables' bash -c '! env | grep -Eq "^AWS_(ACCESS_KEY_ID|SECRET_ACCESS_KEY|SESSION_TOKEN|SECURITY_TOKEN)="'
check 'no alternate AWS credential-provider environment variables' bash -c '! env | grep -Eq "^AWS_(CONTAINER_CREDENTIALS_RELATIVE_URI|CONTAINER_CREDENTIALS_FULL_URI|CONTAINER_AUTHORIZATION_TOKEN|CONTAINER_AUTHORIZATION_TOKEN_FILE|WEB_IDENTITY_TOKEN_FILE|ROLE_ARN|ROLE_SESSION_NAME|CREDENTIAL_EXPIRATION)="'
check 'no AWS profile/config path variables in AI environment' bash -c '[[ -z "${AWS_PROFILE:-}${AWS_DEFAULT_PROFILE:-}${AWS_CONFIG_FILE:-}${AWS_SHARED_CREDENTIALS_FILE:-}${SANDBOX_AWS_HOME:-}${SANDBOX_AWS_PROFILE:-}" ]]'
check 'no AWS credential file in AI container' bash -c '[[ ! -f "$HOME/.aws/credentials" ]]'
check 'no AWS SSO token cache in AI container' bash -c '[[ ! -d "$HOME/.aws/sso/cache" ]]'
check 'no application/service secrets in parent environment' bash -c '! env | grep -Eq "^(ADO_PAT|DATABRICKS_TOKEN|DATABRICKS_SQL_MCP_TOKEN|GEMINI_API_KEY|ANTHROPIC_API_KEY|TAVILY_API_KEY|SNYK_TOKEN|HIDDENLAYER_CLIENT_ID|HIDDENLAYER_CLIENT_SECRET)="'
check 'retired SSM command runner refuses every invocation' bash -c '/usr/local/bin/run-with-ssm-secrets --profile tavily -- /bin/true >/dev/null 2>&1; [[ $? -eq 126 ]]'
check 'legacy broker command client refuses every invocation' bash -c '/usr/local/bin/secret-broker-client --tool snyk-cli test >/dev/null 2>&1; [[ $? -eq 126 ]]'
check 'legacy Git askpass refuses direct use' bash -c '/usr/local/bin/git-askpass-ado Password >/dev/null 2>&1; [[ $? -eq 126 ]]'
check 'credential broker health endpoint is reachable through localhost relay' bash -c 'curl --noproxy "*" -fsS --max-time 5 http://127.0.0.1:8771/healthz >/dev/null'
check 'broker server has no application subprocess launcher' bash -c '! grep -Eq "subprocess\.(Popen|call|check_call|check_output)|os\.(system|exec)" /usr/local/bin/secret-broker-server && [[ "$(grep -Fc "subprocess.run(" /usr/local/bin/secret-broker-server)" -eq 1 ]] && grep -Fq "command_execution=disabled" /usr/local/bin/secret-broker-server'
check 'broker SSM retrieval is limited to internal aws get-parameter code' bash -c 'grep -Fq "ssm\", \"get-parameter" /usr/local/bin/secret-broker-server && ! grep -Fq "run-with-ssm-secrets" /usr/local/bin/secret-broker-server'
check 'AWS SSM direct read is not credentialed' bash -c 'AWS_EC2_METADATA_DISABLED=true aws ssm get-parameter --name /__ai_sandbox_noop__ --region "${AWS_REGION:-eu-west-2}" --output text >/tmp/aws-no-cred.out 2>&1; rc=$?; rm -f /tmp/aws-no-cred.out; [[ $rc -ne 0 ]]'

echo; echo '-- Local command execution and managed credential routes --'
check 'public application wrapper has no broker command execution client' bash -c '! grep -Eq "secret-broker-client|run-with-ssm-secrets" /usr/local/libexec/ai-sandbox/sandbox-command-wrapper'
check 'application wrapper strips inherited service credential variables' bash -c 'grep -Fq "strip_service_secrets" /usr/local/libexec/ai-sandbox/sandbox-command-wrapper && grep -Fq "unset ADO_PAT DATABRICKS_TOKEN DATABRICKS_SQL_MCP_TOKEN" /usr/local/libexec/ai-sandbox/sandbox-command-wrapper'
check 'Claude executes the stashed local Claude binary' bash -c 'grep -Fq '\''$(real_tool claude)'\'' /usr/local/libexec/ai-sandbox/sandbox-command-wrapper && grep -Fq "/anthropic" /usr/local/libexec/ai-sandbox/sandbox-command-wrapper'
check 'Gemini executes the stashed local Gemini binary' bash -c 'grep -Fq '\''$(real_tool gemini)'\'' /usr/local/libexec/ai-sandbox/sandbox-command-wrapper && grep -Fq "/gemini" /usr/local/libexec/ai-sandbox/sandbox-command-wrapper'
check 'ucode Claude/Gemini execute locally with brokered Databricks HTTP auth' bash -c 'grep -Fq "run_audited databricks ucode-claude" /usr/local/libexec/ai-sandbox/sandbox-command-wrapper && grep -Fq "run_audited databricks ucode-gemini" /usr/local/libexec/ai-sandbox/sandbox-command-wrapper && grep -Fq "/databricks/anthropic" /usr/local/libexec/ai-sandbox/sandbox-command-wrapper && grep -Fq "/databricks/gemini" /usr/local/libexec/ai-sandbox/sandbox-command-wrapper && ! grep -Eq "DATABRICKS_TOKEN=.*get_parameter|export DATABRICKS_TOKEN" /usr/local/libexec/ai-sandbox/sandbox-command-wrapper'
check 'Databricks CLI executes locally with placeholder-only token' bash -c 'grep -Fq '\''$(real_tool databricks)'\'' /usr/local/libexec/ai-sandbox/sandbox-command-wrapper && grep -Fq "/databricks/api" /usr/local/libexec/ai-sandbox/sandbox-command-wrapper'
check 'Tavily CLI executes locally through Admin policy and localhost API route' bash -c 'grep -Fq "tavily-cli-policy.py" /usr/local/libexec/ai-sandbox/sandbox-command-wrapper && grep -Fq '\''$(real_tool tvly)'\'' /usr/local/libexec/ai-sandbox/sandbox-command-wrapper && grep -Fq "/tavily-api" /usr/local/libexec/ai-sandbox/sandbox-command-wrapper'
check 'Snyk CLI executes locally with local filesystem access and localhost API route' bash -c 'grep -Fq "real_tool snyk" /usr/local/libexec/ai-sandbox/sandbox-command-wrapper && grep -Fq "SNYK_API=" /usr/local/libexec/ai-sandbox/sandbox-command-wrapper && grep -Fq "/snyk" /usr/local/libexec/ai-sandbox/sandbox-command-wrapper'
check 'Snyk native subcommands/options are not sandbox-blocked' bash -c '! grep -Eq "validate_snyk_args|Snyk command is not approved|Snyk debug/network/authentication override" /usr/local/libexec/ai-sandbox/sandbox-command-wrapper'
check 'Databricks native subcommands/options are not sandbox-blocked' bash -c '! grep -Eq "validate_databricks_cli|Databricks CLI command is not approved|Databricks CLI option is not approved" /usr/local/libexec/ai-sandbox/sandbox-command-wrapper'
check 'Snyk local runtime uses an ephemeral vscode-owned home, not broker workspace access' bash -c 'grep -Fq "/run/ai-sandbox-snyk" /usr/local/libexec/ai-sandbox/sandbox-command-wrapper && ! grep -Eq "secret-broker-client|run-with-ssm-secrets" /usr/local/bin/snyk-mcp-ssm'
check 'transparent Git executes /usr/bin/git locally and uses ADO URL rewrite policy' bash -c '[[ "$(command -v git)" == /usr/local/bin/git ]] && grep -Fq '\''readonly REAL_GIT="/usr/bin/git"'\'' /usr/local/bin/git && grep -Fq "ado-git-policy" /usr/local/bin/git && ! grep -Fq "secret-broker-client" /usr/local/bin/git'
check 'ADO Git adapter consumes shared route policy without command gating' bash -c 'grep -Fq '"'"'ADO_POLICY_FILE="/etc/ai-sandbox/policies/ado-policy.json"'"'"' /usr/local/libexec/ai-sandbox/ado-git-policy && grep -Fq '"'"'.git.broker_base'"'"' /usr/local/libexec/ai-sandbox/ado-git-policy && ! grep -Eq '"'"'allowed_operations|not approved by Sandbox policy|GIT_CONFIG_GLOBAL=/dev/null|GIT_CONFIG_NOSYSTEM=1'"'"' /usr/local/libexec/ai-sandbox/ado-git-policy'
check 'legacy ado-git alias executes the local ADO Git policy' bash -c 'grep -Fq "/usr/local/libexec/ai-sandbox/ado-git-policy" /usr/local/bin/ado-git && ! grep -Fq "secret-broker-client" /usr/local/bin/ado-git'

echo; echo '-- Managed MCP --'
check 'Claude managed MCP config is root-owned and non-writable' bash -c '[[ -r /etc/claude-code/managed-mcp.json && "$(stat -c %U:%G /etc/claude-code/managed-mcp.json)" == root:root && ! -w /etc/claude-code/managed-mcp.json ]]'
check 'Claude managed MCP set contains Tavily/Snyk/Databricks SQL local wrappers' bash -c 'jq -e '\''(.mcpServers.tavily.command=="/usr/local/bin/tavily-mcp-ssm") and (.mcpServers.snyk.command=="/usr/local/bin/snyk-mcp-ssm") and (.mcpServers["databricks-sql"].command=="/usr/local/bin/databricks-sql-mcp-ssm")'\'' /etc/claude-code/managed-mcp.json >/dev/null'
check 'Gemini system settings are root-owned and non-writable' bash -c '[[ -r /etc/gemini-cli/settings.json && "$(stat -c %U:%G /etc/gemini-cli/settings.json)" == root:root && ! -w /etc/gemini-cli/settings.json ]]'
check 'Gemini system MCP set matches Claude and contains no secret env blocks' bash -c 'jq -e '\''(.mcpServers.tavily.command=="/usr/local/bin/tavily-mcp-ssm") and (.mcpServers.snyk.command=="/usr/local/bin/snyk-mcp-ssm") and (.mcpServers["databricks-sql"].command=="/usr/local/bin/databricks-sql-mcp-ssm") and (.mcpServers.tavily.env?==null) and (.mcpServers.snyk.env?==null) and (.mcpServers["databricks-sql"].env?==null)'\'' /etc/gemini-cli/settings.json >/dev/null'
check 'Gemini auto-update is disabled by system policy' bash -c 'jq -e '\''(.general.enableAutoUpdate==false) and (.general.enableAutoUpdateNotification==false)'\'' /etc/gemini-cli/settings.json >/dev/null'
check 'Gemini user compatibility state has all managed MCP wrappers' bash -c 'jq -e '\''(.mcpServers.tavily.command=="/usr/local/bin/tavily-mcp-ssm") and (.mcpServers.snyk.command=="/usr/local/bin/snyk-mcp-ssm") and (.mcpServers["databricks-sql"].command=="/usr/local/bin/databricks-sql-mcp-ssm")'\'' "$HOME/.gemini/settings.json" >/dev/null'
check 'ucode agent MCP commands stay local and model-free' grep -Fq 'if is_local_only_operation "$agent" "${1:-}"' /usr/local/libexec/ai-sandbox/sandbox-command-wrapper
check 'Tavily MCP runs local mcp-remote plus local domain-policy relay' bash -c 'grep -Fq "/usr/local/libexec/ai-sandbox/real/mcp-remote" /usr/local/bin/tavily-mcp-ssm && grep -Fq "tavily-policy-proxy.py" /usr/local/bin/tavily-mcp-ssm && ! grep -Eq "secret-broker-client|run-with-ssm-secrets" /usr/local/bin/tavily-mcp-ssm'
check 'Snyk MCP runs local real Snyk process' bash -c 'grep -Fq "/usr/local/libexec/ai-sandbox/real/snyk" /usr/local/bin/snyk-mcp-ssm && grep -Fq "SNYK_API=" /usr/local/bin/snyk-mcp-ssm && ! grep -Eq "secret-broker-client|run-with-ssm-secrets" /usr/local/bin/snyk-mcp-ssm'
check 'Databricks SQL MCP runs local mcp-remote and broker injects only HTTP auth' bash -c 'grep -Fq "/usr/local/libexec/ai-sandbox/real/mcp-remote" /usr/local/bin/databricks-sql-mcp-ssm && grep -Fq "/databricks/sql-mcp" /usr/local/bin/databricks-sql-mcp-ssm && ! grep -Eq "secret-broker-client|run-with-ssm-secrets" /usr/local/bin/databricks-sql-mcp-ssm'
check 'MCP preamble strips AWS/profile state instead of configuring AWS' bash -c 'grep -Fq "unset AWS_PROFILE AWS_DEFAULT_PROFILE AWS_CONFIG_FILE AWS_SHARED_CREDENTIALS_FILE" /usr/local/libexec/ai-sandbox/mcp-wrapper-preamble && ! grep -Eq "export AWS_CONFIG_FILE|export AWS_SHARED_CREDENTIALS_FILE|aws ssm" /usr/local/libexec/ai-sandbox/mcp-wrapper-preamble'
check 'MCP preamble strips inherited service credential variables' bash -c 'grep -Fq "unset ADO_PAT DATABRICKS_TOKEN DATABRICKS_SQL_MCP_TOKEN" /usr/local/libexec/ai-sandbox/mcp-wrapper-preamble'

echo; echo '-- Policy and logging --'
check 'Tavily allowlist is root-owned and non-writable' bash -c '[[ -r /etc/ai-sandbox/policies/tavily-allowed-domains.json && "$(stat -c %U:%G /etc/ai-sandbox/policies/tavily-allowed-domains.json)" == root:root && ! -w /etc/ai-sandbox/policies/tavily-allowed-domains.json ]]'
check 'ADO policy is root-owned and non-writable' bash -c '[[ -r /etc/ai-sandbox/policies/ado-policy.json && "$(stat -c %U:%G /etc/ai-sandbox/policies/ado-policy.json)" == root:root && ! -w /etc/ai-sandbox/policies/ado-policy.json ]]'
check 'ADO policy drives local routing, local Git and broker enforcement' bash -c 'jq -e '"'"'(.policy_version==1) and (.git.repository_host=="dev.azure.com") and ([.broker_routes[].prefix]|sort==["/ado/dev","/ado/vssps"])'"'"' /etc/ai-sandbox/policies/ado-policy.json >/dev/null && grep -Fq "/etc/ai-sandbox/policies/ado-policy.json" /usr/local/bin/git && grep -Fq "/etc/ai-sandbox/policies/ado-policy.json" /usr/local/libexec/ai-sandbox/ado-git-policy && grep -Fq "ADO_POLICY_PATH" /usr/local/bin/secret-broker-server && grep -Fq "ADO_ROUTES" /usr/local/bin/secret-broker-server'
check 'Tavily MCP fail-closed local policy proxy is installed' test -x /usr/local/libexec/ai-sandbox/tavily-policy-proxy.py
check 'credential broker independently enforces Tavily domain policy' bash -c 'grep -Fq "_enforce_tavily_http" /usr/local/bin/secret-broker-server && grep -Fq "_enforce_tavily_mcp" /usr/local/bin/secret-broker-server'
check 'credential broker keeps ADO on fixed credential routes without command/path/method allowlisting' bash -c '! grep -Eq "_ado_request_allowed|approved Git/PR/pipeline policy|allowed_operations|repository_path_regex|query_requirements" /usr/local/bin/secret-broker-server && grep -Fq "ADO_ROUTES" /usr/local/bin/secret-broker-server'
check 'Claude native WebSearch/WebFetch are denied' bash -c 'jq -e '\''(.permissions.deny | index("WebSearch")) != null and (.permissions.deny | index("WebFetch")) != null'\'' /etc/claude-code/managed-settings.json >/dev/null'
check 'managed log emitter targets Docker PID1 stream' grep -Fq 'target="/proc/1/fd/1"' /usr/local/bin/sandbox-log-emit
check 'application audit required by default' bash -c '[[ "${SANDBOX_AUDIT_REQUIRED:-true}" == true ]]'

echo; echo '-- Required tools --'
for tool in node python3 git vi jq flock aws az databricks claude gemini ucode tvly tavily-mcp snyk run-with-ssm-secrets secret-broker-client provider-loopback-relay application-audit git-askpass-ado ado-git ado-pr-create ado-trigger configure-mcp sandbox-info tavily-mcp-ssm databricks-sql-mcp-ssm snyk-mcp-ssm claude-audit-hook; do
  check "$tool is available" command -v "$tool"
done
check 'in-container AWS login helpers are absent' bash -c '! command -v sandbox-aws-login >/dev/null && ! command -v configure-aws-sso >/dev/null && ! command -v aws-azure-login >/dev/null'
check 'read-only build provenance exists' test -r /etc/ai-sandbox/build-info.json
check 'stashed real application executables are available' bash -c 'for c in claude gemini ucode tvly tavily-mcp mcp-remote snyk databricks; do [[ -x "/usr/local/libexec/ai-sandbox/real/$c" ]]; done'

if [[ -n "${DATABRICKS_HOST:-}" ]]; then
  check 'DATABRICKS_HOST uses https' bash -c '[[ "$DATABRICKS_HOST" == https://* ]]'
else
  soft_check 'DATABRICKS_HOST configured when Databricks routes are required' false
fi

echo; echo '======================================'
if ((failures>0)); then printf 'FAILED: %d check(s) failed, %d warning(s).\n' "$failures" "$warnings" >&2; exit 1; fi
if ((warnings>0)); then printf 'PASSED with %d warning(s).\n' "$warnings"; else echo 'PASSED: all runtime checks succeeded.'; fi
