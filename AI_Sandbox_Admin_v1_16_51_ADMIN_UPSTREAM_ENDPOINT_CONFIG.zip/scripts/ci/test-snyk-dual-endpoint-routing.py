#!/usr/bin/env python3
"""Offline regression for Snyk CLI 1.1306.2 dual endpoint credential routing."""
from __future__ import annotations
import importlib.util
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
BROKER = ROOT / ".devcontainer/scripts/secret-broker-server.py"
WRAPPER = ROOT / ".devcontainer/scripts/sandbox-command-wrapper.sh"
MCP = ROOT / ".devcontainer/scripts/snyk-mcp-ssm.sh"
os.environ["TAVILY_POLICY_FILE"] = str(ROOT / "policies/tavily-allowed-domains.json")
os.environ["ADO_POLICY_FILE"] = str(ROOT / "policies/ado-policy.json")
os.environ["ADMIN_UPSTREAM_ENDPOINTS_FILE"] = str(ROOT / "policies/admin-upstream-endpoints.json")
os.environ.pop("DATABRICKS_HOST", None)

spec = importlib.util.spec_from_file_location("broker_v1651", BROKER)
assert spec and spec.loader
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

# This mirrors code-client-go v1.27.0 SnykCodeApi(): strings.ReplaceAll(API_URL, "api", "deeproxy").
general = "http://api.snyk.local:8771/snyk"
code = "http://deeproxy.snyk.local:8771/snyk"
assert general.replace("api", "deeproxy") == code

w = WRAPPER.read_text(encoding="utf-8")
m = MCP.read_text(encoding="utf-8")
for text in (w, m):
    assert general in text
    assert code in text
    assert "SNYK_TOKEN" in text and "ai-sandbox-broker-placeholder" in text
    for retired in ("8772", "snyk-proxy-ca.pem", "SSL_CERT_FILE", "NODE_EXTRA_CA_CERTS"):
        assert retired not in text
assert 'SNYK_API="$snyk_api" DEEPROXY_API_URL="$snyk_code_api"' in w
assert 'SNYK_HTTP_PROTOCOL_UPGRADE=0' in w, 'CLI local HTTP routes must not be auto-upgraded to HTTPS'
assert 'SNYK_API="$SNYK_API_BASE" DEEPROXY_API_URL="$SNYK_CODE_BASE"' in m
assert 'SNYK_HTTP_PROTOCOL_UPGRADE=0' in m, 'MCP local HTTP routes must not be auto-upgraded to HTTPS'

# Host selects the upstream; path/query remain opaque and unchanged.
h = mod.ProviderProxyHandler.__new__(mod.ProviderProxyHandler)
h.headers = {"Host": "api.snyk.local:8771"}
h.path = "/snyk/rest/orgs/abc/issues?version=2026-01-01&foo=a%2Fb"
r = h._route()
assert r == ("/snyk", mod.SNYK_API_ORIGIN + "/rest/orgs/abc/issues?version=2026-01-01&foo=a%2Fb", "snyk-token", "snyk")

h.headers = {"Host": "deeproxy.snyk.local:8771"}
h.path = "/snyk/bundle/abc?foo=a%2Fb"
r = h._route()
assert r == ("/snyk", mod.SNYK_CODE_ORIGIN + "/bundle/abc?foo=a%2Fb", "snyk-token", "snyk")

h.headers = {"Host": "api.snyk.local:8771"}
h.path = "/snyk/../escape"
assert h._route() is None
h.headers = {"Host": "attacker.invalid:8771"}
h.path = "/snyk/filters"
assert h._route() is None

source = BROKER.read_text(encoding="utf-8")
assert 'headers["Authorization"] = f"token {secret}"' in source
for retired in ("SnykCredentialProxyHandler", "SNYK_PROXY_PORT", "snyk-proxy-ca.pem", "cryptography"):
    assert retired not in source

for compose in (ROOT / "tar/docker-compose.yml", ROOT / "ecr/docker-compose.yml"):
    c = compose.read_text(encoding="utf-8")
    assert '"api.snyk.local:127.0.0.1"' in c
    assert '"deeproxy.snyk.local:127.0.0.1"' in c
    assert "SANDBOX_SNYK_PROXY_PORT" not in c
    assert "SANDBOX_SNYK_PROXY_LOOPBACK_PORT" not in c

print("Snyk validated dual-endpoint routing regression passed")
