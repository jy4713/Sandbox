#!/usr/bin/env bash
# =============================================================================
# Purpose: Copy the Developer's persistent MCP definitions into ucode's
#          short-lived HOME after ucode has configured the selected agent.
#          This preserves normal `claude/gemini mcp add/remove` behavior across
#          direct and Databricks-routed sessions without copying provider auth.
# Safety: Reject legacy Gemini/Claude MCP definitions that contain AWS bootstrap
#         credential mappings. Tavily/Snyk wrappers obtain AWS auth at runtime.
# =============================================================================
set -euo pipefail
umask 077

agent="${1:-}"
target_home="${2:-}"
source_home="${SANDBOX_PERSISTENT_HOME:-/home/vscode}"
[[ "$agent" == "claude" || "$agent" == "gemini" ]] || { echo 'ERROR: sync-ucode-mcp requires claude|gemini' >&2; exit 2; }
[[ -n "$target_home" && -d "$target_home" ]] || { echo 'ERROR: target ucode HOME is missing' >&2; exit 2; }
command -v jq >/dev/null 2>&1 || { echo 'ERROR: jq is required' >&2; exit 1; }

reject_aws_bootstrap_mapping() {
  local file="$1"
  if jq -e '[(.mcpServers // {}) | .. | objects | keys[]?] | any(. == "AWS_ACCESS_KEY_ID" or . == "AWS_SECRET_ACCESS_KEY" or . == "AWS_SESSION_TOKEN")' "$file" >/dev/null 2>&1; then
    echo "ERROR: legacy AWS bootstrap mapping found in MCP settings: $file" >&2
    echo "Run 'configure-mcp' or remove/re-add the affected MCP without AWS env mappings before starting ucode." >&2
    exit 1
  fi
}

merge_mcp_servers() {
  local src="$1" dst="$2" tmp
  reject_aws_bootstrap_mapping "$src"
  mkdir -p "$(dirname "$dst")"
  [[ -f "$dst" ]] || printf '{}\n' > "$dst"
  tmp="$(mktemp "$(dirname "$dst")/.mcp-sync.XXXXXX")"
  jq --slurpfile src "$src" '.mcpServers = ($src[0].mcpServers // {})' "$dst" > "$tmp"
  chmod 0600 "$tmp"
  mv -f "$tmp" "$dst"
}

if [[ "$agent" == "gemini" ]]; then
  src="$source_home/.gemini/settings.json"
  dst="$target_home/.gemini/settings.json"
  if [[ -f "$src" ]] && jq -e 'has("mcpServers")' "$src" >/dev/null 2>&1; then
    merge_mcp_servers "$src" "$dst"
    exit 0
  fi
else
  # Claude Code storage location has changed across releases and can be affected
  # by CLAUDE_CONFIG_DIR. Copy only the mcpServers object from any persistent
  # Claude JSON file that actually contains it; never copy auth/session state.
  found=false
  candidates=()
  [[ -f "$source_home/.claude.json" ]] && candidates+=("$source_home/.claude.json")
  if [[ -d "$source_home/.claude" ]]; then
    while IFS= read -r f; do candidates+=("$f"); done < <(find "$source_home/.claude" -maxdepth 2 -type f -name '*.json' -print 2>/dev/null | sort)
  fi
  for src in "${candidates[@]}"; do
    if jq -e 'has("mcpServers")' "$src" >/dev/null 2>&1; then
      if [[ "$src" == "$source_home/.claude.json" ]]; then
        dst="$target_home/.claude.json"
      else
        rel="${src#"$source_home/.claude/"}"
        dst="$target_home/.claude/$rel"
      fi
      merge_mcp_servers "$src" "$dst"
      found=true
    fi
  done
  if [[ "$found" == true ]]; then exit 0; fi
fi

# First-run fallback: if no persistent MCP source exists yet, seed the approved
# Tavily/Snyk defaults in the temporary HOME. Normal user add/remove operations
# become the source of truth once persistent MCP configuration exists.
env HOME="$target_home" CLAUDE_CONFIG_DIR="$target_home/.claude" /usr/local/bin/configure-mcp >/dev/null
