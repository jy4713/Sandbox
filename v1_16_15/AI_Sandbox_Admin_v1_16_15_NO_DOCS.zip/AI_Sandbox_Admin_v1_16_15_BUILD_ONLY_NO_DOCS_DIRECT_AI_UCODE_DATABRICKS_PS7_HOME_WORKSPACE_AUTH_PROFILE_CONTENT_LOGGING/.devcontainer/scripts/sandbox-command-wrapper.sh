#!/usr/bin/env bash
# =============================================================================
# PACKAGE MAINTENANCE NOTES
# Purpose: Developer-friendly command shim for approved applications.
#          Direct `claude` and `gemini` commands use their official provider
#          APIs with SSM-fetched provider credentials. `ucode ...` is the
#          explicit Databricks-routed entry point and receives the Databricks
#          credential from SSM before it starts.
# Safety rule: Never persist fetched secrets to disk or the parent shell.
#              Never log raw command arguments, prompts, search terms, source
#              code, findings, MCP payloads, API keys or tokens.
# =============================================================================
set -euo pipefail
set +x

readonly REAL_DIR="/usr/local/libexec/ai-sandbox/real"
readonly SECRET_RUNNER="/usr/local/bin/run-with-ssm-secrets"
readonly MCP_AWS_AUTH="/usr/local/bin/mcp-aws-auth"
tool="$(basename -- "$0")"

fail() { echo "ERROR: $*" >&2; exit 1; }
real_tool() { printf '%s/%s' "$REAL_DIR" "$1"; }

exec_without_static_aws() {
  exec env \
    -u AWS_ACCESS_KEY_ID \
    -u AWS_SECRET_ACCESS_KEY \
    -u AWS_SESSION_TOKEN \
    -u AWS_SECURITY_TOKEN \
    "$@"
}

# Help/version/configuration operations that do not need provider credentials
# execute the stashed vendor CLI directly.
is_local_only_operation() {
  local t="$1" first="${2:-}"
  case "$first" in
    --help|-h|help|--version|-v|version) return 0 ;;
  esac
  case "$t:$first" in
    claude:mcp|gemini:mcp|ucode:status) return 0 ;;
  esac
  return 1
}

case "$tool" in
  claude)
    [[ -x "$(real_tool claude)" ]] || fail "real claude executable is missing"
    if is_local_only_operation "$tool" "${1:-}"; then
      if [[ "${1:-}" == "mcp" && -x "$MCP_AWS_AUTH" ]]; then
        "$MCP_AWS_AUTH" prepare >/dev/null
        exec_without_static_aws "$(real_tool claude)" "$@"
      fi
      exec "$(real_tool claude)" "$@"
    fi
    # Direct command: Anthropic official API. Databricks routing is reserved
    # for the explicit `ucode claude` entry point.
    exec "$SECRET_RUNNER" --profile anthropic -- "$(real_tool claude)" "$@"
    ;;

  gemini)
    [[ -x "$(real_tool gemini)" ]] || fail "real gemini executable is missing"
    if is_local_only_operation "$tool" "${1:-}"; then
      if [[ "${1:-}" == "mcp" && -x "$MCP_AWS_AUTH" ]]; then
        "$MCP_AWS_AUTH" prepare >/dev/null
        exec_without_static_aws "$(real_tool gemini)" "$@"
      fi
      exec "$(real_tool gemini)" "$@"
    fi
    # Direct command: Google Gemini official API. Databricks routing is
    # reserved for the explicit `ucode gemini` entry point.
    exec "$SECRET_RUNNER" --profile gemini -- "$(real_tool gemini)" "$@"
    ;;

  ucode)
    [[ -x "$(real_tool ucode)" ]] || fail "real ucode executable is missing"
    if is_local_only_operation "$tool" "${1:-}"; then
      exec "$(real_tool ucode)" "$@"
    fi
    # Explicit Databricks route. The runner keeps the underlying Claude/Gemini
    # vendor binaries ahead of the public wrappers in PATH so ucode cannot
    # recurse back into the direct-provider command shims.
    exec "$SECRET_RUNNER" --profile databricks -- "$(real_tool ucode)" "$@"
    ;;

  databricks)
    [[ -x "$(real_tool databricks)" ]] || fail "real databricks executable is missing"
    if is_local_only_operation "$tool" "${1:-}"; then
      exec "$(real_tool databricks)" "$@"
    fi
    exec "$SECRET_RUNNER" --profile databricks -- "$(real_tool databricks)" "$@"
    ;;

  tvly)
    [[ -x "$(real_tool tvly)" ]] || fail "real tvly executable is missing"
    if is_local_only_operation "$tool" "${1:-}"; then
      exec "$(real_tool tvly)" "$@"
    fi
    exec "$SECRET_RUNNER" --profile tavily -- "$(real_tool tvly)" "$@"
    ;;

  tavily-mcp)
    # Tavily is registered with Claude/Gemini through tavily-mcp-ssm. Keep the
    # public tavily-mcp command on the same audited path as the MCP registration.
    exec /usr/local/bin/tavily-mcp-ssm "$@"
    ;;

  snyk)
    [[ -x "$(real_tool snyk)" ]] || fail "real snyk executable is missing"
    if is_local_only_operation "$tool" "${1:-}"; then
      exec "$(real_tool snyk)" "$@"
    fi
    if [[ "${1:-}" == "mcp" ]]; then
      shift
      exec /usr/local/bin/snyk-mcp-ssm "$@"
    fi
    exec "$SECRET_RUNNER" --profile snyk -- "$(real_tool snyk)" "$@"
    ;;

  *) fail "unsupported sandbox command wrapper name: $tool" ;;
esac
