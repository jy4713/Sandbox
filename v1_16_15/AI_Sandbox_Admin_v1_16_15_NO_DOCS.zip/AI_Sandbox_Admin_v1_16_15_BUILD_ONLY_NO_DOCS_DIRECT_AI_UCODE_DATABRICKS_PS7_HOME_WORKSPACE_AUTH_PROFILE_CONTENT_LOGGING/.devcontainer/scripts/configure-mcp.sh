#!/usr/bin/env bash
# =============================================================================
# PACKAGE MAINTENANCE NOTES
# Purpose: Creates secret-free user-scope MCP registrations for Claude Code and
#          Gemini CLI. MCP definitions contain only wrapper commands; AWS/API
#          credentials are never stored in Claude/Gemini settings.
# Admin maintenance: When adding/removing an MCP server, update this file plus
#                    its wrapper, SSM profile, Dockerfile, Squid allowlist and
#                    runtime verification.
# Safety rule: Never place API keys, AWS keys, tokens, or secret-bearing env
#              mappings in MCP configuration files.
# =============================================================================
set -euo pipefail
umask 077

export CLAUDE_CONFIG_DIR="${CLAUDE_CONFIG_DIR:-$HOME/.claude}"
export DISABLE_AUTOUPDATER=1
export CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC=1
mkdir -p "$CLAUDE_CONFIG_DIR" "$HOME/.gemini"

readonly REAL_DIR="/usr/local/libexec/ai-sandbox/real"
readonly REAL_CLAUDE="$REAL_DIR/claude"
readonly REAL_GEMINI="$REAL_DIR/gemini"
readonly GEMINI_SETTINGS="$HOME/.gemini/settings.json"
[[ -x "$REAL_CLAUDE" ]] || { echo 'ERROR: real Claude CLI is missing' >&2; exit 1; }
[[ -x "$REAL_GEMINI" ]] || { echo 'ERROR: real Gemini CLI is missing' >&2; exit 1; }
command -v jq >/dev/null 2>&1 || { echo 'ERROR: jq is required for secret-free Gemini MCP configuration' >&2; exit 1; }

# Claude Code can safely use its native MCP CLI because these definitions do not
# contain AWS/environment credentials.
"$REAL_CLAUDE" mcp remove tavily --scope user >/dev/null 2>&1 || true
"$REAL_CLAUDE" mcp add-json tavily '{"type":"stdio","command":"/usr/local/bin/tavily-mcp-ssm","args":[]}' --scope user >/dev/null
"$REAL_CLAUDE" mcp remove snyk --scope user >/dev/null 2>&1 || true
"$REAL_CLAUDE" mcp add-json snyk '{"type":"stdio","command":"/usr/local/bin/snyk-mcp-ssm","args":[]}' --scope user >/dev/null

# Gemini CLI v0.53.x resolves $ENV references when settings are loaded and can
# persist the resolved values when a later `gemini mcp add/remove` rewrites the
# mcpServers object. Therefore Admin-managed defaults contain NO AWS env mapping.
# Update both entries atomically and preserve every unrelated Gemini setting/MCP.
[[ -f "$GEMINI_SETTINGS" ]] || printf '{}\n' > "$GEMINI_SETTINGS"
tmp_settings="$(mktemp "$HOME/.gemini/.settings.XXXXXX")"
trap 'rm -f "$tmp_settings"' EXIT
jq '
  .mcpServers = (.mcpServers // {}) |
  .mcpServers.tavily = {
    "command": "/usr/local/bin/tavily-mcp-ssm",
    "args": [],
    "timeout": 10000
  } |
  .mcpServers.snyk = {
    "command": "/usr/local/bin/snyk-mcp-ssm",
    "args": [],
    "timeout": 10000
  }
' "$GEMINI_SETTINGS" > "$tmp_settings"
chmod 0600 "$tmp_settings"
mv -f "$tmp_settings" "$GEMINI_SETTINGS"
trap - EXIT

# Fail closed if a regression reintroduces AWS bootstrap material in Tavily/Snyk
# Gemini definitions. Existing unrelated user MCP entries are intentionally not
# rewritten or inspected here.
if ! jq -e '
  (.mcpServers.tavily.command == "/usr/local/bin/tavily-mcp-ssm") and
  (.mcpServers.snyk.command == "/usr/local/bin/snyk-mcp-ssm") and
  ((.mcpServers.tavily.env // {}) == {}) and
  ((.mcpServers.snyk.env // {}) == {})
' "$GEMINI_SETTINGS" >/dev/null; then
  echo 'ERROR: Gemini Tavily/Snyk MCP configuration is not secret-free.' >&2
  exit 1
fi

chmod -R go-rwx "$CLAUDE_CONFIG_DIR" "$HOME/.gemini" 2>/dev/null || true
echo '[OK] Secret-free Tavily MCP and Snyk MCP definitions configured for Claude Code and Gemini CLI.'
