#!/usr/bin/env bash
# =============================================================================
# PACKAGE MAINTENANCE NOTES
# Purpose: Launch Tavily MCP with TAVILY_API_KEY fetched from SSM at runtime.
# AWS bootstrap authentication is recovered through mcp-aws-auth so Gemini MCP
# settings never need AWS_ACCESS_KEY_ID/AWS_SECRET_ACCESS_KEY env mappings.
# Safety rule: Never log MCP request/response payloads or Tavily search content.
# =============================================================================
set -euo pipefail
set +x
readonly REAL_TAVILY_MCP="/usr/local/libexec/ai-sandbox/real/tavily-mcp"
[[ -x "$REAL_TAVILY_MCP" ]] || { echo 'ERROR: real Tavily MCP executable is missing' >&2; exit 1; }
command -v mcp-aws-auth >/dev/null 2>&1 || { echo 'ERROR: mcp-aws-auth helper is missing' >&2; exit 1; }
start_ms="$(date +%s%3N)"
application-audit --app mcp --event server_start --operation tavily --target tavily --status started --transport stdio
set +e
mcp-aws-auth exec -- run-with-ssm-secrets --profile tavily -- "$REAL_TAVILY_MCP" "$@"
ec=$?
set -e
end_ms="$(date +%s%3N)"
status=success; (( ec == 0 )) || status=failure
application-audit --app mcp --event server_end --operation tavily --target tavily --status "$status" --exit-code "$ec" --duration-ms "$((end_ms-start_ms))" --transport stdio || true
exit "$ec"
