#!/usr/bin/env bash
# =============================================================================
# PACKAGE MAINTENANCE NOTES
# Purpose: Bridge the Sandbox's existing AWS bootstrap authentication into
#          nested MCP server processes without placing AWS credentials in
#          Claude/Gemini MCP configuration files.
#
# Static-key mode:
#   - The container already receives AWS_ACCESS_KEY_ID/AWS_SECRET_ACCESS_KEY.
#   - A runtime-only copy is written to /run/ai-sandbox-auth (tmpfs, mode 0700).
#   - MCP wrappers rehydrate the same AWS bootstrap pair only long enough to
#     fetch their own application secret from SSM.
#
# SSO mode:
#   - No static key is written.
#   - MCP wrappers reuse the Sandbox AWS profile and /home/vscode/.aws SSO cache.
#   - Browser/device login remains the normal sandbox-aws-login flow.
#
# Safety rules:
#   - Never write AWS bootstrap credentials into ~/.gemini, ~/.claude, workspace,
#     Git, logs, or image layers.
#   - Never print credential values.
#   - MCP vendor processes receive only their own SSM-fetched service secret;
#     run-with-ssm-secrets drops AWS static bootstrap variables before exec.
# =============================================================================
set -euo pipefail
set +x
umask 077

readonly RUNTIME_DIR="${SANDBOX_MCP_AWS_AUTH_DIR:-/run/ai-sandbox-auth}"
readonly CREDENTIALS_FILE="$RUNTIME_DIR/credentials"
readonly CONTEXT_FILE="$RUNTIME_DIR/context.json"
readonly PERSISTENT_HOME="/home/vscode"
readonly PERSISTENT_AWS_CONFIG="$PERSISTENT_HOME/.aws/config"
readonly PERSISTENT_AWS_CREDENTIALS="$PERSISTENT_HOME/.aws/credentials"
readonly RUNTIME_PROFILE="sandbox-mcp-runtime"

fail() { echo "ERROR: $*" >&2; exit 1; }

ensure_runtime_dir() {
  [[ -d "$RUNTIME_DIR" ]] || fail "MCP AWS runtime directory is unavailable: $RUNTIME_DIR"
  [[ -w "$RUNTIME_DIR" ]] || fail "MCP AWS runtime directory is not writable: $RUNTIME_DIR"
  chmod 0700 "$RUNTIME_DIR" 2>/dev/null || true
}

valid_profile() { [[ "$1" =~ ^[A-Za-z0-9._-]+$ ]]; }
valid_region() { [[ "$1" =~ ^[A-Za-z0-9-]+$ ]]; }

prepare() {
  ensure_runtime_dir

  local profile="${SANDBOX_AWS_PROFILE:-sandbox}"
  local region="${AWS_REGION:-eu-west-2}"
  local access_key="${AWS_ACCESS_KEY_ID:-}"
  local secret_key="${AWS_SECRET_ACCESS_KEY:-}"
  local session_token="${AWS_SESSION_TOKEN:-}"
  local mode="sso"
  local tmp

  valid_profile "$profile" || fail "SANDBOX_AWS_PROFILE contains unsupported characters"
  valid_region "$region" || fail "AWS_REGION contains unsupported characters"

  if [[ -n "$access_key" || -n "$secret_key" || -n "$session_token" ]]; then
    [[ -n "$access_key" && -n "$secret_key" ]] \
      || fail "AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY must be configured together"
    mode="static"
    tmp="$(mktemp "$RUNTIME_DIR/.credentials.XXXXXX")"
    {
      printf '[%s]\n' "$RUNTIME_PROFILE"
      printf 'aws_access_key_id = %s\n' "$access_key"
      printf 'aws_secret_access_key = %s\n' "$secret_key"
      [[ -n "$session_token" ]] && printf 'aws_session_token = %s\n' "$session_token"
    } > "$tmp"
    chmod 0600 "$tmp"
    mv -f "$tmp" "$CREDENTIALS_FILE"
  else
    rm -f "$CREDENTIALS_FILE"
  fi

  tmp="$(mktemp "$RUNTIME_DIR/.context.XXXXXX")"
  jq -n \
    --arg auth_mode "$mode" \
    --arg profile "$profile" \
    --arg region "$region" \
    --arg runtime_profile "$RUNTIME_PROFILE" \
    '{auth_mode:$auth_mode, profile:$profile, region:$region, runtime_profile:$runtime_profile}' \
    > "$tmp"
  chmod 0600 "$tmp"
  mv -f "$tmp" "$CONTEXT_FILE"
}

read_context_value() {
  local key="$1"
  [[ -r "$CONTEXT_FILE" ]] || fail "MCP AWS auth context is missing; recreate/restart the container or run: mcp-aws-auth prepare"
  jq -er --arg k "$key" '.[$k] // empty' "$CONTEXT_FILE"
}

credential_value() {
  local key="$1"
  [[ -r "$CREDENTIALS_FILE" ]] || fail "runtime AWS credential file is missing"
  sed -n "s/^[[:space:]]*${key}[[:space:]]*=[[:space:]]*//p" "$CREDENTIALS_FILE" | head -n 1
}

exec_with_runtime_auth() {
  (( $# > 0 )) || fail "exec requires a command"
  ensure_runtime_dir

  # Entry point normally prepares the context. This fallback is safe for direct
  # shell invocation while the original container AWS environment is available.
  if [[ ! -r "$CONTEXT_FILE" ]]; then
    prepare
  fi

  local mode profile region runtime_profile
  mode="$(read_context_value auth_mode)"
  profile="$(read_context_value profile)"
  region="$(read_context_value region)"
  runtime_profile="$(read_context_value runtime_profile)"

  export HOME="$PERSISTENT_HOME"
  export AWS_CONFIG_FILE="$PERSISTENT_AWS_CONFIG"
  export AWS_SHARED_CREDENTIALS_FILE="$PERSISTENT_AWS_CREDENTIALS"
  export SANDBOX_AWS_PROFILE="$profile"
  export AWS_REGION="$region"
  export SANDBOX_MCP_NO_INTERACTIVE_AUTH="true"

  case "$mode" in
    static)
      local access_key secret_key session_token
      access_key="$(credential_value aws_access_key_id)"
      secret_key="$(credential_value aws_secret_access_key)"
      session_token="$(credential_value aws_session_token || true)"
      [[ -n "$access_key" && -n "$secret_key" ]] || fail "runtime AWS credential pair is incomplete"
      export AWS_ACCESS_KEY_ID="$access_key"
      export AWS_SECRET_ACCESS_KEY="$secret_key"
      if [[ -n "$session_token" ]]; then export AWS_SESSION_TOKEN="$session_token"; else unset AWS_SESSION_TOKEN || true; fi
      unset AWS_PROFILE AWS_DEFAULT_PROFILE AWS_SECURITY_TOKEN || true
      ;;
    sso)
      unset AWS_ACCESS_KEY_ID AWS_SECRET_ACCESS_KEY AWS_SESSION_TOKEN AWS_SECURITY_TOKEN AWS_PROFILE AWS_DEFAULT_PROFILE || true
      ;;
    *) fail "unsupported MCP AWS auth mode: $mode" ;;
  esac

  exec "$@"
}

status() {
  ensure_runtime_dir
  if [[ ! -r "$CONTEXT_FILE" ]]; then
    echo 'MCP AWS auth context: NOT PREPARED'
    return 1
  fi
  local mode profile region
  mode="$(read_context_value auth_mode)"
  profile="$(read_context_value profile)"
  region="$(read_context_value region)"
  echo "MCP AWS auth mode: $mode"
  echo "AWS profile: $profile"
  echo "AWS region: $region"
  if [[ "$mode" == "static" ]]; then
    [[ -r "$CREDENTIALS_FILE" ]] && echo 'Runtime credential material: PRESENT (value hidden)' || echo 'Runtime credential material: MISSING'
  else
    echo 'Runtime credential material: NOT USED (SSO/profile mode)'
  fi
}

case "${1:-}" in
  prepare)
    prepare
    ;;
  exec)
    shift
    [[ "${1:-}" == "--" ]] && shift
    exec_with_runtime_auth "$@"
    ;;
  status)
    status
    ;;
  clear)
    ensure_runtime_dir
    rm -f "$CREDENTIALS_FILE" "$CONTEXT_FILE"
    ;;
  *)
    cat >&2 <<'USAGE'
Usage:
  mcp-aws-auth prepare
  mcp-aws-auth exec -- <command> [args...]
  mcp-aws-auth status
  mcp-aws-auth clear
USAGE
    exit 2
    ;;
esac
