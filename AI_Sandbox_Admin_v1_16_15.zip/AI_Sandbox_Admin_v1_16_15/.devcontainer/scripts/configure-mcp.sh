#!/usr/bin/env bash
# =============================================================================
# PACKAGE MAINTENANCE NOTES
# Purpose: Creates credential-value-free user-scope MCP registrations for
#          Claude Code and Gemini CLI. Tavily and Snyk are SSM-backed MCP
#          servers; their service credentials are fetched only when the MCP
#          child starts.
#
# v1.16.15 GEMINI CONTRACT
#   Gemini CLI intentionally sanitizes sensitive variables inherited by stdio
#   MCP children. Static AWS bootstrap variables therefore do not reach the
#   SSM-backed wrappers through normal inheritance. The managed Gemini MCP
#   entries explicitly declare ONLY runtime variable references:
#       "$AWS_ACCESS_KEY_ID"
#       "$AWS_SECRET_ACCESS_KEY"
#       "$AWS_SESSION_TOKEN"
#   These are references, never credential values. Gemini expands them from the
#   current process environment when the MCP child starts.
#
#   Static-key mode:
#     the references expand to the runtime AWS pair/session token and the MCP
#     wrapper can call STS/SSM. The wrapper drops AWS bootstrap credentials
#     before launching the actual Tavily/Snyk vendor process.
#
#   IAM Identity Center SSO mode:
#     the static variables are absent/empty. The MCP preamble removes empty or
#     unexpanded references and run-with-ssm-secrets resolves SSO from the
#     persistent SANDBOX_AWS_HOME token/config state.
#
# UCODE GEMINI CONTRACT
#   ucode launches Gemini with GEMINI_CLI_HOME pointing at its own managed
#   Gemini home (currently ~/.ucode/.gemini-home). When GEMINI_CLI_HOME is set,
#   this script writes settings.json under that home rather than normal $HOME.
#   run-with-ssm-secrets sets GEMINI_CLI_HOME to ucode's temporary managed home
#   before calling this script, so `ucode gemini` sees the same Tavily/Snyk MCPs.
#
# Safety rules:
#   * Never put real API keys/tokens/AWS credential values in MCP config files.
#   * Gemini managed MCP env blocks may contain ONLY the three literal AWS
#     runtime references above.
#   * Preserve unrelated user/ucode Gemini settings.
# =============================================================================
set -euo pipefail
umask 077

export CLAUDE_CONFIG_DIR="${CLAUDE_CONFIG_DIR:-$HOME/.claude}"
export DISABLE_AUTOUPDATER=1
export CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC=1

readonly REAL_DIR="/usr/local/libexec/ai-sandbox/real"
readonly REAL_CLAUDE="$REAL_DIR/claude"
readonly REAL_GEMINI="$REAL_DIR/gemini"
[[ -x "$REAL_CLAUDE" ]] || { echo 'ERROR: real Claude CLI is missing' >&2; exit 1; }
[[ -x "$REAL_GEMINI" ]] || { echo 'ERROR: real Gemini CLI is missing' >&2; exit 1; }
command -v jq >/dev/null 2>&1 || { echo 'ERROR: jq is required for MCP configuration' >&2; exit 1; }

# Gemini CLI can be launched with an alternate state root. ucode uses this to
# isolate its routed Gemini configuration from the normal Developer home.
gemini_state_home="${GEMINI_CLI_HOME:-$HOME}"
gemini_config_dir="$gemini_state_home/.gemini"
gemini_settings="$gemini_config_dir/settings.json"
mkdir -p "$CLAUDE_CONFIG_DIR" "$gemini_config_dir"

# MCP start-up budget. The wrappers perform STS + SSM before server startup.
readonly TAVILY_MCP_TIMEOUT_MS=120000
readonly SNYK_MCP_TIMEOUT_MS=180000

# -----------------------------------------------------------------------------
# Claude Code - stdio registration.
# Claude Code passes the parent runtime environment to stdio children, so no
# managed AWS env block is required here.
# -----------------------------------------------------------------------------
"$REAL_CLAUDE" mcp remove tavily --scope user >/dev/null 2>&1 || true
"$REAL_CLAUDE" mcp add-json tavily '{"type":"stdio","command":"/usr/local/bin/tavily-mcp-ssm","args":[]}' --scope user >/dev/null

"$REAL_CLAUDE" mcp remove snyk --scope user >/dev/null 2>&1 || true
"$REAL_CLAUDE" mcp add-json snyk '{"type":"stdio","command":"/usr/local/bin/snyk-mcp-ssm","args":[]}' --scope user >/dev/null

# -----------------------------------------------------------------------------
# Gemini CLI - deterministic settings.json merge.
# Do not use `gemini mcp add -e`: command-line env handling has varied by Gemini
# version and previously created both argument parsing and credential persistence
# defects. Write the exact managed object directly instead.
# -----------------------------------------------------------------------------
if [[ ! -s "$gemini_settings" ]]; then
  printf '%s\n' '{}' > "$gemini_settings"
elif ! jq -e . "$gemini_settings" >/dev/null 2>&1; then
  invalid_backup="${gemini_settings}.invalid.$(date +%Y%m%d%H%M%S)"
  cp -p "$gemini_settings" "$invalid_backup" 2>/dev/null || true
  printf '%s\n' '{}' > "$gemini_settings"
  echo "WARN: invalid Gemini settings were backed up to $invalid_backup and reset" >&2
fi

gemini_tmp="$(mktemp "${TMPDIR:-/tmp}/gemini-settings.XXXXXX")"
trap 'rm -f "$gemini_tmp"' EXIT

# IMPORTANT: the values below are literal strings, not shell substitutions.
# Gemini resolves them against its launch-time environment for the MCP child.
jq \
  --argjson tavily_timeout "$TAVILY_MCP_TIMEOUT_MS" \
  --argjson snyk_timeout "$SNYK_MCP_TIMEOUT_MS" '
  .mcpServers = ((.mcpServers // {}) + {
    tavily: {
      command: "/usr/local/bin/tavily-mcp-ssm",
      args: [],
      timeout: $tavily_timeout,
      env: {
        AWS_ACCESS_KEY_ID: "$AWS_ACCESS_KEY_ID",
        AWS_SECRET_ACCESS_KEY: "$AWS_SECRET_ACCESS_KEY",
        AWS_SESSION_TOKEN: "$AWS_SESSION_TOKEN"
      }
    },
    snyk: {
      command: "/usr/local/bin/snyk-mcp-ssm",
      args: [],
      timeout: $snyk_timeout,
      env: {
        AWS_ACCESS_KEY_ID: "$AWS_ACCESS_KEY_ID",
        AWS_SECRET_ACCESS_KEY: "$AWS_SECRET_ACCESS_KEY",
        AWS_SESSION_TOKEN: "$AWS_SESSION_TOKEN"
      }
    }
  })
' "$gemini_settings" > "$gemini_tmp"

jq -e . "$gemini_tmp" >/dev/null || { echo 'ERROR: generated Gemini settings are not valid JSON' >&2; exit 1; }
mv "$gemini_tmp" "$gemini_settings"
trap - EXIT
chmod 0600 "$gemini_settings"

# Fail closed unless BOTH managed MCP servers carry exactly the approved
# runtime-reference env object. This rejects real AWS values, application
# secrets, additional env names and malformed placeholders.
if ! jq -e '
  def aws_runtime_refs: {
    AWS_ACCESS_KEY_ID: "$AWS_ACCESS_KEY_ID",
    AWS_SECRET_ACCESS_KEY: "$AWS_SECRET_ACCESS_KEY",
    AWS_SESSION_TOKEN: "$AWS_SESSION_TOKEN"
  };
  (.mcpServers.tavily.env == aws_runtime_refs) and
  (.mcpServers.snyk.env == aws_runtime_refs)
' "$gemini_settings" >/dev/null; then
  echo 'ERROR: managed Gemini MCP env must contain only approved AWS runtime references' >&2
  exit 1
fi

# Defense in depth: common AWS access-key IDs must never appear as literal
# credential values anywhere in managed Gemini settings.
if grep -Eq '(AKIA|ASIA)[A-Z0-9]{16}' "$gemini_settings"; then
  echo 'ERROR: AWS access-key credential material detected in Gemini MCP settings' >&2
  exit 1
fi

chmod -R go-rwx "$CLAUDE_CONFIG_DIR" "$gemini_config_dir" 2>/dev/null || true
printf '[OK] Tavily/Snyk MCP configured for Claude and Gemini (Gemini state root: %s; credential values not persisted).\n' "$gemini_state_home"
