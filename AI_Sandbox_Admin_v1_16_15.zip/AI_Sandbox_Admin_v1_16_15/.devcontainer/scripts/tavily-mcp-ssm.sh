#!/usr/bin/env bash
# =============================================================================
# PACKAGE MAINTENANCE NOTES
# Purpose: Launch Tavily MCP with TAVILY_API_KEY supplied only to the child
#          process and record redacted MCP lifecycle metadata.
# AWS auth: Resolved by run-with-ssm-secrets using the sandbox-wide priority
#           (static key pair first, IAM Identity Center SSO otherwise). This
#           wrapper never authenticates interactively and never persists a key.
# Safety rule: Never log MCP request/response payloads or Tavily search content.
#              Never write anything except JSON-RPC to stdout.
# =============================================================================
set -euo pipefail
set +x
umask 077

# shellcheck source=/usr/local/libexec/ai-sandbox/mcp-wrapper-preamble
. /usr/local/libexec/ai-sandbox/mcp-wrapper-preamble

readonly REAL_TAVILY_MCP="/usr/local/libexec/ai-sandbox/real/tavily-mcp"
[[ -x "$REAL_TAVILY_MCP" ]] || { echo 'ERROR: real Tavily MCP executable is missing' >&2; exit 1; }

# Audit must not be able to abort the server before the MCP handshake. The
# audit-required policy is still enforced centrally by run-with-ssm-secrets.
start_ms="$(date +%s%3N)"
application-audit --app mcp --event server_start --operation tavily --target tavily --status started --transport stdio || true

set +e
run-with-ssm-secrets --profile tavily -- "$REAL_TAVILY_MCP" "$@"
ec=$?
set -e

end_ms="$(date +%s%3N)"
status=success; (( ec == 0 )) || status=failure
application-audit --app mcp --event server_end --operation tavily --target tavily --status "$status" --exit-code "$ec" --duration-ms "$((end_ms-start_ms))" --transport stdio || true
exit "$ec"
