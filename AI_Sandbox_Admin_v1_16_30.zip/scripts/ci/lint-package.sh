#!/usr/bin/env bash
# =============================================================================
# PACKAGE MAINTENANCE NOTES
# Purpose: Static regression checks for the current two-container / tamper-resistant Docker-log package.
# =============================================================================
set -uo pipefail
root="$(cd "$(dirname "$0")/../.." && pwd)"; failures=0
pass(){ echo "  [OK]   $*"; }; fail(){ echo "  [FAIL] $*" >&2; failures=$((failures+1)); }; skip(){ echo "  [SKIP] $*"; }
echo '=== AI Sandbox package lint ==='

echo '[1/10] Bash syntax'
while IFS= read -r f; do bash -n "$f" >/dev/null 2>&1 && pass "${f#$root/}" || fail "${f#$root/}"; done < <(find "$root" -type f -name '*.sh' | sort)

echo '[2/10] PowerShell syntax'
if command -v pwsh >/dev/null 2>&1; then while IFS= read -r f; do pwsh -NoProfile -Command '$e=$null;$t=$null;[System.Management.Automation.Language.Parser]::ParseFile($args[0],[ref]$t,[ref]$e)|Out-Null;if($e.Count){$e|%{Write-Error $_};exit 1}' "$f" >/dev/null 2>&1 && pass "${f#$root/}" || fail "${f#$root/}"; done < <(find "$root" -type f -name '*.ps1' | sort); else skip 'pwsh unavailable'; fi
while IFS= read -r f; do if head -n 12 "$f" | grep -Eq '^#Requires[[:space:]]+-Version[[:space:]]+7\.4([[:space:]]|$)'; then pass "PowerShell 7.4 contract: ${f#$root/}"; else fail "PowerShell 7.4 requirement missing: ${f#$root/}"; fi; done < <(find "$root" -type f -name '*.ps1' | sort)

echo '[3/10] JSON / YAML parse'
while IFS= read -r f; do if [[ "$(basename "$f")" == devcontainer*.json ]]; then python3 - "$f" <<'PY' >/dev/null 2>&1
import json,re,sys
s=open(sys.argv[1],encoding='utf-8-sig').read();s=re.sub(r'^\s*//.*$','',s,flags=re.M);json.loads(s)
PY
else python3 -c 'import json,sys;json.load(open(sys.argv[1],encoding="utf-8-sig"))' "$f" >/dev/null 2>&1; fi; [[ $? -eq 0 ]] && pass "${f#$root/}" || fail "${f#$root/}"; done < <(find "$root" -type f -name '*.json' | sort)
if python3 -c 'import yaml' >/dev/null 2>&1; then while IFS= read -r f; do python3 -c 'import yaml,sys;yaml.safe_load(open(sys.argv[1],encoding="utf-8-sig"))' "$f" >/dev/null 2>&1 && pass "${f#$root/}" || fail "${f#$root/}"; done < <(find "$root" -type f \( -name '*.yml' -o -name '*.yaml' \) | sort); else skip 'PyYAML unavailable'; fi

echo '[4/10] Required files'
required=(
  .build.env.example .env.example
  .devcontainer/Dockerfile .devcontainer/devcontainer.json .devcontainer/post-create.sh
  .devcontainer/scripts/run-with-ssm-secrets.sh .devcontainer/scripts/sandbox-command-wrapper.sh
  .devcontainer/scripts/sandbox-audit-logger.sh .devcontainer/scripts/sandbox-log-emit.sh .devcontainer/scripts/application-audit.sh
  .devcontainer/scripts/claude-audit-hook.sh .devcontainer/scripts/configure-aws-sso.sh
  .devcontainer/scripts/sandbox-aws-login.sh .devcontainer/scripts/sandbox-info.sh
  scripts/admin/build-sandbox.ps1 scripts/admin/build-sandbox.sh
  scripts/admin/export-developer-packages.ps1 scripts/admin/export-developer-packages.sh
  scripts/applications/add-application.ps1 scripts/applications/add-application.sh
  scripts/applications/remove-application.ps1 scripts/applications/remove-application.sh
  scripts/applications/validate-application.ps1 scripts/applications/validate-application.sh
  scripts/applications/application-helper.py
  scripts/tar/build-and-export.ps1 scripts/tar/build-and-export.sh
  scripts/tar/load-and-start.ps1 scripts/tar/load-and-start.sh
  scripts/tar/verify-sandbox.ps1 scripts/tar/verify-sandbox.sh
  scripts/platform/02-setup-ecr.ps1 scripts/platform/02-setup-ecr.sh
  scripts/platform/03-setup-logging.ps1 scripts/platform/03-setup-logging.sh
  scripts/ecr/pull-and-start.ps1 scripts/ecr/pull-and-start.sh
  scripts/ecr/deploy-ecr.ps1 scripts/ecr/deploy-ecr.sh
  scripts/monitoring/export-docker-logs-to-host.ps1 scripts/monitoring/export-docker-logs-to-host.sh
  scripts/monitoring/verify-host-log-export.ps1 scripts/monitoring/verify-host-log-export.sh
  tar/docker-compose.yml ecr/docker-compose.yml squid/Dockerfile squid/whitelist.txt
  templates/developer/devcontainer-ecr.json
  templates/developer/DEVELOPER-GUIDE-TAR.md templates/developer/DEVELOPER-GUIDE-ECR.md
  sentinel/detection-rules.kql
)
for f in "${required[@]}"; do [[ -f "$root/$f" ]] && pass "$f" || fail "$f missing"; done

echo '[5/10] Fluent Bit removal regression guard'
[[ ! -d "$root/fluent-bit" ]] && pass 'fluent-bit directory absent' || fail 'fluent-bit directory still exists'
code_refs="$(grep -RInE 'sandbox-fluent-bit|FLUENT_BIT_BASE_IMAGE|AZURE_LAW_|azure-law-(workspace-id|shared-key)' "$root/scripts" "$root/tar" "$root/ecr" "$root/.build.env.example" "$root/.env.example" 2>/dev/null | grep -v 'lint-package' || true)"
[[ -z "$code_refs" ]] && pass 'no active Fluent Bit / Log Analytics shared-key references' || { echo "$code_refs" >&2; fail 'active Fluent Bit/shared-key references remain'; }

echo '[6/10] Two-image release contract'
grep -q 'sandbox-devcontainer.tar' "$root/scripts/tar/build-and-export.sh" && grep -q 'sandbox-squid.tar' "$root/scripts/tar/build-and-export.sh" && pass 'TAR builds DevContainer + Squid' || fail 'TAR image contract incomplete'
if grep -q 'sandbox-fluent-bit.tar' "$root/scripts/tar/build-and-export.sh"; then fail 'TAR still exports Fluent Bit TAR'; else pass 'TAR has no third monitoring image'; fi
grep -q "ai-sandbox/devcontainer" "$root/scripts/platform/02-setup-ecr.sh" && grep -q "ai-sandbox/squid" "$root/scripts/platform/02-setup-ecr.sh" && pass 'ECR builds DevContainer + Squid' || fail 'ECR image contract incomplete'

echo '[7/10] Tamper-resistant protected-host logging contract'
if python3 - "$root/tar/docker-compose.yml" "$root/ecr/docker-compose.yml" <<'PYLOG' >/dev/null 2>&1
import sys,yaml
for filename in sys.argv[1:]:
    data=yaml.safe_load(open(filename,encoding='utf-8-sig'))
    services=data.get('services',{})
    expected={'devcontainer':'/var/log/sandbox','squid-proxy':'/var/log/squid'}
    for service,target in expected.items():
        mounts=services.get(service,{}).get('volumes',[])
        found=[]
        for mount in mounts:
            if isinstance(mount,dict) and mount.get('target')==target:
                found.append(mount)
        if len(found)!=1:
            raise SystemExit(f'{filename}: expected exactly one {target} mount for {service}')
        mount=found[0]
        if mount.get('type')!='bind' or mount.get('read_only') is not True:
            raise SystemExit(f'{filename}: {target} must be a read-only bind mount')
        if 'SANDBOX_LOG_ROOT' not in str(mount.get('source','')):
            raise SystemExit(f'{filename}: {target} must source SANDBOX_LOG_ROOT')
        if services.get(service,{}).get('logging',{}).get('driver')!='local':
            raise SystemExit(f'{filename}: {service} must use Docker local logging')
PYLOG
then pass 'TAR/ECR expose only read-only protected Windows host log mounts'; else fail 'protected host log mount contract missing or writable'; fi
grep -Fq 'S-1-5-18' "$root/scripts/platform/03-setup-logging.ps1" \
  && grep -Fq 'ReadAndExecute' "$root/scripts/platform/03-setup-logging.ps1" \
  && grep -Fq 'AI-Sandbox-Protected-Log-Export' "$root/scripts/platform/03-setup-logging.ps1" \
  && grep -Fq 'Protected host log export must run as LOCALSYSTEM' "$root/scripts/monitoring/export-docker-logs-to-host.ps1" \
  && pass 'Windows protected-log ACL + LOCALSYSTEM exporter contract present' \
  || fail 'Windows protected-log ACL/exporter contract missing'
grep -Fq 'SANDBOX_LOG_MODE=auto' "$root/.env.example" \
  && grep -Fq "ValidateSet('Protected','PocLocal')" "$root/scripts/platform/03-setup-logging.ps1" \
  && grep -Fq "ValidateSet('Protected','PocLocal')" "$root/scripts/monitoring/export-docker-logs-to-host.ps1" \
  && grep -Fq 'poc-local' "$root/scripts/tar/load-and-start.ps1" \
  && grep -Fq 'poc-local' "$root/scripts/ecr/pull-and-start.ps1" \
  && grep -Fq '[switch]$Continuous' "$root/scripts/monitoring/export-docker-logs-to-host.ps1" \
  && grep -Fq "RequestedMode -eq 'auto'" "$root/scripts/tar/load-and-start.ps1" \
  && grep -Fq "RequestedMode -eq 'auto'" "$root/scripts/ecr/pull-and-start.ps1" \
  && grep -Fq 'SANDBOX_LOG_ROOT=$HostLog.ComposeRoot' "$root/scripts/tar/load-and-start.ps1" \
  && grep -Fq 'SANDBOX_LOG_ROOT=$HostLog.ComposeRoot' "$root/scripts/ecr/pull-and-start.ps1" \
  && grep -Fq "Set-RuntimeEnvValue -Path \$EnvFile -Key 'SANDBOX_LOG_ROOT'" "$root/scripts/tar/load-and-start.ps1" \
  && grep -Fq "Set-RuntimeEnvValue -Path \$EnvFile -Key 'SANDBOX_LOG_ROOT'" "$root/scripts/ecr/pull-and-start.ps1" \
  && grep -Fq 'set_env_value SANDBOX_LOG_ROOT "$log_root"' "$root/scripts/tar/load-and-start.sh" \
  && grep -Fq 'set_env_value SANDBOX_LOG_ROOT "$log_root"' "$root/scripts/ecr/pull-and-start.sh" \
  && grep -Fq 'Production manifests require protected host logging' "$root/scripts/tar/load-and-start.ps1" \
  && grep -Fq 'Production manifests require protected host logging' "$root/scripts/ecr/pull-and-start.ps1" \
  && grep -Fq 'Production manifests require protected host logging' "$root/scripts/tar/load-and-start.sh" \
  && grep -Fq 'Production manifests require protected host logging' "$root/scripts/ecr/pull-and-start.sh" \
  && pass 'manifest-driven auto logging selects POC local, persists the resolved Compose path, and Production remains protected' \
  || fail 'auto POC/Production host-logging contract missing'
grep -Fq 'scripts/monitoring/$f' "$root/scripts/admin/export-developer-packages.sh" \
  && grep -Fq 'scripts\monitoring\$f' "$root/scripts/admin/export-developer-packages.ps1" \
  && grep -Fq 'export-docker-logs-to-host.sh' "$root/scripts/admin/export-developer-packages.sh" \
  && grep -Fq 'export-docker-logs-to-host.sh' "$root/scripts/admin/export-developer-packages.ps1" \
  && pass 'Developer TAR/ECR export includes PowerShell and Bash POC log exporter helpers' \
  || fail 'Developer package export is missing POC log exporter helpers'
grep -Fq 'driver: local' "$root/tar/docker-compose.yml" && grep -Fq 'target="/proc/1/fd/1"' "$root/.devcontainer/scripts/sandbox-log-emit.sh" && pass 'TAR runtime uses Docker-owned log streams with a non-configurable sink' || fail 'TAR Docker logging contract missing'
grep -Fq 'access_log stdio:/dev/stdout' "$root/squid/squid.conf" && grep -Fq 'cache_log  /dev/stderr' "$root/squid/squid.conf" && grep -Fq 'cache_store_log none' "$root/squid/squid.conf" && grep -Fq 'logfile_rotate 0' "$root/squid/squid.conf" && pass 'Squid access/cache logs use Docker streams without file rotation/store logs' || fail 'Squid Docker logging missing'
grep -Fq '/usr/local/bin/sandbox-log-emit' "$root/.devcontainer/Dockerfile" && pass 'Managed log emitter is baked into image' || fail 'sandbox-log-emit missing'
if grep -Eq '/var/log/sandbox/.*\.log|/var/log/squid/(access|cache)\.log' "$root/.devcontainer/cis-level1-harden.sh"; then fail 'CIS hardening reintroduces writable runtime file-log sinks'; else pass 'CIS logging is container-tailored to Docker-owned streams'; fi
grep -Fq '"workspaceFolder": "/home/vscode/workspace"' "$root/.devcontainer/devcontainer.json" \
  && grep -Fq '"workspaceFolder": "/home/vscode/workspace"' "$root/templates/developer/devcontainer-ecr.json" \
  && grep -Fq 'target: /home/vscode/workspace' "$root/tar/docker-compose.yml" \
  && grep -Fq 'target: /home/vscode/workspace' "$root/ecr/docker-compose.yml" \
  && grep -Fq 'WORKDIR /home/${USERNAME}/workspace' "$root/.devcontainer/Dockerfile" \
  && pass 'Developer workspace is mounted under /home/vscode/workspace' || fail 'home-workspace contract missing'
if grep -RInE '(workspaceFolder"[[:space:]]*:[[:space:]]*"/workspace"|target:[[:space:]]*/workspace([[:space:]]|$)|WORKDIR[[:space:]]+/workspace([[:space:]]|$))' "$root/.devcontainer" "$root/tar" "$root/ecr" "$root/templates/developer" --exclude='lint-package.*' >/dev/null 2>&1; then fail 'legacy root-level /workspace runtime path remains'; else pass 'legacy root-level /workspace runtime path absent'; fi
grep -q 'SANDBOX_CONTENT_LOGGING: "${SANDBOX_CONTENT_LOGGING:-false}"' "$root/tar/docker-compose.yml" && grep -q 'GEMINI_TELEMETRY_LOG_PROMPTS: "false"' "$root/tar/docker-compose.yml" && grep -q 'SANDBOX_CONTENT_LOGGING: "${SANDBOX_CONTENT_LOGGING:-false}"' "$root/ecr/docker-compose.yml" && grep -q 'GEMINI_TELEMETRY_LOG_PROMPTS: "false"' "$root/ecr/docker-compose.yml" && pass 'TAR/ECR content logging defaults off and Gemini prompts are disabled by default' || fail 'TAR/ECR content-logging default policy missing'
grep -q '/usr/local/bin/claude-audit-hook' "$root/.devcontainer/Dockerfile" && grep -q '/etc/claude-code/managed-settings.json' "$root/.devcontainer/Dockerfile" && pass 'Claude managed audit hook is baked into image' || fail 'Claude managed audit hook missing'
grep -q '/usr/local/bin/application-audit' "$root/.devcontainer/Dockerfile" && pass 'application-audit helper is baked into image' || fail 'application-audit helper missing'
grep -q '/usr/local/libexec/ai-sandbox/sandbox-command-wrapper' "$root/.devcontainer/Dockerfile" && pass 'Developer-friendly SSM command wrapper is baked into image' || fail 'SSM command wrapper missing'
grep -q '/usr/local/bin/tavily-mcp-ssm' "$root/.devcontainer/scripts/configure-mcp.sh" && grep -q 'REAL_GEMINI' "$root/.devcontainer/scripts/configure-mcp.sh" && grep -q '/etc/claude-code/managed-mcp.json' "$root/.devcontainer/scripts/configure-mcp.sh" && ! grep -q 'REAL_CLAUDE.*mcp add' "$root/.devcontainer/scripts/configure-mcp.sh" && pass 'Gemini MCP is credential-value-free and Claude MCP is Admin-file managed' || fail 'MCP registration path is incorrect'
grep -Fq '"allowManagedHooksOnly": true' "$root/.devcontainer/Dockerfile" \
  && pass 'Claude hooks are restricted to the Admin-managed policy source' \
  || fail 'Admin-only Claude hook policy missing'

grep -q '/usr/local/bin/databricks-sql-mcp-ssm' "$root/.devcontainer/scripts/configure-mcp.sh" \
  && grep -q 'databricks-sql-mcp-token' "$root/.devcontainer/scripts/run-with-ssm-secrets.sh" \
  && grep -q 'mcp-remote@${MCP_REMOTE_VERSION}' "$root/.devcontainer/Dockerfile" \
  && pass 'Databricks SQL MCP uses dedicated SSM token and pinned bridge' || fail 'Databricks SQL MCP contract missing'
grep -Fq '/etc/claude-code/managed-mcp.json' "$root/.devcontainer/Dockerfile" \
  && grep -Fq '/etc/claude-code/managed-mcp.json' "$root/.devcontainer/scripts/sandbox-command-wrapper.sh" \
  && grep -Fq '/etc/claude-code/managed-mcp.json' "$root/.devcontainer/scripts/run-with-ssm-secrets.sh" \
  && ! grep -Fq -- '--mcp-config' "$root/.devcontainer/scripts/run-with-ssm-secrets.sh" \
  && pass 'Claude and ucode Claude use the root-owned managed MCP deployment' || fail 'Claude managed MCP contract missing'
grep -Fq 'command -v tavily-mcp >/dev/null 2>&1' "$root/.devcontainer/Dockerfile" \
  && grep -Fq 'command -v mcp-remote >/dev/null 2>&1' "$root/.devcontainer/Dockerfile" \
  && ! grep -Fq 'tavily-mcp --help' "$root/.devcontainer/Dockerfile" \
  && ! grep -Fq 'mcp-remote --help' "$root/.devcontainer/Dockerfile" \
  && pass 'MCP executables are build-validated with command -v, not runtime --help' || fail 'MCP executable build validation regressed'
if grep -RInE 'get-caller-identity|aws[[:space:]]+sts|sts\.eu-west-2\.amazonaws\.com' \
    "$root/.devcontainer/scripts" "$root/scripts/ecr" "$root/squid/whitelist.txt" >/dev/null 2>&1; then
  fail 'explicit STS dependency remains in active runtime/ECR paths'
else
  pass 'active runtime/ECR paths have no explicit STS dependency'
fi
grep -q 'tavily-policy-proxy.py' "$root/.devcontainer/scripts/tavily-mcp-ssm.sh" \
  && grep -q 'unset DEFAULT_PARAMETERS' "$root/.devcontainer/scripts/run-with-ssm-secrets.sh" \
  && grep -q 'tavily-allowed-domains.json' "$root/.devcontainer/Dockerfile" \
  && pass 'Tavily MCP domain allowlist is enforced by Admin-owned proxy' || fail 'Tavily hard domain policy missing'
if command -v python3 >/dev/null 2>&1 && PYTHONDONTWRITEBYTECODE=1 python3 "$root/scripts/ci/test-tavily-policy.py" >/dev/null; then
  pass 'Tavily policy blocks explicit unapproved domains and constrains generic search'
else
  fail 'Tavily policy behavioral regression test failed'
fi
grep -q '"WebSearch"' "$root/.devcontainer/Dockerfile" \
  && grep -q 'google_web_search' "$root/.devcontainer/policies/gemini-web-policy.toml" \
  && pass 'Claude/Gemini native web tools are disabled by Admin policy' || fail 'Admin native-web deny policy missing'


# Gemini MCP requires explicit runtime AWS references because the
# Gemini CLI strips inherited sensitive variables from stdio MCP children.
! grep -Eq "mcp add .*-e ['\"]?[A-Z_]+=\\\$" "$root/.devcontainer/scripts/configure-mcp.sh" && pass 'Gemini MCP does not use CLI -e credential injection' || fail 'Gemini MCP still uses command-line env injection'
grep -Fq 'AWS_ACCESS_KEY_ID: "$AWS_ACCESS_KEY_ID"' "$root/.devcontainer/scripts/configure-mcp.sh" \
  && grep -Fq 'AWS_SECRET_ACCESS_KEY: "$AWS_SECRET_ACCESS_KEY"' "$root/.devcontainer/scripts/configure-mcp.sh" \
  && grep -Fq 'AWS_SESSION_TOKEN: "$AWS_SESSION_TOKEN"' "$root/.devcontainer/scripts/configure-mcp.sh" \
  && grep -Fq 'managed Gemini MCP env must contain only approved AWS runtime references' "$root/.devcontainer/scripts/configure-mcp.sh" \
  && pass 'Gemini MCP stores only approved runtime AWS references, never values' || fail 'Gemini MCP runtime-reference contract missing'
grep -Fq 'gemini_state_home="${GEMINI_CLI_HOME:-$HOME}"' "$root/.devcontainer/scripts/configure-mcp.sh" \
  && grep -Fq 'GEMINI_CLI_HOME="$ucode_gemini_cli_home"' "$root/.devcontainer/scripts/run-with-ssm-secrets.sh" \
  && grep -Fq 'from ucode.agents.gemini import GEMINI_HOME_DIR' "$root/.devcontainer/scripts/run-with-ssm-secrets.sh" \
  && pass 'direct and ucode Gemini MCP settings target the correct Gemini state homes' || fail 'ucode Gemini GEMINI_CLI_HOME MCP contract missing'
grep -q 'mcpServers' "$root/.devcontainer/scripts/configure-mcp.sh" && grep -q 'AWS access-key credential material detected' "$root/.devcontainer/scripts/configure-mcp.sh" && pass 'MCP settings are written deterministically with a credential-value self-check' || fail 'MCP settings writer or credential self-check missing'
helper="$root/scripts/applications/application-helper.py"
grep -Fq 'mcp-wrapper-preamble' "$helper" \
  && grep -Fq 'AWS_ACCESS_KEY_ID: "$AWS_ACCESS_KEY_ID"' "$helper" \
  && grep -Fq '"$gemini_config_dir"' "$helper" \
  && grep -Fq ".devcontainer/policies/claude-mcp.json" "$helper" \
  && grep -Fq 'add_claude_managed_mcp' "$helper" \
  && ! grep -Fq 'REAL_CLAUDE' "$helper" \
  && ! grep -Fq 'mcp add-json' "$helper" \
  && ! grep -Fq '"$REAL_GEMINI" mcp add' "$helper" \
  && pass 'Admin application helper preserves managed Claude and Gemini MCP contracts' || fail 'application helper would regress managed MCP registration'
grep -q 'SANDBOX_AWS_HOME' "$root/.devcontainer/scripts/run-with-ssm-secrets.sh" && grep -q 'HOME="\$AWS_STATE_HOME" aws' "$root/.devcontainer/scripts/run-with-ssm-secrets.sh" && pass 'AWS CLI state is pinned to a HOME-independent anchor for SSO reachability' || fail 'AWS state anchor missing; SSO breaks under ephemeral HOME'
grep -q 'SANDBOX_NONINTERACTIVE' "$root/.devcontainer/scripts/run-with-ssm-secrets.sh" && grep -q 'SANDBOX_NONINTERACTIVE' "$root/.devcontainer/scripts/sandbox-aws-login.sh" && pass 'interactive SSO sign-in is refused in MCP stdio contexts' || fail 'non-interactive SSO guard missing'
for w in tavily-mcp-ssm databricks-sql-mcp-ssm snyk-mcp-ssm; do
  grep -q 'mcp-wrapper-preamble' "$root/.devcontainer/scripts/$w.sh" || fail "$w does not source the MCP wrapper preamble"
done
pass 'MCP wrappers source the deterministic environment preamble'
grep -Fq "databricks-sql-mcp) printf 'databricks' ;;" "$root/.devcontainer/scripts/run-with-ssm-secrets.sh" \
  && ! grep -Fq 'audit_safe "$profile"' "$root/.devcontainer/scripts/run-with-ssm-secrets.sh" \
  && pass 'internal Databricks SQL MCP profile maps to approved databricks audit namespace' || fail 'Databricks SQL MCP profile/audit application mapping is inconsistent'
grep -q '/opt/snyk-cache' "$root/.devcontainer/Dockerfile" && grep -q '/opt/snyk-cache' "$root/.devcontainer/scripts/run-with-ssm-secrets.sh" && pass 'Snyk native runtime cache is pre-warmed and seeded into the exec tmpfs' || fail 'Snyk runtime cache pre-warm/seed missing'
grep -Fq -- '--reuse-hardened-base' "$root/scripts/admin/build-sandbox.sh" \
  && grep -Fq 'can_reuse_hardened_base' "$root/scripts/admin/build-sandbox.sh" \
  && grep -Fq 'hardening.method' "$root/scripts/admin/build-sandbox.sh" \
  && grep -Fq 'hardening.profile' "$root/scripts/admin/build-sandbox.sh" \
  && grep -Fq '.build.env.full-build' "$root/scripts/admin/build-sandbox.sh" \
  && grep -Fq 'committed to .build.env only after hardening succeeds' "$root/scripts/admin/build-sandbox.sh" \
  && grep -Fq 'BUILD_ENV_FILE' "$root/scripts/supply-chain/resolve-base-digests.sh" \
  && grep -Fq -- '-ReuseHardenedBase' "$root/scripts/admin/build-sandbox.ps1" \
  && grep -Fq 'Test-ReusableHardenedBase' "$root/scripts/admin/build-sandbox.ps1" \
  && pass 'validated hardened-base reuse with transactional fallback' || fail 'hardened-base reuse/transaction contract missing'
hardening_sh="$root/scripts/hardening/build-hardened-base.sh"
hardening_ps="$root/scripts/hardening/build-hardened-base.ps1"
if grep -Fq -- '--mount "type=bind,source=$RESULTS_DIR,target=/results"' "$hardening_sh" \
  && grep -Fq 'COPY cleanup-toolchain.sh /opt/hardening/cleanup-toolchain.sh' "$hardening_sh" \
  && grep -Fq 'type=bind,source=$ResultsDir,target=/results' "$hardening_ps" \
  && grep -Fq 'COPY cleanup-toolchain.sh /opt/hardening/cleanup-toolchain.sh' "$hardening_ps" \
  && ! grep -Eq '^[[:space:]]*docker[[:space:]]+cp' "$hardening_sh" \
  && ! grep -Eq 'Invoke-Docker[[:space:]]+-Arguments[[:space:]]+@\("cp"' "$hardening_ps"; then
  pass 'ECI-safe hardening builder avoids docker cp and persists evidence through a bind mount'
else
  fail 'ECI-safe hardening builder contract missing or docker cp reintroduced'
fi
package_version="$(awk -F= '$1=="SANDBOX_VERSION"{print $2;exit}' "$root/.build.env.example")"
release_tag="$(awk -F= '$1=="RELEASE_TAG"{print $2;exit}' "$root/.build.env.example")"
sh_version="$(sed -n "s/^PACKAGE_VERSION='\([^']*\)'$/\1/p" "$root/scripts/admin/build-sandbox.sh" | head -n1)"
ps_version="$(sed -n "s/^\$PackageVersion = '\([^']*\)'$/\1/p" "$root/scripts/admin/build-sandbox.ps1" | head -n1)"
if [[ "$package_version" =~ ^v[0-9]+\.[0-9]+\.[0-9]+$ && "$package_version" == "$release_tag" && "$package_version" == "$sh_version" && "$package_version" == "$ps_version" ]] \
  && grep -Fq -- '--build-env-source' "$root/scripts/admin/build-sandbox.sh" \
  && grep -Fq -- '-BuildEnvSource' "$root/scripts/admin/build-sandbox.ps1"; then
  pass "build-env migration/version metadata is dynamically consistent ($package_version)"
else
  fail 'build-env migration/version metadata is inconsistent'
fi
grep -Fq -- '--deployment-type' "$root/scripts/admin/build-sandbox.sh" \
  && grep -Fq 'DeploymentType' "$root/scripts/admin/build-sandbox.ps1" \
  && grep -Fq 'scripts/tar/build-and-export.sh' "$root/scripts/admin/build-sandbox.sh" \
  && grep -Fq 'scripts\tar\build-and-export.ps1' "$root/scripts/admin/build-sandbox.ps1" \
  && pass 'SandboxType hardening and DeploymentType distribution are independently selectable' \
  || fail 'SandboxType/DeploymentType separation missing'
if grep -Fq 'HARDENED_CONFIG_ID=' "$root/.build.env.example" \
  && grep -Fq 'HARDENED_CONFIG_ID=${HARDENED_CONFIG_ID}' "$hardening_sh" \
  && grep -Fq 'HARDENED_CONFIG_ID=$HardenedConfigId' "$hardening_ps" \
  && grep -Fq 'local recovery is intentionally fail-closed' "$root/scripts/admin/build-sandbox.sh" \
  && grep -Fq 'Labels alone are never sufficient for recovery' "$root/scripts/admin/build-sandbox.ps1" \
  && grep -Fq '.build.env.reuse.' "$root/scripts/admin/build-sandbox.sh" \
  && grep -Fq '.build.env.reuse.' "$root/scripts/admin/build-sandbox.ps1" \
  && grep -Fq 'Registry V2 API' "$hardening_sh" \
  && grep -Fq 'Registry V2 API' "$hardening_ps"; then
  pass 'hardened-base reuse uses config-ID recovery, fail-closed legacy fallback, and transactional digest/tool refresh'
else
  fail 'hardened-base config-ID recovery/transaction contract missing'
fi
grep -Fq 'exec "$SECRET_RUNNER" --profile anthropic -- "$(real_tool claude)"' "$root/.devcontainer/scripts/sandbox-command-wrapper.sh" \
  && grep -Fq 'exec "$SECRET_RUNNER" --profile gemini -- "$(real_tool gemini)"' "$root/.devcontainer/scripts/sandbox-command-wrapper.sh" \
  && grep -Fq 'exec "$SECRET_RUNNER" --profile databricks -- "$(real_tool ucode)"' "$root/.devcontainer/scripts/sandbox-command-wrapper.sh" \
  && grep -Fq 'exec "$SECRET_RUNNER" --profile databricks -- "$(real_tool databricks)"' "$root/.devcontainer/scripts/sandbox-command-wrapper.sh" \
  && pass 'direct Claude/Gemini and explicit ucode/Databricks routing are separated' || fail 'AI command routing contract missing'
grep -q 'AWS_ACCESS_KEY_ID: "${AWS_ACCESS_KEY_ID:-}"' "$root/tar/docker-compose.yml" && grep -q 'AWS_SECRET_ACCESS_KEY: "${AWS_SECRET_ACCESS_KEY:-}"' "$root/tar/docker-compose.yml" && grep -q 'AWS_SSO_START_URL: "${AWS_SSO_START_URL:-}"' "$root/tar/docker-compose.yml" && grep -q 'SANDBOX_AWS_PROFILE:' "$root/tar/docker-compose.yml" && grep -q 'AWS_ACCESS_KEY_ID: "${AWS_ACCESS_KEY_ID:-}"' "$root/ecr/docker-compose.yml" && grep -q 'AWS_SECRET_ACCESS_KEY: "${AWS_SECRET_ACCESS_KEY:-}"' "$root/ecr/docker-compose.yml" && grep -q 'AWS_SSO_START_URL: "${AWS_SSO_START_URL:-}"' "$root/ecr/docker-compose.yml" && grep -q 'SANDBOX_AWS_PROFILE:' "$root/ecr/docker-compose.yml" && ! grep -Eq '^[[:space:]]+AWS_PROFILE:' "$root/tar/docker-compose.yml" && ! grep -Eq '^[[:space:]]+AWS_PROFILE:' "$root/ecr/docker-compose.yml" && pass 'AWS dual-mode values mapped without AWS_PROFILE injection' || fail 'AWS dual-mode Compose/profile isolation missing'
grep -q 'aws_auth_mode="static"' "$root/.devcontainer/scripts/run-with-ssm-secrets.sh" && grep -q 'drop_aws_bootstrap_credentials' "$root/.devcontainer/scripts/run-with-ssm-secrets.sh" && grep -q 'Tavily/Snyk MCP wrappers' "$root/.devcontainer/scripts/run-with-ssm-secrets.sh" && pass 'static AWS credentials have first priority with leaf-process stripping and AI/MCP inheritance' || fail 'static AWS key-first runtime flow with MCP inheritance missing'
grep -q 'Non-secret compatibility profile for static environment credentials' "$root/.devcontainer/scripts/configure-aws-sso.sh" \
  && grep -q '\[default\]' "$root/.devcontainer/scripts/configure-aws-sso.sh" \
  && grep -q 'SANDBOX_AWS_PROFILE' "$root/.devcontainer/scripts/configure-aws-sso.sh" \
  && grep -q 'configure-aws-sso >/dev/null' "$root/.devcontainer/scripts/run-with-ssm-secrets.sh" \
  && pass 'AWS_PROFILE is isolated while default/named AWS config is prepared' || fail 'AWS profile isolation/bootstrap missing'
grep -q 'sandbox-aws-login' "$root/.devcontainer/scripts/run-with-ssm-secrets.sh" && grep -q -- '--use-device-code --no-browser' "$root/.devcontainer/scripts/sandbox-aws-login.sh" && pass 'SSO remains the browser fallback when static keys are absent' || fail 'automatic SSO fallback flow missing'
grep -Fq 'claude-api-key' "$root/scripts/platform/01-setup-ssm.sh" && grep -Fq 'gemini-api-key' "$root/scripts/platform/01-setup-ssm.ps1" && grep -Fq 'claude-api-key' "$root/.devcontainer/scripts/run-with-ssm-secrets.sh" && grep -Fq 'gemini-api-key' "$root/.devcontainer/scripts/run-with-ssm-secrets.sh" && pass 'direct Claude/Gemini API keys are SSM-managed' || fail 'direct AI SSM parameter contract missing'
grep -Fq 'DATABRICKS_CLAUDE_MODEL is required' "$root/.devcontainer/scripts/run-with-ssm-secrets.sh" \
  && grep -Fq -- '--model "$DATABRICKS_CLAUDE_MODEL"' "$root/.devcontainer/scripts/run-with-ssm-secrets.sh" \
  && grep -Fq 'DATABRICKS_CLAUDE_MODEL: "${DATABRICKS_CLAUDE_MODEL:-}"' "$root/tar/docker-compose.yml" \
  && grep -Fq 'DATABRICKS_CLAUDE_MODEL: "${DATABRICKS_CLAUDE_MODEL:-}"' "$root/ecr/docker-compose.yml" \
  && pass 'Claude model is explicit for ucode/Databricks' \
  || fail 'Databricks Claude model routing contract missing'
grep -Fq 'export GEMINI_MODEL="$DATABRICKS_GEMINI_MODEL"' "$root/.devcontainer/scripts/run-with-ssm-secrets.sh" \
  && grep -Fq 'DATABRICKS_GEMINI_MODEL: "${DATABRICKS_GEMINI_MODEL:-}"' "$root/tar/docker-compose.yml" \
  && grep -Fq 'DATABRICKS_GEMINI_MODEL: "${DATABRICKS_GEMINI_MODEL:-}"' "$root/ecr/docker-compose.yml" \
  && grep -Fq 'export GEMINI_MODEL=""' "$root/.devcontainer/scripts/run-with-ssm-secrets.sh" \
  && pass 'Gemini model is explicit for ucode/Databricks while bare Gemini stays direct' || fail 'Databricks Gemini model routing contract missing'
grep -Fxq 'api.anthropic.com' "$root/squid/whitelist.txt" && grep -Fxq 'generativelanguage.googleapis.com' "$root/squid/whitelist.txt" && pass 'direct Anthropic and Gemini API egress is allowlisted' || fail 'direct AI provider egress missing'
grep -Fq 'stash_real ucode' "$root/.devcontainer/Dockerfile" && grep -Fq '/usr/local/bin/ucode' "$root/.devcontainer/Dockerfile" && pass 'ucode is stashed and wrapped as the explicit Databricks launcher' || fail 'ucode wrapper installation missing'
grep -Fq 'run_logged_ephemeral_home tavily' "$root/.devcontainer/scripts/run-with-ssm-secrets.sh" \
  && grep -Fq 'run_logged_snyk_exec_home snyk' "$root/.devcontainer/scripts/run-with-ssm-secrets.sh" \
  && grep -Fq 'XDG_CACHE_HOME="$tmp_home/.cache"' "$root/.devcontainer/scripts/run-with-ssm-secrets.sh" \
  && pass 'Tavily and Snyk use ephemeral writable runtime state' || fail 'Tavily/Snyk read-only HOME regression protection missing'
grep -Fq 'DATABRICKS_CLAUDE_MODEL is required' "$root/.devcontainer/scripts/run-with-ssm-secrets.sh" && grep -Fq 'DATABRICKS_GEMINI_MODEL is required' "$root/.devcontainer/scripts/run-with-ssm-secrets.sh" && pass 'ucode Claude/Gemini fail closed when approved Databricks target is missing' || fail 'ucode Databricks target validation missing'
grep -Fq -- '--use-pat' "$root/.devcontainer/scripts/run-with-ssm-secrets.sh" && grep -Fq 'mktemp -d /tmp/ai-sandbox-ucode' "$root/.devcontainer/scripts/run-with-ssm-secrets.sh" && grep -Fq -- '--skip-validate' "$root/.devcontainer/scripts/run-with-ssm-secrets.sh" && pass 'ucode uses temporary headless PAT configuration' || fail 'ucode headless PAT routing contract missing'
grep -Fq 'function Dc([string[]]$DockerArgs){ & docker compose -f $Compose @DockerArgs }' "$root/scripts/tar/verify-sandbox.ps1" \
  && ! grep -Fq 'function Dc([string[]]$Args)' "$root/scripts/tar/verify-sandbox.ps1" \
  && pass 'PowerShell Docker Compose helper avoids automatic $Args variable collision' || fail 'verify-sandbox.ps1 still uses reserved/automatic $Args parameter'
grep -Fq "ucode configure --help > /tmp/ucode-configure-help.txt 2>&1" "$root/.devcontainer/Dockerfile" && grep -Fq "grep -Fq -- '--use-pat' /tmp/ucode-configure-help.txt" "$root/.devcontainer/Dockerfile" && grep -Fq 'resolve-tool-artifacts.ps1 -Write' "$root/scripts/admin/build-sandbox.ps1" && grep -Fq 'resolve-tool-artifacts.sh --write' "$root/scripts/admin/build-sandbox.sh" && pass 'runtime tool hashes and ucode pin are refreshed on hardened-base reuse' || fail 'tool-artifact refresh on reuse missing'
grep -Fq '/run/ai-sandbox-snyk:rw,exec,nosuid,nodev' "$root/tar/docker-compose.yml" && grep -Fq '/run/ai-sandbox-snyk:rw,exec,nosuid,nodev' "$root/ecr/docker-compose.yml" && grep -Fq 'run_logged_snyk_exec_home' "$root/.devcontainer/scripts/run-with-ssm-secrets.sh" && pass 'Snyk uses isolated executable tmpfs while /tmp remains noexec' || fail 'Snyk executable tmpfs contract missing'
grep -Fq 'vim-tiny' "$root/.devcontainer/Dockerfile" && grep -Fq "'set nomodeline'" "$root/.devcontainer/Dockerfile" && grep -Fq "'set noexrc'" "$root/.devcontainer/Dockerfile" && grep -Fq "'set noswapfile'" "$root/.devcontainer/Dockerfile" && grep -Fq 'chmod 0444 /etc/vim/vimrc.local' "$root/.devcontainer/Dockerfile" && pass 'minimal vi is installed with hardened immutable configuration' || fail 'secure vi/vim-tiny configuration missing'
grep -q '/etc/ai-sandbox/build-info.json' "$root/.devcontainer/Dockerfile" && grep -q '/usr/local/bin/sandbox-info' "$root/.devcontainer/Dockerfile" && pass 'Developer build/runtime info is available without Admin source' || fail 'sandbox-info/build-info missing'
grep -q 'SANDBOX_AUDIT_REQUIRED: "${SANDBOX_AUDIT_REQUIRED:-true}"' "$root/tar/docker-compose.yml" && grep -q 'SANDBOX_AUDIT_REQUIRED: "${SANDBOX_AUDIT_REQUIRED:-true}"' "$root/ecr/docker-compose.yml" && pass 'application audit required by default' || fail 'application audit policy missing'
if command -v jq >/dev/null 2>&1; then
  test_dir="$(mktemp -d)"
  collector="$test_dir/collector.sh"
  cat >"$collector" <<'COLLECT'
#!/usr/bin/env bash
cat >>"${SANDBOX_TEST_LOG:?}"
COLLECT
  chmod +x "$collector"

  hook_test="$test_dir/claude-audit-hook.sh"
  app_test="$test_dir/application-audit.sh"
  sed "s#/usr/local/bin/sandbox-log-emit#$collector#g" "$root/.devcontainer/scripts/claude-audit-hook.sh" >"$hook_test"
  sed "s#/usr/local/bin/sandbox-log-emit#$collector#g" "$root/.devcontainer/scripts/application-audit.sh" >"$app_test"
  chmod +x "$hook_test" "$app_test"

  sensitive="DO-NOT-LOG-$RANDOM-$$"
  hook_tmp="$test_dir/hook.log"
  : >"$hook_tmp"
  printf '%s' "{\"session_id\":\"lint-session\",\"hook_event_name\":\"UserPromptSubmit\",\"prompt\":\"$sensitive\"}" \
    | SANDBOX_TEST_LOG="$hook_tmp" DEVELOPER_ID=lint "$hook_test"
  if grep -Fq "$sensitive" "$hook_tmp"; then fail 'Claude audit hook copied prompt content'; else pass 'Claude audit hook redacts prompt content'; fi
  grep -Fq '"prompt_length"' "$hook_tmp" && pass 'Claude hook records prompt length only' || fail 'Claude hook prompt-length metadata missing'

  content_tmp="$test_dir/content.log"
  : >"$content_tmp"
  printf '%s' "{\"session_id\":\"lint-session\",\"hook_event_name\":\"UserPromptSubmit\",\"prompt\":\"$sensitive\"}" \
    | SANDBOX_TEST_LOG="$content_tmp" SANDBOX_CONTENT_LOGGING=true SANDBOX_AI_ROUTE=databricks-claude DEVELOPER_ID=lint "$hook_test" >/dev/null 2>&1 || true
  if grep -Fq "$sensitive" "$content_tmp" 2>/dev/null && grep -Fq 'databricks-claude' "$content_tmp"; then pass 'Claude content logging is opt-in and route-tagged'; else fail 'Claude opt-in content stream missing prompt/route'; fi

  audit_tmp="$test_dir/application.log"
  : >"$audit_tmp"
  SANDBOX_TEST_LOG="$audit_tmp" DEVELOPER_ID=lint SANDBOX_ENV=poc "$app_test" \
    --app tavily --event process_start --operation 'DO NOT LOG THIS QUERY' --target tavily --status started
  if grep -Fq 'DO NOT LOG THIS QUERY' "$audit_tmp"; then fail 'application audit copied free-form content'; else pass 'application audit rejects/redacts free-form metadata'; fi
  grep -Fq '"operation":"redacted"' "$audit_tmp" && pass 'application audit emitted redacted marker' || fail 'application audit redaction marker missing'
  rm -rf "$test_dir"
else
  skip 'jq unavailable for audit/content regression tests'
fi

echo '[8/10] Unsafe runtime / secret patterns'
for spec in 'privileged:[[:space:]]*true' '/var/run/docker\.sock:' 'image:[[:space:]]+[^#[:space:]]*:latest'; do if grep -RInE "$spec" "$root" --exclude='lint-package.*' --exclude='*.md' >/dev/null 2>&1; then fail "unsafe pattern: $spec"; else pass "no unsafe pattern: $spec"; fi; done
if grep -RInE '(dapi[a-zA-Z0-9]{20,}|AKIA[0-9A-Z]{16}|-----BEGIN (RSA |EC |OPENSSH )?PRIVATE KEY-----)' "$root" --exclude='lint-package.*' >/dev/null 2>&1; then fail 'potential secret material found'; else pass 'no obvious committed secret material'; fi

echo '[9/10] SH/PS1 workflow parity'
while IFS= read -r sh; do ps="${sh%.sh}.ps1"; [[ "$sh" == "$root/scripts/common/load-build-env.sh" ]] && ps="$root/scripts/common/Load-BuildEnv.ps1"; [[ -f "$ps" ]] && pass "${sh#$root/}" || fail "missing PS1 peer for ${sh#$root/}"; done < <(find "$root/scripts" "$root/ado-scripts" -type f -name '*.sh' | sort)
while IFS= read -r ps; do sh="${ps%.ps1}.sh"; [[ "$ps" == "$root/scripts/common/Load-BuildEnv.ps1" ]] && sh="$root/scripts/common/load-build-env.sh"; [[ -f "$sh" ]] || fail "missing SH peer for ${ps#$root/}"; done < <(find "$root/scripts" "$root/ado-scripts" -type f -name '*.ps1' | sort)

obsolete=(.devcontainer/.dockerignore scripts/ecr/devcontainer.template.json policies/registry.json.template WINDOWS-QUICKSTART.md RUNTIME-POLICY.md poc scripts/poc templates/developer/devcontainer-production.json templates/developer/DEVELOPER-GUIDE-POC.md templates/developer/DEVELOPER-GUIDE-PRODUCTION.md scripts/monitoring/send-logs-ingestion.ps1 scripts/monitoring/send-logs-ingestion.sh sentinel/dcr-logs-ingestion.example.json templates/developer/env.example)
for f in "${obsolete[@]}"; do [[ ! -e "$root/$f" ]] && pass "obsolete absent: $f" || fail "obsolete duplicate returned: $f"; done
if find "$root/docs" -maxdepth 1 -type f -name 'RELEASE-NOTES-v1.16.*.md' | grep -q .; then fail 'release-history documents were packaged despite the active-package boundary'; else pass 'release-history documents are external to the active package'; fi

obsolete_build_keys='HARDENED_METHOD|HARDENED_PROFILE|MAX_CRITICAL_FINDINGS|MAX_HIGH_FINDINGS|REQUIRE_IMAGE_SIGNING|COSIGN_KEY_REF'
if grep -Eq "^(${obsolete_build_keys})=" "$root/.build.env.example"; then fail 'obsolete/unimplemented build-env parameters remain in public template'; else pass 'obsolete/unimplemented build-env parameters are absent from public template'; fi
if find "$root" -type d -name __pycache__ -o -type f -name '*.pyc' | grep -q .; then fail 'Python cache artifacts are packaged'; else pass 'Python cache artifacts are absent'; fi
grep -Fxq 'tar/images/' "$root/.dockerignore" && grep -Fxq '.build.env' "$root/.dockerignore" && grep -Fxq 'hardened-base-build/' "$root/.dockerignore"   && pass '.dockerignore excludes TAR bundles, live build state, and hardening scratch data' || fail '.dockerignore build-context exclusions are incomplete'

echo '[10/10] Squid whitelist overlap'
mapfile -t wl < <(grep -vE '^\s*(#|$)' "$root/squid/whitelist.txt" | tr '[:upper:]' '[:lower:]'); overlap=0
for child in "${wl[@]}"; do for parent in "${wl[@]}"; do [[ "$parent" == .* ]] || continue; [[ "$child" == "$parent" ]] && continue; bare="${parent#.}"; if [[ "$child" == "$bare" || "$child" == *"$parent" ]]; then fail "whitelist overlap: $child covered by $parent"; overlap=1; fi; done; done
((overlap==0)) && pass 'no overlapping Squid domains'

# Optional content logging contract
grep -Fq 'SANDBOX_CONTENT_LOGGING=false' "$root/.env.example" && pass 'content logging defaults to false' || fail 'content logging default missing'
grep -Fq 'CONTENT_SOURCE="ucode-claude"' "$root/.devcontainer/scripts/claude-audit-hook.sh" && grep -Fq 'export SANDBOX_AI_ROUTE="databricks-gemini"' "$root/.devcontainer/scripts/run-with-ssm-secrets.sh" && grep -Fq '/usr/local/bin/sandbox-log-emit gemini-telemetry "$source"' "$root/.devcontainer/scripts/run-with-ssm-secrets.sh" && grep -Fq 'GEMINI_TELEMETRY_OUTFILE="/proc/self/fd/${GEMINI_TELEMETRY_PIPE_FD}"' "$root/.devcontainer/scripts/run-with-ssm-secrets.sh" && pass 'Databricks-routed content is route-tagged and Docker-streamed' || fail 'ucode content stream routing missing'
grep -Fq 'GEMINI_TELEMETRY_TRACES_ENABLED="true"' "$root/.devcontainer/scripts/run-with-ssm-secrets.sh" && pass 'Gemini response/content traces are gated by runtime wrapper' || fail 'Gemini content trace toggle missing'
echo '======================================'
if ((failures)); then echo "LINT FAILED: $failures issue(s)." >&2; exit 1; fi
echo 'LINT PASSED: package is structurally valid.'
