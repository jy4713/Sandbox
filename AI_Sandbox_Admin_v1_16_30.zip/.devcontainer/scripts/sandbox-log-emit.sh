#!/usr/bin/env bash
# =============================================================================
# PACKAGE MAINTENANCE NOTES
# Purpose: Append a single structured stream to the container's PID1 stdout.
#          Docker owns the retained log stream; the DevContainer receives no
#          writable audit/access/content log filesystem mount.
# Security: This is append-only from inside the container. /proc/1/fd/1 is a
#           pipe/stream, not a seekable log file, so prior records cannot be
#           edited or truncated by the Developer process.
# Usage:   printf '%s\n' '<record>' | sandbox-log-emit <stream> [source]
# =============================================================================
set -euo pipefail
set +x
umask 077
stream="${1:-}"
source_name="${2:-sandbox}"
target="/proc/1/fd/1"
case "$stream" in
  audit|security|application|claude-events|content|gemini-telemetry|verification) ;;
  *) echo "ERROR: unsupported sandbox log stream: $stream" >&2; exit 2 ;;
esac
stream="$(printf '%s' "$stream" | tr -cd 'A-Za-z0-9._-')"
source_name="$(printf '%s' "$source_name" | tr -cd 'A-Za-z0-9._:-' | cut -c1-64)"
[[ -n "$source_name" ]] || source_name=sandbox
# Use the already-existing /tmp directory inode only as an advisory flock
# anchor. No writable log/lock file is created that a Developer can replace.
exec 9</tmp
flock -x 9
while IFS= read -r line || [[ -n "$line" ]]; do
  printf 'AI_SANDBOX_LOG|%s|%s|%s\n' "$stream" "$source_name" "$line" >> "$target"
done
