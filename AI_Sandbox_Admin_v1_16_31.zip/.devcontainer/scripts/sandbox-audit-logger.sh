#!/usr/bin/env bash
# =============================================================================
# PACKAGE MAINTENANCE NOTES
# Purpose: Write shell, Git and security audit metadata to the Docker-owned
#          append-only container log stream without copying arbitrary arguments.
# Admin maintenance: Keep this metadata-only. Secret-bearing arguments, prompts,
#                    search queries, source code and response payloads must not
#                    be written to the audit/security Docker streams.
# Performance: This file may be sourced from multiple Bash startup mechanisms.
#              The per-shell guard prevents duplicate PROMPT_COMMAND hooks and
#              duplicate SESSION_START records.
# =============================================================================

# Do not install the same hook twice in one shell. The variable is intentionally
# not exported, so child non-login Bash processes still load their own audit
# functions through BASH_ENV.
if [[ "${_AI_SANDBOX_AUDIT_LOGGER_LOADED:-0}" == "1" ]]; then
  return 0 2>/dev/null || exit 0
fi
_AI_SANDBOX_AUDIT_LOGGER_LOADED=1

DEVELOPER_ID="${DEVELOPER_ID:-unknown}"

_aw() {
  printf '%s | %-16s | user=%-10s | %-50s | %s\n' \
    "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$1" "$DEVELOPER_ID" "$2" "${3:-}" \
    | /usr/local/bin/sandbox-log-emit audit shell
}

_sw() {
  # Arguments to _sw must already be metadata-only. jq is avoided here so the
  # shell hook remains lightweight and available during early shell startup.
  local detail="${3:-}"
  detail="$(printf '%s' "$detail" | tr -cd 'A-Za-z0-9._:@/+\-= ' | cut -c1-160)"
  printf '{"ts":"%s","sev":"%s","event":"%s","user":"%s","detail":"%s","host":"%s"}\n' \
    "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$1" "$2" "$DEVELOPER_ID" "$detail" "$(hostname)" \
    | /usr/local/bin/sandbox-log-emit security shell
}

_cmd_metadata() {
  local cmd="${1:-}" first="unknown" second="none" argc=0
  local -a words=()
  # Bash word splitting is sufficient for attribution; this is metadata only and
  # deliberately does not attempt to reconstruct or log the original command.
  read -r -a words <<< "$cmd"
  argc="${#words[@]}"
  if (( argc > 0 )); then
    first="${words[0]##*/}"
  fi
  if (( argc > 1 )); then
    second="${words[1]}"
  fi
  case "$first" in
    run-with-ssm-secrets)
      printf 'tool=run-with-ssm-secrets argc=%s' "$argc"
      ;;
    claude|claude-code|gemini|gemini-cli|tvly|tavily-mcp|snyk|databricks|ado-trigger|ado-pr-create|ado-auth-setup)
      printf 'tool=%s subcommand=%s argc=%s' "$first" "$second" "$argc"
      ;;
    git)
      printf 'tool=git subcommand=%s argc=%s' "$second" "$argc"
      ;;
    *)
      printf 'tool=%s subcommand=%s argc=%s' "$first" "$second" "$argc"
      ;;
  esac
}

_sandbox_log_cmd() {
  local ec=$? cmd meta url host
  cmd=$(HISTTIMEFORMAT='' history 1 | sed 's/^[[:space:]]*[0-9]*[[:space:]]*//')
  [[ -z "$cmd" || "$cmd" == "_sandbox_log_cmd" ]] && return 0
  meta="$(_cmd_metadata "$cmd")"

  # Shell-command audit is post-execution metadata. Logging failure must not
  # freeze or corrupt the Developer's interactive prompt; required application
  # audit remains fail-closed in application-audit.
  _aw "SHELL_CMD" "$meta" "exit=$ec cwd=$(pwd)" >/dev/null 2>&1 || true

  # Detect high-risk patterns from the in-memory command but record only the
  # category, never the original command string. Bash regex avoids spawning grep
  # on every prompt.
  if [[ "$cmd" =~ sudo|chmod[[:space:]]+[0-7]*7|curl.*\|.*sh|wget.*\|.*sh|(^|[[:space:]])nc[[:space:]]|(^|[[:space:]])ncat[[:space:]] ]]; then
    _sw "HIGH" "suspicious_cmd" "$meta" >/dev/null 2>&1 || true
  fi

  # For direct curl/wget, record only the destination hostname, not the URL path,
  # query string, headers, body or command arguments.
  if [[ "$cmd" =~ (^|[[:space:]])(curl|wget)([[:space:]]|$) && "$cmd" =~ https?://[^[:space:]]+ ]]; then
    url="${BASH_REMATCH[0]}"
    url="${url#http://}"; url="${url#https://}"
    url="${url#*@}"
    host="${url%%[/:?#]*}"
    [[ -n "$host" ]] && _aw "EGRESS_ATTEMPT" "tool=curl-wget" "host=${host:0:120}" >/dev/null 2>&1 || true
  fi
  return 0
}

# Install the prompt hook exactly once. Preserve any pre-existing PROMPT_COMMAND.
if [[ $- == *i* ]]; then
  case ";${PROMPT_COMMAND:-};" in
    *';_sandbox_log_cmd;'*) ;;
    *) PROMPT_COMMAND="_sandbox_log_cmd${PROMPT_COMMAND:+; $PROMPT_COMMAND}" ;;
  esac
fi

# Interactive git wrapper. Secret-backed non-interactive ADO git operations are
# separately attributed by run-with-ssm-secrets to the ADO application stream.
git() {
  local sub="${1:-none}" start_ms end_ms duration_ms ec status
  _aw "GIT_OP" "git subcommand=${sub:0:32}" "argc=$#" >/dev/null 2>&1 || true
  if [[ "$sub" == "push" ]]; then
    _sw "INFO" "git_push" "push requested" >/dev/null 2>&1 || true
  fi
  start_ms="$(date +%s%3N)"
  if command -v application-audit >/dev/null 2>&1; then
    application-audit --app git --event process_start --operation "$sub" --target repository --status started >/dev/null 2>&1 || true
  fi
  command git "$@"
  ec=$?
  end_ms="$(date +%s%3N)"; duration_ms=$((end_ms-start_ms)); status=success; (( ec == 0 )) || status=failure
  if command -v application-audit >/dev/null 2>&1; then
    application-audit --app git --event process_end --operation "$sub" --target repository --status "$status" --exit-code "$ec" --duration-ms "$duration_ms" >/dev/null 2>&1 || true
  fi
  return "$ec"
}

sudo() {
  _sw "HIGH" "sudo_attempt" "sudo requested" >/dev/null 2>&1 || true
  _aw "SECURITY" "sudo_attempt" "arguments_redacted=true" >/dev/null 2>&1 || true
  command sudo "$@"
}

# ADO helper functions retained for scripts that source this logger. Free-form PR
# titles, pipeline parameters and repository URLs are intentionally not logged.
log_ado_trigger()    { _aw "ADO_PIPELINE" "trigger" "pipeline_id=${1:-unknown}" >/dev/null 2>&1 || true; }
log_ado_pr_create()  { _aw "ADO_PR" "create_pr" "metadata_redacted=true" >/dev/null 2>&1 || true; }
log_ado_git_clone()  { _aw "ADO_GIT" "clone" "remote_redacted=true" >/dev/null 2>&1 || true; }
export -f log_ado_trigger log_ado_pr_create log_ado_git_clone 2>/dev/null || true

_aw "SESSION_START" "shell=${SHELL##*/}" "tty=$(tty 2>/dev/null || echo notty)" >/dev/null 2>&1 || true
