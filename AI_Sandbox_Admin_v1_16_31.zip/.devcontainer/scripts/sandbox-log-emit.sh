#!/usr/bin/env bash
# =============================================================================
# PACKAGE MAINTENANCE NOTES
# Purpose: Append structured records to the container's PID1 stdout. Docker owns
#          the retained log stream; the DevContainer receives no writable
#          audit/access/content log filesystem mount.
# Security: /proc/1/fd/1 is a stream, not a seekable log file, so prior records
#           cannot be edited or truncated through the container filesystem.
# Performance: Serialization is acquired and released for EACH record. Never
#              hold the flock while waiting for a long-lived input stream (for
#              example Gemini telemetry), because that would stall interactive
#              shell audit records until the producer exits.
# Usage:   printf '%s\n' '<record>' | sandbox-log-emit <stream> [source]
# =============================================================================
set -euo pipefail
set +x
umask 077

stream="${1:-}"
source_name="${2:-sandbox}"
target="/proc/1/fd/1"
lock_timeout="1"

case "$stream" in
  audit|security|application|claude-events|content|gemini-telemetry|verification) ;;
  *) echo "ERROR: unsupported sandbox log stream: $stream" >&2; exit 2 ;;
esac

stream="$(printf '%s' "$stream" | tr -cd 'A-Za-z0-9._-')"
source_name="$(printf '%s' "$source_name" | tr -cd 'A-Za-z0-9._:-' | cut -c1-64)"
[[ -n "$source_name" ]] || source_name=sandbox
# Use the already-existing /tmp directory inode only as an advisory lock anchor.
# The lock is deliberately scoped to a SINGLE write. Long-lived producers keep
# reading after the lock is released, so they cannot monopolize interactive
# audit logging. A bounded wait prevents a broken sink from freezing a shell.
exec 9</tmp
while IFS= read -r line || [[ -n "$line" ]]; do
  if ! flock -w "$lock_timeout" -x 9; then
    echo "ERROR: sandbox log serialization timeout for stream: $stream" >&2
    exit 75
  fi
  printf 'AI_SANDBOX_LOG|%s|%s|%s\n' "$stream" "$source_name" "$line" >> "$target"
  flock -u 9
 done
