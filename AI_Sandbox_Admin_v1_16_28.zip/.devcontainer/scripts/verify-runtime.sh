#!/usr/bin/env bash
# =============================================================================
# PACKAGE MAINTENANCE NOTES
# Purpose: Verifies installed tools, writable-path restrictions, secret handling and runtime prerequisites inside the devcontainer.
# Admin maintenance: Every added or removed application should be reflected here so image drift is detected immediately after container creation.
# Safety rule: preserve secret-free images/configuration, immutable version or
# digest pinning where applicable, and update the paired Bash/PowerShell path.
# After any change, run scripts/ci/lint-package.* and the applicable build/QA.
# Full change procedure: docs/ADMIN-COMPLETE-GUIDE.md
# =============================================================================
# =============================================================================
# Runtime security and component verification. Runs INSIDE the devcontainer.
# =============================================================================
set -uo pipefail
failures=0; warnings=0
check(){ local d="$1"; shift; if "$@" >/dev/null 2>&1; then printf '  [OK]   %s\n' "$d"; else printf '  [FAIL] %s\n' "$d" >&2; failures=$((failures+1)); fi; }
soft_check(){ local d="$1"; shift; if "$@" >/dev/null 2>&1; then printf '  [OK]   %s\n' "$d"; else printf '  [WARN] %s\n' "$d" >&2; warnings=$((warnings+1)); fi; }

echo '=== Runtime security verification ==='
echo; echo '-- Identity and privileges --'
check 'running as UID 1000' test "$(id -u)" = 1000
check 'running as GID 1000' test "$(id -g)" = 1000
check 'sudo is not installed' bash -c '! command -v sudo >/dev/null 2>&1'
check 'effective capabilities are zero' bash -c '[[ "$(awk "/^CapEff:/ {print \$2}" /proc/self/status)" == 0000000000000000 ]]'
check 'no-new-privileges is set' bash -c '[[ "$(awk "/^NoNewPrivs:/ {print \$2}" /proc/self/status)" == 1 ]]'

echo; echo '-- Filesystem --'
check 'root filesystem is read-only' bash -c 'if touch /etc/.sandbox-write-test 2>/dev/null; then rm -f /etc/.sandbox-write-test; exit 1; fi'
check 'no SUID or SGID files remain' bash -c '[[ -z "$(find / -xdev -type f -perm /6000 -print -quit 2>/dev/null)" ]]'
check 'umask is 027 (login shell)' bash -c 'u="$(bash -lc umask)"; [[ "$u" == 0027 || "$u" == 027 ]]'
check 'umask is 027 (non-login bash)' bash -c 'u="$(bash -c umask)"; [[ "$u" == 0027 || "$u" == 027 ]]'
check 'umask is 027 (posix sh)' bash -c 'u="$(sh -c umask)"; [[ "$u" == 0027 || "$u" == 027 ]]'
check '/tmp is noexec' bash -c 'findmnt -no OPTIONS /tmp | grep -q noexec'
check 'Snyk runtime tmpfs is writable and exec-enabled' bash -c 'opts="$(findmnt -no OPTIONS /run/ai-sandbox-snyk)"; [[ -w /run/ai-sandbox-snyk && ",${opts}," != *,noexec,* && ",${opts}," == *,nosuid,* && ",${opts}," == *,nodev,* ]]'

check 'minimal vi editor is installed' bash -c 'command -v vi >/dev/null && vi_out="$(vi --version 2>/dev/null)" && [[ "$vi_out" == *"Vi IMproved"* ]]'
check 'vi security policy is root-owned and non-writable' bash -c '[[ -f /etc/vim/vimrc.local && "$(stat -c %U:%G /etc/vim/vimrc.local)" == "root:root" && ! -w /etc/vim/vimrc.local ]]'
check 'vi disables local config, modelines, swap, backup, undo, and viminfo persistence' bash -c 'grep -Fqx "set nomodeline" /etc/vim/vimrc.local && grep -Fqx "set noexrc" /etc/vim/vimrc.local && grep -Fqx "set noswapfile" /etc/vim/vimrc.local && grep -Fqx "set nobackup" /etc/vim/vimrc.local && grep -Fqx "set nowritebackup" /etc/vim/vimrc.local && grep -Fqx "set noundofile" /etc/vim/vimrc.local && grep -Fqx "set viminfo=" /etc/vim/vimrc.local'
check '/home/vscode/workspace is writable' bash -c 'touch /home/vscode/workspace/.verify-test && rm -f /home/vscode/workspace/.verify-test'
check 'Claude managed audit/web policy is configured' bash -c "jq -e '(.allowManagedHooksOnly == true) and (.hooks.SessionStart[0].hooks[0].command==\"/usr/local/bin/claude-audit-hook\") and (.hooks.PostToolUse[0].hooks[0].command==\"/usr/local/bin/claude-audit-hook\")' /etc/claude-code/managed-settings.json >/dev/null"
check 'Gemini telemetry targets Docker PID1 stream and prompt logging is disabled' bash -c '[[ "${GEMINI_TELEMETRY_ENABLED:-}" == "true" && "${GEMINI_TELEMETRY_TARGET:-}" == "local" && "${GEMINI_TELEMETRY_OUTFILE:-}" == "/proc/1/fd/1" && "${GEMINI_TELEMETRY_LOG_PROMPTS:-}" == "false" ]]'
check 'AI config directories are writable' bash -c 'touch "$HOME/.claude/.verify" "$HOME/.gemini/.verify" && rm -f "$HOME/.claude/.verify" "$HOME/.gemini/.verify"'
check 'AWS config dir is writable' bash -c 'touch "$HOME/.aws/.verify-test" && rm -f "$HOME/.aws/.verify-test"'

echo; echo '-- Secrets isolation / AWS bootstrap --'
check 'IMDS is disabled' bash -c '[[ "${AWS_EC2_METADATA_DISABLED:-}" == true ]]'
check 'AWS_PROFILE/AWS_DEFAULT_PROFILE are not injected into the DevContainer' bash -c '[[ -z "${AWS_PROFILE:-}" && -z "${AWS_DEFAULT_PROFILE:-}" ]]'
if [[ -n "${AWS_ACCESS_KEY_ID:-}" || -n "${AWS_SECRET_ACCESS_KEY:-}" || -n "${AWS_SESSION_TOKEN:-}" ]]; then
  check 'static AWS credential pair is complete' bash -c '[[ -n "${AWS_ACCESS_KEY_ID:-}" && -n "${AWS_SECRET_ACCESS_KEY:-}" ]]'
else
  check 'AWS SSO profile is configured without STS preflight' bash -c 'grep -Fq "[profile ${SANDBOX_AWS_PROFILE:-sandbox}]" "${AWS_CONFIG_FILE:-$HOME/.aws/config}"'
fi
check 'no application/service secrets in parent environment' bash -c '! env | grep -Eq "^(ADO_PAT|DATABRICKS_TOKEN|GEMINI_API_KEY|ANTHROPIC_API_KEY|ANTHROPIC_AUTH_TOKEN|TAVILY_API_KEY|SNYK_TOKEN|HIDDENLAYER_CLIENT_ID|HIDDENLAYER_CLIENT_SECRET)="'
check 'no obvious tokens in workspace' bash -c '! grep -rqE "(ANTHROPIC_API_KEY|GEMINI_API_KEY|DATABRICKS_TOKEN|TAVILY_API_KEY|SNYK_TOKEN|HIDDENLAYER_CLIENT_SECRET)[[:space:]]*=" /home/vscode/workspace 2>/dev/null'
check 'no git credential file on disk' bash -c '[[ ! -f "$HOME/.git-credentials" && ! -f "$HOME/.git-credentials-ado" ]]'
check 'no credential.helper store' bash -c '! git config --global credential.helper 2>/dev/null | grep -q store'

echo; echo '-- Required tools --'
# APPLICATION MAINTENANCE ZONE - REQUIRED COMMANDS
# Add/remove commands here whenever the approved application set changes.
for tool in node python3 git vi jq flock aws az databricks claude gemini ucode tvly tavily-mcp snyk run-with-ssm-secrets application-audit git-askpass-ado configure-mcp configure-aws-sso sandbox-aws-login sandbox-info tavily-mcp-ssm databricks-sql-mcp-ssm snyk-mcp-ssm claude-audit-hook; do
  check "$tool is available" command -v "$tool"
done

echo; echo '-- Configuration --'
check 'read-only build provenance exists' test -r /etc/ai-sandbox/build-info.json
if [[ -n "${AWS_ACCESS_KEY_ID:-}" && -n "${AWS_SECRET_ACCESS_KEY:-}" ]]; then
  check 'AWS authentication mode is static-key first' true
elif [[ -n "${AWS_SSO_START_URL:-}" && "${AWS_SSO_START_URL:-}" != *'<'* ]]; then
  check 'AWS SSO fallback profile is preconfigured' bash -c 'grep -Fq "[profile ${SANDBOX_AWS_PROFILE:-sandbox}]" "${AWS_CONFIG_FILE:-$HOME/.aws/config}"'
else
  soft_check 'AWS SSO fallback values configured by Admin' false
fi
if [[ -n "${DATABRICKS_HOST:-}" ]]; then
  check 'DATABRICKS_HOST uses https when ucode/Databricks routing is configured' bash -c '[[ "$DATABRICKS_HOST" == https://* ]]'
else
  soft_check 'Databricks routing configured when ucode is required' false
fi
if [[ -n "${DATABRICKS_CLAUDE_MODEL:-}" ]]; then
  check 'Databricks Claude model is not a placeholder' bash -c '[[ "$DATABRICKS_CLAUDE_MODEL" != *"<"* && "$DATABRICKS_CLAUDE_MODEL" != *">"* ]]'
else
  soft_check 'DATABRICKS_CLAUDE_MODEL configured when ucode claude is required' false
fi
if [[ -n "${DATABRICKS_GEMINI_MODEL:-}" ]]; then
  check 'Databricks Gemini model is not a placeholder' bash -c '[[ "$DATABRICKS_GEMINI_MODEL" != *"<"* && "$DATABRICKS_GEMINI_MODEL" != *">"* ]]'
else
  soft_check 'DATABRICKS_GEMINI_MODEL configured when ucode gemini is required' false
fi
check 'Claude managed MCP config is root-owned and non-writable' bash -c '[[ -r /etc/claude-code/managed-mcp.json && "$(stat -c %U:%G /etc/claude-code/managed-mcp.json)" == "root:root" && ! -w /etc/claude-code/managed-mcp.json ]]'
claude_admin_mcp_ok() {
  jq -e '(.mcpServers.tavily.command=="/usr/local/bin/tavily-mcp-ssm") and (.mcpServers.snyk.command=="/usr/local/bin/snyk-mcp-ssm") and (.mcpServers["databricks-sql"].command=="/usr/local/bin/databricks-sql-mcp-ssm")' /etc/claude-code/managed-mcp.json >/dev/null
}
check 'Claude Admin MCP config contains Tavily/Snyk/Databricks SQL wrappers' claude_admin_mcp_ok
check 'Gemini MCP contains Tavily and Snyk wrappers' bash -c 'jq -e '\''(.mcpServers.tavily.command=="/usr/local/bin/tavily-mcp-ssm") and (.mcpServers.snyk.command=="/usr/local/bin/snyk-mcp-ssm")'\'' "$HOME/.gemini/settings.json" >/dev/null'

# v1.16.28: Gemini strips inherited sensitive env vars before launching stdio
# MCP servers. The managed env block therefore contains ONLY literal runtime
# references to the AWS bootstrap variables. Real AWS values must never be
# persisted. In SSO mode these references resolve empty (or are discarded by
# the MCP preamble) and the stable SANDBOX_AWS_HOME cache is used instead.
gemini_mcp_runtime_refs_ok() {
  jq -e '
    def refs: {
      AWS_ACCESS_KEY_ID: "$AWS_ACCESS_KEY_ID",
      AWS_SECRET_ACCESS_KEY: "$AWS_SECRET_ACCESS_KEY",
      AWS_SESSION_TOKEN: "$AWS_SESSION_TOKEN"
    };
    (.mcpServers.tavily.env == refs) and (.mcpServers.snyk.env == refs) and (.mcpServers["databricks-sql"].env == refs)
  ' "$HOME/.gemini/settings.json" >/dev/null
}
ucode_gemini_mcp_contract_ok() {
  grep -Fq 'GEMINI_CLI_HOME="$ucode_gemini_cli_home"' /usr/local/bin/run-with-ssm-secrets &&
  grep -Fq 'from ucode.agents.gemini import GEMINI_HOME_DIR' /usr/local/bin/run-with-ssm-secrets
}
check 'Gemini MCP uses only approved AWS runtime references' gemini_mcp_runtime_refs_ok
check 'no literal AWS access-key credential in Gemini MCP settings' bash -c '! grep -Eq "(AKIA|ASIA)[A-Z0-9]{16}" "$HOME/.gemini/settings.json"'
check 'ucode Gemini MCP config targets its managed GEMINI_CLI_HOME' ucode_gemini_mcp_contract_ok
check 'Gemini MCP start-up budget allows SSM credential resolution' bash -c 'jq -e '\''((.mcpServers.tavily.timeout // 0) >= 60000) and ((.mcpServers.snyk.timeout // 0) >= 120000) and ((.mcpServers["databricks-sql"].timeout // 0) >= 120000)'\'' "$HOME/.gemini/settings.json" >/dev/null'
check 'Tavily allowlist is root-owned and non-writable' bash -c '[[ -r /etc/ai-sandbox/tavily-allowed-domains.json && "$(stat -c %U:%G /etc/ai-sandbox/tavily-allowed-domains.json)" == "root:root" && ! -w /etc/ai-sandbox/tavily-allowed-domains.json ]]'
check 'Tavily MCP hard policy proxy is installed' bash -c '[[ -x /usr/local/libexec/ai-sandbox/tavily-policy-proxy.py ]]'
check 'Gemini Admin web policy is root-owned and non-writable' bash -c '[[ -r /etc/gemini-cli/policies/ai-sandbox-web.toml && "$(stat -c %U:%G /etc/gemini-cli/policies)" == "root:root" && ! -w /etc/gemini-cli/policies ]]'
check 'Claude native WebSearch/WebFetch are denied by managed settings' bash -c 'jq -e '"'"'(.permissions.deny | index("WebSearch")) != null and (.permissions.deny | index("WebFetch")) != null'"'"' /etc/claude-code/managed-settings.json >/dev/null'
check 'Claude only loads Admin-managed hooks' bash -c 'jq -e '"'"'.allowManagedHooksOnly == true'"'"' /etc/claude-code/managed-settings.json >/dev/null'
audit_profile_mapping_ok() {
  grep -Fq "databricks-sql-mcp) printf 'databricks' ;;" /usr/local/bin/run-with-ssm-secrets &&
  ! grep -Fq 'audit_safe "$profile"' /usr/local/bin/run-with-ssm-secrets
}
check 'Databricks SQL MCP internal profile uses approved databricks audit namespace' audit_profile_mapping_ok
check 'MCP wrapper environment preamble is installed' bash -c '[[ -r /usr/local/libexec/ai-sandbox/mcp-wrapper-preamble ]]'
check 'Snyk native runtime cache is pre-warmed in the image' bash -c '[[ -d /opt/snyk-cache ]]'

# AWS authentication must stay reachable from short-lived HOME directories.
check 'AWS state anchor is configured' bash -c '[[ -n "${SANDBOX_AWS_HOME:-}" && -d "${SANDBOX_AWS_HOME:-/nonexistent}/.aws" ]]'
check 'AWS CLI state is reachable independently of HOME' bash -c 'env HOME=/tmp aws configure list-profiles >/dev/null 2>&1 || env HOME="${SANDBOX_AWS_HOME:-/home/vscode}" aws configure list-profiles >/dev/null 2>&1'
check 'runtime secret runner uses direct SSM authentication' grep -q 'aws_cli ssm get-parameter' /usr/local/bin/run-with-ssm-secrets
if [[ -n "${HIDDENLAYER_API_URL:-}" ]]; then check 'HiddenLayer API URL uses https' bash -c '[[ "$HIDDENLAYER_API_URL" == https://* ]]'; else soft_check 'HiddenLayer API URL configured when service is required' false; fi
check 'audit logger is loaded (non-login bash)' bash -c 'bash -c "declare -f _aw" >/dev/null 2>&1'
check 'application audit policy requires logging by default' bash -c '[[ "${SANDBOX_AUDIT_REQUIRED:-true}" == "true" ]]'
check 'managed log emitter hardcodes PID1 Docker stream' grep -Fq 'target="/proc/1/fd/1"' /usr/local/bin/sandbox-log-emit
check 'protected sandbox host log mount is non-writable' bash -c '[[ -d /var/log/sandbox && ! -w /var/log/sandbox ]]'
check 'protected sandbox host log mount is mounted read-only' bash -c 'findmnt -T /var/log/sandbox -n -o OPTIONS | tr "," "\n" | grep -qx ro'
check 'Docker socket is not mounted' bash -c '[[ ! -e /var/run/docker.sock ]]'
check 'content logging defaults disabled unless explicitly enabled' bash -c '[[ "${SANDBOX_CONTENT_LOGGING:-false}" == "false" || "${SANDBOX_CONTENT_LOGGING:-false}" == "true" ]]'
check 'application-audit rejects unsupported application names' bash -c '! application-audit --app unsupported --event test >/dev/null 2>&1'
check 'public application commands use the SSM-aware wrapper' bash -c 'for c in claude gemini ucode tvly tavily-mcp snyk databricks; do [[ "$(readlink -f "/usr/local/bin/$c")" == "/usr/local/libexec/ai-sandbox/sandbox-command-wrapper" ]]; done'
check 'stashed real application executables are available' bash -c 'for c in claude gemini ucode tvly tavily-mcp mcp-remote snyk databricks; do [[ -x "/usr/local/libexec/ai-sandbox/real/$c" ]]; done'
check 'bare Claude is routed to Anthropic and requires managed MCP config' bash -c 'grep -Fq '"'"'/etc/claude-code/managed-mcp.json'"'"' /usr/local/libexec/ai-sandbox/sandbox-command-wrapper && grep -Fq '"'"'exec "$SECRET_RUNNER" --profile anthropic -- "$(real_tool claude)"'"'"' /usr/local/libexec/ai-sandbox/sandbox-command-wrapper'
check 'bare Gemini is routed to the direct Gemini SSM profile' grep -Fq 'exec "$SECRET_RUNNER" --profile gemini -- "$(real_tool gemini)"' /usr/local/libexec/ai-sandbox/sandbox-command-wrapper
check 'ucode is routed to the Databricks SSM profile' grep -Fq 'exec "$SECRET_RUNNER" --profile databricks -- "$(real_tool ucode)"' /usr/local/libexec/ai-sandbox/sandbox-command-wrapper
check 'ucode Claude requires the managed MCP deployment' grep -Fq '/etc/claude-code/managed-mcp.json' /usr/local/bin/run-with-ssm-secrets
check 'installed ucode supports required headless PAT options' bash -c '/usr/local/libexec/ai-sandbox/real/ucode configure --help 2>&1 | grep -q -- "--use-pat" && /usr/local/libexec/ai-sandbox/real/ucode configure --help 2>&1 | grep -q -- "--profiles" && /usr/local/libexec/ai-sandbox/real/ucode configure --help 2>&1 | grep -q -- "--skip-validate"'

echo; echo '======================================'
if ((failures>0)); then printf 'FAILED: %d check(s) failed, %d warning(s).\n' "$failures" "$warnings" >&2; exit 1; fi
if ((warnings>0)); then printf 'PASSED with %d warning(s).\n' "$warnings"; else echo 'PASSED: all runtime checks succeeded.'; fi
