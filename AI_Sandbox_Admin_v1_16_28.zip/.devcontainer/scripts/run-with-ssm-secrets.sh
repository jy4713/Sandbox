#!/usr/bin/env bash
# =============================================================================
# PACKAGE MAINTENANCE NOTES
# Purpose: Fetch the minimum required AWS SSM values, inject them into one child
#          process, and write redacted application/integration audit metadata.
# Routing contract:
#   claude       -> Anthropic official API via /sandbox/claude-api-key
#   gemini       -> Google Gemini official API via /sandbox/gemini-api-key
#   ucode ...    -> Databricks via /sandbox/databricks-token
#   databricks   -> Databricks via /sandbox/databricks-token
#   databricks-sql-mcp -> Databricks managed SQL MCP via /sandbox/databricks-sql-mcp-token
# AWS authentication contract (v1.16.28):
#   Priority 1  static AWS_ACCESS_KEY_ID/AWS_SECRET_ACCESS_KEY from the runtime
#               environment. Never falls back to SSO if these are present.
#   Priority 2  IAM Identity Center browser (device-code) SSO.
#   Both modes must remain reachable from MCP child processes. Static keys
#   travel by environment inheritance; SSO travels by FILE (the token cache
#   under $SANDBOX_AWS_HOME/.aws/sso/cache). Because ucode, Tavily, Snyk and Databricks SQL MCP all
#   run with a short-lived HOME, every AWS CLI call is pinned to
#   $SANDBOX_AWS_HOME so the SSO cache stays resolvable.
# Safety rule: Never log secret values, prompts, responses, source-code content,
#              search queries, complete command lines or tool payloads.
# =============================================================================
set -euo pipefail
set +x
umask 077

usage() {
  cat >&2 <<'USAGE'
Internal usage (normally invoked by sandbox command wrappers):
  run-with-ssm-secrets --profile <ado|anthropic|gemini|databricks|databricks-sql-mcp|tavily|snyk|hiddenlayer> -- <command> [args...]

AWS authentication is resolved here, once, for the whole child process tree:
static AWS_ACCESS_KEY_ID/AWS_SECRET_ACCESS_KEY first, IAM Identity Center SSO
otherwise. MCP wrappers reuse that decision; they never re-authenticate
interactively.

Admin/debug examples:
  run-with-ssm-secrets --profile anthropic -- claude
  run-with-ssm-secrets --profile gemini -- gemini
  run-with-ssm-secrets --profile databricks -- ucode claude
  run-with-ssm-secrets --profile databricks -- ucode gemini
  run-with-ssm-secrets --profile databricks -- databricks current-user me
  # databricks-sql-mcp is internal-only and accepts only the pinned mcp-remote executable.
  run-with-ssm-secrets --profile ado -- git push origin main
  # Tavily is normally invoked through /usr/local/bin/tvly or the registered Tavily MCP wrapper.
  run-with-ssm-secrets --profile snyk -- snyk test
  run-with-ssm-secrets --profile hiddenlayer -- /opt/company/bin/hiddenlayer-client
USAGE
  exit 2
}

[[ "${1:-}" == "--profile" ]] || usage
profile="${2:-}"; [[ -n "$profile" ]] || usage
case "$profile" in
  ado|anthropic|gemini|databricks|databricks-sql-mcp|tavily|snyk|hiddenlayer) ;;
  *) echo "ERROR: unknown profile: $profile" >&2; usage ;;
esac
shift 2; [[ "${1:-}" == "--" ]] || usage; shift
(( $# > 0 )) || usage

prefix="${SSM_PREFIX:-/sandbox}"
region="${AWS_REGION:-eu-west-2}"

# Stable anchor for AWS CLI state (config, SSO token cache, role cache).
# Deliberately independent of $HOME: ucode agents, Tavily and Snyk all execute
# under short-lived HOME directories, and AWS CLI v2 resolves ~/.aws/sso/cache
# from HOME rather than from AWS_CONFIG_FILE.
readonly AWS_STATE_HOME="${SANDBOX_AWS_HOME:-/home/vscode}"
export AWS_CONFIG_FILE="${AWS_CONFIG_FILE:-$AWS_STATE_HOME/.aws/config}"
export AWS_SHARED_CREDENTIALS_FILE="${AWS_SHARED_CREDENTIALS_FILE:-$AWS_STATE_HOME/.aws/credentials}"

# Reject unexpanded shell references inherited from a malformed MCP env block.
# A literal '$AWS_ACCESS_KEY_ID' is not a credential; treating it as one would
# select static mode and then refuse the SSO fallback by design.
for _aws_var in AWS_ACCESS_KEY_ID AWS_SECRET_ACCESS_KEY AWS_SESSION_TOKEN AWS_SECURITY_TOKEN; do
  if [[ "${!_aws_var:-}" == '$'* ]]; then
    echo "WARN: ignoring unexpanded placeholder in ${_aws_var}" >&2
    unset "$_aws_var"
  fi
done
unset _aws_var
# An empty session token is not a session token. Remove empty values so the AWS
# CLI does not select an invalid temporary-credential path.
[[ -z "${AWS_SESSION_TOKEN:-}" ]] && unset AWS_SESSION_TOKEN || true
[[ -z "${AWS_SECURITY_TOKEN:-}" ]] && unset AWS_SECURITY_TOKEN || true

command -v aws >/dev/null 2>&1 || { echo "ERROR: aws CLI not found" >&2; exit 1; }
command -v application-audit >/dev/null 2>&1 || { echo "ERROR: application-audit helper not found" >&2; exit 1; }

audit_safe() {
  local app="$1" event="$2" operation="${3:-}" target="${4:-}" status="${5:-info}" exit_code="${6:-}" duration_ms="${7:-}" transport="${8:-}"
  local args=(--app "$app" --event "$event" --status "$status")
  [[ -n "$operation" ]] && args+=(--operation "$operation")
  [[ -n "$target" ]] && args+=(--target "$target")
  [[ -n "$exit_code" ]] && args+=(--exit-code "$exit_code")
  [[ -n "$duration_ms" ]] && args+=(--duration-ms "$duration_ms")
  [[ -n "$transport" ]] && args+=(--transport "$transport")
  if ! application-audit "${args[@]}"; then
    [[ "${SANDBOX_AUDIT_REQUIRED:-true}" == "true" ]] && return 1
  fi
  return 0
}

# Some credential profiles are implementation-specific variants of a logical
# application. Audit filenames/app identifiers intentionally remain stable and
# must use application-audit's approved application namespace.
profile_audit_app() {
  case "$1" in
    databricks-sql-mcp) printf 'databricks' ;;
    *) printf '%s' "$1" ;;
  esac
}
readonly audit_app="$(profile_audit_app "$profile")"

aws_profile="${SANDBOX_AWS_PROFILE:-sandbox}"
access_key="${AWS_ACCESS_KEY_ID:-}"
secret_key="${AWS_SECRET_ACCESS_KEY:-}"
session_token="${AWS_SESSION_TOKEN:-}"
aws_auth_mode="sso"

if [[ -n "$access_key" || -n "$secret_key" || -n "$session_token" ]]; then
  if [[ -z "$access_key" || -z "$secret_key" ]]; then
    audit_safe "$audit_app" "aws_auth" "ssm" "aws-auth" "failure" || true
    echo 'ERROR: AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY must be configured together.' >&2
    exit 1
  fi
  aws_auth_mode="static"
fi

# AWS_PROFILE is intentionally not injected into the DevContainer. SANDBOX_AWS_PROFILE
# is only the Sandbox-selected SSO profile name. In static-key mode, AWS CLI credential
# resolution therefore uses AWS_ACCESS_KEY_ID/AWS_SECRET_ACCESS_KEY directly. A
# non-secret default/named config stub is still created for region/output consistency.
if [[ "$aws_auth_mode" == "static" ]] && command -v configure-aws-sso >/dev/null 2>&1; then
  env HOME="$AWS_STATE_HOME" configure-aws-sso >/dev/null || {
    echo 'ERROR: could not prepare the non-secret AWS CLI compatibility profile for static credential mode.' >&2
    exit 1
  }
fi

# Every AWS CLI invocation runs with HOME pinned to the persistent AWS state
# directory. Without this, an SSO session is invisible to any process started
# under an ephemeral HOME (ucode agents, Tavily, Snyk) and the sandbox would
# incorrectly conclude the session had expired.
aws_cli() {
  if [[ "$aws_auth_mode" == "static" ]]; then
    env -u AWS_PROFILE -u AWS_DEFAULT_PROFILE HOME="$AWS_STATE_HOME" aws "$@"
  else
    env HOME="$AWS_STATE_HOME" aws --profile "$aws_profile" "$@"
  fi
}

drop_aws_bootstrap_credentials() {
  if [[ "$aws_auth_mode" == "static" ]]; then
    unset AWS_ACCESS_KEY_ID AWS_SECRET_ACCESS_KEY AWS_SESSION_TOKEN AWS_SECURITY_TOKEN
  fi
}

# Do not preflight AWS credentials through STS. Every supported runtime path
# ultimately needs SSM, so the first required GetParameter call is the useful
# authentication/authorization check. This removes the redundant STS network
# dependency and avoids a false failure when SSM is allowed but STS is not.
get_parameter() {
  local name="$1" value err_file attempt
  for attempt in 1 2; do
    err_file="$(mktemp "${TMPDIR:-/tmp}/ai-sandbox-aws-error.XXXXXX")"
    if value="$(aws_cli ssm get-parameter --name "${prefix}/${name}" --with-decryption \
      --region "$region" --query 'Parameter.Value' --output text 2>"$err_file")"; then
      rm -f "$err_file"
      [[ -n "$value" && "$value" != "None" ]] || {
        audit_safe "$audit_app" "credential_fetch" "ssm_get_parameter" "aws-ssm" "failure" || true
        echo "ERROR: required SSM parameter for profile '$profile' is empty" >&2
        return 1
      }
      printf '%s' "$value"
      return 0
    fi

    # Static credentials are authoritative when configured. Never fall back to
    # SSO because doing so could silently change identity/permissions.
    if [[ "$aws_auth_mode" == "static" ]]; then
      rm -f "$err_file"
      audit_safe "$audit_app" "credential_fetch" "ssm_get_parameter" "aws-ssm" "failure" || true
      echo "ERROR: static AWS credentials could not read the required SSM parameter for profile '$profile'." >&2
      echo "       Check the key pair/session token, IAM ssm:GetParameter/kms:Decrypt permissions, region and SSM path." >&2
      return 1
    fi

    # Only an authentication/session failure should trigger browser SSO. Access
    # denied, missing parameter, KMS denial and network errors should be surfaced
    # directly rather than causing a misleading login prompt.
    if (( attempt == 1 )) && grep -qiE \
      'SSO session|Error loading SSO Token|token.*(expired|invalid|does not exist)|expired.*token|invalid_grant|login required|credentials.*(expired|invalid|not found|unable)|UnauthorizedException' \
      "$err_file"; then
      rm -f "$err_file"
      if [[ "${SANDBOX_NONINTERACTIVE:-0}" == "1" ]] || [[ ! -t 0 ]]; then
        cat >&2 <<'MSG'
ERROR: The AWS IAM Identity Center session is missing or expired. This MCP/non-
       interactive process cannot start a browser sign-in.
       Run `sandbox-aws-login` in a VS Code terminal, then reconnect/restart the
       MCP server or AI agent session.
MSG
        return 1
      fi
      if command -v sandbox-aws-login >/dev/null 2>&1; then
        echo '[AWS SSO] Session missing/expired. Starting Windows-host browser sign-in flow...' >&2
        sandbox-aws-login || return 1
        continue
      fi
      echo 'ERROR: AWS SSO session is missing/expired and sandbox-aws-login is unavailable.' >&2
      return 1
    fi

    rm -f "$err_file"
    audit_safe "$audit_app" "credential_fetch" "ssm_get_parameter" "aws-ssm" "failure" || true
    echo "ERROR: cannot read required SSM parameter for profile '$profile'." >&2
    echo "       Check IAM ssm:GetParameter/kms:Decrypt permissions, SSO login state, region, proxy access and the configured SSM path." >&2
    return 1
  done

  audit_safe "$audit_app" "credential_fetch" "ssm_get_parameter" "aws-ssm" "failure" || true
  echo "ERROR: cannot read required SSM parameter for profile '$profile' after SSO retry." >&2
  return 1
}

configured() { local v="${1:-}"; [[ -n "$v" && "$v" != *'<'* && "$v" != *'>'* && "$v" != *REPLACE_* ]]; }
normalize_databricks_host() {
  configured "${DATABRICKS_HOST:-}" || { echo "ERROR: DATABRICKS_HOST is not configured" >&2; return 1; }
  [[ "$DATABRICKS_HOST" == https://* ]] || { echo "ERROR: DATABRICKS_HOST must start with https://" >&2; return 1; }
  printf '%s' "${DATABRICKS_HOST%/}"
}

safe_operation_from_command() {
  local cmd="$(basename -- "${1:-unknown}")" op="${2:-}"
  case "$cmd" in
    git)
      case "$op" in clone|fetch|pull|push|ls-remote|submodule) printf 'git-%s' "$op" ;; *) printf 'git' ;; esac
      ;;
    tvly)
      case "$op" in search|extract|crawl|map|research) printf '%s' "$op" ;; *) printf 'cli' ;; esac
      ;;
    tavily-mcp|tavily-policy-proxy.py) printf 'mcp' ;;
    tavily-cli-policy.py) printf 'cli-policy' ;;
    mcp-remote) printf 'mcp-remote' ;;
    snyk)
      case "$op" in test|monitor|code|container|iac|mcp|auth) printf '%s' "$op" ;; *) printf 'cli' ;; esac
      ;;
    databricks) printf 'cli' ;;
    ucode) printf 'ucode-%s' "${op:-cli}" ;;
    claude) printf 'cli' ;;
    gemini) printf 'cli' ;;
    ado-trigger) printf 'pipeline-trigger' ;;
    ado-pr-create) printf 'pr-create' ;;
    *) printf '%s' "$cmd" ;;
  esac
}

run_logged() {
  local app="$1" operation="$2" target="$3" transport="$4"; shift 4
  local start_ms end_ms duration_ms ec status
  start_ms="$(date +%s%3N)"
  audit_safe "$app" "process_start" "$operation" "$target" "started" "" "" "$transport"
  set +e
  "$@"
  ec=$?
  set -e
  end_ms="$(date +%s%3N)"
  duration_ms=$((end_ms-start_ms))
  status="success"; (( ec == 0 )) || status="failure"
  local audit_end_ec=0
  audit_safe "$app" "process_end" "$operation" "$target" "$status" "$ec" "$duration_ms" "$transport" || audit_end_ec=$?
  if (( ec == 0 && audit_end_ec != 0 )); then return "$audit_end_ec"; fi
  return "$ec"
}

has_arg() {
  local needle="$1"; shift
  local a
  for a in "$@"; do [[ "$a" == "$needle" ]] && return 0; done
  return 1
}

content_logging_enabled() {
  [[ "${SANDBOX_CONTENT_LOGGING:-false}" == "true" ]]
}

# Run CLIs that require writable HOME/cache state in a short-lived tmpfs-backed
# directory. The caller's workspace/cwd is preserved; only user-state paths are
# redirected. This prevents read-only HOME failures without making /home/vscode
# writable or persisting vendor credential/cache files.
run_logged_ephemeral_home() {
  local state_name="$1" app="$2" operation="$3" target="$4" transport="$5"; shift 5
  local tmp_home ec
  tmp_home="$(mktemp -d "/tmp/ai-sandbox-${state_name}.XXXXXX")"
  chmod 0700 "$tmp_home"
  mkdir -p "$tmp_home/.cache" "$tmp_home/.config"
  chmod 0700 "$tmp_home/.cache" "$tmp_home/.config"
  set +e
  run_logged "$app" "$operation" "$target" "$transport" \
    env HOME="$tmp_home" \
        XDG_CACHE_HOME="$tmp_home/.cache" \
        XDG_CONFIG_HOME="$tmp_home/.config" \
        "$@"
  ec=$?
  set -e
  rm -rf "$tmp_home"
  return "$ec"
}

# Snyk is different from Tavily: the Snyk CLI downloads a versioned native
# executable under its cache and then fork/execs it. /tmp is deliberately
# mounted noexec, so Snyk receives its own short-lived exec-enabled tmpfs.
# The mount remains nodev,nosuid, UID 1000 only, and is never persisted.
run_logged_snyk_exec_home() {
  local app="$1" operation="$2" target="$3" transport="$4"; shift 4
  local runtime_root="/run/ai-sandbox-snyk" tmp_home ec opts

  [[ -d "$runtime_root" && -w "$runtime_root" ]] || {
    echo "ERROR: Snyk executable runtime tmpfs is unavailable: $runtime_root" >&2
    return 1
  }
  opts="$(findmnt -no OPTIONS "$runtime_root" 2>/dev/null || true)"
  [[ ",$opts," != *,noexec,* ]] || {
    echo "ERROR: Snyk runtime tmpfs is mounted noexec; rebuild/recreate the v1.16.28 container." >&2
    return 1
  }

  tmp_home="$(mktemp -d "$runtime_root/home.XXXXXX")"
  chmod 0700 "$tmp_home"
  mkdir -p "$tmp_home/.cache" "$tmp_home/.config"
  chmod 0700 "$tmp_home/.cache" "$tmp_home/.config"

  # The exec-enabled tmpfs is recreated for every invocation, so without seeding
  # the Snyk CLI would re-download its versioned native executable on each MCP
  # start. That download cannot finish inside an MCP handshake budget. The image
  # ships a pre-warmed read-only copy; it is copied in, never written back.
  if [[ -d /opt/snyk-cache ]]; then
    cp -a /opt/snyk-cache "$tmp_home/.cache/snyk" 2>/dev/null || true
    chmod -R u+rwX "$tmp_home/.cache/snyk" 2>/dev/null || true
  fi

  set +e
  run_logged "$app" "$operation" "$target" "$transport" \
    env HOME="$tmp_home" \
        XDG_CACHE_HOME="$tmp_home/.cache" \
        XDG_CONFIG_HOME="$tmp_home/.config" \
        "$@"
  ec=$?
  set -e
  rm -rf "$tmp_home"
  return "$ec"
}

prepare_gemini_telemetry() {
  local route="${1:-direct}" source="gemini"
  [[ "$route" == "databricks" ]] && source="ucode-gemini"
  export GEMINI_TELEMETRY_ENABLED="true"
  export GEMINI_TELEMETRY_TARGET="local"

  # Keep Gemini's native telemetry off the writable filesystem while preserving
  # route attribution. Bash keeps this anonymous pipe FD open across the child
  # exec; Gemini opens /proc/self/fd/<n>, and sandbox-log-emit serializes the
  # records into PID1 stdout. The Developer cannot redirect this managed sink.
  exec {GEMINI_TELEMETRY_PIPE_FD}> >(/usr/local/bin/sandbox-log-emit gemini-telemetry "$source")
  export GEMINI_TELEMETRY_OUTFILE="/proc/self/fd/${GEMINI_TELEMETRY_PIPE_FD}"
  if content_logging_enabled; then
    export GEMINI_TELEMETRY_LOG_PROMPTS="true"
    export GEMINI_TELEMETRY_TRACES_ENABLED="true"
  else
    export GEMINI_TELEMETRY_LOG_PROMPTS="false"
    export GEMINI_TELEMETRY_TRACES_ENABLED="false"
  fi
}

close_gemini_telemetry() {
  if [[ -n "${GEMINI_TELEMETRY_PIPE_FD:-}" ]]; then
    exec {GEMINI_TELEMETRY_PIPE_FD}>&- 2>/dev/null || true
    unset GEMINI_TELEMETRY_PIPE_FD GEMINI_TELEMETRY_OUTFILE
  fi
}

# ----------------------------------------------------------------------------
# APPLICATION MAINTENANCE ZONE - SSM PROFILES + AUDIT ROUTING
# Each branch fetches only its own credentials and records metadata only.
# Raw command arguments are deliberately not sent to application-audit.
# ----------------------------------------------------------------------------
case "$profile" in
  ado)
    ADO_ORG="$(get_parameter ado-org)"; ADO_PROJECT="$(get_parameter ado-project)"; ADO_REPO="$(get_parameter ado-repo)"
    ADO_PAT="$(get_parameter ado-pat)"
    drop_aws_bootstrap_credentials
    export ADO_ORG ADO_PROJECT ADO_REPO ADO_PAT GIT_ASKPASS=/usr/local/bin/git-askpass-ado GIT_TERMINAL_PROMPT=0
    audit_safe ado "credential_fetch" "ssm_get_parameter" "aws-ssm" "success"
    op="$(safe_operation_from_command "$1" "${2:-}")"
    run_logged ado "$op" "azure-devops" "https" "$@"
    ;;

  anthropic)
    # Bare `claude` always means the official Anthropic API. Force provider
    # routing variables at process level so a previous `ucode claude` session
    # cannot leave a Databricks base URL/header in user configuration that
    # changes the meaning of the direct command.
    ANTHROPIC_API_KEY="$(get_parameter claude-api-key)"
    export ANTHROPIC_API_KEY
    export ANTHROPIC_BASE_URL="https://api.anthropic.com"
    export ANTHROPIC_AUTH_TOKEN=""
    export ANTHROPIC_CUSTOM_HEADERS=""
    export CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC=1 DISABLE_AUTOUPDATER=1
    unset CLAUDE_CODE_USE_BEDROCK CLAUDE_CODE_USE_VERTEX CLAUDE_CODE_USE_FOUNDRY
    unset ANTHROPIC_BEDROCK_BASE_URL ANTHROPIC_VERTEX_BASE_URL
    export SANDBOX_AI_ROUTE="direct-anthropic"
    export SANDBOX_AWS_HOME="$AWS_STATE_HOME"
    export AWS_CONFIG_FILE AWS_SHARED_CREDENTIALS_FILE
    # Keep AWS bootstrap authentication available to the Claude process tree so
    # Tavily/Snyk MCP wrappers and the Databricks SQL MCP wrapper can fetch their own SSM secrets later in session.
    audit_safe anthropic "credential_fetch" "ssm_get_parameter" "aws-ssm" "success"
    run_logged anthropic "claude-direct" "api.anthropic.com" "https" "$@"
    ;;

  gemini)
    # Bare `gemini` always means the official Google Gemini API. Explicitly
    # neutralize Databricks gateway variables because ucode may maintain a
    # ~/.gemini/.env for its own routed sessions.
    GEMINI_API_KEY="$(get_parameter gemini-api-key)"
    export GEMINI_API_KEY
    # An exported empty base URL prevents a ucode-managed ~/.gemini/.env
    # gateway URL from taking precedence over GEMINI_API_KEY in Gemini CLI.
    export GOOGLE_GEMINI_BASE_URL=""
    # Likewise, neutralize any ucode-persisted Databricks model selection so
    # the direct CLI uses Google Gemini's normal default unless the Developer
    # explicitly chooses a model in the direct session.
    export GEMINI_MODEL=""
    export GOOGLE_GENAI_USE_VERTEXAI="false"
    export GOOGLE_GENAI_USE_GCA="false"
    export GOOGLE_API_KEY=""
    export GOOGLE_CLOUD_PROJECT="" GOOGLE_CLOUD_PROJECT_ID="" GOOGLE_CLOUD_LOCATION=""
    export SANDBOX_AI_ROUTE="direct-gemini"
    export SANDBOX_AWS_HOME="$AWS_STATE_HOME"
    export AWS_CONFIG_FILE AWS_SHARED_CREDENTIALS_FILE
    prepare_gemini_telemetry direct
    # Keep AWS bootstrap authentication for nested Tavily/Snyk MCP wrappers and the Databricks SQL MCP wrapper.
    audit_safe gemini "credential_fetch" "ssm_get_parameter" "aws-ssm" "success"
    set +e
    run_logged gemini "gemini-direct" "generativelanguage.googleapis.com" "https" "$@"
    gemini_ec=$?
    set -e
    close_gemini_telemetry
    exit "$gemini_ec"
    ;;

  databricks)
    DATABRICKS_HOST="$(normalize_databricks_host)"; DATABRICKS_TOKEN="$(get_parameter databricks-token)"
    export DATABRICKS_HOST DATABRICKS_TOKEN
    audit_safe databricks "credential_fetch" "ssm_get_parameter" "aws-ssm" "success"
    cmd="$(basename -- "$1")"
    case "$cmd" in
      ucode)
        # `ucode` is the explicit Databricks-routed launcher. It must never fall
        # into ucode's interactive browser-login/bootstrap flow inside this
        # read-only Sandbox. Build a short-lived PAT profile from the SSM token,
        # configure ucode headlessly, run the selected agent, then delete all
        # generated Databricks/ucode/agent auth state from tmpfs.
        agent="${2:-cli}"
        target="workspace"
        ucode_args=("$@")
        if [[ "$agent" == "claude" ]]; then
          configured "${DATABRICKS_CLAUDE_MODEL:-}" || {
            echo "ERROR: DATABRICKS_CLAUDE_MODEL is required for 'ucode claude'" >&2
            exit 1
          }
          [[ -r /etc/claude-code/managed-mcp.json ]] || {
            echo 'ERROR: Admin Claude managed MCP config is missing' >&2
            exit 1
          }
          # Pin the approved Databricks model. MCP is supplied by Claude Code's
          # root-owned managed-mcp.json, which is independent of ucode's
          # short-lived HOME/CLAUDE_CONFIG_DIR.
          if ! has_arg --model "${ucode_args[@]:2}" && ! has_arg -m "${ucode_args[@]:2}"; then
            ucode_args=("${ucode_args[0]}" "${ucode_args[1]}" --model "$DATABRICKS_CLAUDE_MODEL" "${ucode_args[@]:2}")
          fi
          target="$DATABRICKS_CLAUDE_MODEL"
        elif [[ "$agent" == "gemini" ]]; then
          configured "${DATABRICKS_GEMINI_MODEL:-}" || {
            echo "ERROR: DATABRICKS_GEMINI_MODEL is required for 'ucode gemini'" >&2
            exit 1
          }
          # Pin the approved Databricks model for the underlying Gemini CLI.
          # ucode forwards unknown flags to the agent, so use --model explicitly
          # and also export GEMINI_MODEL for compatible Gemini CLI releases.
          if ! has_arg --model "${ucode_args[@]:2}" && ! has_arg -m "${ucode_args[@]:2}"; then
            ucode_args=("${ucode_args[0]}" "${ucode_args[1]}" --model "$DATABRICKS_GEMINI_MODEL" "${ucode_args[@]:2}")
          fi
          export GEMINI_MODEL="$DATABRICKS_GEMINI_MODEL"
          target="$DATABRICKS_GEMINI_MODEL"
        fi

        if [[ "$agent" == "claude" || "$agent" == "gemini" ]]; then
          ucode_home="$(mktemp -d /tmp/ai-sandbox-ucode.XXXXXX)"
          chmod 0700 "$ucode_home"
          ucode_cfg="$ucode_home/.databrickscfg"
          cat >"$ucode_cfg" <<EOF
[DEFAULT]
host = $DATABRICKS_HOST
token = $DATABRICKS_TOKEN
auth_type = pat
EOF
          chmod 0600 "$ucode_cfg"

          # Fail closed if the pinned ucode build does not support headless PAT
          # configuration. Never fall back to interactive `databricks auth login`.
          # Capture the complete help output before checking capabilities. Piping
          # directly to `grep -q` under `set -o pipefail` can produce a false
          # negative when grep exits early and ucode receives SIGPIPE.
          ucode_configure_help="$(
            env HOME="$ucode_home" \
                PATH="/usr/local/libexec/ai-sandbox/real:${PATH}" \
                "${ucode_args[0]}" configure --help 2>&1
          )" || {
            rm -rf "$ucode_home"
            echo "ERROR: unable to inspect installed ucode configure capabilities" >&2
            exit 1
          }

          for required_option in \
            '--profiles' \
            '--use-pat' \
            '--skip-validate' \
            '--skip-upgrade'
          do
            if [[ "$ucode_configure_help" != *"$required_option"* ]]; then
              rm -rf "$ucode_home"
              echo "ERROR: installed ucode configure does not support ${required_option}" >&2
              exit 1
            fi
          done

          audit_safe databricks "ucode_configure" "headless-pat" "workspace" "started"
          set +e
          env -u DATABRICKS_HOST -u DATABRICKS_TOKEN -u DATABRICKS_CONFIG_PROFILE \
            HOME="$ucode_home" \
            DATABRICKS_CONFIG_FILE="$ucode_cfg" \
            PATH="/usr/local/libexec/ai-sandbox/real:${PATH}" \
            "${ucode_args[0]}" configure \
              --profiles DEFAULT \
              --agents "$agent" \
              --use-pat \
              --skip-validate \
              --skip-upgrade
          configure_ec=$?
          set -e
          if (( configure_ec != 0 )); then
            audit_safe databricks "ucode_configure" "headless-pat" "workspace" "failure" "$configure_ec" || true
            rm -rf "$ucode_home"
            echo "ERROR: headless ucode Databricks configuration failed" >&2
            exit "$configure_ec"
          fi
          audit_safe databricks "ucode_configure" "headless-pat" "workspace" "success"

          # ucode Claude receives the root-owned Claude managed MCP file
          # automatically and therefore needs no mutable user/project MCP setup.
          # ucode Gemini uses a separate GEMINI_CLI_HOME rooted under
          # $HOME/.ucode/.gemini-home, so populate and validate that state only
          # for the Gemini route.
          if [[ "$agent" == "gemini" ]]; then
            resolve_ucode_gemini_cli_home() {
              local launcher resolved first_line py candidate
              launcher="${ucode_args[0]}"
              resolved="$(readlink -f "$launcher" 2>/dev/null || printf '%s' "$launcher")"
              first_line="$(head -n 1 "$resolved" 2>/dev/null || true)"
              py="${first_line#\#!}"
              if [[ "$first_line" == '#!'* && -x "$py" ]]; then
                candidate="$(env HOME="$ucode_home" "$py" -c 'from ucode.agents.gemini import GEMINI_HOME_DIR; print(GEMINI_HOME_DIR)' 2>/dev/null || true)"
                if [[ -n "$candidate" && "$candidate" == "$ucode_home/"* ]]; then
                  printf '%s' "$candidate"
                  return 0
                fi
              fi
              printf '%s/.ucode/.gemini-home' "$ucode_home"
            }
            ucode_gemini_cli_home="$(resolve_ucode_gemini_cli_home)"
            set +e
            env HOME="$ucode_home" \
                GEMINI_CLI_HOME="$ucode_gemini_cli_home" \
                /usr/local/bin/configure-mcp >/dev/null 2>&1
            mcp_configure_ec=$?
            set -e
            if (( mcp_configure_ec != 0 )); then
              rm -rf "$ucode_home"
              echo "ERROR: temporary ucode Gemini MCP configuration failed" >&2
              exit "$mcp_configure_ec"
            fi

            # Fail closed before launching Gemini if the ucode-specific settings
            # location is not populated exactly as expected. This catches an
            # upstream ucode/Gemini state-path change during a real runtime rather
            # than silently launching without MCP tools.
            ucode_gemini_settings="$ucode_gemini_cli_home/.gemini/settings.json"
            if ! jq -e '
              def aws_runtime_refs: {
                AWS_ACCESS_KEY_ID: "$AWS_ACCESS_KEY_ID",
                AWS_SECRET_ACCESS_KEY: "$AWS_SECRET_ACCESS_KEY",
                AWS_SESSION_TOKEN: "$AWS_SESSION_TOKEN"
              };
              (.mcpServers.tavily.command == "/usr/local/bin/tavily-mcp-ssm") and
              (.mcpServers.snyk.command == "/usr/local/bin/snyk-mcp-ssm") and
              (.mcpServers["databricks-sql"].command == "/usr/local/bin/databricks-sql-mcp-ssm") and
              (.mcpServers.tavily.env == aws_runtime_refs) and
              (.mcpServers.snyk.env == aws_runtime_refs) and
              (.mcpServers["databricks-sql"].env == aws_runtime_refs)
            ' "$ucode_gemini_settings" >/dev/null 2>&1; then
              rm -rf "$ucode_home"
              echo "ERROR: ucode Gemini MCP settings were not created in the managed GEMINI_CLI_HOME" >&2
              exit 1
            fi
          fi

          # Retain AWS bootstrap credentials in the launched AI-agent process tree
          # so Admin-managed Tavily/Snyk/Databricks-SQL MCP wrappers can fetch their own SSM
          # secrets later in the session. The Databricks PAT stays in temporary
          # runtime storage and is removed when the agent exits.
          # ucode runs the agent under a short-lived HOME. Export the stable AWS
          # state anchor so the Tavily/Snyk/Databricks-SQL MCP wrappers started later in the
          # session can still resolve an IAM Identity Center token cache. In
          # static-key mode the bootstrap pair is inherited as before.
          export SANDBOX_AWS_HOME="$AWS_STATE_HOME"
          export AWS_CONFIG_FILE AWS_SHARED_CREDENTIALS_FILE

          if [[ "$agent" == "claude" ]]; then
            export SANDBOX_AI_ROUTE="databricks-claude"
            agent_config_env=(CLAUDE_CONFIG_DIR="$ucode_home/.claude")
          else
            export SANDBOX_AI_ROUTE="databricks-gemini"
            prepare_gemini_telemetry databricks
            agent_config_env=()
          fi

          set +e
          run_logged databricks "ucode-${agent}" "$target" "https" \
            env -u DATABRICKS_HOST -u DATABRICKS_TOKEN \
                HOME="$ucode_home" \
                DATABRICKS_CONFIG_FILE="$ucode_cfg" \
                DATABRICKS_CONFIG_PROFILE=DEFAULT \
                PATH="/usr/local/libexec/ai-sandbox/real:${PATH}" \
                "${agent_config_env[@]}" \
                "${ucode_args[@]}"
          ucode_ec=$?
          set -e
          [[ "$agent" == "gemini" ]] && close_gemini_telemetry
          rm -rf "$ucode_home"
          exit "$ucode_ec"
        fi

        # Non-agent ucode subcommands use the normal Databricks profile path.
        drop_aws_bootstrap_credentials
        export SANDBOX_AI_ROUTE="databricks-${agent}"
        run_logged databricks "ucode-${agent}" "$target" "https" \
          env PATH="/usr/local/libexec/ai-sandbox/real:${PATH}" "${ucode_args[@]}"
        ;;
      databricks)
        drop_aws_bootstrap_credentials
        run_logged databricks "cli" "workspace" "https" "$@"
        ;;
      *)
        drop_aws_bootstrap_credentials
        op="$(safe_operation_from_command "$1" "${2:-}")"
        run_logged databricks "$op" "workspace" "https" "$@"
        ;;
    esac
    ;;
  databricks-sql-mcp)
    readonly expected_mcp_remote="/usr/local/libexec/ai-sandbox/real/mcp-remote"
    # Dedicated least-capability profile: a caller cannot substitute `env`, curl,
    # another executable, URL or header and receive the SQL PAT.
    [[ "$1" == "$expected_mcp_remote" && $# -eq 1 ]] || {
      echo 'ERROR: databricks-sql-mcp profile accepts only the pinned managed MCP bridge' >&2
      exit 2
    }
    DATABRICKS_HOST="$(normalize_databricks_host)"
    DATABRICKS_SQL_MCP_TOKEN="$(get_parameter databricks-sql-mcp-token)"
    drop_aws_bootstrap_credentials
    export DATABRICKS_HOST DATABRICKS_SQL_MCP_TOKEN
    audit_safe databricks "credential_fetch" "sql_mcp_ssm_get_parameter" "aws-ssm" "success"
    databricks_sql_mcp_url="${DATABRICKS_HOST%/}/api/2.0/mcp/sql"
    # mcp-remote performs ${DATABRICKS_SQL_MCP_TOKEN} substitution internally;
    # the PAT therefore never appears in argv or MCP settings.
    run_logged_ephemeral_home databricks-sql-mcp databricks "sql-mcp" "workspace" "stdio" \
      env -u AWS_CONFIG_FILE -u AWS_SHARED_CREDENTIALS_FILE -u SANDBOX_AWS_HOME \
      "$expected_mcp_remote" \
        "$databricks_sql_mcp_url" \
        --header 'Authorization: Bearer ${DATABRICKS_SQL_MCP_TOKEN}' \
        --silent \
        --enable-proxy \
        --transport http-only
    ;;

  tavily)
    readonly tavily_mcp_policy="/usr/local/libexec/ai-sandbox/tavily-policy-proxy.py"
    readonly tavily_cli_policy="/usr/local/libexec/ai-sandbox/tavily-cli-policy.py"
    readonly real_tavily_mcp="/usr/local/libexec/ai-sandbox/real/tavily-mcp"
    readonly real_tvly="/usr/local/libexec/ai-sandbox/real/tvly"
    # Prevent using this credential profile as a generic secret-exposing runner.
    # MCP must be policy-proxy -> real MCP exactly. CLI must be CLI-policy -> real tvly.
    if [[ "$1" == "$tavily_mcp_policy" ]]; then
      [[ $# -eq 2 && "$2" == "$real_tavily_mcp" ]] || { echo 'ERROR: invalid Tavily MCP policy path' >&2; exit 2; }
      transport="stdio"
    elif [[ "$1" == "$tavily_cli_policy" ]]; then
      [[ $# -ge 3 && "$2" == "$real_tvly" ]] || { echo 'ERROR: invalid Tavily CLI policy path' >&2; exit 2; }
      transport="https"
    else
      echo 'ERROR: Tavily SSM profile may only launch the Admin-managed Tavily policy wrappers' >&2
      exit 2
    fi
    # Tavily MCP applies DEFAULT_PARAMETERS after tool input in this pinned release.
    # Clear any caller-supplied value so it cannot override the root-owned proxy.
    unset DEFAULT_PARAMETERS
    TAVILY_API_KEY="$(get_parameter tavily-api-key)"; drop_aws_bootstrap_credentials; export TAVILY_API_KEY
    audit_safe tavily "credential_fetch" "ssm_get_parameter" "aws-ssm" "success"
    op="$(safe_operation_from_command "$1" "${3:-}")"
    run_logged_ephemeral_home tavily tavily "$op" "tavily" "$transport" "$@"
    ;;

  snyk)
    SNYK_TOKEN="$(get_parameter snyk-token)"; drop_aws_bootstrap_credentials; export SNYK_TOKEN
    if configured "${SNYK_API:-}"; then export SNYK_API; fi
    audit_safe snyk "credential_fetch" "ssm_get_parameter" "aws-ssm" "success"
    op="$(safe_operation_from_command "$1" "${2:-}")"
    transport="https"; [[ "$op" == "mcp" ]] && transport="stdio"
    # Snyk creates and executes a versioned native binary under ~/.cache/snyk.
    # Use the dedicated exec-enabled, nodev/nosuid tmpfs instead of /tmp(noexec).
    run_logged_snyk_exec_home snyk "$op" "snyk" "$transport" "$@"
    ;;

  hiddenlayer)
    configured "${HIDDENLAYER_API_URL:-}" || { echo "ERROR: HIDDENLAYER_API_URL is not configured in .env" >&2; exit 1; }
    [[ "$HIDDENLAYER_API_URL" == https://* ]] || { echo "ERROR: HIDDENLAYER_API_URL must use https://" >&2; exit 1; }
    HIDDENLAYER_CLIENT_ID="$(get_parameter hiddenlayer-client-id)"
    HIDDENLAYER_CLIENT_SECRET="$(get_parameter hiddenlayer-client-secret)"
    drop_aws_bootstrap_credentials
    export HIDDENLAYER_API_URL HIDDENLAYER_CLIENT_ID HIDDENLAYER_CLIENT_SECRET
    audit_safe hiddenlayer "credential_fetch" "ssm_get_parameter" "aws-ssm" "success"
    op="$(safe_operation_from_command "$1" "${2:-}")"
    run_logged hiddenlayer "$op" "hiddenlayer" "https" "$@"
    ;;

  *) echo "ERROR: unknown profile: $profile" >&2; usage ;;
esac
