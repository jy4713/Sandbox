#Requires -Version 7.4
# =============================================================================
# PACKAGE MAINTENANCE NOTES
# Purpose:
#   Developer TAR launcher for an Admin-approved POC or Production hardened bundle.
#
# Maintenance boundary:
#   Keep the required bundle files, runtime-policy validation, image ID checks,
#   and the paired Bash launcher synchronized with scripts/tar/build-and-export.*.
#
# Logging:
#   This launcher creates host-visible DevContainer and Squid log directories.
#   It does not start or authenticate a monitoring/forwarding container.
# =============================================================================
[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
$Images = Join-Path $Root 'tar\images'
$EnvFile = Join-Path $Root '.env'
$Compose = Join-Path $Root 'tar\docker-compose.yml'

$Required = @(
    'sandbox-devcontainer.tar',
    'sandbox-squid.tar',
    'image-manifest.json',
    'image-manifest.env',
    'runtime-policy.sha256',
    'SHA256SUMS'
)

foreach ($FileName in $Required) {
    $Path = Join-Path $Images $FileName
    if (-not (Test-Path $Path) -or (Get-Item $Path).Length -eq 0) {
        throw "Missing or empty TAR bundle file: $Path"
    }
}

if (-not (Test-Path $EnvFile)) {
    Copy-Item (Join-Path $Root '.env.example') $EnvFile
    Write-Host "Created $EnvFile. Configure runtime values and rerun. Protect .env if AWS static credentials are used." -ForegroundColor Yellow
    exit 2
}

function Read-KeyValueFile {
    param([Parameter(Mandatory = $true)][string]$Path)
    $Map = @{}
    Get-Content $Path | ForEach-Object {
        $Line = $_.TrimEnd("`r")
        if ($Line -and -not $Line.TrimStart().StartsWith('#')) {
            $Index = $Line.IndexOf('=')
            if ($Index -gt 0) {
                $Map[$Line.Substring(0, $Index).Trim()] = $Line.Substring($Index + 1)
            }
        }
    }
    return $Map
}

function Test-ConfiguredValue {
    param([string]$Value)
    return (
        -not [string]::IsNullOrWhiteSpace($Value) -and
        $Value -notmatch '[<>]' -and
        $Value -notlike '*REPLACE_*' -and
        $Value -ne 'yourname'
    )
}


$ProtectedLogSystemSid = 'S-1-5-18'
$ProtectedLogWriteMask = [Security.AccessControl.FileSystemRights]::WriteData `
    -bor [Security.AccessControl.FileSystemRights]::AppendData `
    -bor [Security.AccessControl.FileSystemRights]::CreateDirectories `
    -bor [Security.AccessControl.FileSystemRights]::WriteAttributes `
    -bor [Security.AccessControl.FileSystemRights]::WriteExtendedAttributes `
    -bor [Security.AccessControl.FileSystemRights]::Delete `
    -bor [Security.AccessControl.FileSystemRights]::DeleteSubdirectoriesAndFiles `
    -bor [Security.AccessControl.FileSystemRights]::ChangePermissions `
    -bor [Security.AccessControl.FileSystemRights]::TakeOwnership

function Get-ProtectedLogRuleSid([Security.Principal.IdentityReference]$IdentityReference) {
    try { return $IdentityReference.Translate([Security.Principal.SecurityIdentifier]).Value }
    catch { return $IdentityReference.Value }
}

function Assert-ProtectedLogAcl([string]$Path) {
    $Acl = Get-Acl -LiteralPath $Path
    try { $OwnerSid = ([Security.Principal.NTAccount]::new($Acl.Owner)).Translate([Security.Principal.SecurityIdentifier]).Value }
    catch { $OwnerSid = $Acl.Owner }
    if ($OwnerSid -ne $ProtectedLogSystemSid -and $Acl.Owner -notmatch 'SYSTEM') {
        throw "Security check failed: protected log path '$Path' is not owned by LOCALSYSTEM."
    }
    foreach ($Rule in $Acl.Access) {
        if ($Rule.AccessControlType -ne [Security.AccessControl.AccessControlType]::Allow) { continue }
        $RuleSid = Get-ProtectedLogRuleSid -IdentityReference $Rule.IdentityReference
        if ((([int64]$Rule.FileSystemRights -band [int64]$ProtectedLogWriteMask) -ne 0) -and $RuleSid -ne $ProtectedLogSystemSid) {
            throw "Security check failed: non-SYSTEM principal '$($Rule.IdentityReference)' has write/modify/delete rights on protected log path '$Path'."
        }
    }
}

function Assert-ProtectedLogRoot {
    param([hashtable]$Runtime)
    if (-not (Test-ConfiguredValue $Runtime['SANDBOX_LOG_ROOT'])) {
        throw 'SANDBOX_LOG_ROOT is missing or still a placeholder in .env. Ask the Sandbox Admin to run scripts\platform\03-setup-logging.ps1 first.'
    }
    $LogRoot = [IO.Path]::GetFullPath($Runtime['SANDBOX_LOG_ROOT'].Replace('/', '\'))
    if (-not (Test-Path -LiteralPath $LogRoot -PathType Container)) {
        throw "Protected host log root is missing: $LogRoot. Ask the Sandbox Admin to run scripts\platform\03-setup-logging.ps1."
    }
    Assert-ProtectedLogAcl -Path $LogRoot
    foreach ($Subdir in @('devcontainer','squid')) {
        $Path = Join-Path $LogRoot $Subdir
        if (-not (Test-Path -LiteralPath $Path -PathType Container)) {
            throw "Protected host log directory is missing: $Path. Ask the Sandbox Admin to run scripts\platform\03-setup-logging.ps1."
        }
        Assert-ProtectedLogAcl -Path $Path
        $Probe = Join-Path $Path ('.developer-write-probe-' + [guid]::NewGuid().ToString('N'))
        $Writable = $false
        try {
            [IO.File]::WriteAllText($Probe, 'probe', [Text.UTF8Encoding]::new($false))
            $Writable = $true
        }
        catch [UnauthorizedAccessException] { }
        catch [IO.IOException] { }
        finally {
            if (Test-Path -LiteralPath $Probe) { Remove-Item -LiteralPath $Probe -Force -ErrorAction SilentlyContinue }
        }
        if ($Writable) {
            throw "Security check failed: the current Windows user can write to protected log directory $Path. Re-apply the Admin/SYSTEM ACL with scripts\platform\03-setup-logging.ps1."
        }
    }
}

$Runtime = Read-KeyValueFile -Path $EnvFile
Assert-ProtectedLogRoot -Runtime $Runtime
if (-not (Test-ConfiguredValue $Runtime['DEVELOPER_ID'])) {
    throw 'DEVELOPER_ID is missing or still a placeholder in .env'
}
if ($Runtime['DATABRICKS_HOST'] -and $Runtime['DATABRICKS_HOST'] -notmatch '^https://') {
    throw 'DATABRICKS_HOST must use https:// when configured'
}

$HasAccessKey = Test-ConfiguredValue $Runtime['AWS_ACCESS_KEY_ID']
$HasSecretKey = Test-ConfiguredValue $Runtime['AWS_SECRET_ACCESS_KEY']
$HasSessionToken = Test-ConfiguredValue $Runtime['AWS_SESSION_TOKEN']
if ($HasAccessKey -xor $HasSecretKey) {
    throw 'AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY must be configured together. Partial static credentials do not fall back to SSO.'
}
if ($HasSessionToken -and -not ($HasAccessKey -and $HasSecretKey)) {
    throw 'AWS_SESSION_TOKEN requires AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY.'
}
if ($HasAccessKey -and $HasSecretKey) {
    $env:AWS_ACCESS_KEY_ID = $Runtime['AWS_ACCESS_KEY_ID']
    $env:AWS_SECRET_ACCESS_KEY = $Runtime['AWS_SECRET_ACCESS_KEY']
    if ($HasSessionToken) { $env:AWS_SESSION_TOKEN = $Runtime['AWS_SESSION_TOKEN'] } else { Remove-Item Env:AWS_SESSION_TOKEN -ErrorAction SilentlyContinue }
    Write-Host 'AWS authentication mode: static environment credentials (SSO values are not required).' -ForegroundColor Cyan
}
else {
    Remove-Item Env:AWS_ACCESS_KEY_ID,Env:AWS_SECRET_ACCESS_KEY,Env:AWS_SESSION_TOKEN -ErrorAction SilentlyContinue
    foreach ($Key in @('SANDBOX_AWS_PROFILE','AWS_REGION','AWS_SSO_SESSION','AWS_SSO_START_URL','AWS_SSO_REGION','AWS_SSO_ACCOUNT_ID','AWS_SSO_ROLE_NAME')) {
        if (-not (Test-ConfiguredValue $Runtime[$Key])) {
            throw "$Key is missing or still a placeholder in .env. No static AWS key pair is configured, so IAM Identity Center (SSO) fallback values are required."
        }
    }
    if ($Runtime['AWS_SSO_START_URL'] -notmatch '^https://') { throw 'AWS_SSO_START_URL must use https://' }
    if ($Runtime['AWS_SSO_ACCOUNT_ID'] -notmatch '^[0-9]{12}$') { throw 'AWS_SSO_ACCOUNT_ID must be a 12-digit AWS account ID' }
    Write-Host 'AWS authentication mode: IAM Identity Center (SSO) fallback.' -ForegroundColor Cyan
}

# Runtime records are Docker-owned stdout/stderr first, then a SYSTEM host exporter copies them into the protected Windows log folder. Containers mount that folder read-only.

Write-Host '[1/5] Verifying bundle hashes...' -ForegroundColor Yellow
$ImagesBase = [IO.Path]::GetFullPath($Images) + [IO.Path]::DirectorySeparatorChar
Get-Content (Join-Path $Images 'SHA256SUMS') | ForEach-Object {
    if ($_ -notmatch '^([0-9a-fA-F]{64})\s+\*?(.+)$') {
        throw "Invalid SHA256SUMS line: $_"
    }
    $Expected = $matches[1].ToLowerInvariant()
    $Relative = $matches[2].Trim()
    if ($Relative.StartsWith('./')) { $Relative = $Relative.Substring(2) }
    $Path = [IO.Path]::GetFullPath((Join-Path $Images ($Relative -replace '/', '\')))
    if (-not $Path.StartsWith($ImagesBase, [StringComparison]::OrdinalIgnoreCase)) {
        throw "Unsafe hash path: $Relative"
    }
    $Actual = (Get-FileHash $Path -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($Actual -ne $Expected) { throw "SHA256 mismatch: $Relative" }
}

Write-Host '[2/5] Verifying Admin runtime policy...' -ForegroundColor Yellow
$RootBase = [IO.Path]::GetFullPath($Root) + [IO.Path]::DirectorySeparatorChar
Get-Content (Join-Path $Images 'runtime-policy.sha256') | ForEach-Object {
    if ($_ -notmatch '^([0-9a-fA-F]{64})\s+\*?(.+)$') {
        throw "Invalid runtime-policy line: $_"
    }
    $Expected = $matches[1].ToLowerInvariant()
    $Relative = $matches[2].Trim()
    $Path = [IO.Path]::GetFullPath((Join-Path $Root ($Relative -replace '/', '\')))
    if (-not $Path.StartsWith($RootBase, [StringComparison]::OrdinalIgnoreCase)) {
        throw "Unsafe policy path: $Relative"
    }
    $Actual = (Get-FileHash $Path -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($Actual -ne $Expected) { throw "Runtime policy mismatch: $Relative" }
}

Write-Host '[3/5] Loading approved images...' -ForegroundColor Yellow
foreach ($FileName in @('sandbox-devcontainer.tar', 'sandbox-squid.tar')) {
    & docker load -i (Join-Path $Images $FileName) | Out-Null
    if ($LASTEXITCODE -ne 0) { throw "docker load failed: $FileName" }
}

$Manifest = Read-KeyValueFile -Path (Join-Path $Images 'image-manifest.env')
foreach ($Key in @('SANDBOX_TYPE','DEPLOYMENT_TYPE','DEVCONTAINER_TAG', 'DEVCONTAINER_ID', 'SQUID_TAG', 'SQUID_ID')) {
    if (-not $Manifest[$Key]) { throw "Manifest missing $Key" }
}
if ($Manifest['DEPLOYMENT_TYPE'].ToLowerInvariant() -ne 'tar') { throw 'Bundle deployment type is not TAR.' }
$ManifestSandboxType=$Manifest['SANDBOX_TYPE'].ToLowerInvariant()
if ($ManifestSandboxType -notin @('poc','production')) { throw 'Bundle SANDBOX_TYPE must be poc or production.' }

function Confirm-ImageId {
    param([string]$Label, [string]$Tag, [string]$ExpectedId)
    $ActualId = (& docker image inspect $Tag --format '{{.Id}}' 2>$null).Trim()
    if ($ActualId -ne $ExpectedId) { throw "$Label image ID mismatch" }
    Write-Host "  [OK] $Label $ActualId" -ForegroundColor Green
}

Write-Host '[4/5] Verifying loaded image IDs...' -ForegroundColor Yellow
Confirm-ImageId -Label 'devcontainer' -Tag $Manifest.DEVCONTAINER_TAG -ExpectedId $Manifest.DEVCONTAINER_ID
Confirm-ImageId -Label 'squid' -Tag $Manifest.SQUID_TAG -ExpectedId $Manifest.SQUID_ID

Write-Host '[5/5] Starting sandbox...' -ForegroundColor Yellow
$PreviousSandboxEnv=$env:SANDBOX_ENV
try {
    $env:SANDBOX_ENV=$ManifestSandboxType
    & docker compose --env-file $EnvFile -f $Compose config | Out-Null
    if ($LASTEXITCODE -ne 0) { throw 'docker compose config failed' }
    & docker compose --env-file $EnvFile -f $Compose up -d --force-recreate
    if ($LASTEXITCODE -ne 0) { throw 'docker compose up failed' }
}
finally {
    if ($null -eq $PreviousSandboxEnv) { Remove-Item Env:SANDBOX_ENV -ErrorAction SilentlyContinue } else { $env:SANDBOX_ENV=$PreviousSandboxEnv }
}

Write-Host "[OK] $ManifestSandboxType TAR sandbox started." -ForegroundColor Green
Write-Host "[OK] Runtime logs are Docker-owned streams and are exported by SYSTEM to $($Runtime['SANDBOX_LOG_ROOT'])." -ForegroundColor Green
