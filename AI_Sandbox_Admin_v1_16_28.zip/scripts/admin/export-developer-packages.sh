#!/usr/bin/env bash
# =============================================================================
# ADMIN ONLY - Export minimal TAR and ECR Developer runtime packages.
# Documentation is optional and is not required by this export workflow.
# =============================================================================
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
OUT="${1:-$ROOT/developer-packages}"
INCLUDE="${2:-}"
TAR="$OUT/AI_Sandbox_Developer_TAR"
ECR="$OUT/AI_Sandbox_Developer_ECR"
rm -rf "$TAR" "$ECR"
mkdir -p "$TAR" "$ECR"

copy(){ mkdir -p "$(dirname "$2")"; cp -a "$1" "$2"; }

# Stamp optional Admin-approved NON-SECRET SSO fallback defaults from .build.env into
# the Developer .env.example. Missing values are acceptable when the Developer supplies the static AWS key pair;
# otherwise the launchers require the SSO fallback values.
stamp_sso_defaults(){
  local target="$1" build="$ROOT/.build.env" key src value tmp
  [[ -f "$target" && -f "$build" ]] || return 0
  while IFS='|' read -r key src; do
    value="$(awk -F= -v k="$src" '$1==k {sub(/^[^=]*=/,""); print; exit}' "$build")"
    [[ -n "$value" ]] || continue
    tmp="${target}.tmp.$$"
    awk -v k="$key" -v v="$value" 'index($0,k"=")==1 {$0=k"="v} {print}' "$target" > "$tmp"
    mv "$tmp" "$target"
  done <<'MAP'
SANDBOX_AWS_PROFILE|DEVELOPER_AWS_PROFILE
AWS_REGION|DEVELOPER_AWS_REGION
AWS_SSO_SESSION|DEVELOPER_AWS_SSO_SESSION
AWS_SSO_START_URL|DEVELOPER_AWS_SSO_START_URL
AWS_SSO_REGION|DEVELOPER_AWS_SSO_REGION
AWS_SSO_ACCOUNT_ID|DEVELOPER_AWS_SSO_ACCOUNT_ID
AWS_SSO_ROLE_NAME|DEVELOPER_AWS_SSO_ROLE_NAME
MAP
}

# TAR deployment package (POC or Production hardening)
copy "$ROOT/.devcontainer/devcontainer.json" "$TAR/.devcontainer/devcontainer.json"
copy "$ROOT/tar/docker-compose.yml" "$TAR/tar/docker-compose.yml"
for f in load-and-start.ps1 load-and-start.sh verify-sandbox.ps1 verify-sandbox.sh; do
  copy "$ROOT/scripts/tar/$f" "$TAR/scripts/tar/$f"
done
copy "$ROOT/.env.example" "$TAR/.env.example"
stamp_sso_defaults "$TAR/.env.example"
copy "$ROOT/workspace/README.md" "$TAR/workspace/README.md"
copy "$ROOT/templates/developer/DEVELOPER-GUIDE-TAR.md" "$TAR/DEVELOPER-GUIDE.md"
mkdir -p "$TAR/tar/images"
printf '%s\n' 'Admin supplies the complete generated tar/images bundle here. Do not modify bundle files.' > "$TAR/tar/images/README.txt"
if [[ "$INCLUDE" == '--include-tar-images' ]]; then
  [[ -f "$ROOT/tar/images/SHA256SUMS" ]] || { echo 'ERROR: TAR image bundle has not been built yet.' >&2; exit 1; }
  cp -a "$ROOT/tar/images/." "$TAR/tar/images/"
fi

# ECR package
copy "$ROOT/ecr/docker-compose.yml" "$ECR/docker-compose.yml"
copy "$ROOT/templates/developer/devcontainer-ecr.json" "$ECR/.devcontainer/devcontainer.json"
for f in pull-and-start.ps1 pull-and-start.sh; do
  copy "$ROOT/scripts/ecr/$f" "$ECR/scripts/ecr/$f"
done
copy "$ROOT/.env.example" "$ECR/.env.example"
stamp_sso_defaults "$ECR/.env.example"
copy "$ROOT/workspace/README.md" "$ECR/workspace/README.md"
copy "$ROOT/templates/developer/DEVELOPER-GUIDE-ECR.md" "$ECR/DEVELOPER-GUIDE.md"

echo "[OK] $TAR"
echo "[OK] $ECR"
