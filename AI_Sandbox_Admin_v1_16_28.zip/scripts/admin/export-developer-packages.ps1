#Requires -Version 7.4
# =============================================================================
# ADMIN ONLY - Export minimal TAR and ECR Developer runtime packages.
# Documentation is optional and is not required by this export workflow.
# =============================================================================
[CmdletBinding()]
param(
    [string]$OutputDirectory,
    [switch]$IncludeTarImages
)
$ErrorActionPreference='Stop'
$Root=Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
if(-not $OutputDirectory){$OutputDirectory=Join-Path $Root 'developer-packages'}
New-Item -ItemType Directory -Force -Path $OutputDirectory | Out-Null

function Copy-Required([string]$Source,[string]$Destination){
    if(-not(Test-Path $Source)){throw "Required source missing: $Source"}
    $Parent=Split-Path -Parent $Destination
    if($Parent){New-Item -ItemType Directory -Force -Path $Parent|Out-Null}
    Copy-Item $Source $Destination -Recurse -Force
}

function Set-DeveloperSsoDefaults([string]$TargetEnv){
    $BuildEnvPath=Join-Path $Root '.build.env'
    if(-not(Test-Path $BuildEnvPath) -or -not(Test-Path $TargetEnv)){return}
    $Vals=@{}
    Get-Content $BuildEnvPath -Encoding UTF8 | ForEach-Object {
        $line=$_.Trim()
        if($line -and -not $line.StartsWith('#') -and $line.IndexOf('=') -ge 1){
            $i=$line.IndexOf('=')
            $Vals[$line.Substring(0,$i).Trim()]=$line.Substring($i+1)
        }
    }
    $Map=[ordered]@{
        SANDBOX_AWS_PROFILE='DEVELOPER_AWS_PROFILE'; AWS_REGION='DEVELOPER_AWS_REGION';
        AWS_SSO_SESSION='DEVELOPER_AWS_SSO_SESSION'; AWS_SSO_START_URL='DEVELOPER_AWS_SSO_START_URL';
        AWS_SSO_REGION='DEVELOPER_AWS_SSO_REGION'; AWS_SSO_ACCOUNT_ID='DEVELOPER_AWS_SSO_ACCOUNT_ID';
        AWS_SSO_ROLE_NAME='DEVELOPER_AWS_SSO_ROLE_NAME'
    }
    $Lines=Get-Content $TargetEnv -Encoding UTF8
    foreach($dst in $Map.Keys){
        $src=$Map[$dst]
        if(-not $Vals[$src]){continue}
        $Lines=@($Lines | ForEach-Object {
            if($_ -match ('^'+[regex]::Escape($dst)+'=')){"$dst=$($Vals[$src])"}else{$_}
        })
    }
    [IO.File]::WriteAllLines($TargetEnv,$Lines,[Text.UTF8Encoding]::new($false))
}

$Tar=Join-Path $OutputDirectory 'AI_Sandbox_Developer_TAR'
$Ecr=Join-Path $OutputDirectory 'AI_Sandbox_Developer_ECR'
Remove-Item $Tar,$Ecr -Recurse -Force -ErrorAction SilentlyContinue

# TAR deployment package (works with POC- or Production-hardened images)
Copy-Required (Join-Path $Root '.devcontainer\devcontainer.json') (Join-Path $Tar '.devcontainer\devcontainer.json')
Copy-Required (Join-Path $Root 'tar\docker-compose.yml') (Join-Path $Tar 'tar\docker-compose.yml')
foreach($f in 'load-and-start.ps1','load-and-start.sh','verify-sandbox.ps1','verify-sandbox.sh'){
    Copy-Required (Join-Path $Root "scripts\tar\$f") (Join-Path $Tar "scripts\tar\$f")
}
Copy-Required (Join-Path $Root '.env.example') (Join-Path $Tar '.env.example')
Set-DeveloperSsoDefaults (Join-Path $Tar '.env.example')
Copy-Required (Join-Path $Root 'workspace\README.md') (Join-Path $Tar 'workspace\README.md')
Copy-Required (Join-Path $Root 'templates\developer\DEVELOPER-GUIDE-TAR.md') (Join-Path $Tar 'DEVELOPER-GUIDE.md')
New-Item -ItemType Directory -Force -Path (Join-Path $Tar 'tar\images')|Out-Null
Set-Content (Join-Path $Tar 'tar\images\README.txt') -Value 'Admin supplies the complete generated tar/images bundle here. Do not modify bundle files.' -Encoding ASCII
if($IncludeTarImages){
    $BuiltImages=Join-Path $Root 'tar\images'
    if(-not(Test-Path (Join-Path $BuiltImages 'SHA256SUMS'))){throw 'TAR image bundle has not been built yet.'}
    Copy-Item (Join-Path $BuiltImages '*') (Join-Path $Tar 'tar\images') -Recurse -Force
}

# ECR deployment package
Copy-Required (Join-Path $Root 'ecr\docker-compose.yml') (Join-Path $Ecr 'docker-compose.yml')
Copy-Required (Join-Path $Root 'templates\developer\devcontainer-ecr.json') (Join-Path $Ecr '.devcontainer\devcontainer.json')
foreach($f in 'pull-and-start.ps1','pull-and-start.sh'){
    Copy-Required (Join-Path $Root "scripts\ecr\$f") (Join-Path $Ecr "scripts\ecr\$f")
}
Copy-Required (Join-Path $Root '.env.example') (Join-Path $Ecr '.env.example')
Set-DeveloperSsoDefaults (Join-Path $Ecr '.env.example')
Copy-Required (Join-Path $Root 'workspace\README.md') (Join-Path $Ecr 'workspace\README.md')
Copy-Required (Join-Path $Root 'templates\developer\DEVELOPER-GUIDE-ECR.md') (Join-Path $Ecr 'DEVELOPER-GUIDE.md')

Write-Host "[OK] TAR Developer package: $Tar" -ForegroundColor Green
Write-Host "[OK] ECR Developer package: $Ecr" -ForegroundColor Green
