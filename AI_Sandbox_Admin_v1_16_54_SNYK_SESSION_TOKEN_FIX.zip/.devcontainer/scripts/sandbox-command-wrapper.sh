#!/usr/bin/env bash
# =============================================================================
# AI Secure Sandbox credential-isolated command shim - v1.16.54
#
# Core invariant:
#   Every vendor/developer command executes in THIS devcontainer as uid/gid 1000.
#   The secret-broker sidecar only retrieves SSM credentials and injects them at
#   fixed HTTP proxy routes. It never executes Git/Snyk/Tavily/Databricks/AI/MCP.
# =============================================================================
set -euo pipefail
set +x
umask 027

readonly REAL_DIR="/usr/local/libexec/ai-sandbox/real"
readonly PROVIDER_BASE="http://127.0.0.1:8771"
readonly TAVILY_BOOTSTRAP="/usr/local/libexec/ai-sandbox/tavily-python-bootstrap"
tool="$(basename -- "$0")"

fail(){ echo "ERROR: $*" >&2; exit 1; }
real_tool(){ printf '%s/%s' "$REAL_DIR" "$1"; }

is_local_only_operation(){
  local t="$1" first="${2:-}"
  case "$first" in --help|-h|help|--version|-v|version) return 0 ;; esac
  case "$t:$first" in claude:mcp|gemini:mcp|ucode:status) return 0 ;; esac
  return 1
}

strip_aws(){
  unset AWS_ACCESS_KEY_ID AWS_SECRET_ACCESS_KEY AWS_SESSION_TOKEN AWS_SECURITY_TOKEN
  unset AWS_PROFILE AWS_DEFAULT_PROFILE AWS_CONFIG_FILE AWS_SHARED_CREDENTIALS_FILE SANDBOX_AWS_HOME SANDBOX_AWS_PROFILE
  unset AWS_CONTAINER_CREDENTIALS_RELATIVE_URI AWS_CONTAINER_CREDENTIALS_FULL_URI
  unset AWS_CONTAINER_AUTHORIZATION_TOKEN AWS_CONTAINER_AUTHORIZATION_TOKEN_FILE
  unset AWS_WEB_IDENTITY_TOKEN_FILE AWS_ROLE_ARN AWS_ROLE_SESSION_NAME AWS_CREDENTIAL_EXPIRATION
}

strip_service_secrets(){
  # Fail-safe hygiene: a Developer/AI process must never inherit a real service
  # credential from a parent shell. Each approved route below supplies only a
  # fixed non-secret placeholder when a vendor client requires an auth value.
  unset ADO_PAT DATABRICKS_TOKEN DATABRICKS_SQL_MCP_TOKEN
  unset ANTHROPIC_API_KEY ANTHROPIC_AUTH_TOKEN GEMINI_API_KEY GOOGLE_API_KEY
  unset TAVILY_API_KEY SNYK_TOKEN HIDDENLAYER_CLIENT_ID HIDDENLAYER_CLIENT_SECRET
}

ensure_gemini_mcp_config(){
  export GEMINI_CLI_SYSTEM_SETTINGS_PATH=/etc/gemini-cli/settings.json
  /usr/local/bin/configure-mcp >/dev/null || fail "Gemini managed MCP synchronization failed"
}

run_audited(){
  local app="$1" operation="$2" target="$3" transport="$4"; shift 4
  local start_ms end_ms ec status
  start_ms="$(date +%s%3N)"
  application-audit --app "$app" --event process_start --operation "$operation" --target "$target" --status started --transport "$transport" || true
  set +e; "$@"; ec=$?; set -e
  end_ms="$(date +%s%3N)"; status=success; (( ec == 0 )) || status=failure
  application-audit --app "$app" --event process_end --operation "$operation" --target "$target" --status "$status" --exit-code "$ec" --duration-ms "$((end_ms-start_ms))" --transport "$transport" || true
  return "$ec"
}

run_snyk_local(){
  local root=/run/ai-sandbox-snyk h ec snyk_api snyk_code_api snyk_no_proxy
  [[ -d "$root" && -w "$root" ]] || fail "Snyk runtime tmpfs unavailable"
  h="$(mktemp -d "$root/home.XXXXXX")"; chmod 0700 "$h"; mkdir -p "$h/.cache" "$h/.config"
  if [[ -d /opt/snyk-cache ]]; then cp -a /opt/snyk-cache "$h/.cache/snyk" 2>/dev/null || true; chmod -R u+rwX "$h/.cache/snyk" 2>/dev/null || true; fi

  # Snyk CLI 1.1306.2 uses API_URL for the general API. Its pinned
  # code-client-go v1.27.0 derives the Code API by replacing "api" with
  # "deeproxy" in API_URL. These two loopback aliases deliberately preserve
  # that native split: api.snyk.local -> deeproxy.snyk.local.
  snyk_api="http://api.snyk.local:8771"
  snyk_code_api="http://deeproxy.snyk.local:8771"
  snyk_no_proxy="api.snyk.local,deeproxy.snyk.local${NO_PROXY:+,$NO_PROXY}"

  set +e
  env HOME="$h" XDG_CACHE_HOME="$h/.cache" XDG_CONFIG_HOME="$h/.config" \
      SNYK_TOKEN="ai-sandbox-broker-placeholder" \
      SNYK_API="$snyk_api" DEEPROXY_API_URL="$snyk_code_api" \
      SNYK_HTTP_PROTOCOL_UPGRADE=0 \
      NO_PROXY="$snyk_no_proxy" no_proxy="$snyk_no_proxy" \
      SNYK_DISABLE_ANALYTICS=1 \
      "$(real_tool snyk)" "$@"
  ec=$?
  set -e
  rm -rf "$h"
  return "$ec"
}

strip_aws
strip_service_secrets
# Never allow a caller-supplied proxy bypass to send the fixed loopback route
# through Squid. Vendor egress still leaves the credential broker through Squid.
export NO_PROXY="localhost,127.0.0.1,squid-proxy${NO_PROXY:+,$NO_PROXY}"
export no_proxy="$NO_PROXY"

case "$tool" in
  claude)
    [[ -x "$(real_tool claude)" ]] || fail "real claude executable is missing"
    if is_local_only_operation "$tool" "${1:-}"; then exec "$(real_tool claude)" "$@"; fi
    [[ -r /etc/claude-code/managed-mcp.json ]] || fail "Admin Claude managed MCP config is missing"
    export ANTHROPIC_BASE_URL="${PROVIDER_BASE}/anthropic" ANTHROPIC_API_KEY="ai-sandbox-broker-placeholder"
    export ENABLE_TOOL_SEARCH=true ANTHROPIC_AUTH_TOKEN="" ANTHROPIC_CUSTOM_HEADERS=""
    export CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC=1 DISABLE_AUTOUPDATER=1 SANDBOX_AI_ROUTE=brokered-anthropic
    unset CLAUDE_CODE_USE_BEDROCK CLAUDE_CODE_USE_VERTEX CLAUDE_CODE_USE_FOUNDRY
    run_audited anthropic claude-direct api.anthropic.com https "$(real_tool claude)" "$@"
    ;;

  gemini)
    [[ -x "$(real_tool gemini)" ]] || fail "real gemini executable is missing"
    if is_local_only_operation "$tool" "${1:-}"; then
      # Help/version stay completely native. MCP control keeps the existing
      # managed-MCP synchronization, but caller argv is not changed.
      [[ "${1:-}" == mcp ]] && ensure_gemini_mcp_config
      exec "$(real_tool gemini)" "$@"
    fi
    ensure_gemini_mcp_config
    export GOOGLE_GEMINI_BASE_URL="${PROVIDER_BASE}/gemini" GEMINI_API_KEY="ai-sandbox-broker-placeholder"
    export GOOGLE_API_KEY="" GOOGLE_GENAI_USE_VERTEXAI=false GOOGLE_GENAI_USE_GCA=false
    export GOOGLE_CLOUD_PROJECT="" GOOGLE_CLOUD_PROJECT_ID="" GOOGLE_CLOUD_LOCATION="" SANDBOX_AI_ROUTE=brokered-gemini
    run_audited gemini gemini-direct generativelanguage.googleapis.com https "$(real_tool gemini)" "$@"
    ;;

  ucode)
    [[ -x "$(real_tool ucode)" ]] || fail "real ucode executable is missing"
    case "${1:-}" in --help|-h|help|--version|-v|version) exec "$(real_tool ucode)" "$@" ;; esac
    agent="${1:-}"
    if [[ "$agent" != claude && "$agent" != gemini ]]; then
      # Preserve native ucode subcommands/providers that do not use the Sandbox
      # Databricks credential route. No SSM credential is exposed to the process.
      exec "$(real_tool ucode)" "$@"
    fi
    shift
    if is_local_only_operation "$agent" "${1:-}"; then
      # ucode passes agent arguments through to the underlying CLI. Only Gemini
      # MCP control needs the existing managed-MCP synchronization.
      [[ "$agent" == gemini && "${1:-}" == mcp ]] && ensure_gemini_mcp_config
      exec "$(real_tool "$agent")" "$@"
    fi
    [[ -n "${DATABRICKS_HOST:-}" && "$DATABRICKS_HOST" == https://* ]] || fail "DATABRICKS_HOST must be configured with https://"
    if [[ "$agent" == claude ]]; then
      model="${DATABRICKS_CLAUDE_MODEL:-}"; [[ -n "$model" ]] || fail "DATABRICKS_CLAUDE_MODEL is required"
      export ANTHROPIC_BASE_URL="${PROVIDER_BASE}/databricks/anthropic" ANTHROPIC_AUTH_TOKEN="ai-sandbox-broker-placeholder"
      export ANTHROPIC_API_KEY="" OAUTH_TOKEN="" ANTHROPIC_MODEL="$model" CLAUDE_CODE_USE_GATEWAY=1 ENABLE_TOOL_SEARCH=true
      export ANTHROPIC_CUSTOM_HEADERS="" CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC=1 DISABLE_AUTOUPDATER=1 SANDBOX_AI_ROUTE=brokered-databricks-claude
      unset CLAUDE_CODE_USE_BEDROCK CLAUDE_CODE_USE_VERTEX CLAUDE_CODE_USE_FOUNDRY
      run_audited databricks ucode-claude "$model" https "$(real_tool claude)" "$@"
    else
      model="${DATABRICKS_GEMINI_MODEL:-}"; [[ -n "$model" ]] || fail "DATABRICKS_GEMINI_MODEL is required"
      ensure_gemini_mcp_config
      export GOOGLE_GEMINI_BASE_URL="${PROVIDER_BASE}/databricks/gemini" GEMINI_API_KEY="ai-sandbox-broker-placeholder" GEMINI_API_KEY_AUTH_MECHANISM=bearer
      export GEMINI_MODEL="$model" GEMINI_CLI_TRUST_WORKSPACE=true GOOGLE_API_KEY="" OAUTH_TOKEN=""
      export GOOGLE_GENAI_USE_VERTEXAI=false GOOGLE_GENAI_USE_GCA=false GOOGLE_CLOUD_PROJECT="" GOOGLE_CLOUD_PROJECT_ID="" GOOGLE_CLOUD_LOCATION="" SANDBOX_AI_ROUTE=brokered-databricks-gemini
      run_audited databricks ucode-gemini "$model" https "$(real_tool gemini)" "$@"
    fi
    ;;

  databricks)
    [[ -x "$(real_tool databricks)" ]] || fail "real databricks executable is missing"
    if is_local_only_operation "$tool" "${1:-}"; then exec "$(real_tool databricks)" "$@"; fi
    export DATABRICKS_HOST="${PROVIDER_BASE}/databricks/api" DATABRICKS_TOKEN="ai-sandbox-broker-placeholder"
    run_audited databricks cli databricks https "$(real_tool databricks)" "$@"
    ;;

  tvly)
    [[ -x "$(real_tool tvly)" ]] || fail "real tvly executable is missing"
    if is_local_only_operation "$tool" "${1:-}"; then exec "$(real_tool tvly)" "$@"; fi
    export TAVILY_API_KEY="ai-sandbox-broker-placeholder" AI_SANDBOX_TAVILY_BASE_URL="${PROVIDER_BASE}/tavily-api"
    export PYTHONPATH="${TAVILY_BOOTSTRAP}${PYTHONPATH:+:$PYTHONPATH}"
    run_audited tavily "${1:-cli}" tavily https /usr/local/libexec/ai-sandbox/tavily-cli-policy.py "$(real_tool tvly)" "$@"
    ;;

  tavily-mcp)
    # Help/version are pure local operations and retain the vendor CLI output.
    # Runtime MCP traffic uses the brokered remote route so the real Tavily key
    # stays outside the DevContainer; Tavily domain allowlisting remains the only
    # intentional application-policy exception.
    if is_local_only_operation "$tool" "${1:-}"; then exec "$(real_tool tavily-mcp)" "$@"; fi
    exec /usr/local/bin/tavily-mcp-ssm "$@"
    ;;

  snyk)
    [[ -x "$(real_tool snyk)" ]] || fail "real snyk executable is missing"
    # Snyk touches its versioned cache even for local-only operations such as
    # --version. Always use the per-invocation writable home while preserving
    # the native argv unchanged.
    # Preserve the native Snyk command contract, including `snyk mcp ...`.
    # The dedicated snyk-mcp-ssm launcher remains only for Admin-managed MCP
    # configuration; the public `snyk` command forwards argv unchanged.
    run_audited snyk "${1:-command}" snyk https run_snyk_local "$@"
    ;;

  *) fail "unsupported sandbox command wrapper name: $tool" ;;
esac
