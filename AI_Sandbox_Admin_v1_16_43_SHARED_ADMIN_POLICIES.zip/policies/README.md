# Admin-managed policy source of truth

All Admin-maintained policy/configuration sources for the AI Sandbox live in this directory.
They are build-time inputs, not Developer runtime files.

- `ado-policy.json` - shared Azure DevOps credential-use policy. Both the local DevContainer Git policy and the credential broker read the same baked copy.
- `tavily-allowed-domains.json` - shared Tavily domain allowlist. Both local Tavily validation and broker enforcement read the same baked copy.
- `claude-mcp.json` - Admin-managed Claude MCP configuration.
- `gemini-managed-settings.json` - Admin-managed Gemini settings/MCP configuration.
- `gemini-web-policy.toml` - Admin Gemini native-web/shell policy.
- `admin-settings.json` - Docker Desktop/Admin host-policy example.
- `squid-egress-allowlist.txt` - Admin default-deny Squid egress destination allowlist.

At image build time the shared runtime security policies are installed under `/etc/ai-sandbox/policies/` as `root:root` mode `0444`. The running DevContainer and secret-broker use the same immutable image copy, preventing policy drift between first-line local validation and final credential-use enforcement.

Change policy here, run package lint/tests, rebuild the image, and redeploy. Do not maintain a second runtime copy under `.devcontainer/`.

## Egress policy

`policies/squid-egress-allowlist.txt` is the Admin source of truth for Squid's default-deny egress allowlist. The Squid image copies it to `/etc/squid/whitelist.txt` during build. Keep `squid/squid.conf` with the Squid implementation; change destinations only in this central policy file.
