# Security Logging and Sentinel - v1.16.26

## Objective

The Windows 365 host must retain log files so the approved Windows monitoring agent can collect them for Microsoft Sentinel, while the Developer must not be able to manually modify, truncate, replace or delete those files from either Windows or the Linux containers.

v1.16.26 uses a two-stage logging boundary instead of allowing runtime containers to write directly into a Windows bind mount.

```text
DevContainer / Squid
        |
        | stdout/stderr only
        v
Docker local logging driver
        |
        | read by LOCALSYSTEM scheduled task
        v
C:\ProgramData\AI-Sandbox\Logs
        |
        +-- devcontainer\*.log
        `-- squid\*.log
        |
        +-- Windows Developer: read-only
        +-- LOCALSYSTEM: writer
        +-- Sentinel/AMA running as SYSTEM: read
        |
        `-- mounted back into containers as read-only
```

The Windows host log directory is therefore present for Sentinel collection, but it is not the write target of an untrusted container process.

## Runtime log sources

Runtime records first enter Docker-owned stdout/stderr streams:

- shell/security audit metadata -> `sandbox-log-emit` -> DevContainer PID1 stdout;
- application/MCP events for Anthropic, Gemini, Databricks, Tavily, Snyk, ADO, HiddenLayer, Git and MCP -> DevContainer PID1 stdout;
- Claude managed-hook metadata and approved content records -> DevContainer PID1 stdout;
- Gemini telemetry/content -> DevContainer PID1 stdout;
- Squid access records -> Squid stdout;
- Squid cache/runtime records -> Squid stderr.

Both containers use Docker's `local` logging driver with rotation. The Developer cannot edit a previously emitted record through the container filesystem because the original sink is a stream rather than a seekable file.

## Protected Windows file export

Run the following once from an elevated PowerShell 7.4+ session on each Windows 365 host:

```powershell
pwsh -NoProfile -File .\scripts\platform\03-setup-logging.ps1
```

The script creates:

```text
C:\ProgramData\AI-Sandbox\Logs\devcontainer
C:\ProgramData\AI-Sandbox\Logs\squid
C:\ProgramData\AI-Sandbox\Monitoring
```

and installs the scheduled task:

```text
AI-Sandbox-Protected-Log-Export
```

The task runs as `LOCALSYSTEM` and executes `scripts\monitoring\export-docker-logs-to-host.ps1` every minute by default.

The protected log ACL is intentionally narrow:

| Principal | Normal rights on protected log tree |
|---|---|
| LOCALSYSTEM | Full control / writer |
| Local Administrators | Read and execute only through the normal ACL |
| Configured Developer/read principal | Read and execute only |
| DevContainer | Read-only bind mount |
| Squid container | Read-only bind mount |

The exporter fails closed if the protected host log directory owner changes away from `LOCALSYSTEM` or if a non-SYSTEM allow rule gains write/append/delete/ACL-change rights.

The default runtime configuration is:

```env
SANDBOX_LOG_ROOT=C:/ProgramData/AI-Sandbox/Logs
```

POC and ECR Compose definitions mount the two service folders back into the containers as `read_only: true`:

```text
C:\ProgramData\AI-Sandbox\Logs\devcontainer -> /var/log/sandbox  RO
C:\ProgramData\AI-Sandbox\Logs\squid        -> /var/log/squid    RO
```

These mounts are for inspection/compatibility only. Containers do not write their audit/access/content records through those mounts.

## Host file layout

The SYSTEM exporter creates daily files such as:

```text
C:\ProgramData\AI-Sandbox\Logs\devcontainer\
  all-YYYY-MM-DD.log
  audit-YYYY-MM-DD.log
  security-YYYY-MM-DD.log
  application-YYYY-MM-DD.log
  claude-events-YYYY-MM-DD.log
  content-YYYY-MM-DD.log
  gemini-telemetry-YYYY-MM-DD.log
  verification-YYYY-MM-DD.log
  runtime-YYYY-MM-DD.log

C:\ProgramData\AI-Sandbox\Logs\squid\
  all-YYYY-MM-DD.log
  access-YYYY-MM-DD.log
  runtime-YYYY-MM-DD.log
```

`content-*.log` is populated only when content logging is explicitly approved and enabled. `SANDBOX_CONTENT_LOGGING=false` remains the default.

## Tamper-resistance matrix

| Record class | Linux Developer/constrained root | Normal Windows Developer | Local Windows Administrator |
|---|---|---|---|
| Audit/security/application files | Read-only mount; cannot modify/delete through the container | Read-only NTFS ACL | Can ultimately override endpoint ACL using administrator privileges |
| Claude/Gemini content files | Read-only mount | Read-only NTFS ACL | Can ultimately override endpoint ACL |
| Squid access/runtime files | Read-only mount | Read-only NTFS ACL | Can ultimately override endpoint ACL |
| Original Docker retained stream | No Docker socket inside DevContainer | Docker lifecycle permissions depend on host policy | Can manage Docker retention |

`read_only: true`, ECI, `cap_drop: ALL`, and `no-new-privileges` provide additional container-side defense in depth. Docker Desktop ECI also prevents a container from remounting an approved read-only bind mount as writable.

## Important administrator boundary

A local Windows Administrator cannot be made cryptographically or absolutely unable to delete endpoint-local evidence using NTFS ACLs alone. An Administrator can take ownership, reset ACLs, disable a task/agent, or otherwise alter the endpoint. Therefore:

- POC: keep Developers as standard Windows users; use the protected SYSTEM-owned log folder and the SYSTEM exporter.
- POST POC: centrally enforce Docker Desktop/ECI and endpoint settings so Developers cannot weaken the runtime configuration.
- Production authoritative evidence: forward the protected host files promptly to Log Analytics / Microsoft Sentinel.
- If policy requires that even endpoint/platform administrators cannot delete evidence, store the authoritative copy in immutable/WORM retention under a separately administered security control plane.

The local Windows files are a protected collection buffer and operational evidence copy. Sentinel/immutable central retention should be the authoritative record for administrator-resistant audit requirements.

## Docker lifecycle caveat

A Developer with unrestricted host Docker lifecycle access could attempt to stop/remove a container before the next exporter interval and suppress not-yet-exported local Docker records. The protected files already exported to Windows remain read-only to the normal Developer, but Production should also restrict Docker lifecycle/API operations or use an enterprise collector with sufficiently short forwarding latency.

## Sentinel collection

Configure the approved Windows collection method to read:

```text
C:\ProgramData\AI-Sandbox\Logs\devcontainer\*.log
C:\ProgramData\AI-Sandbox\Logs\squid\*.log
```

A collector running as LOCALSYSTEM can read the files without granting the Developer write access. If the client collector uses a different Windows service identity, grant only that dedicated identity read access (for example with `-ReadPrincipal`) and do not grant Developer write/modify/delete rights. Adapt the DCR/custom-table mapping in `sentinel/` to the client environment.

An optional direct Logs Ingestion API sender remains available in `scripts/monitoring/send-logs-ingestion.*`; do not grant a Developer write permission to the protected log tree merely to support a collector.

## Verification

After the protected host logging setup is installed and both containers are recreated, run from a normal Developer PowerShell session:

```powershell
pwsh -NoProfile -File .\scripts\monitoring\verify-host-log-export.ps1
```

The verification checks that:

- the current Windows user cannot create files in either protected host log folder;
- protected folders are SYSTEM-owned and no non-SYSTEM allow rule has write/modify/delete rights;
- the SYSTEM scheduled exporter is installed and can transfer a marker into the Windows file tree;
- audit/application/content metadata redaction behavior remains correct;
- `/var/log/sandbox` and `/var/log/squid` are non-writable inside the containers;
- those mount points are actually Docker read-only mounts;
- `/var/run/docker.sock` is absent from the DevContainer;
- both containers use Docker's `local` logging driver.

Useful manual checks:

```powershell
icacls C:\ProgramData\AI-Sandbox\Logs
Get-ScheduledTask -TaskName AI-Sandbox-Protected-Log-Export
Get-ChildItem C:\ProgramData\AI-Sandbox\Logs\devcontainer
Get-ChildItem C:\ProgramData\AI-Sandbox\Logs\squid
```

From the DevContainer:

```bash
touch /var/log/sandbox/developer-write-test
# Expected: Read-only file system or Permission denied
```

From Squid, the `/var/log/squid` bind mount is also read-only; Squid itself continues to log to stdout/stderr rather than to that path.

## Upgrade from v1.16.21/v1.16.22

Do not reuse the old Developer-writable `logs\devcontainer` or `logs\squid` bind mounts as log sinks. Archive any old evidence, run `03-setup-logging.ps1`, set `SANDBOX_LOG_ROOT`, and recreate the containers. The protected Windows paths are now written by LOCALSYSTEM and mounted into the containers read-only.
