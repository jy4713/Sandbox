#!/usr/bin/env python3
"""Offline regression tests for the v1.16.47 credential-only HTTP broker.

No AWS or vendor network access is used. The tests verify that the broker has no
application-command execution path, that fixed upstream validation is fail
closed, that ADO stays on fixed Admin routes without CLI/API command gating,
and that Tavily domain policy cannot be bypassed by calling the broker directly.
"""
from __future__ import annotations

import importlib.util
import json
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
BROKER = ROOT / ".devcontainer" / "scripts" / "secret-broker-server.py"
TAVILY_POLICY = ROOT / "policies" / "tavily-allowed-domains.json"
ADO_POLICY = ROOT / "policies" / "ado-policy.json"
os.environ["TAVILY_POLICY_FILE"] = str(TAVILY_POLICY)
os.environ["ADO_POLICY_FILE"] = str(ADO_POLICY)
os.environ.pop("DATABRICKS_HOST", None)
os.environ.pop("SNYK_API", None)

spec = importlib.util.spec_from_file_location("ai_sandbox_secret_broker", BROKER)
assert spec and spec.loader
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)


def expect_denied(fn, *args):
    try:
        fn(*args)
    except (PermissionError, ValueError, RuntimeError):
        return
    raise AssertionError(f"expected denial: {fn.__name__}{args!r}")


# Broker architecture: AWS SSM retrieval is the only subprocess use.
source = BROKER.read_text(encoding="utf-8")
for forbidden in ("subprocess.Popen", "subprocess.call", "subprocess.check_call", "subprocess.check_output", "os.system(", "os.exec"):
    assert forbidden not in source
assert source.count("subprocess.run(") == 1
assert "run-with-ssm-secrets" not in source
assert "secret-broker-client" not in source
assert "/home/vscode/workspace" not in source
assert '["aws", "--profile", AWS_PROFILE, "ssm", "get-parameter"' in source
assert "command_execution=disabled" in source

# Dependency errors keep useful vendor/proxy diagnostics but redact credentials.
raw_error = (
    'aws: [ERROR]: Failed to connect to proxy URL: "http://squid-proxy:3128"\n'
    'Authorization: Bearer super-secret-token\n'
    'aws_secret_access_key=example-secret\n'
    'access=AKIA1234567890ABCDEF'
)
san = mod.sanitize_error_text(raw_error)
assert 'Failed to connect to proxy URL: "http://squid-proxy:3128"' in san
assert 'super-secret-token' not in san
assert 'example-secret' not in san
assert 'AKIA1234567890ABCDEF' not in san
assert '[REDACTED]' in san

# AWS SSM stderr is returned to the caller after sanitization instead of being
# replaced with a generic "refresh profile" message. No network access occurs.
class _FakeCompleted:
    returncode = 255
    stdout = ''
    stderr = 'aws: [ERROR]: An error occurred (ParameterNotFound) when calling the GetParameter operation'

_real_run = mod.subprocess.run
mod.subprocess.run = lambda *args, **kwargs: _FakeCompleted()
try:
    try:
        mod.get_parameter('__lint_missing_parameter__')
    except RuntimeError as exc:
        text = str(exc)
        assert text.startswith('[broker:aws-ssm] ')
        assert 'ParameterNotFound' in text
        assert 'refresh the host AWS profile' not in text
    else:
        raise AssertionError('expected sanitized AWS SSM error')
finally:
    mod.subprocess.run = _real_run

# Fixed upstream origins must be HTTPS, approved, no custom path/userinfo/port.
assert mod._validate_https_origin("https://api.snyk.io", (".snyk.io",), "x") == "https://api.snyk.io"
for bad in (
    "http://api.snyk.io",
    "https://user:pass@api.snyk.io",
    "https://api.snyk.io/evil",
    "https://api.snyk.io:8443",
    "https://example.invalid",
):
    expect_denied(mod._validate_https_origin, bad, (".snyk.io",), "x")

# Traversal must be denied before privileged forwarding.
assert mod.safe_suffix("/ado/dev/org/proj", "/ado/dev") == "/org/proj"
for bad in (
    "/ado/dev/../x",
    "/ado/dev/%2e%2e/x",
    "/ado/dev/%252e%252e/x",
    "/ado/dev/a\\..\\b",
):
    expect_denied(mod.safe_suffix, bad, "/ado/dev")

# ADO policy is loaded from the same single source used by the local Git policy.
ado_doc = json.loads(ADO_POLICY.read_text(encoding="utf-8"))
assert mod.ADO_POLICY["policy_version"] == ado_doc["policy_version"]
assert set(mod.ADO_ROUTES) == {r["prefix"] for r in ado_doc["broker_routes"]}
assert mod.ADO_POLICY["git"]["repository_host"] == "dev.azure.com"
assert "allowed_operations" not in mod.ADO_POLICY["git"]
assert "repository_path_regex" not in mod.ADO_POLICY["git"]
assert all("rules" not in route for route in ado_doc["broker_routes"])
assert "allowed_operations" not in source
assert "repository_path_regex" not in source
assert "query_requirements" not in source

# ADO remains fixed to the shared Admin route metadata, but the broker is not a
# Git/REST subcommand allowlist. Azure DevOps permissions on the PAT are the
# authorization boundary; only Tavily retains an application-level allowlist.
assert "_ado_request_allowed" not in source
assert "approved Git/PR/pipeline policy" not in source
assert mod.ADO_ROUTES["/ado/dev"]["upstream_origin"] == "https://dev.azure.com"
assert mod.ADO_ROUTES["/ado/vssps"]["upstream_origin"] == "https://vssps.dev.azure.com"
assert all(route["credential_parameter"] == "ado-pat" for route in mod.ADO_ROUTES.values())

# Tavily policy is enforced again at the broker, so direct HTTP use cannot
# bypass the Admin allowlist even if a Developer ignores the CLI/MCP wrapper.
allowed = json.loads(mod._enforce_tavily_http(
    "/search", json.dumps({"query": "python docs from docs.python.org"}).encode()
).decode())
assert allowed["include_domains"] == ["docs.python.org"]

normalized = json.loads(mod._enforce_tavily_http(
    "/search", json.dumps({"query": "secure coding"}).encode()
).decode())
assert set(normalized["include_domains"]) == set(mod.TAVILY_ALLOWED)

expect_denied(
    mod._enforce_tavily_http,
    "/search",
    json.dumps({"query": "arsenal news from espn.com"}).encode(),
)
expect_denied(
    mod._enforce_tavily_http,
    "/search",
    json.dumps({"query": "test", "include_domains": ["espn.com"]}).encode(),
)
expect_denied(
    mod._enforce_tavily_http,
    "/extract",
    json.dumps({"urls": ["https://espn.com/news"]}).encode(),
)
expect_denied(mod._enforce_tavily_http, "/research", json.dumps({"input": "x"}).encode())
expect_denied(mod._enforce_tavily_http, "/unknown", json.dumps({"x": 1}).encode())

mcp = {
    "jsonrpc": "2.0",
    "id": 1,
    "method": "tools/call",
    "params": {"name": "tavily_search", "arguments": {"query": "docs.python.org asyncio"}},
}
out = json.loads(mod._enforce_tavily_mcp(json.dumps(mcp).encode()).decode())
assert out["params"]["arguments"]["include_domains"] == ["docs.python.org"]
mcp["params"]["arguments"] = {"query": "scores from espn.com"}
expect_denied(mod._enforce_tavily_mcp, json.dumps(mcp).encode())

print("Credential-only broker policy regression tests passed")
