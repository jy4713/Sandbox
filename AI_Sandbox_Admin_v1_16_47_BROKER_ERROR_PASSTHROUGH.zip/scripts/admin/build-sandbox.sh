#!/usr/bin/env bash
# =============================================================================
# ADMIN unified build entry point.
# v1.16.44 separates image hardening (SandboxType) from distribution (--deployment-type) and preserves reuse.
# Reuse is accepted only when .build.env is complete and the hardened image is
# cryptographically tied to the prior state by exact digest or persisted config
# ID, with matching hardening provenance. Otherwise it falls back to hardening.
# =============================================================================
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
cd "$ROOT"
PACKAGE_VERSION='v1.16.47'

usage(){
  cat >&2 <<'EOF'
Usage:
  build-sandbox.sh <POC|Production> [UbuntuProToken] [--deployment-type Tar|Ecr] [--reuse-hardened-base] [--skip-cis-assessment] [--build-env-source PATH]

Examples:
  bash scripts/admin/build-sandbox.sh POC --reuse-hardened-base --skip-cis-assessment
  bash scripts/admin/build-sandbox.sh POC --deployment-type Ecr --reuse-hardened-base
  bash scripts/admin/build-sandbox.sh Production --deployment-type Tar --reuse-hardened-base
  bash scripts/admin/build-sandbox.sh Production "$UBUNTU_PRO_TOKEN"   # defaults to Ecr
EOF
}

TYPE="${1:-}"
[[ "$TYPE" == -h || "$TYPE" == --help ]] && { usage; exit 0; }
[[ -n "$TYPE" ]] || { usage; exit 2; }
shift

TOKEN="${UBUNTU_PRO_TOKEN:-}"
DEPLOYMENT_TYPE=''
REUSE=false
SKIP_CIS=false
BUILD_ENV_SOURCE=''
while (($#)); do
  case "$1" in
    --deployment-type)
      [[ $# -ge 2 ]] || { echo 'ERROR: --deployment-type requires Tar or Ecr.' >&2; exit 2; }
      DEPLOYMENT_TYPE="$2"; shift 2 ;;
    --reuse-hardened-base)
      REUSE=true; shift ;;
    --skip-cis-assessment)
      SKIP_CIS=true; shift ;;
    --build-env-source)
      [[ $# -ge 2 ]] || { echo 'ERROR: --build-env-source requires a path.' >&2; exit 2; }
      BUILD_ENV_SOURCE="$2"; shift 2 ;;
    --ubuntu-pro-token)
      [[ $# -ge 2 ]] || { echo 'ERROR: --ubuntu-pro-token requires a value.' >&2; exit 2; }
      TOKEN="$2"; shift 2 ;;
    -h|--help)
      usage; exit 0 ;;
    --*)
      echo "ERROR: unknown option: $1" >&2; usage; exit 2 ;;
    *)
      if [[ -z "$TOKEN" ]]; then TOKEN="$1"; shift; else echo "ERROR: unexpected argument: $1" >&2; usage; exit 2; fi ;;
  esac
done

BUILD_ENV="$ROOT/.build.env"
case "${TYPE,,}" in
  poc) TYPE='POC'; EXPECTED_MODE='poc' ;;
  production) TYPE='Production'; EXPECTED_MODE='production' ;;
  *) echo "ERROR: SandboxType must be POC or Production. Received: $TYPE" >&2; usage; exit 2 ;;
esac
if [[ -z "$DEPLOYMENT_TYPE" ]]; then
  [[ "$EXPECTED_MODE" == 'poc' ]] && DEPLOYMENT_TYPE='tar' || DEPLOYMENT_TYPE='ecr'
  DEPLOYMENT_SOURCE='default'
else
  DEPLOYMENT_TYPE="${DEPLOYMENT_TYPE,,}"
  [[ "$DEPLOYMENT_TYPE" == 'tar' || "$DEPLOYMENT_TYPE" == 'ecr' ]] || { echo 'ERROR: --deployment-type must be Tar or Ecr.' >&2; exit 2; }
  DEPLOYMENT_SOURCE='explicit'
fi
echo "[selection] SandboxType=$TYPE -> hardening=$EXPECTED_MODE"
echo "[selection] DeploymentType=$DEPLOYMENT_TYPE ($DEPLOYMENT_SOURCE)"

if [[ "$SKIP_CIS" == true && "$EXPECTED_MODE" != 'poc' ]]; then
  echo 'ERROR: --skip-cis-assessment is permitted only with SandboxType POC.' >&2
  exit 2
fi
[[ "$SKIP_CIS" == true ]] && echo 'WARNING: CIS/OpenSCAP assessment will be skipped. POC/test use only; not security-assessed release evidence.' >&2

set_env_value(){
  local key="$1" value="$2" file="${3:-$BUILD_ENV}" tmp="${3:-$BUILD_ENV}.tmp.$$"
  awk -v k="$key" -v v="$value" '
    BEGIN{found=0}
    index($0,k"=")==1 {$0=k"="v; found=1}
    {print}
    END{if(!found) print k"="v}
  ' "$file" > "$tmp"
  mv "$tmp" "$file"
}

get_env_value(){
  local key="$1" file="${2:-$BUILD_ENV}"
  awk -F= -v k="$key" '$1==k {sub(/^[^=]*=/,""); print; exit}' "$file" 2>/dev/null || true
}

remove_obsolete_build_env_keys(){
  local file="${1:-$BUILD_ENV}" tmp="${1:-$BUILD_ENV}.clean.$$"
  awk -F= '
    $1=="HARDENED_METHOD" || $1=="HARDENED_PROFILE" ||
    $1=="MAX_CRITICAL_FINDINGS" || $1=="MAX_HIGH_FINDINGS" ||
    $1=="REQUIRE_IMAGE_SIGNING" || $1=="COSIGN_KEY_REF" {next}
    {print}
  ' "$file" > "$tmp"
  mv "$tmp" "$file"
}

update_package_version(){
  local file="${1:-$BUILD_ENV}"
  [[ -f "$file" ]] || return 0
  local old_version old_release
  old_version="$(get_env_value SANDBOX_VERSION "$file")"
  old_release="$(get_env_value RELEASE_TAG "$file")"
  set_env_value SANDBOX_VERSION "$PACKAGE_VERSION" "$file"
  # Follow the package version only when RELEASE_TAG was blank or tracked the
  # previous SANDBOX_VERSION. Deliberately custom release tags are preserved.
  if [[ -z "$old_release" || "$old_release" == "$old_version" ]]; then
    set_env_value RELEASE_TAG "$PACKAGE_VERSION" "$file"
  fi
}

apply_hardened_env(){
  local target="${1:-$BUILD_ENV}" src="$ROOT/hardened-base-build/hardened-base.env" line key value
  [[ -f "$src" ]] || { echo "ERROR: hardened base environment file not found: $src" >&2; return 1; }
  local base='' squid=''
  while IFS= read -r line; do
    case "$line" in
      BASE_IMAGE=*) base="${line#*=}" ;;
      SQUID_BASE_IMAGE=*) squid="${line#*=}" ;;
      HARDENED_SOURCE_IMAGE=*|HARDENED_SSG_SHA256=*|HARDENED_CONFIG_ID=*)
        key="${line%%=*}"; value="${line#*=}"; set_env_value "$key" "$value" "$target" ;;
    esac
  done < "$src"
  [[ -n "$base" && -n "$squid" ]] || { echo 'ERROR: hardened-base builder did not produce BASE_IMAGE and SQUID_BASE_IMAGE.' >&2; return 1; }
  set_env_value BASE_IMAGE "$base" "$target"
  set_env_value SQUID_BASE_IMAGE "$squid" "$target"
}

validate_build_env(){
  local file="${1:-$BUILD_ENV}"
  BUILD_ENV_FILE="$file" bash -c 'source scripts/common/load-build-env.sh >/dev/null'
}

REUSE_RESOLVED_REF=''
REUSE_RESOLVED_CONFIG_ID=''

get_registry_digest(){
  local registry="$1" repo="$2" tag="$3" image_ref="$4" digest=''
  if [[ "$registry" == localhost:* ]]; then
    local port="${registry#localhost:}"
    digest="$(curl -fsSI \
      -H 'Accept: application/vnd.oci.image.manifest.v1+json, application/vnd.docker.distribution.manifest.v2+json, application/vnd.oci.image.index.v1+json, application/vnd.docker.distribution.manifest.list.v2+json' \
      "http://localhost:${port}/v2/${repo}/manifests/${tag}" 2>/dev/null \
      | awk 'BEGIN{IGNORECASE=1} /^Docker-Content-Digest:/ {gsub("\r","",$2); d=$2} END{print d}')" || true
    [[ "$digest" =~ ^sha256:[0-9a-fA-F]{64}$ ]] && { printf '%s\n' "${digest,,}"; return 0; }
  fi

  digest="$(docker image inspect "$image_ref" --format '{{index .RepoDigests 0}}' 2>/dev/null \
    | sed -n 's/.*@\(sha256:[0-9a-fA-F]\{64\}\)$/\1/p' | head -n1)"
  [[ "$digest" =~ ^sha256:[0-9a-fA-F]{64}$ ]] && { printf '%s\n' "${digest,,}"; return 0; }

  digest="$(docker buildx imagetools inspect "$image_ref" --format '{{json .Manifest.Digest}}' 2>/dev/null | tr -d '"' || true)"
  [[ "$digest" =~ ^sha256:[0-9a-fA-F]{64}$ ]] && { printf '%s\n' "${digest,,}"; return 0; }
  return 1
}

test_hardened_image_provenance(){
  local image_ref="$1" expected_cid="${2:-}" config_id method profile expected_source actual_source expected_ssg actual_ssg
  config_id="$(docker image inspect "$image_ref" --format '{{.Id}}' 2>/dev/null || true)"
  config_id="${config_id,,}"
  [[ "$config_id" =~ ^sha256:[0-9a-f]{64}$ ]] || { echo "[reuse] Invalid image config ID for $image_ref." >&2; return 1; }
  if [[ -n "$expected_cid" && "$config_id" != "${expected_cid,,}" ]]; then
    echo "[reuse] Hardened image config ID mismatch. Expected '$expected_cid', found '$config_id'." >&2
    return 1
  fi

  method="$(docker image inspect "$image_ref" --format '{{ index .Config.Labels "hardening.method" }}' 2>/dev/null || true)"
  profile="$(docker image inspect "$image_ref" --format '{{ index .Config.Labels "hardening.profile" }}' 2>/dev/null || true)"
  [[ "$method" == "$EXPECTED_MODE" ]] || { echo "[reuse] Hardened base mode mismatch. Expected '$EXPECTED_MODE', found '$method'." >&2; return 1; }
  [[ "$profile" == 'cis_level1_server' ]] || { echo "[reuse] Hardened base profile mismatch. Expected 'cis_level1_server', found '$profile'." >&2; return 1; }

  expected_source="$(get_env_value HARDENED_SOURCE_IMAGE)"
  if [[ -n "$expected_source" ]]; then
    actual_source="$(docker image inspect "$image_ref" --format '{{ index .Config.Labels "hardening.source.image" }}' 2>/dev/null || true)"
    [[ "$actual_source" == "$expected_source" ]] || { echo "[reuse] Hardened source-image provenance mismatch. Expected '$expected_source', found '$actual_source'." >&2; return 1; }
  fi

  expected_ssg="$(get_env_value HARDENED_SSG_SHA256)"
  if [[ -n "$expected_ssg" ]]; then
    actual_ssg="$(docker image inspect "$image_ref" --format '{{ index .Config.Labels "hardening.ssg.sha256" }}' 2>/dev/null || true)"
    [[ "$actual_ssg" == "$expected_ssg" ]] || { echo '[reuse] Hardened SSG provenance mismatch.' >&2; return 1; }
  fi

  REUSE_RESOLVED_CONFIG_ID="$config_id"
  return 0
}

restore_local_scratch_digest_reference(){
  local ref="$1"
  if [[ ! "$ref" =~ ^(localhost:([0-9]+))/([^@]+)@(sha256:[0-9a-fA-F]{64})$ ]]; then
    return 1
  fi
  local registry="${BASH_REMATCH[1]}" port="${BASH_REMATCH[2]}" repo="${BASH_REMATCH[3]}" expected="${BASH_REMATCH[4],,}"
  local expected_cid candidate='' candidate_cid='' image_ref repo_digests
  expected_cid="$(get_env_value HARDENED_CONFIG_ID)"
  expected_cid="${expected_cid,,}"
  if [[ -n "$expected_cid" && ! "$expected_cid" =~ ^sha256:[0-9a-f]{64}$ ]]; then
    echo '[reuse] HARDENED_CONFIG_ID is present but malformed; refusing local recovery.' >&2
    return 1
  fi

  # Strategy 1: exact old RepoDigest is still attached to a local image.
  while IFS= read -r image_ref; do
    [[ -n "$image_ref" && "$image_ref" != *'<none>'* ]] || continue
    repo_digests="$(docker image inspect "$image_ref" --format '{{json .RepoDigests}}' 2>/dev/null || true)"
    if [[ "$repo_digests" == *"$ref"* ]]; then
      candidate="$image_ref"
      candidate_cid="$(docker image inspect "$image_ref" --format '{{.Id}}' 2>/dev/null || true)"
      candidate_cid="${candidate_cid,,}"
      echo "[reuse] Local candidate matched the previous RepoDigest: $candidate"
      break
    fi
  done < <(docker image ls --format '{{.Repository}}:{{.Tag}}' 2>/dev/null || true)

  # Strategy 2: v1.16.44+ persists the registry-independent image config ID.
  if [[ -z "$candidate" && -n "$expected_cid" ]]; then
    while IFS= read -r image_ref; do
      [[ -n "$image_ref" && "$image_ref" != *'<none>'* ]] || continue
      local candidate_repo="${image_ref%:*}"
      candidate_repo="${candidate_repo#localhost:*/}"
      [[ "$candidate_repo" == "$repo" ]] || continue
      local cid
      cid="$(docker image inspect "$image_ref" --format '{{.Id}}' 2>/dev/null || true)"
      cid="${cid,,}"
      if [[ "$cid" == "$expected_cid" ]]; then
        candidate="$image_ref"
        candidate_cid="$cid"
        echo "[reuse] Local candidate matched HARDENED_CONFIG_ID: $candidate"
        break
      fi
    done < <(docker image ls --format '{{.Repository}}:{{.Tag}}' 2>/dev/null || true)
  fi

  if [[ -z "$candidate" ]]; then
    if [[ -z "$expected_cid" ]]; then
      echo '[reuse] Legacy build state has no HARDENED_CONFIG_ID and no exact local RepoDigest; local recovery is intentionally fail-closed.' >&2
    else
      echo '[reuse] No local image matches the persisted hardened image config ID.' >&2
    fi
    return 1
  fi

  [[ "$candidate_cid" =~ ^sha256:[0-9a-f]{64}$ ]] || { echo '[reuse] Candidate image config ID is invalid.' >&2; return 1; }
  test_hardened_image_provenance "$candidate" "$expected_cid" || return 1
  candidate_cid="$REUSE_RESOLVED_CONFIG_ID"

  local registry_name='ai-sandbox-hardened-base-digest-scratch-registry'
  local registry_volume='ai-sandbox-hardened-base-registry-data'
  if docker container inspect "$registry_name" >/dev/null 2>&1; then
    local port_mapping
    port_mapping="$(docker port "$registry_name" 5000/tcp 2>/dev/null || true)"
    if [[ -n "$port_mapping" && "$port_mapping" != *"127.0.0.1:${port}"* ]]; then
      echo "[reuse] Existing scratch registry uses a different host port: '$port_mapping'." >&2
      return 1
    fi
    if [[ "$(docker inspect "$registry_name" --format '{{.State.Running}}' 2>/dev/null || true)" != 'true' ]]; then
      docker start "$registry_name" >/dev/null || return 1
    fi
  else
    if command -v ss >/dev/null 2>&1 && ss -tlnH "sport = :$port" 2>/dev/null | grep -q .; then
      echo "[reuse] Port $port is already in use; scratch registry cannot be recreated safely." >&2
      return 1
    fi
    docker volume create "$registry_volume" >/dev/null || return 1
    docker run -d --restart unless-stopped --name "$registry_name" \
      -p "127.0.0.1:${port}:5000" -v "${registry_volume}:/var/lib/registry" registry:2 >/dev/null || return 1
    sleep 2
  fi

  local short_config="${candidate_cid#sha256:}" recovery_tag actual resolved_ref pulled_cid
  short_config="${short_config:0:12}"
  recovery_tag="${registry}/${repo}:reuse-recovery-${short_config}"
  echo "[reuse] Re-materializing the verified local image through $registry..."
  docker tag "$candidate" "$recovery_tag" >/dev/null || return 1
  docker push "$recovery_tag" >/dev/null || return 1
  actual="$(get_registry_digest "$registry" "$repo" "reuse-recovery-${short_config}" "$recovery_tag" || true)"
  [[ "$actual" =~ ^sha256:[0-9a-f]{64}$ ]] || { echo '[reuse] Re-push succeeded but no registry digest could be resolved.' >&2; return 1; }

  resolved_ref="${registry}/${repo}@${actual}"
  docker pull "$resolved_ref" >/dev/null 2>&1 || return 1
  pulled_cid="$(docker image inspect "$resolved_ref" --format '{{.Id}}' 2>/dev/null || true)"
  pulled_cid="${pulled_cid,,}"
  [[ "$pulled_cid" == "$candidate_cid" ]] || { echo '[reuse] Re-materialized registry reference does not resolve to the verified image config ID.' >&2; return 1; }

  if [[ "$actual" != "$expected" ]]; then
    echo "[reuse] Scratch-registry manifest digest changed: $expected -> $actual" >&2
    echo '[reuse] Image config ID is unchanged; the new digest will be committed transactionally to .build.env.' >&2
  else
    echo '[reuse] Exact localhost hardened digest was re-materialized.'
  fi
  REUSE_RESOLVED_REF="$resolved_ref"
  REUSE_RESOLVED_CONFIG_ID="$candidate_cid"
  return 0
}

ensure_image_available(){
  local ref="$1"
  REUSE_RESOLVED_REF=''
  REUSE_RESOLVED_CONFIG_ID=''
  if docker image inspect "$ref" >/dev/null 2>&1; then
    REUSE_RESOLVED_REF="$ref"
    REUSE_RESOLVED_CONFIG_ID="$(docker image inspect "$ref" --format '{{.Id}}' 2>/dev/null || true)"
    REUSE_RESOLVED_CONFIG_ID="${REUSE_RESOLVED_CONFIG_ID,,}"
    return 0
  fi
  echo "[reuse] Exact digest is not materialized locally; attempting docker pull: $ref"
  if docker pull "$ref" >/dev/null 2>&1; then
    REUSE_RESOLVED_REF="$ref"
    REUSE_RESOLVED_CONFIG_ID="$(docker image inspect "$ref" --format '{{.Id}}' 2>/dev/null || true)"
    REUSE_RESOLVED_CONFIG_ID="${REUSE_RESOLVED_CONFIG_ID,,}"
    return 0
  fi
  restore_local_scratch_digest_reference "$ref"
}

can_reuse_hardened_base(){
  echo '[reuse] Checking whether the existing hardened base can be reused...'
  if ! validate_build_env; then
    echo '[reuse] .build.env is incomplete or invalid.' >&2
    return 1
  fi

  local base squid expected_cid
  base="$(get_env_value BASE_IMAGE)"
  squid="$(get_env_value SQUID_BASE_IMAGE)"
  if [[ "$base" != "$squid" ]]; then
    echo '[reuse] BASE_IMAGE and SQUID_BASE_IMAGE are not the same digest.' >&2
    return 1
  fi

  command -v docker >/dev/null 2>&1 || { echo '[reuse] docker is unavailable.' >&2; return 1; }
  if ! ensure_image_available "$base"; then
    echo "[reuse] Hardened base digest is unavailable and could not be safely restored: $base" >&2
    return 1
  fi

  expected_cid="$(get_env_value HARDENED_CONFIG_ID)"
  expected_cid="${expected_cid,,}"
  if [[ -n "$expected_cid" && ! "$expected_cid" =~ ^sha256:[0-9a-f]{64}$ ]]; then
    echo '[reuse] HARDENED_CONFIG_ID is malformed.' >&2
    return 1
  fi
  test_hardened_image_provenance "$REUSE_RESOLVED_REF" "$expected_cid" || return 1

  if [[ -z "$expected_cid" ]]; then
    echo '[reuse] Legacy build state verified by exact digest; HARDENED_CONFIG_ID will be added transactionally for future recovery.'
  fi
  echo '[reuse] Existing hardened base passed validation.'
  echo "[reuse] BASE_IMAGE = $REUSE_RESOLVED_REF"
  return 0
}

commit_reuse_state_and_refresh_tools(){
  local work_env="$ROOT/.build.env.reuse.$$.$RANDOM.tmp"
  cp "$BUILD_ENV" "$work_env"
  remove_obsolete_build_env_keys "$work_env"
  set_env_value BASE_IMAGE "$REUSE_RESOLVED_REF" "$work_env"
  set_env_value SQUID_BASE_IMAGE "$REUSE_RESOLVED_REF" "$work_env"
  if [[ "$REUSE_RESOLVED_CONFIG_ID" =~ ^sha256:[0-9a-f]{64}$ ]]; then
    set_env_value HARDENED_CONFIG_ID "$REUSE_RESOLVED_CONFIG_ID" "$work_env"
  fi
  update_package_version "$work_env"

  if (
    trap 'rm -f "$work_env"' EXIT
    BUILD_ENV_FILE="$work_env" bash scripts/supply-chain/resolve-tool-artifacts.sh --write || exit $?
    validate_build_env "$work_env" || exit $?
    mv "$work_env" "$BUILD_ENV" || exit $?
  ); then
    echo '[reuse] Verified hardened-base state and refreshed tool pins committed to .build.env.'
  else
    local rc=$?
    rm -f "$work_env"
    echo '[reuse] Reuse-state/tool-pin transaction failed; existing .build.env was preserved.' >&2
    return "$rc"
  fi
}

full_resolve_and_harden(){
  echo '[build] Running full resolver + hardened-base build path.'
  echo '[build] Resolver changes are staged and committed to .build.env only after hardening succeeds.'
  local work_env="$ROOT/.build.env.full-build.$$.$RANDOM.tmp"
  cp "$BUILD_ENV" "$work_env"
  remove_obsolete_build_env_keys "$work_env"

  if (
    trap 'rm -f "$work_env"' EXIT

    BUILD_ENV_FILE="$work_env" bash scripts/supply-chain/resolve-base-digests.sh --write || exit $?
    BUILD_ENV_FILE="$work_env" bash scripts/supply-chain/resolve-tool-artifacts.sh --write || exit $?
    validate_build_env "$work_env" || exit $?

    source_image="$(get_env_value BASE_IMAGE "$work_env")"
    if [[ "$EXPECTED_MODE" == 'poc' ]]; then
      bash scripts/hardening/build-hardened-base.sh --sandbox-type poc --source-image "$source_image" --build-env-file "$work_env" || exit $?
    else
      [[ -n "$TOKEN" ]] || { echo 'ERROR: Ubuntu Pro token is required because the Production hardened base must be rebuilt.' >&2; exit 2; }
      UBUNTU_PRO_TOKEN="$TOKEN" bash scripts/hardening/build-hardened-base.sh --sandbox-type "$TYPE" --source-image "$source_image" --build-env-file "$work_env" || exit $?
    fi

    apply_hardened_env "$work_env" || exit $?
    update_package_version "$work_env" || exit $?
    validate_build_env "$work_env" || exit $?
    mv "$work_env" "$BUILD_ENV" || exit $?
  ); then
    echo '[build] New hardened-base state committed to .build.env.'
  else
    local rc=$?
    rm -f "$work_env"
    echo '[build] Full resolver/hardening transaction failed; existing .build.env was preserved.' >&2
    return "$rc"
  fi
}

if [[ -n "$BUILD_ENV_SOURCE" ]]; then
  [[ -f "$BUILD_ENV_SOURCE" ]] || { echo "ERROR: build env source not found: $BUILD_ENV_SOURCE" >&2; exit 2; }
  src_abs="$(cd "$(dirname "$BUILD_ENV_SOURCE")" && pwd)/$(basename "$BUILD_ENV_SOURCE")"
  dst_abs="$BUILD_ENV"
  if [[ "$src_abs" != "$dst_abs" ]]; then
    cp "$BUILD_ENV_SOURCE" "$BUILD_ENV"
    echo "[INFO] Copied existing build configuration: $BUILD_ENV_SOURCE -> $BUILD_ENV"
  fi
fi

if [[ ! -f "$BUILD_ENV" ]]; then
  cp .build.env.example "$BUILD_ENV"
  echo '[INFO] Created .build.env from .build.env.example.'
fi
# Package/release metadata is updated only when a full-build or reuse transaction succeeds.

USING_REUSED=false
if [[ "$REUSE" == true ]]; then
  if can_reuse_hardened_base; then
    commit_reuse_state_and_refresh_tools
    USING_REUSED=true
    echo '[reuse] Skipping upstream base-image resolution and hardened-base generation for this iterative build.'
    echo '[reuse] Tool hashes and any restored scratch-registry digest were committed transactionally.'
  else
    echo '[reuse] Reuse requirements were not met. Falling back automatically to a new hardened-base build.' >&2
  fi
fi

if [[ "$USING_REUSED" != true ]]; then
  full_resolve_and_harden
fi

validate_build_env

if [[ "$DEPLOYMENT_TYPE" == 'tar' ]]; then
  echo "=== Admin image: $TYPE / deployment: TAR ==="
  [[ "$USING_REUSED" == true ]] && echo "[reuse] $TYPE hardened base reused."
  SANDBOX_TYPE="$TYPE" SKIP_CIS_ASSESSMENT="$SKIP_CIS" bash scripts/tar/build-and-export.sh
  echo '[OK] TAR bundle is ready under tar/images/. Developer uses scripts/tar/load-and-start.*'
else
  echo "=== Admin image: $TYPE / deployment: ECR ==="
  [[ "$USING_REUSED" == true ]] && echo "[reuse] $TYPE hardened base reused; hardening was not rerun."
  SANDBOX_TYPE="$TYPE" SKIP_CIS_ASSESSMENT="$SKIP_CIS" bash scripts/platform/02-setup-ecr.sh
  echo "[OK] $TYPE images are in ECR; approved manifest publication follows PUBLISH_APPROVED_MANIFEST_TO_SSM."
fi
