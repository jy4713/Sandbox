#!/usr/bin/env bash
# Credential-free MCP registration/synchronization.
#
# v1.16.47 keeps the three built-in MCP bridges in a root-owned Gemini system
# settings file so direct Gemini and Databricks-routed `ucode gemini` always
# resolve the same managed MCP set, even when the persistent ~/.gemini volume is
# stale or GEMINI_CLI_HOME changes. This helper also self-heals the user settings
# copy for compatibility with Gemini CLI tooling and preserves unrelated user/app
# settings. No AWS or service credential is written into either settings file.
set -euo pipefail
umask 077

export CLAUDE_CONFIG_DIR="${CLAUDE_CONFIG_DIR:-$HOME/.claude}"
export DISABLE_AUTOUPDATER=1
export CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC=1

readonly REAL_DIR="/usr/local/libexec/ai-sandbox/real"
readonly REAL_GEMINI="$REAL_DIR/gemini"
readonly SYSTEM_GEMINI_SETTINGS="/etc/gemini-cli/settings.json"
[[ -x "$REAL_GEMINI" ]] || { echo 'ERROR: real Gemini CLI is missing' >&2; exit 1; }
[[ -r /etc/claude-code/managed-mcp.json ]] || { echo 'ERROR: Admin Claude MCP config is missing' >&2; exit 1; }
[[ -r "$SYSTEM_GEMINI_SETTINGS" ]] || { echo 'ERROR: Admin Gemini system settings are missing' >&2; exit 1; }
command -v jq >/dev/null 2>&1 || { echo 'ERROR: jq is required for MCP configuration' >&2; exit 1; }

# GEMINI_CLI_HOME is a replacement home root. Gemini appends .gemini beneath it.
gemini_state_home="${GEMINI_CLI_HOME:-$HOME}"
gemini_config_dir="$gemini_state_home/.gemini"
gemini_settings="$gemini_config_dir/settings.json"
mkdir -p "$CLAUDE_CONFIG_DIR" "$gemini_config_dir"

readonly TAVILY_MCP_TIMEOUT_MS=120000
readonly SNYK_MCP_TIMEOUT_MS=180000
readonly DATABRICKS_SQL_MCP_TIMEOUT_MS=180000

# The immutable system settings are the authoritative registration. System
# settings have higher precedence than workspace/user settings in Gemini CLI
# 0.53.0+, so a stale persistent ~/.gemini volume cannot remove or replace the
# built-in bridge definitions.
if ! jq -e '
  (.mcpServers.tavily.command == "/usr/local/bin/tavily-mcp-ssm") and
  (.mcpServers.snyk.command == "/usr/local/bin/snyk-mcp-ssm") and
  (.mcpServers["databricks-sql"].command == "/usr/local/bin/databricks-sql-mcp-ssm") and
  (.mcpServers.tavily.env? == null) and
  (.mcpServers.snyk.env? == null) and
  (.mcpServers["databricks-sql"].env? == null)
' "$SYSTEM_GEMINI_SETTINGS" >/dev/null; then
  echo 'ERROR: Admin Gemini system MCP settings are incomplete or unsafe' >&2
  exit 1
fi

if [[ ! -s "$gemini_settings" ]]; then
  printf '%s\n' '{}' > "$gemini_settings"
elif ! jq -e . "$gemini_settings" >/dev/null 2>&1; then
  invalid_backup="${gemini_settings}.invalid.$(date +%Y%m%d%H%M%S)"
  cp -p "$gemini_settings" "$invalid_backup" 2>/dev/null || true
  printf '%s\n' '{}' > "$gemini_settings"
  echo "WARN: invalid Gemini settings backed up to $invalid_backup and reset" >&2
fi

tmp="$(mktemp "${TMPDIR:-/tmp}/gemini-settings.XXXXXX")"
trap 'rm -f "$tmp"' EXIT
jq \
  --argjson tavily_timeout "$TAVILY_MCP_TIMEOUT_MS" \
  --argjson snyk_timeout "$SNYK_MCP_TIMEOUT_MS" \
  --argjson databricks_sql_timeout "$DATABRICKS_SQL_MCP_TIMEOUT_MS" '
  .mcpServers = ((.mcpServers // {}) + {
    tavily: {
      command: "/usr/local/bin/tavily-mcp-ssm",
      args: [],
      timeout: $tavily_timeout
    },
    snyk: {
      command: "/usr/local/bin/snyk-mcp-ssm",
      args: [],
      timeout: $snyk_timeout
    },
    "databricks-sql": {
      command: "/usr/local/bin/databricks-sql-mcp-ssm",
      args: [],
      timeout: $databricks_sql_timeout
    }
  }) |
  del(.mcpServers.tavily.env) |
  del(.mcpServers.snyk.env) |
  del(.mcpServers["databricks-sql"].env) |
  # If an older/persistent Gemini config has an MCP allow/exclude filter, do
  # not let it accidentally hide an Admin-managed built-in server. Preserve
  # every unrelated entry while adding/removing only the three managed names.
  if ((.mcp.allowed? // null) | type) == "array" then
    .mcp.allowed = ((.mcp.allowed + ["tavily", "snyk", "databricks-sql"]) | unique)
  else . end |
  if ((.mcp.excluded? // null) | type) == "array" then
    .mcp.excluded = (.mcp.excluded | map(select(. != "tavily" and . != "snyk" and . != "databricks-sql")))
  else . end
' "$gemini_settings" > "$tmp"

jq -e . "$tmp" >/dev/null || { echo 'ERROR: generated Gemini settings are invalid JSON' >&2; exit 1; }
mv "$tmp" "$gemini_settings"
trap - EXIT
chmod 0600 "$gemini_settings"

if ! jq -e '
  (.mcpServers.tavily.command == "/usr/local/bin/tavily-mcp-ssm") and
  (.mcpServers.snyk.command == "/usr/local/bin/snyk-mcp-ssm") and
  (.mcpServers["databricks-sql"].command == "/usr/local/bin/databricks-sql-mcp-ssm") and
  (.mcpServers.tavily.env? == null) and
  (.mcpServers.snyk.env? == null) and
  (.mcpServers["databricks-sql"].env? == null)
' "$gemini_settings" >/dev/null; then
  echo 'ERROR: managed Gemini MCP user settings are incomplete or unsafe' >&2
  exit 1
fi

if grep -Eq '(AKIA|ASIA)[A-Z0-9]{16}|AWS_(ACCESS_KEY_ID|SECRET_ACCESS_KEY|SESSION_TOKEN)|DATABRICKS_SQL_MCP_TOKEN|TAVILY_API_KEY|SNYK_TOKEN' "$gemini_settings" "$SYSTEM_GEMINI_SETTINGS"; then
  echo 'ERROR: credential material/reference detected in Gemini MCP settings' >&2
  exit 1
fi

chmod -R go-rwx "$CLAUDE_CONFIG_DIR" "$gemini_config_dir" 2>/dev/null || true
printf '[OK] Gemini managed MCP synchronized: tavily, snyk, databricks-sql (system policy + user compatibility state).\n'
