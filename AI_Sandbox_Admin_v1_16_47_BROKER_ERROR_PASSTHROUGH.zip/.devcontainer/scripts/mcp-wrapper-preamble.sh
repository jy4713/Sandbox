# =============================================================================
# MCP local-execution preamble - AI Secure Sandbox v1.16.47
#
# Every MCP process runs in the devcontainer as the vscode user. This sourced
# fragment is deliberately credential-free: it never points an MCP child at an
# AWS profile and never fetches SSM parameters. Secret injection happens only
# at fixed credential-broker HTTP routes reached through the loopback relay.
# =============================================================================

# MCP servers speak JSON-RPC on stdout. Nothing here may write to stdout.
export SANDBOX_NONINTERACTIVE=1
export PATH="/usr/local/bin:/usr/bin:/bin:/usr/local/sbin:/usr/sbin:/sbin${PATH:+:$PATH}"

# A developer/AI-side MCP process must never inherit a usable AWS credential
# provider, profile path or SSM bootstrap hint.
unset AWS_ACCESS_KEY_ID AWS_SECRET_ACCESS_KEY AWS_SESSION_TOKEN AWS_SECURITY_TOKEN
unset AWS_PROFILE AWS_DEFAULT_PROFILE AWS_CONFIG_FILE AWS_SHARED_CREDENTIALS_FILE
unset AWS_CONTAINER_CREDENTIALS_RELATIVE_URI AWS_CONTAINER_CREDENTIALS_FULL_URI
unset AWS_CONTAINER_AUTHORIZATION_TOKEN AWS_CONTAINER_AUTHORIZATION_TOKEN_FILE
unset AWS_WEB_IDENTITY_TOKEN_FILE AWS_ROLE_ARN AWS_ROLE_SESSION_NAME AWS_CREDENTIAL_EXPIRATION
unset SANDBOX_AWS_HOME SANDBOX_AWS_PROFILE SSM_PREFIX
export AWS_EC2_METADATA_DISABLED=true

# MCP children also drop any caller-injected service credentials. They receive
# only a fixed localhost URL and, where required, a non-secret placeholder.
unset ADO_PAT DATABRICKS_TOKEN DATABRICKS_SQL_MCP_TOKEN
unset ANTHROPIC_API_KEY ANTHROPIC_AUTH_TOKEN GEMINI_API_KEY GOOGLE_API_KEY
unset TAVILY_API_KEY SNYK_TOKEN HIDDENLAYER_CLIENT_ID HIDDENLAYER_CLIENT_SECRET

# The broker is intentionally reached only through the local relay. The child
# gets no broker DNS name and no secret; vendor authentication is injected
# upstream by the credential-only broker.
export SANDBOX_PROVIDER_LOOPBACK_URL="http://127.0.0.1:8771"

# mcp-remote uses ~/.mcp-auth by default. The container root filesystem is
# read-only, so keep its non-SSM runtime state in the existing writable /tmp
# tmpfs. Managed Sandbox MCP routes do not use mcp-remote OAuth credentials;
# this path only prevents vendor-client config/cache permission failures.
export MCP_REMOTE_CONFIG_DIR="/tmp/ai-sandbox-mcp-remote-${UID:-1000}"
mkdir -p "$MCP_REMOTE_CONFIG_DIR" 2>/dev/null || { echo "ERROR: cannot create mcp-remote runtime config directory" >&2; return 1 2>/dev/null || exit 1; }
chmod 0700 "$MCP_REMOTE_CONFIG_DIR" 2>/dev/null || true

# Preserve the managed outbound proxy for vendor clients that need egress. The
# fixed local credential route itself must bypass Squid.
if [[ -z "${HTTPS_PROXY:-}" && -n "${SANDBOX_HTTPS_PROXY:-}" ]]; then
  export HTTPS_PROXY="$SANDBOX_HTTPS_PROXY" HTTP_PROXY="$SANDBOX_HTTPS_PROXY"
  export https_proxy="$SANDBOX_HTTPS_PROXY" http_proxy="$SANDBOX_HTTPS_PROXY"
fi
export NO_PROXY="localhost,127.0.0.1,squid-proxy${NO_PROXY:+,$NO_PROXY}"
export no_proxy="$NO_PROXY"
