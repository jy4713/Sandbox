# AI Secure Sandbox v1.16.47

v1.16.47 is a **narrow broker error-observability update** on top of v1.16.46. Runtime architecture, folder structure, Squid policy/layout, logging/export flow, command routing, credential isolation, application wrappers, and writable state mounts are unchanged.

The credential broker now preserves useful dependency error detail instead of replacing every AWS SSM failure with a generic message. AWS CLI stderr (for example `ParameterNotFound`, `AccessDeniedException`, expired/invalid credentials, or proxy connection errors) is sanitized for credential-like values, logged as broker metadata, and returned to the calling tool with a `[broker:aws-ssm]` source prefix. Non-HTTP upstream connection failures are handled the same way with `[broker:upstream]`. Provider HTTP responses such as Azure DevOps 401/403/404 continue to pass through with their native status/body behavior.

No application command policy is added. Git/native CLI errors remain native errors; Tavily Admin allowed-domain enforcement remains the only application-level policy exception. The broker still performs only SSM credential retrieval and fixed-route credential injection and still has no workspace mount or application-command execution path.

## 1. Security model

```text
Windows 365 host
  Developer -> host AWS profile (static test pair or Azure/Entra browser/SAML)
                         |
                         | read-only .aws mount
                         v
                  secret-broker
                  - SSM GetParameter only
                  - inject auth only at fixed HTTP routes
                  - no workspace mount
                  - no Git/Snyk/Tavily/Databricks/AI/MCP child process
                         ^
                         | credential-free HTTP through internal relay
                         |
              AI Dev Container (uid/gid 1000 vscode)
                  - Claude / Gemini
                  - ucode Claude / Gemini
                  - Git / Snyk / Tavily / Databricks CLI
                  - Tavily / Snyk / Databricks SQL MCP
                  - workspace filesystem I/O
                  - no .aws, no raw PAT/API key, no SSM credential
```

The broker and Dev Container use the same hardened runtime image but have different runtime roles and mounts. Only `secret-broker` receives the host `.aws` directory; only `devcontainer` receives the workspace bind mount. The broker therefore cannot create, chmod, chown, scan, or otherwise modify source files. The Dev Container has no Docker socket, no privileged capabilities, a read-only root filesystem, and no AWS credential mount.

## 2. AWS login information required from the federation administrator

The Developer package uses the following non-secret host/runtime values in its deployment-local `.env`. The Azure fields are required only when SAML is selected or AUTO cannot find a static host key pair:

```ini
SANDBOX_AWS_PROFILE=sandbox
AWS_REGION=eu-west-2
AWS_AUTH_MODE=auto

AZURE_TENANT_ID=<tenant-id>
AZURE_APP_ID_URI=<enterprise-application-id-uri>
AZURE_DEFAULT_USERNAME=<developer-email>
AZURE_DEFAULT_ROLE_ARN=arn:aws:iam::<12-digit-account-id>:role/<role-name>
AZURE_DEFAULT_DURATION_HOURS=1
AZURE_DEFAULT_REMEMBER_ME=true
```

These correspond to the `aws-azure-login` profile fields:

```ini
azure_tenant_id=...
azure_app_id_uri=...
azure_default_username=...
azure_default_role_arn=...
azure_default_duration_hours=1
azure_default_remember_me=true
```

Do not put `AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY`, `AWS_SESSION_TOKEN`, or native `AWS_SSO_*` values in `.env`. v1.16.44 rejects them. For static-key testing, configure the host profile instead with `aws configure --profile sandbox`; AUTO mode detects that pair without exposing it to the AI DevContainer.

When SAML is selected, the Windows launchers create/update the named profile in host `~/.aws/config` and invoke the Azure/Entra browser authentication flow. When a static host key pair is selected, the browser flow is skipped. No separate STS preflight is required; the first SSM/ECR operation validates the AWS permissions actually needed by the package:

```powershell
aws-azure-login --profile sandbox --mode gui
```

If the normal GUI path fails once on Windows 365, the launcher retries with `--disable-gpu`.

## 3. Windows 365 prerequisites

Developer host prerequisites:

- Docker Desktop / approved Docker runtime
- VS Code with Dev Containers extension
- AWS CLI v2
- Node.js/npm only if SAML mode requires installation of the approved `aws-azure-login` client
- `aws-azure-login` on `PATH` only for SAML/AUTO fallback
- Browser access to the corporate Azure/Entra authentication flow only for SAML/AUTO fallback

Example installation of `aws-azure-login` when permitted by the client software policy:

```powershell
npm install -g aws-azure-login
aws-azure-login --version
```

The AI CLIs remain inside the container; installing Claude Code or Gemini CLI on the Windows host is not required.

## 4. SSM secrets

Runtime secrets remain in AWS SSM Parameter Store. The Admin bootstrap creates the approved parameter names, including:

| Parameter | Type | Consumer |
|---|---|---|
| `/sandbox/claude-api-key` | SecureString | provider broker only |
| `/sandbox/gemini-api-key` | SecureString | provider broker only |
| `/sandbox/databricks-token` | SecureString | credential broker HTTP routes used by local ucode/Databricks CLI |
| `/sandbox/databricks-sql-mcp-token` | SecureString | credential broker route used by local Databricks SQL MCP |
| `/sandbox/ado-pat` | SecureString | credential broker route used by local Git/ADO helpers |
| `/sandbox/tavily-api-key` | SecureString | credential broker route used by local Tavily CLI/MCP |
| `/sandbox/snyk-token` | SecureString | credential broker route used by local Snyk CLI/MCP |
| `/sandbox/hiddenlayer-client-id` | SecureString | reserved; requires a reviewed credential-only HiddenLayer HTTP adapter |
| `/sandbox/hiddenlayer-client-secret` | SecureString | reserved; requires a reviewed credential-only HiddenLayer HTTP adapter |

The old command-running paths are retained only as fail-closed compatibility guards. `run-with-ssm-secrets` and `secret-broker-client` return exit code 126 in **every** role. New integrations must never re-enable a generic command-with-secret runner; they must keep the real executable in the Dev Container and add a reviewed fixed credential-injection HTTP adapter when a secret is required.

## 5. AI and tool routing

### Direct Claude

```text
claude -> 127.0.0.1 loopback relay -> secret-broker -> SSM claude-api-key -> api.anthropic.com
```

Claude sees only a fixed non-secret placeholder credential. The broker discards client authentication and inserts the real key for the upstream request.

### Direct Gemini

```text
gemini -> 127.0.0.1 loopback relay -> secret-broker -> SSM gemini-api-key -> Google Gemini API
```

Gemini also receives only a fixed placeholder. The real key exists only in broker memory while the request is made.

### Databricks coding-agent route

The existing Developer command contract is preserved:

```bash
ucode claude
ucode gemini
```

For credential isolation, v1.16.44 does **not** use upstream ucode's PAT-injection runtime path. The public `ucode` wrapper launches the approved Claude/Gemini binary against a brokered Databricks AI Gateway route:

```text
ucode claude -> local relay -> broker -> SSM databricks-token -> <DATABRICKS_HOST>/ai-gateway/anthropic
ucode gemini -> local relay -> broker -> SSM databricks-token -> <DATABRICKS_HOST>/ai-gateway/gemini
```

The Databricks PAT is never placed in the AI agent environment or user configuration. `DATABRICKS_CLAUDE_MODEL` and `DATABRICKS_GEMINI_MODEL` select the approved models.

### MCP and CLI integrations

**v1.16.44 managed MCP consistency:** the three built-in **local MCP launchers** (`tavily`, `snyk`, `databricks-sql`) are Admin-managed for both Claude and Gemini. Claude uses the root-owned managed MCP policy; Gemini uses the root-owned `/etc/gemini-cli/settings.json` policy and refreshes the persistent user settings on every Gemini launch. This prevents an older `~/.gemini` volume or a different `GEMINI_CLI_HOME` from hiding a built-in MCP. No service secret is stored in either client configuration.

The four supported shell-level checks should expose the same built-in MCP set:

```bash
claude mcp list
gemini mcp list
ucode claude mcp list
ucode gemini mcp list
```

`ucode ... mcp ...` is treated as a local client-control operation and does not require or inject a Databricks model. During an interactive `ucode gemini` session, `/mcp list` uses the same managed Gemini policy. A registered server can still report disconnected if its approved endpoint, SSM parameter, or network dependency is unavailable.

- Tavily CLI and Tavily MCP processes run locally; Admin domain policy is enforced locally and again in the credential broker before the broker injects the SSM Tavily key upstream.
- Snyk CLI and Snyk MCP processes run locally and read the Developer workspace directly; their API traffic uses a fixed localhost route where the broker injects the SSM Snyk token.
- Databricks SQL MCP and approved Databricks CLI processes run locally; the broker injects only the appropriate SSM token into their fixed Databricks HTTP route.
- Normal `git clone/fetch/pull/push/ls-remote` and credentialed `git remote/submodule/archive` operations execute `/usr/bin/git` locally. For validated `dev.azure.com` traffic, a root-owned policy rewrites only the HTTP transport to the localhost credential route; the broker injects the SSM ADO PAT upstream.
- ADO PR/pipeline helper processes and `curl` run locally and use fixed localhost ADO routes. The helpers require explicit target identifiers; these are not stored in SSM.

The broker has no application command protocol and no workspace mount. Its only subprocess is the internal AWS CLI call used to read an approved SSM parameter; it never starts a Developer or vendor application process.


### Normal Git commands with brokered ADO authentication

Use normal Git syntax. Do **not** prefix commands with `ado-git`:

```bash
git clone --branch feature/todo-app-scaffold --single-branch \
  "https://dev.azure.com/ORG/PROJECT/_git/REPO"
cd REPO
git status
git add .
git commit -m "Update"
git pull
git fetch --prune
git push -u origin feature/todo-app-scaffold
```

All Git commands, including ADO `clone`, `fetch`, `pull`, and `push`, execute as the `vscode` user through the local `/usr/bin/git` binary in the Dev Container. For credentialed ADO operations, `/usr/local/bin/git` invokes a root-owned validation policy locally; that policy keeps the stored remote as normal `https://dev.azure.com/...` but applies an execution-time `url.<localhost>/insteadOf` rewrite so only Git's HTTP traffic crosses the credential broker. The Git process never receives `ADO_PAT`, `GIT_ASKPASS`, an AWS profile, or an SSM credential. The legacy `ado-git` command is only a local compatibility alias to the same validation policy. Standard Git push semantics—including direct pushes to `main`/`master`, `--force`, `--force-with-lease`, `--delete`, `--all`, `--mirror`, `--prune`, and force/delete refspecs—are not restricted by the Sandbox; Azure DevOps repository permissions and branch policies are the authoritative governance layer. Credential/configuration overrides, non-HTTPS/custom transports and credential-redirection overrides remain blocked. Repository/project authorization is delegated to the ADO PAT and Azure DevOps permissions; the Sandbox no longer pins org/project/repo metadata.

## 6. Developer TAR flow

1. Extract the Developer TAR package.
2. If Windows marks downloaded PowerShell files as blocked, use the documented Process-scope execution-policy/unblock commands.
3. Copy `.env.example` to `.env` if the launcher has not already done so.
4. Fill the Azure/Entra SAML fields and other non-secret runtime values.
5. Run:

```powershell
.\scripts\tar\load-and-start.ps1
```

The launcher validates package hashes, configures the host AWS profile, opens browser login if needed, and starts `squid-proxy`, `secret-broker`, and `devcontainer`.

## 7. Developer ECR flow

Fill the same host authentication fields plus the approved ECR registry value, then run:

```powershell
.\scripts\ecr\pull-and-start.ps1
```

The host session is used to read the centrally approved image manifest and pull immutable image digests. The AWS profile is not copied into the AI container.

## 8. Verification inside the Dev Container

Run:

```bash
verify-runtime
```

Important expected results:

```text
[OK] running as UID 1000
[OK] devcontainer writes remain vscode-owned, including local Git directories
[OK] container role is AI client
[OK] no AWS bootstrap credential environment variables
[OK] no AWS profile/config path variables in AI environment
[OK] no AWS credential file in AI container
[OK] no AWS SSO token cache in AI container
[OK] no application/service secrets in parent environment
[OK] retired SSM command runner refuses every invocation
[OK] credential broker health endpoint is reachable through localhost relay
[OK] broker server has no application subprocess launcher
[OK] Snyk CLI executes locally with local filesystem access and localhost API route
[OK] transparent Git executes /usr/bin/git locally and uses ADO URL rewrite policy
[OK] AWS SSM direct read is not credentialed
```

Additional safe checks:

```bash
env | grep -E 'AWS_(ACCESS_KEY|SECRET|SESSION)|TAVILY_API_KEY|SNYK_TOKEN|DATABRICKS_TOKEN|ADO_PAT'
ls -la ~/.aws 2>/dev/null || true
aws ssm get-parameter --name /sandbox/tavily-api-key --with-decryption --region eu-west-2
```

The first two must not reveal credentials. The direct SSM command must fail because the AI container has no AWS credential source.

## 9. What the Developer can and cannot see

The Developer controls the Windows host and can therefore inspect their own host-side AWS profile, whether it contains a static test key pair or temporary SAML credentials. This POC does not claim to hide the Developer's own AWS credentials from the Developer.

However, application PATs/API keys are not written to `.env`, workspace files, or AI-agent configuration. They stay in SSM and are fetched by the trusted broker. To prevent the Developer from directly reading those SSM values as well, use a separate production broker IAM identity and remove `ssm:GetParameter`/KMS decrypt from the Developer SSO role.

## 10. Important production boundary

The v1.16.44 broker prevents AI processes in the Dev Container from obtaining AWS/SSM credentials or raw service secrets. If the Developer is also considered hostile and retains full Docker Desktop administrator control on the same Windows host, a local sibling container is not a complete security boundary against the host administrator. Production should move the broker to an Admin-controlled service/host or otherwise enforce the Docker runtime outside Developer control.

## 11. Main Admin validation

```bash
scripts/ci/lint-package.sh
```

The lint checks architecture invariants rather than a version-specific file list: only the broker receives `.aws`, only the Dev Container receives the workspace, the broker has no application-process launcher, retired command runners fail closed, Git/Snyk/Tavily/Databricks/Claude/Gemini/ucode/MCP use local real executables, managed MCP definitions are credential-free, and source/policy regression checks pass.
